// Use separate CAPTCHA proofs for OTP requests.
(function ($) {
    'use strict';

    var pending = false;
    var sequence = 0;
    var proofFields = ['g-recaptcha-response', 'h-captcha-response', 'cf-turnstile-response',
        'digits_reg_logincaptcha', 'dig_captcha_ses', 'captcha', 'captcha_ses'];

    window.digitsOtpCaptchaAjax = function (options) {
        var config = window.dig_otp_captcha || {};
        var deferred = $.Deferred();
        var transport, dialog, timer, poll, widget, widgetId, provider;
        var done = false;
        var sending = false;
        var restoreFocus = false;
        var generation = 0;
        var previousFocus = document.activeElement;
        var context = options.context || options;
        var requestData = $.extend({}, options.data);
        var eventName = '.digitsOtpCaptcha' + (++sequence);

        function label(key, fallback) { return config[key] || fallback; }
        function callback(name, args) {
            if (typeof options[name] === 'function') { options[name].apply(context, args); }
        }
        function removeDialog() {
            generation++;
            clearTimeout(timer);
            clearTimeout(poll);
            $(document).off(eventName);
            if (widgetId !== undefined && widget) {
                try {
                    if (provider === 'recaptcha' && !sending && widget.reset) {
                        widget.reset(widgetId);
                    } else if (provider !== 'recaptcha' && widget.remove) {
                        widget.remove(widgetId);
                    }
                } catch (ignore) {}
            }
            widgetId = undefined;
            widget = null;
            if (dialog) { dialog.remove(); dialog = null; }
        }
        function finish() {
            removeDialog();
            pending = false;
            if (restoreFocus && previousFocus && document.documentElement.contains(previousFocus)) {
                try { previousFocus.focus(); } catch (ignore) {}
            }
        }
        function fail(xhr, status, message) {
            if (done) { return; }
            done = true;
            finish();
            if (status === 'captcha' && typeof window.showDigErrorMessage === 'function') {
                window.showDigErrorMessage(message || label('error', 'Could not verify captcha. Please try again.'));
            }
            callback('error', [xhr || {status: 0}, status, message]);
            callback('complete', [xhr || {status: 0}, status]);
            deferred.reject(xhr, status, message);
        }
        function abort() {
            if (done) { return; }
            // Settle before abort triggers transport callbacks.
            fail(transport, 'abort', 'abort');
            if (transport && transport.abort) { transport.abort(); }
        }
        var result = deferred.promise();
        result.abort = abort;

        if (pending) {
            done = true;
            callback('error', [{status: 0}, 'busy', 'busy']);
            callback('complete', [{status: 0}, 'busy']);
            deferred.reject({status: 0}, 'busy', 'busy');
            return result;
        }
        pending = true;

        function send(proof) {
            if (done || sending) { return; }
            sending = true;
            removeDialog();
            if (proof) {
                $.each(proofFields, function (_, field) { delete requestData[field]; });
                $.extend(requestData, proof);
            }
            var settings = $.extend({}, options, {data: requestData});
            delete settings.beforeCaptcha;
            delete settings.success;
            delete settings.error;
            delete settings.complete;
            try {
                transport = $.ajax(settings);
                transport.done(function (data, status, xhr) {
                    if (done) { return; }
                    done = true;
                    finish();
                    callback('success', [data, status, xhr]);
                    callback('complete', [xhr, status]);
                    deferred.resolve(data, status, xhr);
                }).fail(function (xhr, status, error) { fail(xhr, status, error); });
            } catch (error) {
                fail({status: 0}, 'error', error);
            }
        }

        function challenge(data) {
            var currentGeneration = generation;
            callback('beforeCaptcha', []);
            var content = $('<div></div>').html(data.html || '');
            content.find('script').remove();
            var originalWidget = content.find('.g-recaptcha,.invi-recaptcha,.dig-hcaptcha,.cf-turnstile').first();
            var sitekey = data.sitekey || originalWidget.attr('data-sitekey');
            var size = data.size || originalWidget.attr('data-size') || 'normal';
            provider = data.provider;
            var automatic = Number(data.captcha_type) === 2 &&
                ((provider === 'recaptcha' && data.provider_type === 'v3') ||
                    ((provider === 'recaptcha' || provider === 'hcaptcha') && data.provider_type === 'invisible'));
            var form = $(), message = $(), area, cancel;

            if (automatic) {
                dialog = $('<div class="digits-otp-captcha-background"></div>').appendTo(document.body);
                area = dialog;
            } else {
                restoreFocus = true;
                dialog = $('<div class="digits-otp-captcha-overlay"></div>').css({
                    position: 'fixed', inset: 0, zIndex: 1000000, background: 'rgba(0,0,0,.45)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '16px', boxSizing: 'border-box'
                });
                var panel = $('<div role="dialog" aria-modal="true"></div>').css({
                    background: '#fff', color: '#222', borderRadius: '8px', padding: '16px',
                    width: '360px', maxWidth: '100%', maxHeight: '90vh', overflow: 'auto', boxSizing: 'border-box'
                }).attr('aria-labelledby', 'digits-otp-captcha-title-' + sequence).appendTo(dialog);
                $('<h3></h3>').attr('id', 'digits-otp-captcha-title-' + sequence)
                    .text(label('title', 'Verify you are human')).appendTo(panel);
                form = $('<form class="digits-otp-captcha-form"></form>').appendTo(panel);
                area = $('<div class="digits-otp-captcha-content"></div>').appendTo(form);
                message = $('<p role="status"></p>').text(label('loading', 'Loading...')).appendTo(form);
                cancel = $('<button type="button" class="digits-otp-captcha-cancel"></button>')
                    .text(label('cancel', 'Cancel')).appendTo(form).on('click', abort);
                dialog.appendTo(document.body);
                cancel.trigger('focus');
            }
            $(document).on('keydown' + eventName, function (event) {
                if (event.key === 'Escape') { event.preventDefault(); abort(); }
                if (!automatic && event.key === 'Tab' && dialog && $.contains(dialog[0], document.activeElement)) {
                    var controls = dialog.find('button,input,textarea,select,iframe,[tabindex]')
                        .filter(function () {
                            return !this.disabled && !this.hidden && this.tabIndex !== -1 &&
                                $(this).css('display') !== 'none' && $(this).css('visibility') !== 'hidden';
                        });
                    var first = controls[0], last = controls[controls.length - 1];
                    if (event.shiftKey && document.activeElement === first) {
                        event.preventDefault(); if (last) { last.focus(); }
                    } else if (!event.shiftKey && document.activeElement === last) {
                        event.preventDefault(); if (first) { first.focus(); }
                    }
                }
            });
            timer = setTimeout(function () {
                fail(null, 'captcha', label('error', 'Could not verify captcha. Please try again.'));
            }, 180000);

            if (Number(data.captcha_type) === 1) {
                content.find('.dig_captcha').removeClass('dig_captcha');
                area.append(content.contents());
                message.text('');
                $('<button type="submit"></button>').text(label('continue', 'Continue')).insertBefore(cancel);
                $('<button type="button"></button>').text(label('refresh', 'Refresh captcha')).insertBefore(cancel)
                    .on('click', function () { removeDialog(); preflight(); });
                form.on('submit', function (event) {
                    event.preventDefault();
                    var code = form.find('[name="digits_reg_logincaptcha"]').val();
                    var session = form.find('[name="dig_captcha_ses"]').val();
                    if (!code || !session) { message.text(label('error', 'Please verify captcha.')); return; }
                    send({digits_reg_logincaptcha: code, dig_captcha_ses: session});
                });
                form.find('[name="digits_reg_logincaptcha"]').trigger('focus');
                return;
            }
            form.on('submit', function (event) { event.preventDefault(); });
            // Avoid the existing form widget scanners.
            var host = $('<div class="digits-otp-captcha-widget"></div>')
                .attr('id', 'digits-otp-captcha-widget-' + sequence).appendTo(area);
            function solved(token) {
                if (!token || done || sending || currentGeneration !== generation) { return; }
                var field = provider === 'turnstile' ? 'cf-turnstile-response' :
                    provider === 'hcaptcha' ? 'h-captcha-response' : 'g-recaptcha-response';
                var proof = {}; proof[field] = token; send(proof);
            }
            function providerError() {
                if (done || sending || currentGeneration !== generation) { return; }
                fail(null, 'captcha', label('error', 'Could not verify captcha. Please try again.'));
            }
            function render() {
                if (done || !dialog) { return; }
                widget = provider === 'turnstile' ? window.turnstile :
                    provider === 'hcaptcha' ? window.hcaptcha : window.grecaptcha;
                var isV3 = provider === 'recaptcha' && data.provider_type === 'v3';
                if (!widget || (isV3 ? !widget.ready || !widget.execute : !widget.render)) { return false; }
                message.text('');
                try {
                    if (!sitekey) { providerError(); return true; }
                    if (isV3) {
                        widget.ready(function () {
                            if (!done && !sending && currentGeneration === generation) {
                                try { widget.execute(sitekey, {action: 'digits_otp'}).then(solved, providerError); }
                                catch (error) { providerError(); }
                            }
                        });
                    } else {
                        var parameters = {
                            sitekey: sitekey, size: size, callback: solved,
                            'error-callback': providerError, 'expired-callback': providerError
                        };
                        if (provider === 'recaptcha') { parameters.isolated = true; }
                        if (provider === 'hcaptcha') {
                            parameters['close-callback'] = function () {
                                if (!done && !sending && currentGeneration === generation) { abort(); }
                            };
                            parameters['chalexpired-callback'] = providerError;
                        }
                        if (size !== 'invisible' && window.innerWidth < 380) { parameters.size = 'compact'; }
                        widgetId = widget.render(host[0], parameters);
                        if (!done && !sending && data.provider_type === 'invisible') { widget.execute(widgetId); }
                    }
                } catch (error) { providerError(); }
                return true;
            }
            if (render()) { return; }
            function providerUrl(value) {
                var url;
                try { url = new URL(value); } catch (error) { return null; }
                if (url.protocol !== 'https:' || url.username || url.password || url.port) { return null; }
                var valid = provider === 'turnstile' ?
                    url.hostname === 'challenges.cloudflare.com' && url.pathname === '/turnstile/v0/api.js' :
                    provider === 'hcaptcha' ? url.hostname === 'js.hcaptcha.com' && url.pathname === '/1/api.js' :
                    ['www.recaptcha.net', 'recaptcha.net', 'www.google.com', 'google.com'].indexOf(url.hostname) !== -1 &&
                        url.pathname === '/recaptcha/api.js';
                return valid ? url : null;
            }
            var existing = $('script[src]').filter(function () { return !!providerUrl(this.src); }).length;
            if (!existing) {
                var url = providerUrl(data.script_url);
                if (!url) { providerError(); return; }
                var script = document.createElement('script');
                script.async = true;
                script.src = url.href;
                script.onerror = function () {
                    if (script.parentNode) { script.parentNode.removeChild(script); }
                    providerError();
                };
                document.head.appendChild(script);
            }
            var attempts = 0;
            function waitForApi() {
                if (done || sending || !dialog || currentGeneration !== generation) { return; }
                if (render()) { return; }
                if (++attempts >= 150) {
                    if (script && script.parentNode) { script.parentNode.removeChild(script); }
                    providerError(); return;
                }
                poll = setTimeout(waitForApi, 100);
            }
            waitForApi();
        }

        function preflight() {
            if (done) { return; }
            try {
                transport = $.ajax({
                    type: 'POST', url: config.ajax_url || options.url, dataType: 'json', timeout: 15000,
                    data: {action: 'digits_get_otp_captcha', csrf: requestData.csrf, login: requestData.login}
                });
            } catch (error) {
                fail(null, 'captcha', label('error', 'Could not verify captcha. Please try again.'));
                return;
            }
            transport.done(function (response) {
                if (done) { return; }
                if (!response || response.success !== true || !response.data) {
                    fail(null, 'captcha', response && response.data && response.data.message);
                    return;
                }
                var data = response.data;
                if (data.required === false) { send(null); }
                else if (data.required === true && (Number(data.captcha_type) === 1 || Number(data.captcha_type) === 2)) {
                    challenge(data);
                } else { fail(null, 'captcha', label('error', 'Could not verify captcha. Please try again.')); }
            }).fail(function (xhr) {
                fail(xhr, 'captcha', xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message);
            });
        }
        preflight();
        return result;
    };
})(jQuery);
