<?php

if (!defined('ABSPATH')) {
    exit;
}

add_action('digits_create_database', 'digits_create_req_logs_db');

function digits_create_req_logs_db()
{
    global $wpdb;


    $tb = $wpdb->prefix . 'digits_request_logs';
    if ($wpdb->get_var("SHOW TABLES LIKE '$tb'") != $tb) {
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE $tb (
                  request_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
		          phone VARCHAR(40) NOT NULL,
		          email VARCHAR(100) NOT NULL,
		          mode VARCHAR(100) NOT NULL,
		          request_type VARCHAR(100) NOT NULL,
		          user_agent VARCHAR(255) NULL,
		          ip VARCHAR(200) NOT NULL,
		          time datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
		          PRIMARY KEY  (request_id),
		          INDEX idx_phone (phone),
		          INDEX idx_email (email),
                   INDEX idx_ip (ip)
	            ) $charset_collate;";
        dbDelta(array($sql));
    }

    $query = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE table_schema = DATABASE() AND table_name = %s AND column_name = %s";
    $query = $wpdb->prepare($query, $tb, 'gateway_id');
    $row = $wpdb->get_results($query);
    if (empty($row)) {
        $wpdb->query("ALTER TABLE $tb ADD message TEXT NULL,ADD gateway_id VARCHAR(255) NULL,ADD sub_gateway VARCHAR(255) NULL");
    }
}

function digits_add_request_log($phone, $mode, $request_type, $message, $gateway)
{
    global $wpdb;
    $table = $wpdb->prefix . 'digits_request_logs';
    $data = array('phone' => '', 'email' => '');
    $data['time'] = gmdate('Y-m-d H:i:s');
    $data['ip'] = digits_get_ip();
    if (is_numeric($phone)) {
        $data['phone'] = $phone;
    } else {
        $data['email'] = $phone;
    }
    $data['mode'] = $mode;

    $data['request_type'] = $request_type;
    $data['message'] = $message;
    $data['sub_gateway'] = 0;
    $data['gateway_id'] = $gateway;

    $data['user_agent'] = isset($_SERVER['HTTP_USER_AGENT']) ? substr(sanitize_text_field($_SERVER['HTTP_USER_AGENT']), 0, 255) : '';

    return $wpdb->insert($table, $data);
}


function digits_check_request($phone, $email)
{
    global $wpdb;
    $phone = is_scalar($phone) ? sanitize_mobile_field_dig((string) $phone) : '';
    $email = is_scalar($email) ? strtolower(trim((string) $email)) : '';
    $ip = digits_get_ip();
    if ($ip === 'unknown') {
        return new WP_Error('invalid_client_ip', __('Unable to verify your connection. Please try again or contact site support.', 'digits'));
    }
    $locks = array();
    $identities = array('site-send-quota');
    try {
        foreach ($identities as $identity) {
            $lock = digits_security_lock('send:' . $identity);
            if (!$lock) {
                return new WP_Error('limit_unavailable', __('Please try again after some time.', 'digits'));
            }
            $locks[] = $lock;
        }
        $limits = array(
            array('duration_type' => 'day', 'duration' => 1, 'max' => 36, 'type' => 'phone'),
            array('duration_type' => 'minute', 'duration' => 10, 'max' => 20, 'type' => 'phone'),
            array('duration_type' => 'day', 'duration' => 1, 'max' => 36, 'type' => 'email'),
            array('duration_type' => 'minute', 'duration' => 10, 'max' => 20, 'type' => 'email'),
            array('duration_type' => 'minute', 'duration' => 10, 'max' => 24, 'type' => 'ip'),
            array('duration_type' => 'hour', 'duration' => 1, 'max' => 60, 'type' => 'ip'),
            array('duration_type' => 'hour', 'duration' => 2, 'max' => 120, 'type' => 'ip'),
            array('duration_type' => 'day', 'duration' => 1, 'max' => 200, 'type' => 'ip'),
            array('duration_type' => 'day', 'duration' => 15, 'max' => 800, 'type' => 'ip'),
        );
        $allowed = (array) get_option('dig_brute_force_allowed_ip', array());
        if (get_option('digits_brute_force_protection', 1) == 0 || in_array($ip, $allowed, true)) {
            $limits = array(
                array('duration_type' => 'hour', 'duration' => 1, 'max' => 100, 'type' => 'phone'),
                array('duration_type' => 'hour', 'duration' => 1, 'max' => 100, 'type' => 'email'),
                array('duration_type' => 'hour', 'duration' => 1, 'max' => 1000, 'type' => 'ip'),
            );
        }
        $limits = apply_filters('digits_rate_limits', $limits);
        foreach ($limits as $limit) {
            $values = array('phone' => $phone, 'email' => $email, 'ip' => $ip);
            if (!isset($limit['type'], $limit['duration'], $limit['duration_type'], $limit['max'])
                || !isset($values[$limit['type']])) {
                continue;
            }
            $value = $values[$limit['type']];
            if ($value === '') continue;
            $count = digits_count_req_in_time($limit['type'], $value, $limit['duration'], $limit['duration_type']);
            if (is_wp_error($count)) return $count;
            if ($count >= (int) $limit['max']) {
                return new WP_Error('limit_exceed', __('OTP limit has exceeded since you made too many attempts, Please try again after some time!', 'digits'));
            }
        }
        $reserved = $wpdb->insert($wpdb->prefix . 'digits_request_logs', array(
            'phone' => $phone, 'email' => $email, 'ip' => $ip,
            'mode' => 'quota', 'request_type' => 'quota',
            'time' => gmdate('Y-m-d H:i:s'), 'user_agent' => '',
        ));
        if (!$reserved) {
            return new WP_Error('limit_unavailable', __('Please try again after some time.', 'digits'));
        }
        return true;
    } finally {
        foreach (array_reverse($locks) as $lock) digits_security_unlock($lock);
    }
}

function digits_count_req_in_time($key, $value, $duration, $duration_type, $count = true)
{
    global $wpdb;
    $units = array('minute' => 60, 'hour' => 3600, 'day' => 86400);
    if (!in_array($key, array('phone', 'email', 'ip'), true) || !isset($units[$duration_type]) || absint($duration) < 1) {
        return new WP_Error('invalid_limit', __('Please try again after some time.', 'digits'));
    }
    $cutoff = gmdate('Y-m-d H:i:s', time() - absint($duration) * $units[$duration_type]);
    $select = $count ? 'COUNT(*)' : '*';
    $order = $count ? '' : ' ORDER BY time DESC';
    $query = $wpdb->prepare("SELECT $select FROM {$wpdb->prefix}digits_request_logs WHERE $key = %s AND time >= %s AND mode = 'quota'$order", $value, $cutoff);
    $results = $count ? $wpdb->get_var($query) : $wpdb->get_results($query);
    if ($results === null || !empty($wpdb->last_error)) {
        return new WP_Error('limit_unavailable', __('Please try again after some time.', 'digits'));
    }
    return $count ? (int) $results : $results;
}
