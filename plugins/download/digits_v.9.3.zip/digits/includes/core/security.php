<?php

defined('ABSPATH') || exit;

function digits_security_lock($scope, $timeout = 5)
{
    global $wpdb;
    $name = 'digits_' . substr(hash('sha256', $wpdb->prefix . $scope), 0, 48);
    if ((int) $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, %d)', $name, max(0, (int) $timeout))) !== 1) {
        return false;
    }
    return $name;
}

function digits_security_unlock($name)
{
    if ($name) {
        global $wpdb;
        $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $name));
    }
}

function digits_security_password_check($user, $password)
{
    if (!$user instanceof WP_User || !is_string($password) || $password === '') {
        return new WP_Error('invalid_password', __('Please enter your current password.', 'digits'));
    }
    $details = array('user_id' => $user->ID, 'login_type' => 'reauthentication');
    $blocked = DigitsBruteForceProtection::is_user_blocked($details);
    if (is_wp_error($blocked)) {
        return $blocked;
    }
    if (!wp_check_password($password, $user->user_pass, $user->ID)) {
        try {
            DigitsBruteForceProtection::add_invalid_otp_attempt($details);
        } catch (Exception $e) {
            return new WP_Error('invalid_password', $e->getMessage());
        }
        return new WP_Error('invalid_password', __('Your current password is incorrect.', 'digits'));
    }
    return true;
}

function digits_security_require_recent_auth()
{
    $user_id = get_current_user_id();
    $token = wp_get_session_token();
    if (!$user_id || !$token) {
        return new WP_Error('reauthentication_required', __('Please sign in again to change your account security.', 'digits'));
    }
    $session = WP_Session_Tokens::get_instance($user_id)->get($token);
    if (empty($session['login']) || time() - (int) $session['login'] > 300) {
        return new WP_Error('reauthentication_required', __('Please sign in again to change your account security.', 'digits'));
    }
    return true;
}

function digits_security_has_additional_factors($user_id)
{
    return \DigitsUserFormHandler\UserSettingsHandler::isUserFaEnabled($user_id, 2)
        || \DigitsUserFormHandler\UserSettingsHandler::isUserFaEnabled($user_id, 3);
}

function digits_security_check_legacy_login($user, $method)
{
    if (!$user instanceof WP_User) {
        return new WP_Error('invalid_user', __('Please sign in using the login form.', 'digits'));
    }
    $validation = apply_filters('digits_check_user_login', new WP_Error(), $user);
    if ($validation->has_errors()) {
        return $validation;
    }
    $methods = \DigitsUserFormHandler\UserSettingsHandler::get_user_methods($user, 1);
    if (digits_security_has_additional_factors($user->ID) || !in_array($method, $methods, true)) {
        return new WP_Error('additional_authentication_required', __('Please sign in using the login form to complete your account verification.', 'digits'));
    }
    return true;
}

function digits_security_schema()
{
    if (get_option('digits_security_schema_version') === '1'
        || get_transient('digits_security_schema_retry')) {
        return;
    }
    $lock = digits_security_lock('security_schema', 0);
    if (!$lock) {
        return;
    }
    try {
        if (get_option('digits_security_schema_version') === '1'
            || get_transient('digits_security_schema_retry')) {
            return;
        }
        set_transient('digits_security_schema_retry', 1, HOUR_IN_SECONDS);
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        DigitsBruteForceProtection::get_instance()->create_database();
        global $wpdb;
        if ($wpdb->last_error) {
            return;
        }
        digits_create_req_logs_db();
        if ($wpdb->last_error) {
            return;
        }
        $failed = $wpdb->prefix . DigitsBruteForceProtection::TABLE_NAME;
        $requests = $wpdb->prefix . 'digits_request_logs';
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($failed))) === $failed
            && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($requests))) === $requests) {
            update_option('digits_security_schema_version', '1', true);
            delete_transient('digits_security_schema_retry');
        }
    } finally {
        digits_security_unlock($lock);
    }
}
add_action('digits_activation_hooks', 'digits_security_schema', 20);

function digits_security_maybe_upgrade_schema()
{
    if (wp_doing_ajax() || !current_user_can('manage_options')) {
        return;
    }
    digits_security_schema();
}
add_action('admin_init', 'digits_security_maybe_upgrade_schema');

function digits_security_cleanup()
{
    global $wpdb;
    $cutoff = gmdate('Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS);
    $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->prefix}digits_failed_login_logs WHERE attempt_time < %s AND (locked_until IS NULL OR locked_until < %s)", $cutoff, gmdate('Y-m-d H:i:s')));
    $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->prefix}digits_request_logs WHERE time < %s", $cutoff));
}
add_action('digits_cron', 'digits_security_cleanup');

function digits_security_otp_size($value)
{
    return max(6, min(10, (int) $value));
}
add_filter('option_dig_otp_size', 'digits_security_otp_size');

function digits_security_token_error($message)
{
    return digits_security_verification_failure(array('login_type' => 'token'), $message);
}

function digits_security_verification_failure($details, $message)
{
    try {
        DigitsBruteForceProtection::add_invalid_otp_attempt($details);
    } catch (Exception $e) {
        return new WP_Error('invalid_verification', $e->getMessage());
    }
    return new WP_Error('invalid_verification', $message);
}

function digits_security_claim_otp($scope, $id, $validity)
{
    $key = 'digits_otp_claim_' . hash('sha256', $scope . ':' . $id);
    $lock = digits_security_lock($key);
    if (!$lock) return false;
    try {
        $token = DigitsSessions::get_token();
        if (!$token) return false;
        $owner = hash_hmac('sha256', $token, wp_salt('auth'));
        $row = DigitsSessions::get_from_identifier($key, true);
        if ($row) {
            return $row->data_key === 'otp_claim' && is_string($row->data_value) && hash_equals($row->data_value, $owner);
        }
        return (bool) DigitsSessions::set_session_value($token, 'otp_claim', $owner, $validity, $key);
    } finally {
        digits_security_unlock($lock);
    }
}
