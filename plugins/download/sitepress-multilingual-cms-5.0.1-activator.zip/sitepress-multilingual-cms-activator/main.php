<?php
/**
 * @wordpress-plugin
 * Plugin Name:       فعال ساز افزونه WPML
 * Plugin URI:        https://wpml.org/
 * Description:       فعال سازی افزونه چند زبانه وردپرس - WPML
 * Version:           5.0.1
 * Requires at least: 5.9.0
 * Requires PHP:      7.2
 * Author:            pluginyab
 * Author URI:        https://pluginyab.ir/
 **/

use OTGS\Installer\Settings;

defined( 'ABSPATH' ) || exit;
$PLUGIN_NAME   = 'WPML Multilingual CMS Activator';
$PLUGIN_DOMAIN = 'sitepress-multilingual-cms-activator';
$site_key      = 'Activated';
$repository_id = 'wpml';
extract( require_once __DIR__ . DIRECTORY_SEPARATOR . 'functions.php' );
if (
	$admin_notice_ignored()
	|| $admin_notice_plugin_install( 'sitepress-multilingual-cms/sitepress.php', null, 'WPML Multilingual CMS', $PLUGIN_NAME, $PLUGIN_DOMAIN )
	|| $admin_notice_plugin_activate( 'sitepress-multilingual-cms/sitepress.php', $PLUGIN_NAME, $PLUGIN_DOMAIN )
) {
	return;
}

if ( ! defined( 'OTGS_INSTALLER_SITE_KEY_' . strtoupper( $repository_id ) ) ) {
	define( 'OTGS_INSTALLER_SITE_KEY_' . strtoupper( $repository_id ), $site_key );
}

$wpml_api_url = function () use ( $repository_id ) {
	$repositories_xml = WP_PLUGIN_DIR . '/sitepress-multilingual-cms/vendor/otgs/installer/repositories.xml';
	$wpml_api_url     = 'https://api.wpml.org/';

	if ( file_exists( $repositories_xml ) ) {
		$xml = simplexml_load_file( $repositories_xml );
		if ( $xml ) {
			foreach ( $xml->repository as $repo ) {
				if ( (string) $repo->id === $repository_id ) {
					$wpml_api_url = (string) $repo->apiurl;
					break;
				}
			}
		}
	}

	return $wpml_api_url;
};

add_action( 'admin_init', function () use ( $wpml_api_url, $site_key, $repository_id ) {
	if ( function_exists( 'icl_set_setting' ) ) {
		icl_set_setting( 'site_key', $site_key, true );
	}
	$settings = Settings::load();

	$settings['repositories'][ $repository_id ]['subscription'] = [
		'key'           => $site_key,
		'key_type'      => \OTGS_Installer_Subscription::SITE_KEY_TYPE_PRODUCTION,
		'data'          => (object) [
			'status'            => \OTGS_Installer_Subscription::SUBSCRIPTION_STATUS_ACTIVE,
			'expires'           => '+100 year',
			'notes'             => 'by WPML',
			'subscription_type' => 6719,
		],
		'registered_by' => get_current_user_id(),
		'site_url'      => get_site_url(),
	];
	Settings::save( $settings );
} );

add_filter( 'pre_http_request', function ( $pre, $parsed_args, $url ) use ( $serialize_response, $wpml_api_url ) {
	if ( str_starts_with( $url, $wpml_api_url() ) ) {
		switch ( $parsed_args['body']['action'] ?? false ) {
			case 'product_bucket_url':
				return $serialize_response( [] );
			case 'site_key_validation':
				$data = [
					'info'                  => [
						'site_key_validation' => 'Site key validation'
					],
					'active_status_updated' => true,
					'success'               => 'Success',
					'site_key'              => [
						'type' => '0'
					],
					'subscription_data'     => (object) [
						'subscription_type' => 6719,
						'expires'           => date( 'Y-m-d', strtotime( '+100 year' ) ),
						'status'            => \OTGS_Installer_Subscription::SUBSCRIPTION_STATUS_ACTIVE,
						'notes'             => 'by WPML',
						'order_id'          => '12345678',
						'hasAutoRenewal'    => true
					],
					'ts_info'               => [
						'client_id' => '654321',
						'preferred' => null,
						'referal'   => null
					],
				];

				return $serialize_response( $data );
		}
	}

	return $pre;
}, 99, 3 );
