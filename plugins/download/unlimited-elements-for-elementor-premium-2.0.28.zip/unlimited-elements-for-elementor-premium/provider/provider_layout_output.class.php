<?php
/**
 * @package Unlimited Elements
 * @author unlimited-elements.com
 * @copyright (C) 2012 Unite CMS, All Rights Reserved.
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 * */
if ( ! defined( 'ABSPATH' ) ) exit;

class UELM_CreatorLayoutOutput extends UniteCreatorLayoutOutputWork{
	
	/**
	 * construct
	 */
	public function __construct(){
		
		parent::__construct();
				
	}
	
	
}

class_alias( UELM_CreatorLayoutOutput::class, 'UniteCreatorLayoutOutput' );
