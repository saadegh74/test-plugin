<?php
/**
 * @package Unlimited Elements
 * @author unlimited-elements.com
 * @copyright (C) 2021 Unlimited Elements, All Rights Reserved. 
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 * */
if ( ! defined( 'ABSPATH' ) ) exit;


require HelperUC::getPathViewObject("layouts_view.class");
require HelperUC::getPathViewProvider("provider_layouts_view.class");

if(!isset($uelm_layoutType))
	$uelm_layoutType = UniteFunctionsUC::getGetVar("layout_type", "",UniteFunctionsUC::SANITIZE_KEY);
	

$uelm_objLayouts = new UELM_CreatorLayoutsViewProvider();
$uelm_objLayouts->setLayoutType($uelm_layoutType);
$uelm_objLayouts->display();
