=== CHANGELOG ===

=== Version 1.50.1 === Released on 15 October 2025

* New: support for WooCommerce 10.3
* Update: YITH plugin framework

=== Version 1.51.0 === Released on 15 September 2025

* New: support for WooCommerce 10.2
* Update: YITH plugin framework

=== Version 1.49.0 === Released on 14 August 2025

* New: support for WooCommerce 10.1
* Update: YITH plugin framework

=== Version 1.48.0 === Released on 01 July 2025

* New: support for WooCommerce 10.0
* Update: YITH plugin framework

=== Version 1.47.0 === Released on 04 June 2025

* New: support for WooCommerce 9.9
* Update: YITH plugin framework
* Fix: issue with the checkout fields of PDF Invoices

=== Version 1.46.0 === Released on 31 March 2025

* New: support for WordPress 6.8
* New: support for WooCommerce 9.8
* Update: YITH plugin framework

=== Version 1.45.0 === Released on 04 February 2025

* New: support for WooCommerce 9.7
* Update: YITH plugin framework
* Fix: prevent notice if the billing postcode is not required

=== Version 1.44.0 === Released on 04 December 2024

* New: support for WooCommerce 9.5
* Update: YITH plugin framework

=== Version 1.43.0 === Released on 16 September 2024

* New: support for WooCommerce 9.3
* Update: YITH plugin framework
* Fix: sortable fields not working

=== Version 1.42.0 === Released on 14 August 2024

* New: support for WooCommerce 9.2
* Update: YITH plugin framework
* Fix: error occurring if the billing state is not required
* Dev: new filter 'ywccp_email_additional_field_list'

=== Version 1.41.0 === Released on 14 July 2024

* New: support for WordPress 6.6
* New: support for WooCommerce 9.1
* Update: YITH plugin framework

=== Version 1.40.0 === Released on 26 Jun 2024

* New: support for WooCommerce 9.0
* Update: YITH plugin framework
* Fix: set required not working on billing company field

=== Version 1.39.0 === Released on 21 May 2024

* New: support for WooCommerce 8.9
* Update: YITH plugin framework

=== Version 1.38.0 === Released on 22 Apr 2024

* New: support for WooCommerce 8.8
* Update: YITH plugin framework

=== Version 1.37.0 === Released on 27 Mar 2024

* New: support for WordPress 6.5
* New: support for WooCommerce 8.7
* Update: YITH plugin framework

=== Version 1.36.0 === Released on 7 Feb 2024

* New: support for WooCommerce 8.6
* Update: YITH plugin framework

=== Version 1.35.0 === Released on 17 Jan 2024

* New: support for WooCommerce 8.5
* Update: YITH plugin framework
* Fix: billing state field required when no state is available

=== Version 1.34.0 === Released on 18 Dec 2023

* New: support for WooCommerce 8.4
* Update: YITH plugin framework
* Fix: set required not working on Billing Address 2

=== Version 1.33.0 === Released on 22 Nov 2023

* New: support for WordPress 6.4
* New: support for WooCommerce 8.3
* Update: YITH plugin framework

=== Version 1.32.0 === Released on 16 Oct 2023

* New: support for WooCommerce 8.2
* Update: YITH plugin framework

=== Version 1.31.0 === Released on 18 Sep 2023

* New: support for WooCommerce 8.1
* Update: YITH plugin framework
* Tweak: hide diabled fields in order billing and shipping fields.

=== Version 1.30.0 === Released on 08 Aug 2023

* New: support for WordPress 6.3
* New: support for WooCommerce 8.0
* Update: YITH plugin framework
* Tweak: add support for email subaddressing
* Fix: minor bugs

=== Version 1.29.0 === Released on 18 Jul 2023

* New: support for WooCommerce 7.9
* Update: YITH plugin framework
* Tweak: add support for email subaddressing
* Fix: minor bugs

=== Version 1.28.0 === Released on 22 Jun 2023

* New: support for WooCommerce 7.8
* New: HPOS support
* Update: YITH plugin framework
* Fix: plugin author name
* Fix: minor bugs

=== Version 1.27.0 === Released on 17 May 2023

* New: support for WooCommerce 7.7
* Update: YITH plugin framework
* Fix: minor bugs

=== Version 1.26.0 === Released on 19 Apr 2023

* New: support for WooCommerce 7.6
* Update: YITH plugin framework
* Fix: minor bugs

=== Version 1.25.0 === Released on 21 Mar 2023

* New: support for WordPress 6.2
* New: support for WooCommerce 7.5
* Update: YITH plugin framework
* Dev: filter the date formats only for this plugin
* Fix: minor bugs

=== Version 1.24.0 === Released on 21 Feb 2023

* New: support for WooCommerce 7.4
* Update: YITH plugin framework
* Tweak: prevent fatal error unset a non-array variable
* Fix: minor bugs

=== Version 1.23.0 === Released on 16 Jan 2023

* New: support for WooCommerce 7.3
* Update: YITH plugin framework
* Fix: minor bugs

=== Version 1.22.0 === Released on 15 Dec 2022

* New: support for WooCommerce 7.2
* Update: YITH plugin framework
* Fix: sanitize field label to allow HTML
* Fix: minor bugs

=== Version 1.21.0 === Released on 15 Nov 2022

* New: support for WordPress 6.1
* New: support for WooCommerce 7.1
* Update: YITH plugin framework
* Fix: patched security vulnerability
* Fix: minor bugs

=== Version 1.20.0 === Released on 13 Oct 2022

* New: support for WooCommerce 7.0
* Update: YITH plugin framework
* Fix: minor bugs

=== Version 1.19.0 === Released on 19 Sep 2022

* New: support for WooCommerce 6.9
* Update: YITH plugin framework
* Dev: improve admin add new field process
* Dev: new filter 'yith_wccp_show_always_additional_field_in_table'
* Fix: minor bugs

=== Version 1.18.0 === Released on 16 Aug 2022

* New: support for WooCommerce 6.8
* Update: YITH plugin framework
* Fix: minor bugs

=== Version 1.17.0 === Released on 18 Jul 2022

* New: support for WooCommerce 6.7
* Update: YITH plugin framework
* Fix: undefined index billing_country
* Fix: minor bugs

=== Version 1.16.0 === Released on 22 Jun 2022

* New: support for WooCommerce 6.6
* Update: YITH plugin framework
* Fix: minor bugs

=== Version 1.15.0 === Released on 23 May 2022

* New: support for WordPress 6.0
* New: support for WooCommerce 6.5
* Update: YITH plugin framework
* Fix: minor bugs

=== Version 1.14.0 === Released on 06 April 2022

* New: support for WooCommerce 6.4
* Update: YITH plugin framework
* Update: language files

=== Version 1.13.0 === Released on 03 March 2022

* New: support for WooCommerce 6.3
* Update: YITH plugin framework
* Update: language files
* Dev: new filter 'ywccp_panel_capability'

=== Version 1.12.0 === Released on 10 February 2022

* New: support for WooCommerce 6.2
* Update: YITH plugin framework
* Update: language files

=== Version 1.11.0 === Released on 11 January 2022

* New: support for WordPress 5.9
* New: support for WooCommerce 6.1
* Update: YITH plugin framework
* Update: language files

=== Version 1.10.0 === Released on 02 December 2021

* New: support for WooCommerce 6.0
* Update: YITH plugin framework
* Update: language files
* Fix: custom fields not shown on thank you page and order edit page if fields has conditions

=== Version 1.9.0 === Released on 04 November 2021

* New: support for WooCommerce 5.9
* Update: YITH plugin framework
* Update: language files
* Dev: new filter 'ywccp_field_ids_to_exclude'

=== Version 1.8.0 === Released on 13 October 2021

* New: support for WooCommerce 5.8
* Update: YITH plugin framework
* Fix: added a condition to avoid prefix errors

=== Version 1.7.1 === Released on 27 September 2021

* Update: YITH plugin framework
* Fix: debug info feature removed for all logged in users

=== Version 1.7.0 === Released on 08 September 2021

* New: support for WooCommerce 5.7
* Update: YITH plugin framework

=== Version 1.6.4 === Released on 12 August 2021

* New: support for WooCommerce 5.6
* New: Russian translation
* Update: YITH plugin framework

=== Version 1.6.3 === Released on 05 July 2021

* New: support for WordPress 5.8
* New: support for WooCommerce 5.5
* Update: YITH plugin framework
* Fix: product in cart validate condition
* Fix: enable/disable field using bulk action

=== Version 1.6.2 === Released on 03 June 2021

* New: support for WooCommerce 5.4
* Update: YITH plugin framework
* Fix: checkout validation for products and categories conditions

=== Version 1.6.1 === Released on 13 May 2021

* New: support for WooCommerce 5.3
* Update: YITH plugin framework
* Fix: shipping costs didn't set properly
* Fix: issue with required condition
* Fix: prevent invalid condition fields to be processed
* Tweak: cache on field conditions to improve performance

=== Version 1.6.0 === Released on 08 April 2021

* New: support for WooCommerce 5.2
* New: German translation
* New: include the additional fields to the list of conditional fields
* Update: YITH plugin framework
* Update: language files
* Fix: heading fields visibility in order address details

=== Version 1.5.0 === Released on 02 March 2021

* New: support for WordPress 5.7
* New: support for WooCommerce 5.1
* Update: YITH plugin framework
* Update: language files
* Fix: issues with conditions for heading fields
* Fix: issues with conditions based on products in cart

=== Version 1.4.6 === Released on 02 February 2021

* New: support for WooCommerce 5.0
* Update: YITH plugin framework
* Update: language files

=== Version 1.4.5 === Released on 11 January 2021

* New: Support for WooCommerce 4.9
* Update: Plugin framework
* Update: Language files

=== Version 1.4.4 === Released on 04 December 2020

* New: Support for WooCommerce 4.8
* New: Option to customize date format
* Update: Plugin framework
* Update: Language files

=== Version 1.4.3 === Released on 03 November 2020

* New: Support for WordPress 5.6
* New: Support for WooCommerce 4.7
* Update: Plugin framework
* Update: Language files

=== Version 1.4.2 === Released on 12 October 2020

* New: Support for WooCommerce 4.6
* Update: Plugin framework
* Update: Language files
* Dev: New filter 'ywccp_datepicker_allowed_days'

=== Version 1.4.1 === Released on 17 September 2020

* New: Support for WooCommerce 4.5
* Update: Plugin framework
* Update: Language files

=== Version 1.4.0 === Released on 11 August 2020

* New: Support for WooCommerce 4.4
* New: Support for WordPress 5.5
* Update: Plugin framework
* Update: Language files
* Fix: Condition based on product category in cart didn't work
* Dev: New filter 'ywccp_ship_different_address_old_behaviour'

=== Version 1.3.13 === Released on 26 May 2020

* New: Support for WooCommerce 4.2
* Update: Plugin framework
* Update: Language files
* Fix: Missing class attribute for required fields

=== Version 1.3.12 === Released on 27 April 2020

* New: Support for WooCommerce 4.1
* Update: Plugin framework
* Fix: Prevent fatal error "Call to undefined method WC_Product::get_category_ids()"

=== Version 1.3.11 === Released on 17 April 2020

* Update: Plugin framework
* Update: qtip2 script to version 3.0.3
* Tweak: Improved responsive style

=== Version 1.3.10 === Released on 11 March 2020

* Fix: issue with required field not working properly

=== Version 1.3.9 === Released on 09 March 2020

* New: support for WordPress 5.4
* New: support for WooCommerce 4.0
* Update: Italian translation
* Fix: required fields in according to selected country
* Fix: issue on removing a condition on a rule

=== Version 1.3.8 === Released on 14 February 2020

* Update: Plugin Core
* Fix: Checkout required fields don't match plugin settings
* Tweak: Allow adding more values to fields check conditions

=== Version 1.3.7 === Released on 04 February 2020

* New: Support to WooCommerce 3.9.1
* Update: Plugin Core
* Fix: Wrong state field type when country field is not a select dropdown
* Fix: Additional fields didn't work properly with conditional rules
* Fix: Wrong value of "ship to different address" checkbox when checkout has custom fields

=== Version 1.3.6 === Released on 08 January 2020

* Update: spanish language
* Fix: phone and email fields not shown in My Account billing section

=== Version 1.3.5 === Released on 23 December 2019

* New: Support to WooCommerce 3.9
* New: Support to WordPress 5.3.2
* Update: Plugin framework
* Update: Dutch language

=== Version 1.3.4 === Released on 07 December 2019

* Fix: issue with rule validation on radio and checkout input fields

=== Version 1.3.3 === Released on 29 November 2019

* Update: Italian language
* Update: Notice handler
* Update: Plugin framework
* Fix: JavaScript set required condition for fields by checking products in cart

=== Version 1.3.2 === Released on 06 November 2019

* Fix: undefined variable $condition_is_valid

=== Version 1.3.1 === Released on 06 November 2019

* Fix: undefined function

=== Version 1.3.0 === Released on 06 November 2019

* New: Show fields with logic conditions
* Update: Plugin Core

=== Version 1.2.14 === Released on 25 October 2019

* New: Support for WooCommerce 3.8
* New: Support for WordPress 5.3
* Update: Plugin Core

=== Version 1.2.13 === Released on 26 September 2019

* New: Added field type "number"
* Update: Plugin Core
* Fix: Prevent warning "array_merge(): Argument #1 is not an array"
* Dev: Set min date for datepicker through new filter 'ywccp_datepicker_min_date'

=== Version 1.2.12 === Released on 06 August 2019

* New: Support to WooCommerce 3.7.0 RC2
* Update: Italian language
* Update: Plugin Core
* Fix: Decode option keys in order to prevent issue with not latin charset

=== Version 1.2.11 === Released on 11 June 2019

* New: Support to WooCommerce 3.6.4
* New: Support to WordPress 5.2.1
* Update: Plugin Core
* Fix: Warning explode() expects parameter 2 to be string, array given
* Fix: Warning: Invalid argument supplied for foreach()
* Dev: New filter 'ywccp_datepicker_change_year'
* Dev: New filter 'ywccp_datepicker_change_month'
* Dev: New filter 'ywccp_datepicker_year_range'
* Dev: New filter 'ywccp_custom_shipping_fields'
* Dev: New filter 'ywccp_custom_billing_fields'

=== Version 1.2.10 === Released on 03 May 2019

* New: Support to WooCommerce 3.6.2
* Update: Plugin Core
* Fix: Missing classes for heading field type

=== Version 1.2.9 === Released on 09 April 2019

* New: Support to WooCommerce 3.6.0 RC1
* Update: Plugin Core
* Fix: Validation process for VAT with whitespaces

=== Version 1.2.8 === Released on 26 March 2019

* New: Support to WooCommerce 3.5.7
* Update: Plugin Core
* Fix: WPML translation not used for shipping fields showed in popup of Multiple Shipping Address plugin
* Fix: Made plain_text param optional for ywccp_email_additional_fields_list function
* Dev: Filtered get_address method of WC_Order class

=== Version 1.2.7 === Released on 28 January 2019

* New: Support to WooCommerce 3.5.4
* Update: Plugin Core
* Update: Dutch translation
* Fix: Missing fields in user edit profile admin section

=== Version 1.2.6 === Released on 02 January 2019

* Update: Plugin Core
* Update: Spanish translation
* Fix: Missing translations in order table using WPML or Polylang

=== Version 1.2.5 === Released on 05 December 2018

* New: Support to WooCommerce 3.5.2
* New: Support to WordPress 5.0.0
* Tweak: Drag and drop icon and new cursor for the checkout fields edit table
* Update: Plugin Core

=== Version 1.2.4 === Released on 08 November 2018

* Update: Plugin Core
* Fix: Checkout fields showed in a wrong order

=== Version 1.2.3 === Released on 26 October 2018

* New: Support to WooCommerce 3.5.0
* Update: Plugin Core
* Update: Languages files

=== Version 1.2.2 === Released on 28 September 2018

* New: Support to WooCommerce 3.4.5
* New: Support to WordPress 4.9.8
* New: Support to Polylang 2.3.10
* Update: Italian language
* Update: Dutch language
* Update: Plugin Core
* Dev: New hook "ywccp_scripts_registered" after scripts register

=== Version 1.2.1 === Released on 30 May 2018

* New: Support to WooCommerce 3.4.1
* New: Support to WordPress 4.9.6
* New: YITH WooCommerce EU Vat compatibility
* Update: Plugin core

=== Version 1.2.0 === Released on 15 May 2018

* New: Support to WooCommerce 3.4 RC1
* New: General Data Protection Regulation (GDPR) compliance
* Update: Plugin Core
* Update: Italian language files
* Update: Dutch language files
* Fix: Customer order note string fields not translatable
* Fix: New fields name sanitize and clean-up

=== Version 1.1.0 === Released on 31 January 2018

* New: Support to WooCommerce 3.3.0
* New: Support to WordPress 4.9.2
* New: Dutch translation
* New: Option show/hide field label for the formatted addresses
* Update: Plugin Core
* Update: Language files
* Fix: Get customer address functions now includes also custom fields
* Fix: Custom fields visibility in my account pages

=== Version 1.0.11 === Released on 29 November 2017

* New: Support to WooCommerce 3.2.5
* New: Support to WordPress 4.9.0
* Fix: Filter customer details for AJAX action in order edit pages
* Fix: Plugin scripts minimization

=== Version 1.0.10 === Released on 24 October 2017

* New: Support to WooCommerce 3.2.1
* Update: Plugin Core
* Fix: WPML String Translation for "locale" and "locale default" arrays

=== Version 1.0.9 === Released on 10 October 2017

* New: Support to WooCommerce 3.2.0 RC2
* New: Support to WordPress 4.8.2
* Update: Plugin Core

=== Version 1.0.8 === Released on 20 September 2017

* New: German Translation ( thanks to Alexander Cekic )
* Fix: Prevent infinite loops if default options are not already saved

=== Version 1.0.7 === Released on 30 August 2017

* Fix: RTL issue for checkout fields order
* Fix: Prevent infinite loops on some cases when getting the default WC checkout fields
* Fix: Undefined index notices

=== Version 1.0.6 === Released on 24 August 2017

* New: Support to WooCommerce 3.1.2
* New: Support to WordPress 4.8.1
* Update: Plugin Framework
* Update: Language files
* Fix: Removed unnecessary empty option for fields type select
* Fix: Translate also select options using WPML
* Fix: Stripslashes for label and placeholder options
* Fix: Removed unnecessary "clear row" option

=== Version 1.0.5 === Released on 03 March 2017

* New: Option for choose date format for date fields
* New: Support to WooCommerce 2.7 RC 1
* New: Allow not latin charset for options values
* New: Option to overwrite formatted addresses ordering
* Update: Plugin Framework
* Update: Language files
* Fix: Compatibility issues with WPML
* Fix: Required for heading fields
* Fix: Skip validate process for empty fields

=== Version 1.0.4 === Released on 05 August 2016

* Update: Plugin Framework
* Fix: CSS issue with datepicker

=== Version 1.0.3 === Released on 22 July 2016

* New: Type Tel for checkout fields
* New: Spanish Translation
* New: Compatibility with WooCommerce Customer Order Csv Export
* Update: Language files
* Update: Core plugin
* Fix: Placeholder for type select doesn't show
* Fix: Plugin documentation link
* Fix: Checkbox required in checkout process now is checked correctly

=== Version 1.0.2 === Released on 07 June 2016

* New: Support to WooCommerce 2.6 Beta
* New: Italian Translation
* Update: Language files
* Update: Core plugin

=== Version 1.0.1 === Released on 03 May 2016

* New: Now you can specify the key when you add an option for a select or radio type ( key::value )
* Fix: show/hide correctly State field on Country change
* Fix: Javascript error with select2 script

=== Version 1.0.0 === Released on 22 April 2016

 * Initial Release
