(function ($) {
	$( window ).on( 'elementor/frontend/init', () => {
		/*
		 * The carousel layout is PPCarouselBase (frontend-carousel-base.js): Swiper options,
		 * reduced motion, autoplay pauses, slide visibility and the position announcement.
		 * This handler adds the masonry layout.
		 */
		class InstafeedWidget extends window.PPCarouselBase {
			getDefaultSettings() {
				const settings = super.getDefaultSettings();

				settings.selectors = Object.assign( {}, settings.selectors, {
					feed: '.pp-instafeed-grid',
				} );

				return settings;
			}

			getDefaultElements() {
				const selectors = this.getSettings( 'selectors' );

				return Object.assign( super.getDefaultElements(), {
					$feed: this.$element.find( selectors.feed ),
				} );
			}

			/*
			 * Always scope by widget ID, editor included: PP_Helper::render_arrows() gives
			 * every arrow the id-scoped class, and the generic `.elementor-swiper-button-*` /
			 * `.swiper-pagination` selectors resolve against the document, so two instances
			 * on one page would both bind to whichever renders first.
			 */
			getNavigationSelectors() {
				return {
					prevEl:       '.swiper-button-prev-' + this.getID(),
					nextEl:       '.swiper-button-next-' + this.getID(),
					paginationEl: '.swiper-pagination-' + this.getID(),
				};
			}

			// The status sits after the dots and arrows, outside the Swiper container.
			getStatusElement() {
				return this.$element.find( '#pp-instafeed-status-' + this.getID() );
			}

			bindEvents() {
				const elementSettings = this.getElementSettings();
				const layout = elementSettings.feed_layout;

				if ( 'carousel' === layout ) {
					this.initSlider();
				}

				if ( 'masonry' === layout ) {
					this.initMasonryLayout();
				}
			}

			initMasonryLayout() {
				this.masonry = new PPMasonry( {
					container: this.elements.$feed[0],
					itemSelector: '.pp-feed-item',
				} );

				this.masonry.observeResize();

				// Measure once images are loaded, then keep it in sync as (lazy) images resolve.
				this.elements.$feed.imagesLoaded( () => {
					this.masonry.setReady();
					this.masonry.layout();
				} );

				// Namespaced so onDestroy can unbind, and coalesced into one pass per
				// frame — a full layout per image is a forced reflow per item, per image.
				this.elements.$feed.find( 'img' ).on( 'load.ppInstafeed', () => this.scheduleMasonryLayout() );
			}

			scheduleMasonryLayout() {
				if ( this.masonryFrame ) {
					return;
				}

				this.masonryFrame = requestAnimationFrame( () => {
					this.masonryFrame = null;

					if ( this.masonry ) {
						this.masonry.layoutIfReady();
					}
				} );
			}

			onElementChange() {
				if ( this.masonry && 'masonry' === this.getElementSettings('feed_layout') ) {
					setTimeout( () => this.masonry.layout() );
				}
			}

			onDestroy() {
				if ( this.masonryFrame ) {
					cancelAnimationFrame( this.masonryFrame );
					this.masonryFrame = null;
				}

				this.elements.$feed.find( 'img' ).off( '.ppInstafeed' );

				if ( this.masonry ) {
					this.masonry.destroy();
				}

				// Takes down the Swiper and the carousel's handlers.
				super.onDestroy();
			}

		}

		elementorFrontend.elementsHandler.attachHandler( 'pp-instafeed', InstafeedWidget );
	} );
})(jQuery);