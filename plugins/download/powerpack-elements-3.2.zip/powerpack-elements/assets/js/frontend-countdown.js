(function ($) {
	$( window ).on( 'elementor/frontend/init', () => {
		class CountdownWidget extends elementorModules.frontend.handlers.Base {
			getDefaultSettings() {
				const config = JSON.parse( this.$element.find('[name=pp-countdown-settings]').val() ),
				settings = {
					timertype: config.timer_type,
					timer_format: config.timer_format,
					timer_layout: config.timer_layout,
					timer_labels: config.timer_labels,
					timer_labels_singular: config.timer_labels_singular,
					redirect_link: config.redirect_link.url,
					redirect_link_target: config.redirect_link_target,
					fixed_timer_action: config.fixed_timer_action,
					evergreen_timer_action: config.evergreen_timer_action,
					evergreen_date_days: config.days,
					evergreen_date_hour: config.hours,
					evergreen_date_minutes: config.minutes,
					evergreen_date_seconds: config.seconds,
					timezone: config.time_zone,
					variation_data: config.variation_data,
					woo_variation: config.woo_variation,
					id: this.getID()
				}

				if ( 'NULL' === config.time_zone || '' === config.time_zone ) {
					settings.timezone = null;
				}

				if ( 'evergreen' === config.timer_type ) {
					settings.timer_date = new Date();
				} else {
					settings.timer_date = new Date( config.years, (config.months - 1), config.days, config.hours, config.minutes );
				}

				if ( config.timer_exp_text ) {
					settings.timer_exp_text = config.timer_exp_text;
				}

				settings.selectors = {
					wrap: '.pp-countdown-wrapper',
					srStatus: '.pp-countdown-sr-only',
				};

				return settings;
			}
		
			getDefaultElements() {
				const selectors = this.getSettings( 'selectors' );
				return {
					$wrap: this.$element.find( selectors.wrap ),
					$srStatus: this.$element.find( selectors.srStatus ),
				};
			}
		
			bindEvents() {
				const settings = this.getSettings();

				if ( 'fixed' == settings.timertype ) {
					var variation_datas = settings.variation_data;

					if ( true === settings.woo_variation && Object.keys( variation_datas ).length > 0 ) {
						var that = this;
						$( ".single_variation_wrap" ).on( "show_variation", function ( event, variation ) {
							if ( '' !== variation.variation_id ) {
								var variation_data =  variation_datas[variation.variation_id];
								if ( Object.keys( variation_data ).length > 0 ) {
									settings.timer_date = new Date( variation_data.years, (variation_data.months - 1), variation_data.days, 0, 0 );
									that.initFixedTimer();
									that.initCountdown();
									that.elements.$wrap.countdown( 'option', { until: settings.timer_date } );
								}
							}
						} );
					} else {
						this.initFixedTimer();
					}
				}

				if ( 'evergreen' == settings.timertype ) {
					var currdate = '',
						timevar = 0;

					if ( undefined == Cookies.get( 'countdown-' + settings.id ) ) {
						Cookies.set( 'countdown-' + settings.id, true );
						Cookies.set( 'countdown-' + settings.id + '-currdate', new Date() );
					}

					currdate = new Date( Cookies.get( 'countdown-' + settings.id + '-currdate' ) );

					currdate.setTime( currdate.getTime() + this.getEvergreenDuration() );

					settings.timer_date = currdate;

					this.initEverGreenTimer();
				}

				this.initCountdown();
			}

			/**
			 * Clear cookies written by earlier versions.
			 *
			 * The expiry message, redirect target and expiry action used to be
			 * stored in cookies and read back from them, which let anyone able
			 * to set a cookie on the domain inject markup or a redirect URL.
			 * They are now always read from the widget settings, so the
			 * year-long cookies left in visitors' browsers are removed.
			 */
			initCountdown() {
				const id = this.getSettings( 'id' );

				[ 'expiremsg', 'redirect', 'redirectwindow', 'hide', 'reset' ].forEach( ( key ) => {
					Cookies.remove( 'countdown-' + id + key );
				} );
			}

			getEvergreenDuration() {
				const settings = this.getSettings();

				return ( ( parseFloat( settings.evergreen_date_days ) || 0 ) * 86400 +
					( parseFloat( settings.evergreen_date_hour ) || 0 ) * 3600 +
					( parseFloat( settings.evergreen_date_minutes ) || 0 ) * 60 +
					( parseFloat( settings.evergreen_date_seconds ) || 0 ) ) * 1000;
			}

			countdownConfig(settings) {
				const config = {
					until: settings.timer_date,
					format: settings.timer_format,
					layout: settings.timer_layout,
					labels: settings.timer_labels.split(','),
					timezone: settings.timezone,
					labels1: settings.timer_labels_singular.split(','),
					onTick: this.onCountdownTick.bind( this ),
				};

				return config;
			}

			onCountdownTick( periods ) {
				if ( ! this.elements.$srStatus || ! this.elements.$srStatus.length ) {
					return;
				}

				const now = Date.now(),
					lastAnnounce = this.elements.$wrap.data( 'ppCountdownLastSrAnnounce' );

				if ( lastAnnounce && ( now - lastAnnounce ) < 60000 ) {
					return;
				}
				this.elements.$wrap.data( 'ppCountdownLastSrAnnounce', now );

				const settings = this.getSettings(),
					labels = settings.timer_labels.split( ',' ),
					labelsSingular = settings.timer_labels_singular.split( ',' ),
					unitIndexes = [ 0, 1, 3, 4, 5, 6 ],
					parts = [];

				unitIndexes.forEach( ( i ) => {
					const value = parseInt( periods[ i ], 10 ) || 0;

					if ( value <= 0 ) {
						return;
					}

					const label = 1 === value ? labelsSingular[ i ] : labels[ i ];

					parts.push( value + ' ' + label );
				} );

				this.elements.$srStatus.text( parts.length ? parts.join( ', ' ) : '' );
			}

			initFixedTimer() {
				const settings = this.getSettings(),
					dateNow = new Date();

				if ( ( dateNow.getTime() - settings.timer_date.getTime() ) > 0 ) {
					var config = this.countdownConfig(settings);

					if ( 'msg' === settings.fixed_timer_action ) {
						if ( parseInt( window.location.href.toLowerCase().indexOf('?elementor') ) === parseInt(-1) ) {
							this.elements.$wrap.append( settings.timer_exp_text );
						} else {
							config.expiryText = settings.timer_exp_text;

							this.elements.$wrap.countdown(config);
						}

					} else if ( 'redirect' === settings.fixed_timer_action ) {

						if ( parseInt( window.location.href.toLowerCase().indexOf('?elementor') ) === parseInt(-1) ) {
							window.open( settings.redirect_link, settings.redirect_link_target );
						} else {
							config.expiryText = settings.timer_exp_text;

							this.elements.$wrap.countdown(config);
						}

					} else if ( 'hide' === settings.fixed_timer_action ) {
						if ( parseInt( window.location.href.toLowerCase().indexOf('?elementor') ) === parseInt(-1) ) {
							this.elements.$wrap.countdown('destroy');
						} else {
							config.expiryText = settings.timer_exp_text;

							this.elements.$wrap.countdown(config);
						}

					} else {
						this.elements.$wrap.countdown(config);
					}
				} else {
					var config = this.countdownConfig(settings);

					if ( 'msg' === settings.fixed_timer_action ) {

						if ( parseInt( window.location.href.toLowerCase().indexOf('?elementor') ) === parseInt(-1) ) {
							config.expiryText = settings.timer_exp_text;

							this.elements.$wrap.countdown(config);
						} else {
							this.elements.$wrap.countdown(config);
						}
					} else if ( 'redirect' === settings.fixed_timer_action ) {
						config.expiryText = settings.timer_exp_text;
						config.onExpiry = () => this.redirectCounter();

						this.elements.$wrap.countdown(config);

					} else if ( 'hide' === settings.fixed_timer_action ) {
						config.onExpiry = () => this.destroyCounter();

						this.elements.$wrap.countdown(config);

					} else {
						config.expiryText = settings.timer_exp_text;

						this.elements.$wrap.countdown(config);
					}
				}
			}

			initEverGreenTimer() {
				const settings = this.getSettings(),
					dateNow = new Date();

				if ( ( dateNow.getTime() - settings.timer_date.getTime() ) > 0 ) {
					var config = this.countdownConfig(settings);

					if ( 'msg' === settings.evergreen_timer_action ) {
						if ( parseInt( window.location.href.toLowerCase().indexOf('?elementor') ) === parseInt(-1) ) {
							this.elements.$wrap.append( settings.timer_exp_text );
						} else {
							config.expiryText = settings.timer_exp_text;

							this.elements.$wrap.countdown(config);
						}

					} else if ( 'redirect' === settings.evergreen_timer_action ) {

						if ( parseInt( window.location.href.toLowerCase().indexOf('?elementor') ) === parseInt(-1) ) {
							window.open(settings.redirect_link, settings.redirect_link_target);
						} else {
							config.onExpiry = () => this.redirectCounter();

							this.elements.$wrap.countdown(config);
						}

					} else if ( 'hide' === settings.evergreen_timer_action ) {
						if ( parseInt( window.location.href.toLowerCase().indexOf('?elementor') ) === parseInt(-1) ) {
							this.elements.$wrap.countdown('destroy');
						} else {
							config.onExpiry = () => this.destroyCounter();

							this.elements.$wrap.countdown(config);
						}

					} else if ( 'reset' === settings.evergreen_timer_action ) {
						config.onExpiry = () => this.restartCountdown();

						this.elements.$wrap.countdown(config);

					} else {
						this.elements.$wrap.countdown(config);
					}
				} else {
					var config = this.countdownConfig(settings);

					if ( 'msg' === settings.evergreen_timer_action ) {

						if ( parseInt( window.location.href.toLowerCase().indexOf('?elementor') ) === parseInt(-1) ) {
							config.expiryText = settings.timer_exp_text;

							this.elements.$wrap.countdown(config);
						} else {
							this.elements.$wrap.countdown(config);
						}

					} else if ( 'redirect' === settings.evergreen_timer_action ) {
						config.onExpiry = () => this.redirectCounter();

						this.elements.$wrap.countdown(config);

					} else if ( 'hide' === settings.evergreen_timer_action ) {
						config.onExpiry = () => this.destroyCounter();

						this.elements.$wrap.countdown(config);

					} else if ( 'reset' === settings.evergreen_timer_action ) {
						config.onExpiry = () => this.restartCountdown();

						this.elements.$wrap.countdown(config);

					} else {
						this.elements.$wrap.countdown(config);
					}
				}
			}

			redirectCounter() {
				const settings = this.getSettings();

				if ( parseInt( window.location.href.toLowerCase().indexOf('?elementor') ) !== parseInt(-1) || ! settings.redirect_link ) {
					return;
				}

				this.elements.$srStatus.text( 'Redirecting now.' );

				window.open( settings.redirect_link, settings.redirect_link_target );
			}

			destroyCounter() {
				if ( parseInt( window.location.href.toLowerCase().indexOf('?elementor') ) === parseInt(-1) ) {
					const $wrap = this.elements.$wrap;

					$wrap.countdown('destroy');

					$wrap.attr( 'aria-hidden', 'true' ).removeAttr( 'role tabindex aria-live aria-atomic aria-label aria-describedby' );
					this.elements.$srStatus.empty();
				}
			}

			restartCountdown() {
				const $wrap = this.elements.$wrap,
					now = new Date();

				Cookies.set( 'countdown-' + this.getSettings( 'id' ) + '-currdate', now );

				$wrap.data( 'ppCountdownLastSrAnnounce', null );
				this.elements.$srStatus.text( '' );

				$wrap.countdown( 'option', { until: new Date( now.getTime() + this.getEvergreenDuration() ) } );
			}
		}

		elementorFrontend.elementsHandler.attachHandler( 'pp-countdown', CountdownWidget );
    });

})(jQuery);
