(function ($) {
	$(window).on( 'elementor/frontend/init', () => {
		class ImageComparisonWidget extends elementorModules.frontend.handlers.Base {
			getDefaultSettings() {
				return {
					selectors: {
						container: '.pp-image-comparison',
						afterImg: '.pp-after-image',
						handle: '.pp-comparison-handle',
						labelBefore: '.pp-comparison-label-before span',
						labelAfter: '.pp-comparison-label-after span',
					},
					labelGap: 15,
					keyboardStep: 1,
					keyboardStepLarge: 10,
				};
			}

			getDefaultElements() {
				const selectors = this.getSettings('selectors');
				return {
					$container: this.$element.find(selectors.container),
					$afterImg: this.$element.find(selectors.afterImg),
					$handle: this.$element.find(selectors.handle),
					$labelBefore: this.$element.find(selectors.labelBefore),
					$labelAfter: this.$element.find(selectors.labelAfter),
				};
			}

			getNamespace() {
				return '.ppImageComparison-' + this.getID();
			}

			bindEvents() {
				const container = this.elements.$container,
					handle = this.elements.$handle,
					ns = this.getNamespace();

				if ( ! container.length ) {
					return;
				}

				const settings = container.data('settings') || {};

				this.orientation = 'vertical' === settings.orientation ? 'vertical' : 'horizontal';
				this.isRtl = 'rtl' === container.css('direction');
				this.valueText = handle.attr('data-value-text') || '';
				this.suppressClick = false;

				const onPointerMove = (event) => this.setPosition(this.positionFromEvent(event));

				handle
					.on('move' + ns, onPointerMove)
					.on('keydown' + ns, (event) => this.handleKeyDown(event));

				// A drag finishes with a click on the container; it must not re-run the click path.
				handle.on('moveend' + ns, () => {
					this.suppressClick = true;
					setTimeout(() => {
						this.suppressClick = false;
					}, 0);
				});

				if ( settings.slider_on_hover ) {
					container.on('mousemove' + ns, onPointerMove);
				} else {
					// WCAG 2.5.7: the divider has to be positionable with a single pointer
					// without dragging, so a click or tap on the image moves it there.
					container.on('click' + ns, (event) => {
						if ( this.suppressClick ) {
							return;
						}

						this.setPosition(this.positionFromEvent(event));

						// So the arrow keys carry on from wherever the tap landed.
						if ( ! handle[0].contains(event.target) ) {
							handle.trigger('focus');
						}
					});
				}

				// The server already rendered --pp-ic-position, so this only syncs
				// the handle's ARIA values and the label visibility.
				this.setPosition(parseFloat(settings.visible_ratio) * 100);
			}

			unbindEvents() {
				const ns = this.getNamespace();

				this.elements.$handle.off(ns);
				this.elements.$container.off(ns);
			}

			/**
			 * Clamp a divider position to 0-100, falling back to the midpoint.
			 */
			normalize(percent) {
				if ( isNaN(percent) ) {
					return 50;
				}

				return Math.max(0, Math.min(100, percent));
			}

			/**
			 * Translate a pointer event into a divider position, measured from the
			 * inline start (horizontal) or the top (vertical).
			 */
			positionFromEvent(event) {
				const container = this.elements.$container,
					offset = container.offset();

				if ( 'vertical' === this.orientation ) {
					const height = container.outerHeight();
					return height ? ((event.pageY - offset.top) / height) * 100 : 0;
				}

				const width = container.outerWidth(),
					fromLeft = width ? ((event.pageX - offset.left) / width) * 100 : 0;

				return this.isRtl ? 100 - fromLeft : fromLeft;
			}

			/**
			 * Move the divider with the keyboard. Arrow keys track the direction the
			 * divider moves on screen, so they stay intuitive in RTL and in both
			 * orientations. The perpendicular arrows are left alone so they still
			 * scroll the page.
			 */
			handleKeyDown(event) {
				const settings = this.getSettings(),
					step = event.shiftKey ? settings.keyboardStepLarge : settings.keyboardStep,
					// Legacy key names from older browsers.
					key = event.key.replace(/^(Left|Right|Up|Down)$/, 'Arrow$1'),
					isVertical = 'vertical' === this.orientation;

				let delta;

				switch ( key ) {
					case 'ArrowLeft':
						if ( isVertical ) {
							return;
						}
						delta = this.isRtl ? step : -step;
						break;
					case 'ArrowRight':
						if ( isVertical ) {
							return;
						}
						delta = this.isRtl ? -step : step;
						break;
					case 'ArrowUp':
						if ( ! isVertical ) {
							return;
						}
						delta = -step;
						break;
					case 'ArrowDown':
						if ( ! isVertical ) {
							return;
						}
						delta = step;
						break;
					// The ARIA slider pattern: Page Up raises the value, Page Down lowers it.
					case 'PageUp':
						delta = settings.keyboardStepLarge;
						break;
					case 'PageDown':
						delta = -settings.keyboardStepLarge;
						break;
					case 'Home':
						event.preventDefault();
						this.setPosition(0);
						return;
					case 'End':
						event.preventDefault();
						this.setPosition(100);
						return;
					default:
						return;
				}

				event.preventDefault();
				this.setPosition(this.position + delta);
			}

			setPosition(percent) {
				const position = this.normalize(percent);

				this.position = position;
				this.elements.$container[0].style.setProperty('--pp-ic-position', position + '%');
				const rounded = Math.round(position);

				this.elements.$handle.attr('aria-valuenow', rounded);

				if ( this.valueText ) {
					this.elements.$handle.attr('aria-valuetext', this.valueText.replace('{percent}', rounded));
				}

				this.updateLabels();
			}

			updateLabels() {
				const isVertical = 'vertical' === this.orientation,
					container = this.elements.$container,
					containerSize = isVertical ? container.outerHeight() : container.outerWidth(),
					handlePosition = (this.position / 100) * containerSize;

				this.toggleLabel(this.elements.$labelBefore, handlePosition, containerSize, true);
				this.toggleLabel(this.elements.$labelAfter, handlePosition, containerSize, false);
			}

			/**
			 * Fade a label out once the divider reaches it. Either label can be absent
			 * - both are optional - so each one is checked on its own.
			 */
			toggleLabel($label, handlePosition, containerSize, isBefore) {
				if ( ! $label.length ) {
					return;
				}

				const gap = this.getSettings('labelGap'),
					offset = $label.position(),
					extent = 'vertical' === this.orientation
						? offset.top + $label.outerHeight()
						: offset.left + $label.outerWidth(),
					overlapped = isBefore
						? extent + gap >= handlePosition
						: containerSize - (extent + gap) <= handlePosition;

				$label.stop().css('opacity', overlapped ? 0 : 1);
			}
		}

		elementorFrontend.elementsHandler.attachHandler( 'pp-image-comparison', ImageComparisonWidget );
	} );
})(jQuery);
