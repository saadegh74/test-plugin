(function ($) {
	$( window ).on( 'elementor/frontend/init', () => {
		/*
		 * The carousel layout is PPCarouselBase (frontend-carousel-base.js): Swiper options,
		 * reduced motion, autoplay pauses, slide visibility and the position announcement.
		 * This handler adds the grid's pagination, load more and infinite scroll.
		 */
		class CategoriesWidget extends window.PPCarouselBase {
			getDefaultSettings() {
				const settings = super.getDefaultSettings();

				settings.selectors = Object.assign( {}, settings.selectors, {
					categoriesContainer: '.pp-categories',
					categoriesGrid: '.pp-categories-grid-wrapper',
					category: '.pp-category',
				} );

				return settings;
			}

			getDefaultElements() {
				const selectors = this.getSettings( 'selectors' );

				return Object.assign( super.getDefaultElements(), {
					$categoriesContainer: this.$element.find( selectors.categoriesContainer ),
					$categoriesGrid: this.$element.find( selectors.categoriesGrid ),
					$category: this.$element.find( selectors.category ),
				} );
			}

			// The status sits after the dots and arrows, outside the Swiper container.
			getStatusElement() {
				return this.$element.find( '#pp-categories-status-' + this.getID() );
			}

			getLiveRegion() {
				let $liveRegion = this.$element.find( '.pp-categories-live-region' );

				if ( ! $liveRegion.length ) {
					$liveRegion = $( '<div>', {
						'class': 'pp-categories-live-region elementor-screen-only',
						'role': 'status',
						'aria-live': 'polite',
						'aria-atomic': 'true'
					} );

					this.elements.$categoriesContainer.append( $liveRegion );
				}

				return $liveRegion;
			}

			announce( message ) {
				const $liveRegion = this.getLiveRegion();
				$liveRegion.text( '' );
				setTimeout( () => {
					$liveRegion.text( message );
				}, 100 );
			}

			bindEvents() {
				const elementSettings = this.getElementSettings();

				if ( 'yes' === elementSettings.equal_height ) {
					this.setEqualHeight();
				}

				if ( 'carousel' === elementSettings.layout ) {
					this.initSlider();
				}
				
				if ( 'grid' === elementSettings.layout && 'list' !== elementSettings.skin ) {
					this.setCategoriesCount( 1 );

					this.initNumberedPagination();

					this.initLoadMore();

					this.initInfiniteScroll();
				}
			}

			setEqualHeight() {
				const catBox = this.$element.find('.pp-category');
				let highestBox = 0;

				catBox.each(function () {
					if ( $(this).outerHeight() > highestBox) {
						highestBox = $(this).outerHeight();
					}
				});

				catBox.css( 'height', highestBox + 'px' );
			}

			initNumberedPagination() {
				const self = this;

				$('body').on( 'click', '.pp-categories-pagination-ajax .page-numbers', function(e) {
					let $scope = $(this).closest( '.elementor-widget-pp-categories' );

					if ( $scope.length <= 0 ) {
						return;
					}

					let lastItem  = $scope.find( '.pp-category' ).last(),
						container = $scope.find( '.pp-categories-grid-wrapper' ),
						pageID    = container.data('page');

					e.preventDefault();

					lastItem.after( '<div class="pp-category-loader" role="status" aria-live="polite"><div class="pp-loader"></div><div class="pp-loader-overlay"></div><span class="elementor-screen-only">' + ( ppCategoriesScript.i18n && ppCategoriesScript.i18n.loading ? ppCategoriesScript.i18n.loading : 'Loading…' ) + '</span></div>' );

					container.attr( 'aria-busy', 'true' );

					let pageNumber = 1,
						curr = parseInt( $scope.find( '.pp-categories-pagination .page-numbers.current' ).html() );

					if ( $(this).hasClass( 'next' ) ) {
						pageNumber = curr + 1;
					} else if ( $(this).hasClass( 'prev' ) ) {
						pageNumber = curr - 1;
					} else {
						pageNumber = $(this).html();
					}

					let $args = {
						'page_id':     pageID,
						'widget_id':   self.getID(),
						'page_number': pageNumber,
					};

					$('html, body').animate({
						scrollTop: ( ( $scope.find( '.pp-categories-grid' ).offset().top ) - 30 )
					}, 'slow');

					self.callAjax( self, $args );
				} );
			}

			initLoadMore() {
				const self = this;
				this.loadStatus = true;

				// Load More is a link with role="button": Enter clicks it natively, Space has to be wired.
				this.$element.off( 'keydown.ppLoadMore' ).on( 'keydown.ppLoadMore', '.pp-category-load-more', function(e) {
					if ( ' ' !== e.key || e.altKey || e.ctrlKey || e.metaKey ) {
						return;
					}

					e.preventDefault();

					if ( ! e.originalEvent || ! e.originalEvent.repeat ) {
						this.click();
					}
				} );

				$(document).on( 'click', '.pp-category-load-more', function(e) {

					e.preventDefault();

					let $scope = $(this).closest( '.elementor-widget-pp-categories' ),
						loader    = $scope.find( '.pp-categories-loader' ),
						pageCount = self.getCategoriesCount(),
						pageID    = $scope.find( '.pp-categories-grid-wrapper' ).data('page');

					if ( elementorFrontend.isEditMode() ) {
						loader.show();
						return false;
					}

					let $args = {
						'page_id':     pageID,
						'widget_id':   self.getID(),
						'page_number': ( pageCount + 1 ),
					};

					self.total = $scope.find( '.pp-categories-pagination' ).data( 'total' );

					if ( true == self.loadStatus ) {
						if ( pageCount < self.total ) {
							loader.show();
							loader.attr( { 'role': 'status', 'aria-live': 'polite', 'aria-hidden': 'false' } );
							$scope.find( '.pp-categories-grid-wrapper' ).attr( 'aria-busy', 'true' );
							$(this).hide();
							self.callAjax( self, $args, true, pageCount );
							pageCount++;
							self.loadStatus = false;
						}
					}
				} );
			}

			initInfiniteScroll() {
				let self   = this,
					count  = 1,
					loader = this.$element.find( '.pp-categories-loader' );

				this.loadStatus = true;

				if ( this.elements.$categoriesContainer.hasClass( 'pp-categories-infinite-scroll' ) ) {
					let windowHeight50 = jQuery(window).outerHeight() / 1.25;

					$(window).scroll( function () {
						if ( elementorFrontend.isEditMode() ) {
							loader.show();
							return false;
						}

						let $container = self.$element,
							$wrapper   = self.elements.$categoriesGrid,
							$lastItem  = $container.find( '.pp-category:last' );

						let $args = {
							'page_id':     $wrapper.data('page'),
							'widget_id':   self.getID(),
							'page_number': $container.find( '.page-numbers.current' ).next( 'a' ).html(),
						};

						self.total = $container.find( '.pp-categories-pagination' ).data( 'total' );

						if ( ( $(window).scrollTop() + windowHeight50 ) >= ( $lastItem.offset().top ) ) {
							if ( true == self.loadStatus ) {
								if ( count < self.total ) {
									loader.show();
									loader.attr( { 'role': 'status', 'aria-live': 'polite', 'aria-hidden': 'false' } );
									$container.attr( 'aria-busy', 'true' );
									self.callAjax( self, $args, true );
									count++;
									self.loadStatus = false;
								}
							}
						}
					} );
				}
			}

			setCategoriesCount(count) {
				this.$element.find( '.pp-category-load-more' ).attr( 'data-count', count );
			}

			getCategoriesCount() {
				return this.$element.find('.pp-category-load-more').data('count');
			}

			callAjax( self, $obj, $append, $count ) {
				let loader = this.$element.find( '.pp-categories-loader' );

				$.ajax({
					url: ppCategoriesScript.ajax_url,
					data: {
						action:      'pp_get_categories',
						page_id:     $obj.page_id,
						widget_id:   $obj.widget_id,
						page_number: $obj.page_number,
						nonce:       ppCategoriesScript.categories_nonce,
					},
					dataType: 'json',
					type: 'POST',
					success: function( data ) {
						let $container = self.elements.$categoriesContainer,
							sel = $container.find( '.pp-categories-grid-wrapper' );

						let not_found = $container.find( '.pp-categories-empty' );

						not_found.remove();

						if ( $(not_found).length == 0 ) {
							$(data.data.not_found).insertBefore(sel);
						}

						$container.find( '.pp-category-loader' ).remove();
						sel.attr( 'aria-busy', 'false' );

						let $newItems;

						if ( true == $append ) {
							let html_str = data.data.html;
							$newItems = $( html_str );
							sel.append( $newItems );
						} else {
							sel.html( data.data.html );
							$newItems = sel.find( '.pp-category' );
						}

						$container.find( '.pp-categories-pagination-wrap' ).html( data.data.pagination );

						//	Complete the process 'loadStatus'
						self.loadStatus = true;
						if ( true == $append ) {
							loader.hide();
							loader.attr( 'aria-hidden', 'true' );
							$container.find( '.pp-category-load-more' ).show();
						}

						self.setCategoriesCount( $obj.page_number );

						$count = $count + 1;

						if ( $count == self.total ) {
							$container.find( '.pp-category-load-more' ).hide();
						}

						const newCount = $newItems.length;
						const message = ( true == $append )
							? ( ppCategoriesScript.i18n && ppCategoriesScript.i18n.itemsLoaded
								? ppCategoriesScript.i18n.itemsLoaded.replace( '%d', newCount )
								: newCount + ' more categories loaded' )
							: ( ppCategoriesScript.i18n && ppCategoriesScript.i18n.pageLoaded
								? ppCategoriesScript.i18n.pageLoaded.replace( '%d', $obj.page_number )
								: 'Page ' + $obj.page_number + ' loaded' );

						self.announce( message );

						const $firstNewLink = $newItems.first().find( '.pp-category-link' );
						if ( $firstNewLink.length ) {
							$firstNewLink.attr( 'tabindex', '-1' ).trigger( 'focus' );
						}

						self.$element.trigger('posts.rendered', [self.$element]);
					}
				} ).done( function() {
					if ( self.$element.find( '.elementor-invisible' ).length > 0 ) {
						self.$element.find( '.elementor-invisible' ).removeClass( 'elementor-invisible' );
					}
				} );
			}
		}

		elementorFrontend.elementsHandler.attachHandler( 'pp-categories', CategoriesWidget );
	} );
})(jQuery);