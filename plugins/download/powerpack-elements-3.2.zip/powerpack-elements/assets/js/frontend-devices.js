(function ($) {
	$( window ).on( 'elementor/frontend/init', () => {
		class DevicesWidget extends elementorModules.frontend.handlers.Base {
			getDefaultSettings() {
				return {
					selectors: {
						outerWrap: '.pp-video',
						videoPlay: '.pp-video-play',
						videoOverlay: '.pp-video-overlay',
						playButton: '.pp-player-controls-play',
						screen: '.pp-device-screen',
						volumeBar: '.pp-player-controls-volume-bar',
						deviceContainer: '.pp-device-container',
						swiperContainer: '.pp-swiper-slider',
						swiperSlide: '.swiper-slide',
					},
				};
			}

			getDefaultElements() {
				const selectors = this.getSettings( 'selectors' );
				return {
					$outerWrap: this.$element.find( selectors.outerWrap ),
					$videoPlay: this.$element.find( selectors.videoPlay ),
					$videoOverlay: this.$element.find( selectors.videoOverlay ),
					$playButton: this.$element.find( selectors.playButton ),
					$screen: this.$element.find( selectors.screen ),
					$volumeBar: this.$element.find( selectors.volumeBar ),
					$deviceContainer: this.$element.find( selectors.deviceContainer ),
					$swiperContainer: this.$element.find( selectors.swiperContainer ),
					$swiperSlide: this.$element.find( selectors.swiperSlide ),
				};
			}

			getSliderSettings(prop) {
				const sliderSettings = ( undefined !== this.elements.$swiperContainer.data('slider-settings') ) ? this.elements.$swiperContainer.data('slider-settings') : '';

				if ( 'undefined' !== typeof prop && 'undefined' !== sliderSettings[prop] ) {
					return sliderSettings[prop];
				}

				return sliderSettings;
			}

			getI18n() {
				return ( 'undefined' !== typeof ppDevicesScript && ppDevicesScript.i18n ) ? ppDevicesScript.i18n : {};
			}

			prefersReducedMotion() {
				return !! ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches );
			}

			getNamespace() {
				return '.ppDevices' + this.getID();
			}

			getEffect() {
				return this.getSliderSettings('effect');
			}

			getSwiperOptions() {
				const sliderSettings = this.getSliderSettings();

				const swiperOptions = {
					grabCursor:              'yes' === sliderSettings.grab_cursor,
					// initialSlide:             this.getInitialSlide(),
					slidesPerView:            1,
					slidesPerGroup:           1,
					loop:                     'yes' === sliderSettings.loop,
					centeredSlides:           'yes' === sliderSettings.centered_slides,
					speed:                    sliderSettings.speed,
					autoHeight:               sliderSettings.auto_height,
					effect:                   this.getEffect(),
					preventClicksPropagation: false,
					slideToClickedSlide:      true,
					// Without the flag Swiper still runs its a11y module, in English.
					a11y: {
						enabled: false,
					},
				};

				/*
				 * The keyboard module rides along with the translated strings: it listens
				 * on the document, so it is only enabled where PHP asked for it.
				 */
				if ( 'yes' === sliderSettings.a11y ) {
					const i18n = this.getI18n();

					swiperOptions.a11y = {
						enabled:                    true,
						prevSlideMessage:           i18n.prevSlide || 'Previous slide',
						nextSlideMessage:           i18n.nextSlide || 'Next slide',
						firstSlideMessage:          i18n.firstSlide || 'This is the first slide',
						lastSlideMessage:           i18n.lastSlide || 'This is the last slide',
						paginationBulletMessage:    i18n.paginationBullet || 'Go to slide {{index}}',
						slideLabelMessage:          i18n.slideLabel || 'Slide {{index}} of {{slidesLength}}',
						slideRole:                  'group',
						itemRoleDescriptionMessage: i18n.slideRoleDescription || 'slide',
					};

					swiperOptions.keyboard = {
						enabled:        true,
						onlyInViewport: true,
					};
				}

				if ( 'fade' === this.getEffect() ) {
					swiperOptions.fadeEffect = {
						crossFade: true,
					};
				}

				if ( sliderSettings.show_arrows ) {
					var prevEle = ( this.isEdit ) ? '.elementor-swiper-button-prev' : '.swiper-button-prev-' + this.getID();
					var nextEle = ( this.isEdit ) ? '.elementor-swiper-button-next' : '.swiper-button-next-' + this.getID();

					swiperOptions.navigation = {
						prevEl: prevEle,
						nextEl: nextEle,
					};
				}

				if ( sliderSettings.pagination ) {
					var paginationEle = ( this.isEdit ) ? '.swiper-pagination' : '.swiper-pagination-' + this.getID();

					swiperOptions.pagination = {
						el: paginationEle,
						type: sliderSettings.pagination,
						clickable: true
					};
				}

				// Autoplay is decorative, so a system-level request for reduced motion always wins.
				if ( ! this.isEdit && sliderSettings.autoplay && ! this.prefersReducedMotion() ) {
					swiperOptions.autoplay = {
						delay: sliderSettings.autoplay_speed,
						disableOnInteraction: !!sliderSettings.pause_on_interaction
					};
				}

				return swiperOptions;
			}

			bindEvents() {
				this.initVideo();
				this.initHostedVideo();
				this.initAccessibility();

				const deviceSlider = this.$element.find('.pp-device-slider');

				if ( 0 !== deviceSlider.length ) {
					this.initSlider();
				}
			}

			makeKeyboardActivatable( $el ) {
				$el.each( function () {
					const $this = $( this );

					if ( ! $this.attr( 'tabindex' ) ) {
						$this.attr( 'tabindex', '0' );
					}
				} );

				$el.off( 'keydown.ppA11y' ).on( 'keydown.ppA11y', function ( e ) {
					if ( 'Enter' === e.key || ' ' === e.key || 'Spacebar' === e.key ) {
						e.preventDefault();
						$( this ).trigger( 'click' );
					}
				} );
			}

			initAccessibility() {
				const self = this;

				const $controlsBar = this.$element.find( '.pp-video-player-controls' );

				$controlsBar.on( 'focusin.ppA11y', function () {
					$( this ).css( 'opacity', 1 );
				} );

				$controlsBar.on( 'focusout.ppA11y', function ( e ) {
					if ( ! $.contains( this, e.relatedTarget ) && ! $( this ).is( ':hover' ) ) {
						$( this ).css( 'opacity', '' );
					}
				} );

				this.makeKeyboardActivatable( this.$element.find( '.pp-player-controls-play' ) );
				this.makeKeyboardActivatable( this.$element.find( '.pp-player-controls-rewind' ) );
				this.makeKeyboardActivatable( this.$element.find( '.pp-player-controls-volume-icon' ) );
				this.makeKeyboardActivatable( this.$element.find( '.pp-player-controls-fs' ) );
				this.makeKeyboardActivatable( this.$element.find( '.pp-device-orientation .fas.fa-mobile' ) );

				const $progress = this.$element.find( '.pp-player-controls-progress:not(.pp-player-controls-volume-bar)' );
				this.makeKeyboardActivatable( $progress );
				$progress.on( 'keydown.ppA11y', function ( e ) {
					const video = self.$element.find( '.pp-video-player-source' ).get( 0 );

					if ( ! video || ! video.duration ) {
						return;
					}

					let percentage = ( 100 * video.currentTime / video.duration ) || 0;

					if ( 'ArrowRight' === e.key || 'ArrowUp' === e.key ) {
						percentage = Math.min( 100, percentage + 5 );
					} else if ( 'ArrowLeft' === e.key || 'ArrowDown' === e.key ) {
						percentage = Math.max( 0, percentage - 5 );
					} else if ( 'Home' === e.key ) {
						percentage = 0;
					} else if ( 'End' === e.key ) {
						percentage = 100;
					} else {
						return;
					}

					e.preventDefault();
					self.seekToPercentage( percentage, video );
				} );

				const $volumeBar = this.elements.$volumeBar;
				this.makeKeyboardActivatable( $volumeBar );
				$volumeBar.on( 'keydown.ppA11y', function ( e ) {
					const video = self.$element.find( '.pp-video-player-source' ).get( 0 );

					if ( ! video ) {
						return;
					}

					let volume = video.volume || 0;

					if ( 'ArrowRight' === e.key || 'ArrowUp' === e.key ) {
						volume = Math.min( 1, volume + 0.05 );
					} else if ( 'ArrowLeft' === e.key || 'ArrowDown' === e.key ) {
						volume = Math.max( 0, volume - 0.05 );
					} else if ( 'Home' === e.key ) {
						volume = 0;
					} else if ( 'End' === e.key ) {
						volume = 1;
					} else {
						return;
					}

					e.preventDefault();
					self.setVolume( volume, video );
				} );
			}

			seekToPercentage( percentage, video ) {
				const maxduration = video.duration;

				video.currentTime = maxduration * percentage / 100;

				this.$element.find( '.pp-player-controls-progress-time.pp-player-control-progress-inner' ).css( 'width', percentage + '%' );

				const date = new Date( null );
				date.setSeconds( video.currentTime );
				const timeString = date.toISOString().substr( 11, 8 );

				this.$element.find( '.pp-player-controls-progress' ).attr( {
					'aria-valuenow': Math.round( percentage ),
					'aria-valuetext': timeString,
				} );
			}

			setVolume( volume, video ) {
				const percentage = 100 * volume;

				video.volume = volume;
				video.muted = 0 === volume;

				this.$element.find( '.pp-player-controls-volume-bar-amount.pp-player-control-progress-inner' ).css( 'width', percentage + '%' );
				this.elements.$volumeBar.attr( 'aria-valuenow', Math.round( percentage ) );

				const $volumeIcon = this.$element.find( '.pp-player-controls-volume-icon' );

				if ( 0 === volume ) {
					$volumeIcon.removeClass( 'fa-volume-up' ).addClass( 'fa-volume-mute' );
					$volumeIcon.attr( { 'aria-pressed': 'true', 'aria-label': 'Unmute' } );
				} else {
					$volumeIcon.removeClass( 'fa-volume-mute' ).addClass( 'fa-volume-up' );
					$volumeIcon.attr( { 'aria-pressed': 'false', 'aria-label': 'Mute' } );
				}
			}

			initVideo() {
				let self = this;

				this.elements.$videoPlay.off( 'click' ).on( 'click', function( e ) {
					e.preventDefault();

					const videoPlayer = $(this).find( '.pp-video-player' );

					self.videoPlay( videoPlayer, self.elements.$outerWrap );
				});

				if ( ! elementorFrontend.isEditMode() ) {
					if ( this.elements.$videoPlay.data( 'autoplay' ) == '1' ) {
						self.videoPlay( this.$element.find( '.pp-video-player' ), this.elements.$outerWrap );
					}
				}

				this.orientationControl();
			}

			videoPlay(selector, outerWrap) {
				var $iframe  = $( '<iframe/>' ),
					$vidSrc = selector.data( 'src' );

				if ( 0 === selector.find( 'iframe' ).length ) {
					if ( outerWrap.hasClass( 'pp-video-type-youtube' ) || outerWrap.hasClass( 'pp-video-type-vimeo' ) || outerWrap.hasClass( 'pp-video-type-dailymotion' ) ) {
						$iframe.attr( 'src', $vidSrc );
					}

					$iframe.attr( 'frameborder', '0' );
					$iframe.attr( 'allowfullscreen', '1' );
					$iframe.attr( 'allow', 'autoplay;encrypted-media;' );
					$iframe.attr( 'title', 'Video player' );
					selector.html( $iframe );

					if ( outerWrap.hasClass( 'pp-video-type-hosted' ) ) {
						var hostedVideoHtml = JSON.parse( outerWrap.data( 'hosted-html' ) );

						$iframe.on( 'load', function() {
							var hostedVideoIframe = $iframe.contents().find( 'body' );
							hostedVideoIframe.html( hostedVideoHtml );
							$iframe.contents().find( 'video' ).css( {"width":"100%", "height":"100%"} );
							$iframe.contents().find( 'video' ).attr( 'autoplay','autoplay' );
					   });
				   }
			   }
		  	}

			initHostedVideo() {
				const elementSettings = this.getElementSettings(),
					videoObj          = this.$element.find( '.pp-video-player-source' ),
					video             = videoObj.get(0),
					videoSource       = elementSettings.video_source,
					stopOthers        = elementSettings.stop_others;

				if ( 'yes' === stopOthers ) {
					$("video").on("play", function() {
						$("video").not(this).each(function(index, video) {
							var plybtn = $(video).parent().find('.pp-player-controls-play');
							plybtn.removeClass('pp-pause');
							plybtn.addClass('pp-play');
							video.pause();
						});
					});
				}

				// Player Controls
				this.playerControls(videoObj, video);

				if ( 'hosted' == videoSource ) {
					this.initHostedPlay(video);

					// Screen Play
					this.initScreenPlay(video);
				}
			}

			playerControls(videoObj, video) {
				const elementSettings = this.getElementSettings(),
					playbtn           = this.elements.$playButton,
					rewindbtn         = this.$element.find( '.pp-player-controls-rewind'),
					autoPlay          = elementSettings.autoplay,
					playback_speed    = elementSettings.playback_speed;

				// Get HTML5 video time duration
				videoObj.on('loadedmetadata', function() {
					if ( 'yes' === autoPlay ) {
						playbtn.first().trigger('click');
					}

					// Playback speed.
					video.playbackRate = playback_speed.size;
					var date = new Date(null);
					date.setSeconds(video.duration); // Specify value for SECONDS here
					var timeString = date.toISOString().substr(11, 8);
					this.$element.find( '.pp-player-controls-duration' ).text(timeString);
				}.bind(this));

				// Update HTML5 video current play time
				videoObj.on('timeupdate', function() {
					var currentPos = video.currentTime; //Get currenttime
					var maxduration = video.duration; //Get video duration
					var percentage = 100 * currentPos / maxduration; //in %
					this.$element.find( '.pp-player-control-progress-track.pp-player-control-progress-inner' ).css('width', percentage+'%');
					var date = new Date(null);
					date.setSeconds(video.currentTime); // specify value for SECONDS here
					var timeString = date.toISOString().substr(11, 8);
					this.$element.find( '.pp-player-controls-time' ).text(timeString);

					if ( video.currentTime === video.duration ) {
						this.elements.$screen.removeClass('pp-paused');
						this.elements.$screen.removeClass('pp-playing');
						playbtn.removeClass('pp-pause');
						playbtn.addClass('pp-play');

						if ( playbtn.hasClass( 'pp-play' ) ) {
							playbtn.find( '.fa-play, .e-fas-fa-play' ).show();
							playbtn.find( '.fa-pause, .e-fas-fa-pause' ).hide();
						} else {
							playbtn.find( '.fa-pause, .e-fas-fa-pause' ).show();
							playbtn.find( '.fa-play, .e-fas-fa-play' ).hide();
						}

						this.$element.find( '.pp-player-controls-time' ).text('00:00');
						this.$element.find( '.pp-player-control-progress-track.pp-player-control-progress-inner' ).css('width', '0%');
						this.elements.$videoOverlay.css('opacity', '');
						// is_playing = false;
					}
				}.bind(this));

				// On video play
				videoObj.on('play', function() {
					this.elements.$videoOverlay.css('opacity', '0');
				}.bind(this));

				// On video pause
				videoObj.on('pause', function() {
					this.$element.find( '.pp-player-controls-rewind.pp-video-button' ).show();
					this.elements.$videoOverlay.css('opacity', '');
				}.bind(this));

				// Mute
				this.$element.find( '.pp-player-controls-volume-icon' ).click( function() {
					if( $(this).hasClass('fa-volume-up') ){
						$(this).removeClass('fa-volume-up');
						$(this).addClass('fa-volume-mute');
					}
					else if( $(this).hasClass('fa-volume-mute') ){
						$(this).removeClass('fa-volume-mute');
						$(this).addClass('fa-volume-up');
					}
					video.muted = !video.muted;

					$(this).attr( {
						'aria-pressed': video.muted ? 'true' : 'false',
						'aria-label': video.muted ? 'Unmute' : 'Mute',
					} );

					return false;
				});

				// Volume bar
				var volumeDrag = false;   /* Drag status */
				this.elements.$volumeBar.mousedown( function(e) {
					volumeDrag = true;
					this.updateVolumeBar(e.pageX, video);
				}.bind(this));

				this.elements.$volumeBar.mouseup( function(e) {
					if(volumeDrag) {
						volumeDrag = false;
						this.updateVolumeBar(e.pageX, video);
					}
				}.bind(this));

				this.elements.$volumeBar.mousemove( function(e) {
					if(volumeDrag) {
						this.updateVolumeBar(e.pageX, video);
					}
				}.bind(this));

				// Rewind control
				rewindbtn.on('click', function() {
					video.currentTime = 0;
					return false;
				});

				var timeDrag = false;   /* Drag status */
				this.$element.find( '.pp-player-controls-progress' ).mousedown( function(e) {
					timeDrag = true;
					this.updatebar(e.pageX, video);
				}.bind(this));

				this.$element.find( '.pp-player-controls-progress' ).mouseup( function(e) {
					if(timeDrag) {
						timeDrag = false;
						this.updatebar(e.pageX, video);
					}
				}.bind(this));

				this.$element.find( '.pp-player-controls-progress' ).mousemove( function(e) {
					if(timeDrag) {
						this.updatebar(e.pageX, video);
					}
				}.bind(this));

				// Full screen control
				this.initFullScreen(video);
			}

			initHostedPlay(video) {
				const elementSettings = this.getElementSettings(),
					$screen           = this.elements.$screen,
					playbtn           = this.elements.$playButton;
				let restartOnPause = elementSettings.restart_on_pause;

				if ( 'yes' === restartOnPause ) {
					restartOnPause = true;
				}

				playbtn.on("click", function (e) {
					if ( $(this).hasClass('pp-play') ) {
						video.play();
						playbtn.removeClass('pp-play');
						playbtn.addClass('pp-pause');
						$screen.removeClass('pp-paused');
						$screen.addClass('pp-playing');
					}
					else if ( $(this).hasClass('pp-pause') ) {
						video.pause();
						playbtn.removeClass('pp-pause');
						playbtn.addClass('pp-play');
						$screen.removeClass('pp-playing');
						$screen.addClass('pp-paused');
						if ( restartOnPause ) {
							video.currentTime = 0;
						}
					}

					if ( playbtn.hasClass( 'pp-play' ) ) {
						playbtn.find( '.fa-play, .e-fas-fa-play' ).show();
						playbtn.find( '.fa-pause, .e-fas-fa-pause' ).hide();
						playbtn.attr( { 'aria-pressed': 'false', 'aria-label': 'Play video' } );
					} else {
						playbtn.find( '.fa-pause, .e-fas-fa-pause' ).show();
						playbtn.find( '.fa-play, .e-fas-fa-play' ).hide();
						playbtn.attr( { 'aria-pressed': 'true', 'aria-label': 'Pause video' } );
					}

					return false;
				});
			}

			initScreenPlay(video) {
				const elementSettings = this.getElementSettings(),
					$screen           = this.elements.$screen,
					playbtn           = this.elements.$playButton,
					show_buttons      = elementSettings.video_show_buttons;
				let is_playing = false;
				
				if ( 'show' === show_buttons ) {
					return;
				}

				$screen.on('click', function (e) {
					if ( $(this).hasClass('pp-device-screen-video') ) {
						if ( !is_playing ) {
							video.play();
							$screen.removeClass('pp-paused');
							$screen.addClass('pp-playing');
							playbtn.removeClass('pp-play');
							playbtn.addClass('pp-pause');
							playbtn.attr( { 'aria-pressed': 'true', 'aria-label': 'Pause video' } );
							is_playing = true;
							return;
						}

						if ( is_playing ) {
							video.pause();
							$screen.removeClass('pp-playing');
							$screen.addClass('pp-paused');
							playbtn.removeClass('pp-pause');
							playbtn.addClass('pp-play');
							playbtn.attr( { 'aria-pressed': 'false', 'aria-label': 'Play video' } );
							is_playing = false;
							return;
						}

						if ( playbtn.hasClass( 'pp-play' ) ) {
							playbtn.find( '.fa-play, .e-fas-fa-play' ).show();
							playbtn.find( '.fa-pause, .e-fas-fa-pause' ).hide();
							playbtn.attr( { 'aria-pressed': 'false', 'aria-label': 'Play video' } );
						} else {
							playbtn.find( '.fa-pause, .e-fas-fa-pause' ).show();
							playbtn.find( '.fa-play, .e-fas-fa-play' ).hide();
							playbtn.attr( { 'aria-pressed': 'true', 'aria-label': 'Pause video' } );
						}
					}
				});
			}

			initFullScreen(video) {
				const fsControl = this.$element.find( '.pp-player-controls-fs');

				fsControl.on('click', function() {
					if ( video.requestFullscreen ) {
						video.requestFullscreen();
					} else if ( video.webkitRequestFullscreen ) {
						video.webkitRequestFullscreen();
					} else if ( video.webkitEnterFullscreen ) {
						video.webkitEnterFullscreen();
					} else if ( video.mozRequestFullScreen ) {
						video.mozRequestFullScreen();
					} else if ( video.msRequestFullscreen ) {
						video.msRequestFullscreen();
					} else {
						alert('Your browser doesn\'t support fullscreen');
					}
				});
			}

			updateVolumeBar(x, video) {
				var volumebar = this.elements.$volumeBar;

				var position = x - volumebar.offset().left; // Click pos
				var volume = position / volumebar.width();
				var percentage = 100 * volume; // In %

				// Check within range
				if (volume > 1) {
					volume = 1;
					percentage = 100;
				}

				if (volume < 0) {
					volume = 0;
					percentage = 0;
				}

				// Update volume
				video.volume = volume;
				this.$element.find( '.pp-player-controls-volume-bar-amount.pp-player-control-progress-inner' ).css('width', percentage+'%');
				volumebar.attr( 'aria-valuenow', Math.round( percentage ) );
			}

			updatebar(x, video) {
				const elementSettings = this.getElementSettings();
				const end_at_last_frame = elementSettings.end_at_last_frame;
				const progress = this.$element.find( '.pp-player-controls-progress' );
				const maxduration = video.duration; // Video duraiton
				const position = x - progress.offset().left; // Click pos
				let percentage = 100 * position / progress.width();

				// Check within range
				if ( percentage > 100 ) {
					percentage = 100;
				}

				if ( percentage < 0 ) {
					percentage = 0;
				}

				// Update progress bar and video currenttime
				video.currentTime = maxduration * percentage / 100;
				this.$element.find( '.pp-player-controls-progress-time.pp-player-control-progress-inner' ).css('width', percentage+'%');

				const barDate = new Date( null );
				barDate.setSeconds( video.currentTime );
				progress.attr( {
					'aria-valuenow': Math.round( percentage ),
					'aria-valuetext': barDate.toISOString().substr( 11, 8 ),
				} );

				if ( 'yes' === end_at_last_frame && 'yes' !== loop ) {
					if ( 100 === percentage ){
						this.elements.$playButton.removeClass('pp-pause');
						this.elements.$playButton.addClass('pp-play');
					}
				}
			}

			orientationControl() {
				const self = this;
				let orientationControl = this.$element.find( '.pp-device-orientation .fas.fa-mobile' );

				orientationControl.click( function(e) {
					if ( $(this).hasClass( 'pp-mobile-icon-portrait' ) ){
						self.elements.$deviceContainer.removeClass( 'pp-device-orientation-portrait' );
						self.elements.$deviceContainer.addClass( 'pp-device-orientation-landscape' );
						$(this).removeClass( 'pp-mobile-icon-portrait' );
						$(this).addClass( 'pp-mobile-icon-landscape' );
						$(this).attr( 'aria-label', self.getI18n().portraitOrientation || 'Switch to portrait orientation' );
					}
					else if ( $(this).hasClass( 'pp-mobile-icon-landscape' ) ){
						self.elements.$deviceContainer.removeClass( 'pp-device-orientation-landscape' );
						self.elements.$deviceContainer.addClass( 'pp-device-orientation-portrait' );
						$(this).addClass( 'pp-mobile-icon-portrait' );
						$(this).removeClass( 'pp-mobile-icon-landscape' );
						$(this).attr( 'aria-label', self.getI18n().landscapeOrientation || 'Switch to landscape orientation' );
					}
				});
			}

			async initSlider() {
				const elementSettings = this.getElementSettings();

				// Read before Swiper adds its loop clones.
				this.slidesTotal = this.elements.$swiperSlide.length;

				const Swiper = elementorFrontend.utils.swiper;
				this.swiper = await new Swiper( this.elements.$swiperContainer, this.getSwiperOptions() );

				this.initSliderAccessibility( elementSettings );

				// this.setEqualHeight();
			}

			/**
			 * Everything the slider needs once Swiper is up: what screen readers can
			 * reach, what they are told, and the ways the visitor can stop the autoplay.
			 */
			initSliderAccessibility( elementSettings ) {
				const ns = this.getNamespace(),
					sliderSettings = this.getSliderSettings(),
					$wrap = this.$element.find( '.swiper-container-wrap' ),
					$status = $wrap.children( '.elementor-screen-only[aria-live]' );

				this.syncSlideVisibility();

				this.swiper.on( 'slideChangeTransitionEnd resize', () => {
					this.syncSlideVisibility();
				} );

				// Autoplay must not speak. An announcement answers the visitor having moved the slider.
				this.userNavigated = false;

				/*
				 * Swiper emits navigationNext/navigationPrev only after the slide has
				 * changed, so a flag set from those is one press behind. Marking the
				 * intent on the way down, in the capture phase, gets there first.
				 */
				this.onNavigationIntent = ( e ) => {
					const onControl = e.target.closest && e.target.closest( '.pp-slider-arrow, .swiper-pagination-bullet' );

					if ( 'keydown' === e.type ) {
						const isArrowKey   = ( 'ArrowLeft' === e.key || 'ArrowRight' === e.key ),
							isActivation = onControl && ( 'Enter' === e.key || ' ' === e.key );

						if ( ! isArrowKey && ! isActivation ) {
							return;
						}
					} else if ( ! onControl ) {
						return;
					}

					this.markNavigated( sliderSettings );
				};

				if ( $wrap[0] ) {
					$wrap[0].addEventListener( 'pointerdown', this.onNavigationIntent, true );
					$wrap[0].addEventListener( 'keydown', this.onNavigationIntent, true );
				}

				// A swipe is deliberate too, and touchEnd lands before the transition.
				this.swiper.on( 'touchEnd', () => {
					this.markNavigated( sliderSettings );
				} );

				if ( $status.length ) {
					/*
					 * The arrows keep Swiper's aria-controls; the status region only
					 * describes the result. Swiper also makes the slides wrapper a live
					 * region, which would read the new slide a second time.
					 */
					this.$element.find( '.pp-slider-arrow' ).attr( 'aria-describedby', $status.attr( 'id' ) );

					if ( this.swiper.$wrapperEl ) {
						this.swiper.$wrapperEl.attr( 'aria-live', 'off' );
					}

					this.swiper.on( 'slideChange', () => {
						if ( ! this.userNavigated ) {
							return;
						}

						this.userNavigated = false;

						const format = this.getI18n().slideStatus || 'Showing Slide %1$s of %2$s';

						$status.text(
							format
								.replace( '%1$s', this.swiper.realIndex + 1 )
								.replace( '%2$s', this.slidesTotal )
						);
					} );
				}

				/*
				 * params.autoplay.enabled, not the widget setting: it is true only where the
				 * autoplay actually started, so never in the editor and never once reduced
				 * motion has held it back. autoplay.start() has no such guard.
				 */
				if ( ! this.swiper.params.autoplay || ! this.swiper.params.autoplay.enabled ) {
					return;
				}

				let hovered = false,
					focused = false;

				const update = () => {
					if ( ! this.swiper || this.swiper.destroyed || ! this.swiper.autoplay ) {
						return;
					}

					if ( this.autoplayHalted || ( hovered && 'yes' === elementSettings.pause_on_hover ) || focused ) {
						this.swiper.autoplay.stop();
					} else {
						this.swiper.autoplay.start();
					}
				};

				this.updateAutoplay = update;

				$wrap
					.on( 'mouseenter' + ns, () => {
						hovered = true;
						update();
					} )
					.on( 'mouseleave' + ns, () => {
						hovered = false;
						update();
					} )
					// The keyboard equivalent of the hover pause, so it applies whatever Pause on Hover says.
					.on( 'focusin' + ns, () => {
						focused = true;
						update();
					} )
					.on( 'focusout' + ns, ( e ) => {
						// Moving between two controls inside the slider is not leaving it.
						if ( e.relatedTarget && $wrap[0].contains( e.relatedTarget ) ) {
							return;
						}

						focused = false;
						update();
					} );
			}

			markNavigated( sliderSettings ) {
				this.userNavigated = true;

				// Pause on Interaction: the first deliberate move ends the autoplay for good,
				// so leaving the slider must not start it again.
				if ( 'yes' === sliderSettings.pause_on_interaction ) {
					this.autoplayHalted = true;

					if ( this.updateAutoplay ) {
						this.updateAutoplay();
					}
				}
			}

			/**
			 * Off-screen slides, and the loop clones that repeat every image, leave the
			 * accessibility tree. The fade effect stacks every slide in one place, so
			 * without this all of them are read out at once.
			 */
			syncSlideVisibility() {
				if ( ! this.swiper || ! this.swiper.slides ) {
					return;
				}

				const active = this.swiper.slides[ this.swiper.activeIndex ];

				$( this.swiper.slides ).each( function () {
					if ( this === active ) {
						this.removeAttribute( 'aria-hidden' );
						this.removeAttribute( 'inert' );
					} else {
						this.setAttribute( 'aria-hidden', 'true' );
						this.setAttribute( 'inert', '' );
					}
				} );
			}

			onDestroy() {
				const $wrap = this.$element.find( '.swiper-container-wrap' );

				$wrap.off( this.getNamespace() );

				if ( this.onNavigationIntent && $wrap[0] ) {
					$wrap[0].removeEventListener( 'pointerdown', this.onNavigationIntent, true );
					$wrap[0].removeEventListener( 'keydown', this.onNavigationIntent, true );
				}

				if ( this.swiper && 'function' === typeof this.swiper.destroy ) {
					this.swiper.destroy( true, true );
					this.swiper = null;
				}

				if ( super.onDestroy ) {
					super.onDestroy();
				}
			}

			setEqualHeight() {
				let height = 0;

				this.elements.$swiperSlide.each(function () {
					if ( $(this).height() > height) {
						height = $(this).height();
					}
				});

				this.elements.$swiperContainer.css( 'height', (height + 70) + 'px' );
			}
		}

		elementorFrontend.elementsHandler.attachHandler( 'pp-devices', DevicesWidget );
	} );
})(jQuery);