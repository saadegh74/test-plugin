/**
 * Site Builder header states.
 *
 * Keeps data-pp-state on the header current: "top" or "scrolled", plus
 * "hidden" while it is tucked away on scroll down. Every visual change keys
 * off that attribute in CSS, including the styles set in the editor, so this
 * only decides which state applies and never styles anything itself.
 *
 * Sticky uses position: sticky, which holds the header's place in the page
 * and so cannot shift the layout. It falls back to position: fixed with a
 * spacer only where an ancestor's overflow would stop sticky from working,
 * and a transparent header is always fixed because it is meant to sit over
 * the content rather than push it down.
 *
 * @since x.x.x
 */
( function () {
	'use strict';

	var header = document.querySelector( '.pp-site-header[data-pp-offset]' );

	if ( ! header || ! window.requestAnimationFrame ) {
		return;
	}

	var root = document.documentElement;
	var stickyOn = ( header.getAttribute( 'data-pp-sticky-on' ) || '' ).split( ' ' );
	var hideOnScroll = header.hasAttribute( 'data-pp-hide-on-scroll' );
	var transparent = header.hasAttribute( 'data-pp-transparent' );
	var offset = parseFloat( header.getAttribute( 'data-pp-offset' ) ) || 0;
	var breakpoints = ( header.getAttribute( 'data-pp-breakpoints' ) || '767 1024' ).split( ' ' );

	// Ignore scroll jitter smaller than this, in px, when deciding direction.
	var DELTA = 6;

	var lastY = window.pageYOffset;
	var hidden = false;
	var focused = false;
	var sticky = false;
	var spacer = null;
	var ticking = false;

	function currentDevice() {
		var width = window.innerWidth;

		if ( width <= parseFloat( breakpoints[ 0 ] ) ) {
			return 'mobile';
		}

		return width <= parseFloat( breakpoints[ 1 ] ) ? 'tablet' : 'desktop';
	}

	/**
	 * Whether an ancestor is a scroll container, which turns sticky into static.
	 *
	 * Not "clip": it cuts off overflow without making a scroll container, and
	 * themes set overflow-x: clip on their wrapper precisely so sticky still works.
	 *
	 * @return {boolean} True when sticky would not stick.
	 */
	function stickyIsBlocked() {
		for ( var node = header.parentElement; node && node !== document.body; node = node.parentElement ) {
			var style = window.getComputedStyle( node );

			if ( /(auto|scroll|hidden)/.test( style.overflow + style.overflowX + style.overflowY ) ) {
				return true;
			}
		}

		return false;
	}

	function measure() {
		var height = header.offsetHeight;

		// Read by the scroll-padding rule, so in-page links and focus land below the header.
		root.style.setProperty( '--pp-header-height', height + 'px' );

		// The spacer holds the full header height; measuring once shrunk would let the page jump.
		if ( spacer && ! /scrolled/.test( header.getAttribute( 'data-pp-state' ) ) ) {
			spacer.style.height = height + 'px';
		}
	}

	function layout() {
		sticky = -1 !== stickyOn.indexOf( currentDevice() );

		var fixed = sticky && ( transparent || stickyIsBlocked() );

		// A transparent header is meant to overlap the content, so only an opaque one needs its space held.
		var needsSpacer = fixed && ! transparent;

		toggleClass( header, 'is-sticky', sticky && ! fixed );
		toggleClass( header, 'is-fixed', fixed );
		toggleClass( root, 'pp-has-sticky-header', sticky );

		if ( needsSpacer && ! spacer ) {
			spacer = document.createElement( 'div' );
			spacer.className = 'pp-site-header-spacer';
			spacer.setAttribute( 'aria-hidden', 'true' );
			header.parentNode.insertBefore( spacer, header.nextSibling );
		} else if ( ! needsSpacer && spacer ) {
			spacer.parentNode.removeChild( spacer );
			spacer = null;
		}

		measure();
		update();
	}

	function update() {
		ticking = false;

		var y = window.pageYOffset;
		var scrolled = y > offset;

		if ( ! hideOnScroll || ! sticky || ! scrolled || focused ) {
			hidden = false;
		} else if ( y > lastY + DELTA ) {
			hidden = true;
		} else if ( y < lastY - DELTA ) {
			hidden = false;
		}

		if ( Math.abs( y - lastY ) > DELTA || ! scrolled ) {
			lastY = y;
		}

		var state = ( scrolled ? 'scrolled' : 'top' ) + ( hidden ? ' hidden' : '' );

		if ( header.getAttribute( 'data-pp-state' ) !== state ) {
			header.setAttribute( 'data-pp-state', state );
		}
	}

	function requestUpdate() {
		if ( ! ticking ) {
			ticking = true;
			window.requestAnimationFrame( update );
		}
	}

	function toggleClass( element, name, on ) {
		if ( on ) {
			element.classList.add( name );
		} else {
			element.classList.remove( name );
		}
	}

	// A hidden header comes back the moment keyboard focus moves into it.
	header.addEventListener( 'focusin', function () {
		focused = true;
		update();
	} );

	header.addEventListener( 'focusout', function ( event ) {
		if ( ! header.contains( event.relatedTarget ) ) {
			focused = false;
		}
	} );

	var resizeTimer;

	window.addEventListener( 'scroll', requestUpdate, { passive: true } );
	window.addEventListener( 'resize', function () {
		clearTimeout( resizeTimer );
		resizeTimer = setTimeout( layout, 150 );
	} );

	// Images and web fonts change the height after load; keep the spacer and scroll padding honest.
	if ( window.ResizeObserver ) {
		new window.ResizeObserver( measure ).observe( header );
	} else {
		window.addEventListener( 'load', measure );
	}

	layout();
}() );
