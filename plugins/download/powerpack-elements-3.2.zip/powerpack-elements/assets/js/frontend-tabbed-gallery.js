(function ($) {
	$( window ).on( 'elementor/frontend/init', () => {
		/*
		 * The carousel is PPCarouselBase (frontend-carousel-base.js): Swiper options,
		 * reduced motion, autoplay pauses and slide visibility. This handler adds the
		 * group tabs, their announcement and the lightbox.
		 */
		class TabbedGalleryWidget extends window.PPCarouselBase {
			getSwiperOptions() {
				const swiperOptions = super.getSwiperOptions();

				// Groups are shown and hidden with the tabs, so Swiper re-measures on DOM changes.
				swiperOptions.observer       = true;
				swiperOptions.observeParents = true;

				// The tabs jump across groups, so the travel is removed too, not only autoplay.
				if ( this.isMotionReduced() ) {
					swiperOptions.speed = 0;
				}

				return swiperOptions;
			}

			/*
			 * This carousel speaks in groups, not slide numbers: announceGroup() writes
			 * "Showing Landscapes" when the tab changes. A second, positional message in
			 * the same region would talk over it, so the base announcement is off.
			 */
			getStatusElement() {
				return $();
			}

			afterSliderInit() {
				this.initTabs();
				this.initFancybox();
			}
			initTabs() {
				let tabsNav = this.$element.find( '.pp-gallery-filters .pp-gallery-filter' ),
					self = this;
				const sliderOptions = this.getSwiperOptions();
				const sliderSettings = this.getSliderSettings();

				this.setActiveTab( tabsNav, tabsNav.eq(0) );

				if ( 'undefined' !== typeof this.swiper ) {
					this.swiper.on( 'slideChange', function () {
						var currentSlide = self.$element.find( '.swiper-slide.swiper-slide-active' ).data( 'swiper-slide-index' );
						var nextSlide    = self.$element.find( '.swiper-slide.swiper-slide-next' ).data( 'swiper-slide-index' );

						var tabGroupCurrent = tabsNav.eq( currentSlide ).data('group'),
							tabGroupNext    = tabsNav.eq( nextSlide ).data('group');

						if ( tabGroupCurrent !== tabGroupNext ) {
							var $group = tabsNav.eq( nextSlide ).data('group');
							self.setActiveTab( tabsNav, tabsNav.filter('[data-group="' + $group + '"]') );
						}
					});

					// Spacers carry the same class for index parity, but only the real
					// buttons are interactive.
					tabsNav.filter( '[role="button"]' ).on( 'click', function ( e ) {
						e.preventDefault();

						var currentSlide;

						if ( ( $( window ).width() <= 480 ) && sliderSettings.slides_per_view_mobile <= 2 ) {
							currentSlide = $(this).data('index') + parseInt( sliderSettings.slides_per_view_mobile );
						} else if ( ( $( window ).width() <= 768 ) && sliderSettings.slides_per_view_tablet <= 2 ) {
							currentSlide = $(this).data('index') + parseInt( sliderSettings.slides_per_view_tablet );
						} else {
							currentSlide = $(this).data('index') + parseInt( sliderOptions.slidesPerView );
						}

						self.setActiveTab( tabsNav, $(this) );

						self.swiper.slideTo( currentSlide );
					});

					// The filters carry role="button", so Enter and Space have to be
					// wired up by hand; Left/Right move between them as expected of a
					// button group.
					tabsNav.filter( '[role="button"]' ).on( 'keydown', function ( e ) {
						if ( 'Enter' === e.key || ' ' === e.key || 'Spacebar' === e.key ) {
							// Space would scroll the page.
							e.preventDefault();
							$( this ).trigger( 'click' );
							return;
						}

						if ( 'ArrowRight' !== e.key && 'ArrowLeft' !== e.key ) {
							return;
						}

						e.preventDefault();

						const buttons = tabsNav.filter( '[role="button"]' ),
							index     = buttons.index( this ),
							next      = ( 'ArrowRight' === e.key ) ? index + 1 : index - 1;

						buttons.eq( ( next + buttons.length ) % buttons.length ).trigger( 'focus' ).trigger( 'click' );
					});
				}
			}

			setActiveTab( tabsNav, $active ) {
				tabsNav.removeClass( 'pp-active-slide' );
				tabsNav.filter( '[role="button"]' ).attr( 'aria-current', 'false' );

				$active.addClass( 'pp-active-slide' );
				$active.filter( '[role="button"]' ).attr( 'aria-current', 'true' );

				this.announceGroup( $active.filter( '[role="button"]' ).first() );
			}

			/**
			 * Announce the group change. Tab activation and swiping both bypass
			 * Swiper's own navigation notifications, so nothing else reports it.
			 */
			announceGroup( $button ) {
				const $status = this.$element.find( '.pp-tabbed-gallery-status' );

				if ( ! $status.length || ! $button.length ) {
					return;
				}

				const i18n = this.getI18n(),
					format = i18n.status || 'Showing %s',
					label  = $.trim( $button.find( '.pp-gallery-filter-label' ).text() );

				if ( '' === label ) {
					return;
				}

				$status.text( format.replace( '%s', label ) );
			}

			initFancybox() {
				// The class and the data-fancybox value both have to match what
				// render_gallery_items() actually prints.
				const sliderId       = 'pp-tabbed-gallery-' + this.getID(),
					lightboxSelector = '.swiper-slide:not(.swiper-slide-duplicate) .pp-tabbed-gallery-item-link[data-fancybox="' + sliderId + '"]';

				if ( $(lightboxSelector).length > 0 ) {
					$(lightboxSelector).fancybox({
						loop: true
					} );
				}
			}
		}

		elementorFrontend.elementsHandler.attachHandler( 'pp-tabbed-gallery', TabbedGalleryWidget );
	} );
})(jQuery);