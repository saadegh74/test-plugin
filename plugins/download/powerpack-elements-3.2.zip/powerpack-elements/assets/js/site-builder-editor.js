/**
 * Site Builder header states in the Elementor editor.
 *
 * The state styles are written against an ancestor carrying data-pp-state,
 * which on the site is the <header>. The preview has no <header> around the
 * template, so its body takes the attributes instead, following the Preview
 * control and the Transparent at Top switch.
 *
 * @since x.x.x
 */
( function ( $ ) {
	'use strict';

	var WATCHED = [ 'pp_preview_state', 'pp_transparent' ];

	function apply() {
		var current = elementor.documents.getCurrent();

		if ( ! current || 'pp-header' !== current.config.type || ! elementor.$previewContents ) {
			return;
		}

		var settings = elementor.settings.page.model;
		var body = elementor.$previewContents.find( 'body' );

		body.attr( 'data-pp-state', settings.get( 'pp_preview_state' ) || 'top' );

		if ( 'yes' === settings.get( 'pp_transparent' ) ) {
			body.attr( 'data-pp-transparent', '' );
		} else {
			body.removeAttr( 'data-pp-transparent' );
		}
	}

	$( window ).on( 'elementor:init', function () {
		// Each document gets a fresh settings module, so register again whenever one loads.
		elementor.on( 'preview:loaded', function () {
			WATCHED.forEach( function ( key ) {
				elementor.settings.page.addChangeCallback( key, apply );
			} );

			apply();
		} );
	} );
}( jQuery ) );
