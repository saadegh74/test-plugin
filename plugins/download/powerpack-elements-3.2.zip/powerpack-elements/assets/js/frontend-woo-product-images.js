( function( $ ) {
	$( window ).on( 'elementor/frontend/init', () => {

		/*
		 * WooCommerce starts every product gallery on the page once, on document
		 * ready. A gallery the editor renders after that, when a setting changes,
		 * would sit there with no slider, zoom or lightbox, so it is started here.
		 * Only in the editor: on the live site WooCommerce's own pass covers it.
		 */
		class WooProductImagesWidget extends elementorModules.frontend.handlers.Base {

			getDefaultSettings() {
				return {
					selectors: {
						gallery: '.woocommerce-product-gallery',
					},
				};
			}

			onInit() {
				super.onInit();

				if ( ! elementorFrontend.isEditMode() || 'function' !== typeof $.fn.wc_product_gallery ) {
					return;
				}

				// After WooCommerce's own ready pass, which marks each gallery it starts.
				$( () => {
					this.$element.find( this.getSettings( 'selectors.gallery' ) ).each( function() {
						if ( ! $( this ).data( 'product_gallery' ) ) {
							$( this ).wc_product_gallery();
						}
					} );
				} );
			}
		}

		elementorFrontend.elementsHandler.attachHandler( 'pp-woo-product-images', WooProductImagesWidget );
	} );

}( jQuery ) );
