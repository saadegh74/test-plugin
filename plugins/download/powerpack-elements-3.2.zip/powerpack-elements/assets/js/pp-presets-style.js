( function() {
	jQuery( window ).on( 'elementor:init', function() {

		var preset_data = elementor.modules.controls.BaseData.extend({

			isPpPreset: function() {
				return "presets_options" === this.model.get( "name" ) && 0 === this.getWidgetName().indexOf( "pp-" );
			},
			getWidgetName: function() {
				return this.container.settings.get( "widgetType" );
			},
			getPresets: function() {
				return pp_presets.presets[ this.getWidgetName() ] || {};
			},
			onBaseInputChange: function( event ) {
				if ( ! this.isPpPreset() ) {
					this.constructor.__super__.onBaseInputChange.apply( this, arguments );
					return;
				}

				event.stopPropagation();

				var preset_name = event.currentTarget.value,
					preset = this.getPresets()[ preset_name ];

				// The placeholder isn't a preset, so keep showing the one that's applied.
				if ( ! preset ) {
					event.currentTarget.value = this.getControlValue();
					return;
				}

				// Close any edit still in its debounce window, so merging can't lose its values.
				$e.internal( "document/history/end-transaction" );

				// One log, so a single undo reverts the reset and every preset value.
				var history_id = $e.internal( "document/history/start-log", {
					type: "change",
					title: this.model.get( "label" )
				} );

				try {
					var links_changed = this.applyPresets( preset, preset_name );

					// Settings commands are debounced, so close them while this log is still open.
					$e.internal( "document/history/end-transaction" );
					$e.internal( "document/history/end-log", { id: history_id } );

					// No change event fires when the stored value stays the same, as with Reset to Default.
					event.currentTarget.value = this.getControlValue();
				} catch ( error ) {
					$e.internal( "document/history/delete-log", { id: history_id } );
					throw error;
				}

				if ( links_changed ) {
					this.refreshPanel();
				}
			},
			/**
			 * Redraw the panel so the colour controls show their global links as they now are.
			 * Elementor's Paste Style does the same, since the controls don't follow __globals__.
			 *
			 * @since x.x.x
			 */
			refreshPanel: function() {
				var container = this.container,
					control_view;

				container.panel.refresh();

				// The redraw replaces this control, so put focus back on the new dropdown.
				control_view = container.panel.getControlView( this.model.get( "name" ) );

				if ( control_view ) {
					control_view.$el.find( "select" ).trigger( "focus" );
				}
			},
			applyPresets: function( preset, preset_name ) {
				var current_widget = this,
					container = this.container,
					settings = container.settings,
					presets = this.getPresets(),
					// Content as the user left it, before the reset below can touch it.
					content_before_reset = _.clone( settings.attributes ),
					links_changed = this.unlinkGlobals( container ) || ! _.isEmpty( preset.__globals__ ),
					new_settings = {};

				$e.run( "document/elements/reset-style", { container: container } );

				_.each( settings.controls, function( control, name ) {
					var value = preset[ name ];

					if ( current_widget.model.get( "name" ) === name || control.is_repeater ) {
						return;
					}

					if ( current_widget.isContentTransferControl( control ) ) {
						value = current_widget.getContentValue( control, content_before_reset[ name ], value, _.pluck( presets, name ) );
					}

					if ( ! _.isUndefined( value ) && ! _.isEqual( value, settings.get( name ) ) ) {
						new_settings[ name ] = value;
					}
				} );

				// Reset to Default leaves no preset applied, and the reset above already cleared the value.
				if ( "default" !== preset_name ) {
					new_settings[ this.model.get( "name" ) ] = preset_name;
				}

				if ( ! _.isEmpty( new_settings ) ) {
					$e.run( "document/elements/settings", {
						container: container,
						settings: new_settings,
						options: { external: true }
					} );
				}

				// Links to the kit's global colours, applied the way Elementor's Paste Style does.
				// The plain value stays as well, and shows if the link is removed.
				if ( ! _.isEmpty( preset.__globals__ ) ) {
					// Merged with the settings above, the links would lose their own undo step.
					$e.internal( "document/history/end-transaction" );

					$e.run( "document/globals/settings", {
						container: container,
						settings: preset.__globals__,
						options: { external: true }
					} );

					// The preview CSS only uses a global colour Elementor has fetched, which picking
					// it in the panel does but setting it here does not. Fetch, then rebuild the CSS.
					Promise.all( _.map( _.uniq( _.values( preset.__globals__ ) ), function( global_key ) {
						var global_args = $e.data.commandExtractArgs( global_key );

						return $e.data.get( global_args.command, global_args.args.query );
					} ) ).then( function() {
						container.renderUI();
					} );
				}

				_.each( settings.controls, function( control, name ) {
					if ( control.is_repeater && ! _.isUndefined( preset[ name ] ) && current_widget.applyRepeaterPreset( name, preset[ name ] ) ) {
						links_changed = true;
					}
				} );

				return links_changed;
			},
			applyRepeaterPreset: function( name, preset_rows ) {
				var current_widget = this,
					container = this.container,
					presets = this.getPresets(),
					links_removed = false;

				container.settings.get( name ).each( function( row, index ) {
					var preset_row = current_widget.getPresetRow( preset_rows, index ),
						row_settings = {};

					_.each( row.controls, function( field, field_name ) {
						var value = row.get( field_name );

						if ( current_widget.isStyleTransferControl( field ) ) {
							value = _.isUndefined( preset_row[ field_name ] ) ? field.default : preset_row[ field_name ];
						} else {
							value = current_widget.getContentValue( field, value, preset_row[ field_name ], _.map( presets, function( other_preset ) {
								return current_widget.getPresetRow( other_preset[ name ], index )[ field_name ];
							} ) );
						}

						if ( ! _.isEqual( value, row.get( field_name ) ) ) {
							row_settings[ field_name ] = value;
						}
					} );

					// A global colour outranks the value, so the preset's colour would not show.
					if ( current_widget.unlinkGlobals( container.repeaters[ name ].children[ index ] ) ) {
						links_removed = true;
					}

					if ( ! _.isEmpty( row_settings ) ) {
						$e.run( "document/elements/settings", {
							container: container.repeaters[ name ].children[ index ],
							settings: row_settings,
							options: { external: true }
						} );
					}
				} );

				return links_removed;
			},
			/**
			 * Remove an element's global colour links.
			 *
			 * Reset Style only empties __globals__ in the settings. The colour controls,
			 * the preview and the next global change all read container.globals, which
			 * would keep the old links, so clear both through Elementor's own command.
			 *
			 * @since x.x.x
			 *
			 * @param {Object} container Widget or repeater row.
			 * @return {boolean} Whether there were links to remove.
			 */
			unlinkGlobals: function( container ) {
				if ( _.isEmpty( _.compact( _.values( container.globals.toJSON() ) ) ) ) {
					return false;
				}

				$e.run( "document/globals/settings", {
					container: container,
					settings: {},
					options: { external: true }
				} );

				// The command is debounced; record it now so undo restores it after the reset.
				$e.internal( "document/history/end-transaction" );

				return true;
			},
			// Rows beyond the preset's own repeat its pattern, so every row gets styled.
			getPresetRow: function( preset_rows, index ) {
				return _.isEmpty( preset_rows ) ? {} : preset_rows[ index % preset_rows.length ];
			},
			/**
			 * The value a content field should hold after a preset. Anything the user
			 * has written stays; empty, default or preset-supplied values may change.
			 */
			getContentValue: function( control, current_value, preset_value, all_preset_values ) {
				var managed_values = _.reject( all_preset_values, _.isUndefined );

				if ( ! managed_values.length ) {
					return current_value;
				}

				var is_set_by_a_preset = _.some( managed_values, function( value ) {
					return _.isEqual( value, current_value );
				} );

				if ( ! is_set_by_a_preset && ! this.isContentEmpty( current_value ) && ! _.isEqual( current_value, control.default ) ) {
					return current_value;
				}

				return _.isUndefined( preset_value ) ? control.default : preset_value;
			},
			// Use this only for repeater fields.
			isStyleTransferControl: function ( control ) {
				if ( undefined !== control.style_transfer ) {
					return control.style_transfer;
				}
				return 'content' !== control.tab || control.selectors || control.prefix_class || control.return_value;
			},
			// Check if current field is non-editable.
			isContentTransferControl: function ( control ) {
				var control_type = control.type;
				if( 'text' === control_type || 'textarea' === control_type || 'icons' === control_type || 'wysiwyg' === control_type || 'media' === control_type || 'url' === control_type ) {
					if ( true === control.style_transfer ) {
						return false;
					}
					return true;
				}
				return false;
			},
			// Check if a text, icon, media or link value holds nothing.
			isContentEmpty: function ( value ) {
				return ! value || '' === value.url || '' === value.value;
			}
		});
		elementor.addControlView( "pp-presets-style", preset_data );
	});
} )();
