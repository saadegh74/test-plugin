(function ($) {
	$( window ).on( 'elementor/frontend/init', () => {
		/*
		 * The carousel core (Swiper options, reduced motion, autoplay pauses, slide
		 * visibility and the position announcement) lives in PPCarouselBase,
		 * frontend-carousel-base.js. This handler adds the Image Slider's thumbnails and
		 * lightbox and the equal height boxes some of these widgets offer.
		 */
		class PpCarouselWidget extends window.PPCarouselBase {
			getNavigationControls() {
				return '.pp-slider-arrow:not(.pp-image-slider-thumbs-arrow), .swiper-pagination-bullet, .pp-image-slider-thumb-item-wrap[role="button"]';
			}

			// The slideshow thumbnails move the slider from the arrow keys, Home and End as well.
			isNavigationIntentKey( e, onControl ) {
				const isThumbArrowKey = onControl && [ 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Home', 'End' ].indexOf( e.key ) > -1;

				return super.isNavigationIntentKey( e, onControl ) || !! isThumbArrowKey;
			}

			/*
			 * Widgets that name their slides say which one is showing: the Image Slider
			 * prints data-image-label from the attachment's alt, falling back to its
			 * caption, and renders the first slide's status with that label already
			 * appended — without this the label would disappear on the first move.
			 */
			getSlideLabel() {
				return this.elements.$swiperContainer
					.find( '.swiper-slide-active' )
					.attr( 'data-image-label' ) || '';
			}

			hasEqualHeight() {
				const elementSettings = this.getElementSettings();

				return 'yes' === elementSettings.equal_height_boxes || 'yes' === elementSettings.equal_height;
			}

			async afterSliderInit( Swiper ) {
				this.thumbsNav();

				await this.initThumbsCarousel( Swiper );
				this.bindThumbsCarousel();

				if ( this.hasEqualHeight() ) {
					this.setEqualHeight();
				}

				this.initFancybox();
			}

			onCarouselSlideChange() {
				if ( this.hasEqualHeight() ) {
					this.setEqualHeight();
				}
			}

			thumbsNav() {
				const elementSettings = this.getElementSettings(),
					thumbsNav         = this.$element.find( '.pp-image-slider-thumb-item-wrap' ),
					swiper            = this.swiper,
					scrollToTop       = ( undefined !== this.elements.$swiperContainer.data('scroll-top') ) ? this.elements.$swiperContainer.data('scroll-top') : '';

				// Carousel thumbnails are wired up by initThumbsCarousel()/bindThumbsCarousel() instead.
				if ( this.getThumbsElement().length ) {
					return;
				}

				if ( 'slideshow' === elementSettings.skin ) {
					thumbsNav.removeClass( 'pp-active-slide' ).attr( {
						'aria-current': 'false',
						'tabindex': '-1',
					} );
					thumbsNav.eq( 0 ).addClass( 'pp-active-slide' ).attr( {
						'aria-current': 'true',
						'tabindex': '0',
					} );

					swiper.on( 'slideChange', function () {
						const activeSlide = ( 'yes' === elementSettings.infinite_loop ) ? swiper.realIndex : swiper.activeIndex;

						thumbsNav.removeClass( 'pp-active-slide' ).attr( {
							'aria-current': 'false',
							'tabindex': '-1',
						} );
						thumbsNav.eq( activeSlide ).addClass( 'pp-active-slide' ).attr( {
							'aria-current': 'true',
							'tabindex': '0',
						} );
					} );

					const offset = elementSettings.infinite_loop ? 1 : 0;
					var container = this.elements.$swiperContainer;

					// Scroll to Top follows a click only. From the keyboard it would scroll on
					// every arrow key and carry the focused thumbnail out of view.
					const activateThumb = function( $el, fromKeyboard ) {
						swiper.slideTo( $el.index() + offset, 500 );

						if ( 'yes' === scrollToTop && ! fromKeyboard ) {
							$( 'html, body' ).animate( {
								scrollTop: ( container.offset().top - 50 ) + 'px'
							}, 100 );
						}
					};

					thumbsNav.on( 'click', function() {
						activateThumb( $( this ) );
					} );

					thumbsNav.on( 'keydown', function( e ) {
						const currentIndex = thumbsNav.index( this );
						let targetIndex = -1;

						if ( 'ArrowRight' === e.key || 'ArrowDown' === e.key ) {
							e.preventDefault();
							targetIndex = ( currentIndex + 1 ) % thumbsNav.length;
						} else if ( 'ArrowLeft' === e.key || 'ArrowUp' === e.key ) {
							e.preventDefault();
							targetIndex = ( currentIndex - 1 + thumbsNav.length ) % thumbsNav.length;
						} else if ( 'Home' === e.key ) {
							e.preventDefault();
							targetIndex = 0;
						} else if ( 'End' === e.key ) {
							e.preventDefault();
							targetIndex = thumbsNav.length - 1;
						} else if ( 'Enter' === e.key || ' ' === e.key ) {
							e.preventDefault();
							activateThumb( $( this ), true );
						}

						if ( targetIndex >= 0 ) {
							const $target = thumbsNav.eq( targetIndex );
							$target.trigger( 'focus' );
							activateThumb( $target, true );
						}
					} );
				}
			}

			getThumbsElement() {
				return this.$element.find( '.pp-image-slider-thumbs-slider' );
			}

			getThumbsSettings(prop) {
				const $thumbs = this.getThumbsElement();

				if ( ! $thumbs.length ) {
					return '';
				}

				const thumbsSettings = ( undefined !== $thumbs.data('thumbs-settings') ) ? $thumbs.data('thumbs-settings') : '';

				if ( thumbsSettings && 'undefined' !== typeof prop ) {
					return thumbsSettings[prop];
				}

				return thumbsSettings;
			}

			/**
			 * Thumbnails sit in a narrow column beside the feature image, so they run vertically there.
			 * Once the layout stacks, that column becomes full width and they have to run horizontally.
			 */
			getThumbsDirection() {
				if ( 'vertical' !== this.getThumbsSettings('direction') ) {
					return 'horizontal';
				}

				const stackOn      = this.getThumbsSettings('stack_on') || 'tablet',
					breakpoints    = elementorFrontend.config.responsive.activeBreakpoints,
					fallbackWidths = { tablet: 1024, mobile: 767 },
					stackWidth     = ( breakpoints[stackOn] ) ? breakpoints[stackOn].value : fallbackWidths[stackOn];

				return ( stackWidth && window.innerWidth <= stackWidth ) ? 'horizontal' : 'vertical';
			}

			getThumbsSlidesPerView(device) {
				const key = 'slides_per_view' + ('desktop' === device ? '' : '_' + device);
				return Math.min( this.getSlidesCount(), +this.getThumbsSettings(key) || +this.getThumbsSettings('slides_per_view') || 4 );
			}

			getThumbsSlidesToScroll(device) {
				const key = 'slides_per_group' + ('desktop' === device ? '' : '_' + device);
				return Math.min( this.getSlidesCount(), +this.getThumbsSettings(key) || 1 );
			}

			getThumbsSpaceBetween(device) {
				const key = 'space_between' + ('desktop' === device ? '' : '_' + device),
					value = this.getThumbsSettings(key);

				return ( undefined !== value && '' !== value ) ? +value : +this.getThumbsSettings('space_between') || 0;
			}

			getThumbsOptions() {
				const thumbsSettings = this.getThumbsSettings();

				const thumbsOptions = {
					direction:                  this.getThumbsDirection(),
					slidesPerView:              this.getThumbsSlidesPerView('desktop'),
					slidesPerGroup:             this.getThumbsSlidesToScroll('desktop'),
					spaceBetween:               this.getThumbsSpaceBetween('desktop'),
					watchOverflow:              true,
					watchSlidesVisibility:      true,
					watchSlidesProgress:        true,
					preventClicksPropagation:   false,
					handleElementorBreakpoints: true
				};

				if ( thumbsSettings.free_mode ) {
					// Object form keeps both the legacy and the current Swiper API happy.
					thumbsOptions.freeMode = { enabled: true };
				}

				// Nothing to loop through when every thumbnail already fits, and Swiper duplicates badly there.
				if ( thumbsSettings.loop && this.getSlidesCount() > this.getThumbsSlidesPerView('desktop') ) {
					thumbsOptions.loop = true;
					thumbsOptions.loopedSlides = this.getSlidesCount();
				}

				if ( thumbsSettings.arrows ) {
					thumbsOptions.navigation = {
						prevEl: '.pp-thumbs-button-prev-' + this.getID(),
						nextEl: '.pp-thumbs-button-next-' + this.getID(),
					};
				}

				const breakpointsSettings = {},
					breakpoints = elementorFrontend.config.responsive.activeBreakpoints;

				Object.keys(breakpoints).forEach(breakpointName => {
					breakpointsSettings[breakpoints[breakpointName].value] = {
						slidesPerView:  this.getThumbsSlidesPerView(breakpointName),
						slidesPerGroup: this.getThumbsSlidesToScroll(breakpointName),
						spaceBetween:   this.getThumbsSpaceBetween(breakpointName),
					};
				});

				thumbsOptions.breakpoints = breakpointsSettings;

				/*
				 * Swiper's a11y module runs on this strip by default and, left alone, rewrites
				 * every thumbnail to role="group" aria-label="3 / 8" and relabels the strip
				 * arrows "Previous/Next slide". Null role and label keep the PHP markup, and
				 * the arrow messages are read back from the labels PHP printed.
				 */
				const i18n = this.getI18n(),
					$prevThumbs = this.$element.find( '.pp-thumbs-button-prev-' + this.getID() ),
					$nextThumbs = this.$element.find( '.pp-thumbs-button-next-' + this.getID() );

				thumbsOptions.a11y = {
					enabled:           true,
					slideRole:         null,
					slideLabelMessage: null,
					prevSlideMessage:  $prevThumbs.attr( 'aria-label' ) || i18n.prevSlide || 'Previous slide',
					nextSlideMessage:  $nextThumbs.attr( 'aria-label' ) || i18n.nextSlide || 'Next slide',
					firstSlideMessage: i18n.firstSlide || 'This is the first slide',
					lastSlideMessage:  i18n.lastSlide || 'This is the last slide',
				};

				return thumbsOptions;
			}

			async initThumbsCarousel(Swiper) {
				const $thumbs = this.getThumbsElement();

				if ( ! $thumbs.length ) {
					return;
				}

				this.onThumbsResize = this.onThumbsResize.bind( this );
				this.matchThumbsHeight = this.matchThumbsHeight.bind( this );

				// The markup is rendered for the desktop direction, so correct it before Swiper measures anything.
				this.setThumbsDirectionClass( this.getThumbsDirection() );
				this.matchThumbsHeight();

				this.thumbsSwiper = await new Swiper( $thumbs, this.getThumbsOptions() );

				// The strip only scrolls; the thumbnails' aria-current says which one is showing.
				if ( this.thumbsSwiper.$wrapperEl ) {
					this.thumbsSwiper.$wrapperEl.attr( 'aria-live', 'off' );
				}

				this.observeFeatureImageHeight();

				// Bound by reference rather than by namespace so a re-render cannot unbind its replacement.
				elementorFrontend.elements.$window.on( 'resize', this.onThumbsResize );
			}

			/**
			 * Sole owner of the thumbnail strip's movement. Swiper's thumbs module does the same job, but
			 * running both means two slideTo calls per change, each interrupting the other's animation.
			 */
			bindThumbsCarousel() {
				const mainSwiper = this.swiper,
					thumbsSwiper = this.thumbsSwiper;

				if ( ! mainSwiper || ! thumbsSwiper ) {
					return;
				}

				const scrollToTop = !! this.getThumbsSettings('scroll_top'),
					$container    = this.elements.$swiperContainer;

				this.scrollThumbsIntoView = this.scrollThumbsIntoView.bind( this );
				this.lastThumbRealIndex = mainSwiper.realIndex;

				// Looping duplicates slides, so every copy of the active thumbnail gets highlighted.
				this.syncActiveThumb = () => {
					const slides = thumbsSwiper.slides;

					for ( let index = 0; index < slides.length; index++ ) {
						const isActive = this.getSlideRealIndex( slides[index], index ) === mainSwiper.realIndex;
						$( slides[index] )
							.toggleClass( 'pp-active-slide', isActive )
							.attr( {
								'aria-current': isActive ? 'true' : 'false',
								'tabindex': isActive ? '0' : '-1',
							} );
					}
				};

				this.syncActiveThumb();

				const handleThumbActivation = ( target, fromKeyboard ) => {
					const realIndex = this.getSlideRealIndex( target, $( target ).index() );

					mainSwiper.slideTo(
						mainSwiper.params.loop ? this.getNearestSlideIndex( mainSwiper, realIndex ) : realIndex
					);

					// Click only: from the keyboard it would carry the focused thumbnail out of view.
					if ( scrollToTop && ! fromKeyboard ) {
						$( 'html, body' ).animate( {
							scrollTop: ( $container.offset().top - 50 ) + 'px'
						}, 100 );
					}
				};

				// Delegated, because Swiper rebuilds its loop duplicates whenever a breakpoint changes.
				this.getThumbsElement().on( 'click.ppThumbs', '.swiper-wrapper > .swiper-slide', ( event ) => {
					handleThumbActivation( event.currentTarget );
				} );

				this.getThumbsElement().on( 'keydown.ppThumbs', '.swiper-wrapper > .swiper-slide', ( event ) => {
					const $slides = this.getThumbsElement().find( '.swiper-wrapper > .swiper-slide' );
					const currentIndex = $slides.index( event.currentTarget );
					let targetIndex = -1;

					if ( 'ArrowRight' === event.key || 'ArrowDown' === event.key ) {
						event.preventDefault();
						targetIndex = ( currentIndex + 1 ) % $slides.length;
					} else if ( 'ArrowLeft' === event.key || 'ArrowUp' === event.key ) {
						event.preventDefault();
						targetIndex = ( currentIndex - 1 + $slides.length ) % $slides.length;
					} else if ( 'Home' === event.key ) {
						event.preventDefault();
						targetIndex = 0;
					} else if ( 'End' === event.key ) {
						event.preventDefault();
						targetIndex = $slides.length - 1;
					} else if ( 'Enter' === event.key || ' ' === event.key ) {
						event.preventDefault();
						handleThumbActivation( event.currentTarget, true );
					}

					if ( targetIndex >= 0 ) {
						const $target = $slides.eq( targetIndex );
						$target.trigger( 'focus' );
						handleThumbActivation( $target[0], true );
					}
				} );

				mainSwiper.on( 'slideChange', () => {
					this.syncActiveThumb();
					this.scrollThumbsIntoView();
				});
			}

			getSlideRealIndex(slide, fallback) {
				const realIndex = slide.getAttribute( 'data-swiper-slide-index' );

				return ( null === realIndex ) ? fallback : parseInt( realIndex, 10 );
			}

			/**
			 * DOM position of the slide for a real index. Working in DOM positions rather than real indexes
			 * is what keeps a looping strip travelling the short way instead of unwinding back across
			 * itself. Pass `forward` when following a moving slider: the copy nearest in absolute terms can
			 * sit behind the view once the copies ahead run out, which reads as a backwards lurch.
			 */
			getNearestSlideIndex(swiper, realIndex, forward) {
				const current = swiper.activeIndex,
					slides    = swiper.slides;

				let nearest = -1,
					ahead   = -1,
					behind  = -1;

				for ( let index = 0; index < slides.length; index++ ) {
					if ( this.getSlideRealIndex( slides[index], index ) !== realIndex ) {
						continue;
					}

					if ( index >= current && ( ahead < 0 || index < ahead ) ) {
						ahead = index;
					}

					if ( index <= current && ( behind < 0 || index > behind ) ) {
						behind = index;
					}

					if ( nearest < 0 || Math.abs( index - current ) < Math.abs( nearest - current ) ) {
						nearest = index;
					}
				}

				if ( true === forward && ahead >= 0 ) {
					return ahead;
				}

				if ( false === forward && behind >= 0 ) {
					return behind;
				}

				return ( nearest < 0 ) ? realIndex : nearest;
			}

			/**
			 * Keep the active thumbnail in view, with a one-thumb look-ahead in the direction of travel.
			 */
			scrollThumbsIntoView() {
				const thumbs = this.thumbsSwiper;

				if ( ! thumbs || thumbs.destroyed ) {
					return;
				}

				const realIndex = this.swiper.realIndex,
					total       = this.getSlidesCount(),
					previous    = this.lastThumbRealIndex;

				// Which way the feature image just moved, counted the short way round so that stepping off
				// the end still reads as forward rather than as a jump back to the start.
				let forward;

				if ( undefined !== previous && previous !== realIndex && total > 1 ) {
					forward = ( ( realIndex - previous + total ) % total ) <= total / 2;
				}

				this.lastThumbRealIndex = realIndex;

				const index    = thumbs.params.loop
						? this.getNearestSlideIndex( thumbs, realIndex, forward )
						: realIndex,
					perView    = Math.ceil( thumbs.params.slidesPerView ) || 1,
					maxIndex   = Math.max( thumbs.slides.length - perView, 0 ),
					firstVisible = thumbs.activeIndex,
					lastVisible  = firstVisible + perView - 1;

				let newIndex;

				if ( index >= lastVisible ) {
					newIndex = this.snapThumbIndex( Math.min( index - perView + 2, maxIndex ), true );
				} else if ( index <= firstVisible ) {
					newIndex = this.snapThumbIndex( Math.max( index - 1, 0 ), false );
				} else {
					return;
				}

				// The feature image loops but the strip does not, so wrapping past either end asks the strip
				// to travel its whole length at once. Animating that reads as a lurch, where a jump is over
				// before it registers. Ordinary steps still slide.
				const isJump = Math.abs( newIndex - firstVisible ) > perView;

				thumbs.slideTo( newIndex, isJump ? 0 : undefined );
			}

			/**
			 * Swiper floors every slideTo onto a group boundary, so with more than one thumbnail per scroll
			 * a forward nudge lands short while the mirrored backward one overshoots, and the same step
			 * feels different each way. Round towards the direction of travel so both move alike.
			 */
			snapThumbIndex(index, forward) {
				const thumbs = this.thumbsSwiper,
					group    = thumbs.params.slidesPerGroup || 1;

				if ( group < 2 ) {
					return index;
				}

				const snapped = forward
					? Math.ceil( index / group ) * group
					: Math.floor( index / group ) * group;

				return Math.max( 0, Math.min( snapped, Math.max( thumbs.slides.length - 1, 0 ) ) );
			}

			setThumbsDirectionClass(direction) {
				this.$element.find( '.pp-image-slider-thumbs' )
					.removeClass( 'pp-image-slider-thumbs-horizontal pp-image-slider-thumbs-vertical' )
					.addClass( 'pp-image-slider-thumbs-' + direction );

				if ( 'vertical' !== direction ) {
					this.thumbsMatchedHeight = null;
					this.getThumbsElement().css( 'height', '' );
				}
			}

			/**
			 * The feature image settles its height late — cached images report no layout at handler init, and in
			 * the editor the widget is re-rendered over AJAX. Watching the box keeps the vertical strip in step,
			 * where a one-off measurement leaves it collapsed.
			 */
			observeFeatureImageHeight() {
				if ( 'undefined' === typeof ResizeObserver || ! this.elements.$swiperContainer.length ) {
					return;
				}

				this.thumbsResizeObserver = new ResizeObserver( this.matchThumbsHeight );
				this.thumbsResizeObserver.observe( this.elements.$swiperContainer[0] );
			}

			matchThumbsHeight() {
				if ( ! this.getThumbsSettings('match_height') || 'vertical' !== this.getThumbsDirection() ) {
					return;
				}

				const height = this.elements.$swiperContainer.outerHeight();

				if ( ! height || height === this.thumbsMatchedHeight ) {
					return;
				}

				this.thumbsMatchedHeight = height;
				this.getThumbsElement().css( 'height', height + 'px' );

				if ( ! this.thumbsSwiper ) {
					return;
				}

				// Recalculating mid-transition snaps the strip out of its animation, and a feature image
				// of changing height fires the observer on exactly those frames. Let it settle first.
				if ( this.thumbsSwiper.animating ) {
					this.thumbsSwiper.once( 'transitionEnd', () => {
						if ( this.thumbsSwiper && ! this.thumbsSwiper.destroyed ) {
							this.thumbsSwiper.update();
						}
					});
				} else {
					this.thumbsSwiper.update();
				}
			}

			onThumbsResize() {
				if ( ! this.thumbsSwiper ) {
					return;
				}

				const direction = this.getThumbsDirection();

				if ( direction !== this.thumbsSwiper.params.direction ) {
					this.setThumbsDirectionClass( direction );
					this.thumbsSwiper.changeDirection( direction );
				}

				this.matchThumbsHeight();

				// A breakpoint change can rebuild the loop duplicates, dropping the active highlight with them.
				if ( this.syncActiveThumb ) {
					this.syncActiveThumb();
				}
			}

			setEqualHeight() {
				const swiperOptions = this.getSwiperOptions(),
					effect          = swiperOptions.effect,
					activeSlide     = this.elements.$swiperContainer.find( '.swiper-slide-visible' );

				let maxHeight = -1;

				activeSlide.each( function() {
					let containerHeight = $(this).outerHeight();

					if ( maxHeight < containerHeight ) {
						maxHeight = containerHeight;
					}
				});

				activeSlide.each( function() {
					if ( 'coverflow' === effect ) {
						$(this).css({ height: maxHeight } );
					} else {
						$(this).animate({ height: maxHeight }, { duration: 200, easing: 'linear' });
					}
				});
			}

			initFancybox() {
				const sliderId       = this.elements.$swiperContainer.attr( 'id' ),
					fancyboxSettings = this.elements.$swiperContainer.data('fancybox-settings'),
					linkSelector     = '.pp-image-slider-slide-link[data-fancybox="' + sliderId + '"]',
					lightboxSelector = '.pp-swiper-slide:not(.swiper-slide-duplicate) ' + linkSelector;

				// A trigger with no URL makes fancybox open the slide markup itself as
				// inline content and put it back hidden on close, so the slide image
				// disappears. Fancybox binds to [data-fancybox] globally, so those
				// triggers have the attribute dropped rather than merely left unbound —
				// looped slides included, since their clones carry it too.
				$( linkSelector ).filter( function() {
					return ! $( this ).attr( 'data-src' );
				} ).removeAttr( 'data-fancybox' );

				// Elementor's lightbox: links carry elementor-clickable instead of data-fancybox.
				this.elements.$swiperContainer.off( 'click.ppCarouselLightboxFocus' ).on( 'click.ppCarouselLightboxFocus', '.pp-image-slider-slide-link.elementor-clickable', ( event ) => {
					this.returnFocusAfterElementorLightbox( event.currentTarget );
				} );

				if ( $(lightboxSelector).length > 0 ) {
					const escNamespace = 'keydown.ppCarouselLightbox' + this.getID();

					$(lightboxSelector).fancybox( $.extend( true, {}, fancyboxSettings, {
						// With keyboard navigation off, fancybox ignores Esc too, which would
						// leave a keyboard user with no way out of a focus-trapped dialog.
						// Bound on window so fancybox's own document handler, which reads the
						// current slide, has already run before the instance is closed.
						onInit: ( instance ) => {
							if ( fancyboxSettings && false === fancyboxSettings.keyboard ) {
								$( window ).off( escNamespace ).on( escNamespace, ( event ) => {
									if ( 'Escape' === event.key || 'Esc' === event.key ) {
										event.preventDefault();
										instance.close( event );
									}
								} );
							}
						},
						afterClose: ( instance ) => {
							$( window ).off( escNamespace );
							this.restoreLightboxFocus( instance );
						},
					} ) );
				}
			}

			/**
			 * Elementor's lightbox closes itself on Esc but leaves focus on <body>.
			 * Its modal is one shared dialog, so the hide listener removes itself.
			 *
			 * @since x.x.x
			 *
			 * @param {HTMLElement} trigger The link that opened the lightbox.
			 */
			returnFocusAfterElementorLightbox( trigger ) {
				const openLightbox = trigger.getAttribute( 'data-elementor-open-lightbox' );

				if ( this.isEdit || ! elementorFrontend.utils ) {
					return;
				}

				// Same test Elementor uses, so a link that does not open the lightbox
				// never leaves a listener behind for some later one.
				if ( 'no' === openLightbox || ( 'yes' !== openLightbox && ! elementorFrontend.getKitSettings( 'global_image_lightbox' ) ) ) {
					return;
				}

				Promise.resolve( elementorFrontend.utils.lightbox ).then( ( lightbox ) => {
					const modal = lightbox && lightbox.getModal ? lightbox.getModal() : null;

					if ( ! modal || ! modal.on ) {
						return;
					}

					const onHide = () => {
						modal.off( 'hide', onHide );
						this.restoreLightboxFocus( { $trigger: $( trigger ) }, modal.getElements( 'widget' )[0] );
					};

					modal.on( 'hide', onHide );
				} ).catch( () => {} );
			}

			/**
			 * Fancybox puts focus back on the current slide's link, which is inert when
			 * that slide is off screen, so focus silently falls to <body>. Fall back to
			 * the link that opened the lightbox, then to the slider itself.
			 *
			 * @since x.x.x
			 *
			 * @param {Object}      instance Fancybox instance, or an object with $trigger.
			 * @param {HTMLElement} overlay  The closing overlay, if focus may still be in it.
			 */
			restoreLightboxFocus( instance, overlay ) {
				const $trigger = instance && instance.$trigger;

				// afterClose runs before fancybox's own backFocus step.
				setTimeout( () => {
					const active = document.activeElement;

					if ( active && active !== document.body && ! ( overlay && overlay.contains( active ) ) ) {
						return;
					}

					const candidates = [
						$trigger && $trigger[0],
						this.elements.$swiperContainer[0],
					];

					for ( let i = 0; i < candidates.length; i++ ) {
						const el = candidates[ i ];

						if ( ! el || ! document.body.contains( el ) || ( el.closest && el.closest( '[inert]' ) ) ) {
							continue;
						}

						el.focus( { preventScroll: true } );

						if ( document.activeElement === el ) {
							return;
						}
					}
				}, 0 );
			}

			onDestroy() {
				// An own, bound copy once the carousel has initialised; otherwise nothing matches.
				elementorFrontend.elements.$window.off( 'resize', this.onThumbsResize );
				$( window ).off( 'keydown.ppCarouselLightbox' + this.getID() );

				if ( this.thumbsResizeObserver ) {
					this.thumbsResizeObserver.disconnect();
					this.thumbsResizeObserver = null;
				}

				if ( this.thumbsSwiper ) {
					this.thumbsSwiper.destroy( true, true );
					this.thumbsSwiper = null;
				}

				super.onDestroy();
			}
		}

		const widgets = {
			'business-reviews':     [ 'default', 'classic', 'card' ],
			'content-ticker':       '',
			'image-slider':         '',
			'info-box-carousel':    '',
			'logo-carousel':        '',
			'magazine-slider':      '',
			'team-member-carousel': '',
			'woo-categories':       '',
		}

		$.each( widgets, function( widget, skin ) {
			if ( 'object' ===  typeof skin ) {
				$.each( skin, function( index, wSkin ) {
					elementorFrontend.elementsHandler.attachHandler( 'pp-' + widget, PpCarouselWidget, wSkin );
				});
			} else {
				elementorFrontend.elementsHandler.attachHandler( 'pp-' + widget, PpCarouselWidget );
			}
		});
	} );
})(jQuery);