/**
 * Shared Swiper carousel behaviour for PowerPack widgets.
 *
 * Defines window.PPCarouselBase, an Elementor frontend handler that builds the Swiper
 * options from the widget's data-slider-settings and adds what every carousel needs on
 * top of Swiper: translated a11y strings, reduced motion, pausing autoplay on hover and
 * focus, keeping off-screen slides out of the accessibility tree, and announcing the
 * slide position after a move the visitor made.
 *
 * A widget script lists this as a dependency and extends the class, overriding the
 * hooks below for whatever its carousel does differently:
 *
 *   getStatusElement()        Where the slide position is announced.
 *   getNavigationControls()   Selector for the controls that move the slider.
 *   isNavigationIntentKey()   Which key presses count as the visitor moving it.
 *   getSlideLabel()           Text appended to the announced position.
 *   afterSliderInit()         Runs once Swiper is up.
 *   onCarouselSlideChange()   Runs on every slide change.
 */
(function ($) {
	$( window ).on( 'elementor/frontend/init', () => {
		class PPCarouselBase extends elementorModules.frontend.handlers.Base {
			getDefaultSettings() {
				return {
					selectors: {
						swiperContainer: '.pp-swiper-slider',
						swiperSlide: '.swiper-slide',
					},
					slidesPerView: {
						widescreen: 3,
						desktop: 3,
						laptop: 3,
						tablet_extra: 3,
						tablet: 2,
						mobile_extra: 2,
						mobile: 1
					}
				};
			}

			getDefaultElements() {
				const selectors = this.getSettings( 'selectors' ),
					$swiperContainer = this.$element.find( selectors.swiperContainer );

				return {
					$swiperContainer: $swiperContainer,
					// Scoped to the main slider so thumbnail carousel slides are not counted as slides.
					$swiperSlide: $swiperContainer.find( selectors.swiperSlide ),
				};
			}

			/**
			 * An event namespace unique to this widget instance, so onDestroy() unbinds
			 * exactly what this handler bound and nothing a sibling widget added.
			 */
			getCarouselNamespace() {
				return '.ppCarousel' + this.getID();
			}

			/**
			 * Widgets write switches into data-slider-settings either as 'yes'/'' or as
			 * true/false (the Posts skins use booleans), so accept both.
			 */
			isOn( value ) {
				return true === value || 'yes' === value;
			}

			getSliderSettings(prop) {
				const sliderSettings = ( undefined !== this.elements.$swiperContainer.data('slider-settings') ) ? this.elements.$swiperContainer.data('slider-settings') : '';

				if ( 'undefined' !== typeof prop && 'undefined' !== sliderSettings[prop] ) {
					return sliderSettings[prop];
				}

				return sliderSettings;
			}

			getSlidesCount() {
				return this.elements.$swiperSlide.length;
			}

			getEffect() {
				return this.getSliderSettings('effect') || 'slide';
			}

			getDeviceSlidesPerView(device) {
				const slidesPerViewKey = 'slides_per_view' + ('desktop' === device ? '' : '_' + device);
				return Math.min(this.getSlidesCount(), +this.getSliderSettings(slidesPerViewKey) || this.getSettings('slidesPerView')[device]);
			}

			getSlidesPerView(device) {
				if ('slide' === this.getEffect() || 'coverflow' === this.getEffect()) {
					return this.getDeviceSlidesPerView(device);
				}
				return 1;
			}

			getDeviceSlidesToScroll(device) {
				const slidesToScrollKey = 'slides_to_scroll' + ('desktop' === device ? '' : '_' + device);
				return Math.min(this.getSlidesCount(), +this.getElementSettings(slidesToScrollKey) || 1);
			}

			getSlidesToScroll(device) {
				if ('slide' === this.getEffect()) {
					return this.getDeviceSlidesToScroll(device);
				}
				return 1;
			}

			getSpaceBetween(device) {
				// Swiper adds this to slide positions with +, so a size saved as the string "10"
				// concatenated into a nonsense grid and left the arrows unable to move.
				return parseFloat( elementorFrontend.utils.controls.getResponsiveControlValue(this.getSliderSettings(), 'space_between', 'size', device) ) || 0;
			}

			getSwiperOptions() {
				const sliderSettings = this.getSliderSettings();

				const swiperOptions = {
					grabCursor:                 this.isOn( sliderSettings.grab_cursor ),
					slidesPerView:              this.getSlidesPerView('desktop'),
					slidesPerGroup:             this.getSlidesToScroll('desktop'),
					spaceBetween:               this.getSpaceBetween(),
					loop:                       this.isOn( sliderSettings.loop ),
					centeredSlides:             this.isOn( sliderSettings.centered_slides ),
					speed:                      sliderSettings.speed,
					autoHeight:                 sliderSettings.auto_height,
					effect:                     this.getEffect(),
					watchSlidesVisibility:      true,
					watchSlidesProgress:        true,
					preventClicksPropagation:   false,
					slideToClickedSlide:        true,
					handleElementorBreakpoints: true,
				};

				if ( 'fade' === this.getEffect() ) {
					swiperOptions.fadeEffect = {
						crossFade: true,
					};
				}

				const navigation = this.getNavigationSelectors();

				if ( sliderSettings.show_arrows ) {
					swiperOptions.navigation = {
						prevEl: navigation.prevEl,
						nextEl: navigation.nextEl,
					};
				}

				if ( sliderSettings.pagination ) {
					swiperOptions.pagination = {
						el: navigation.paginationEl,
						type: sliderSettings.pagination,
						clickable: true
					};
				}

				/*
				 * Opt-in per widget, via `a11y` in data-slider-settings. The a11y module is what makes the
				 * div[role=button] arrows answer Enter and Space — a div does not synthesise
				 * a click from those the way a native button does — and what gives the
				 * pagination bullets a role and a tab stop. It also sets aria-disabled at
				 * either end.
				 *
				 * Swiper's keyboard module rides the same opt-in: it listens on the document,
				 * so enabling it everywhere would let an arrow key pressed anywhere on the
				 * page move every carousel currently on screen.
				 */
				if ( 'yes' === sliderSettings.a11y ) {
					const i18n = this.getI18n();

					swiperOptions.a11y = {
						enabled:                    true,
						prevSlideMessage:           i18n.prevSlide  || 'Previous slide',
						nextSlideMessage:           i18n.nextSlide  || 'Next slide',
						firstSlideMessage:          i18n.firstSlide || 'This is the first slide',
						lastSlideMessage:           i18n.lastSlide  || 'This is the last slide',
						paginationBulletMessage:    i18n.paginationBullet || 'Go to slide {{index}}',
						slideLabelMessage:          i18n.slideLabel || 'Slide {{index}} of {{slidesLength}}',
						slideRole:                  'group',
						itemRoleDescriptionMessage: i18n.slideRoleDescription || 'slide',
					};

					/*
					 * A widget can keep the strings and still turn this off with `keyboard: 'no'`.
					 * The module ignores preventDefault(), so a widget with its own arrow-key
					 * handling (the Image Slider's thumbnails) would move twice per key.
					 */
					if ( 'no' !== sliderSettings.keyboard ) {
						swiperOptions.keyboard = {
							enabled:        true,
							onlyInViewport: true,
						};
					}
				}

				if ('cube' !== this.getEffect()) {
					const breakpointsSettings = {},
					breakpoints = elementorFrontend.config.responsive.activeBreakpoints;

					Object.keys(breakpoints).forEach(breakpointName => {
						breakpointsSettings[breakpoints[breakpointName].value] = {
							slidesPerView: this.getSlidesPerView(breakpointName),
							slidesPerGroup: this.getSlidesToScroll(breakpointName),
						};

						if ( this.getSpaceBetween(breakpointName) ) {
							breakpointsSettings[breakpoints[breakpointName].value].spaceBetween = this.getSpaceBetween(breakpointName);
						}
					});

					swiperOptions.breakpoints = breakpointsSettings;
				}

				/*
				 * Offset sides, as in Elementor's carousels: the container is padded on the
				 * chosen sides so the neighbouring slides peek in. On the right that only
				 * works if Swiper keeps a sliver of the next slide in view at the last
				 * position, hence the extra thousandth of a slide.
				 */
				const offsetSide = this.getOffsetSides();

				if ( 'right' === offsetSide || 'both' === offsetSide ) {
					swiperOptions.slidesPerView += 0.001;

					if ( swiperOptions.breakpoints ) {
						Object.keys( swiperOptions.breakpoints ).forEach( ( bp ) => {
							swiperOptions.breakpoints[ bp ].slidesPerView += 0.001;
						} );
					}
				}

				if ( !this.isEdit && sliderSettings.autoplay && ! this.isMotionReduced() ) {
					swiperOptions.autoplay = {
						delay: sliderSettings.autoplay_speed,
						disableOnInteraction: !!sliderSettings.pause_on_interaction
					};
				}

				return swiperOptions;
			}

			/**
			 * Selectors Swiper binds the arrows and the pagination to.
			 *
			 * In the editor these fall back to Elementor's generic classes. Swiper resolves
			 * them against the document, so a widget whose arrows always carry the
			 * id-scoped class can override this to stay scoped there as well.
			 */
			getNavigationSelectors() {
				return {
					prevEl:       this.isEdit ? '.elementor-swiper-button-prev' : '.swiper-button-prev-' + this.getID(),
					nextEl:       this.isEdit ? '.elementor-swiper-button-next' : '.swiper-button-next-' + this.getID(),
					paginationEl: this.isEdit ? '.swiper-pagination' : '.swiper-pagination-' + this.getID(),
				};
			}

			/**
			 * Which sides the slides peek in from: 'left', 'right', 'both', or '' for none.
			 * Only a looping slide carousel has a neighbour on each side to show.
			 */
			getOffsetSides() {
				const side = this.getSliderSettings( 'offset_sides' );

				if ( -1 === [ 'left', 'right', 'both' ].indexOf( side ) ) {
					return '';
				}

				if ( ! this.isOn( this.getSliderSettings( 'loop' ) ) || 'slide' !== this.getEffect() ) {
					return '';
				}

				return side;
			}

			getI18n() {
				return ( 'undefined' !== typeof ppCarouselBaseScript && ppCarouselBaseScript.i18n )
					? ppCarouselBaseScript.i18n
					: {};
			}

			prefersReducedMotion() {
				return !! ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches );
			}

			/**
			 * Autoplay and slide animation are decorative, so an explicit system-level
			 * request for reduced motion is always honoured — there is no author opt-out.
			 */
			isMotionReduced() {
				return this.prefersReducedMotion();
			}

			/**
			 * Whether hovering the widget should hold the autoplay. Read from the element
			 * settings, where the Pause on Hover control is frontend_available.
			 */
			shouldPauseOnHover() {
				return 'yes' === this.getElementSettings( 'pause_on_hover' );
			}

			/**
			 * The live region the slide position is announced in.
			 *
			 * [aria-live] and not the class alone: .elementor-screen-only is a plain
			 * visually hidden marker, and slides carry their own (the "(opens in a new
			 * tab)" note on external links), which a bare descendant match would overwrite
			 * with the slide count.
			 */
			getStatusElement() {
				return this.elements.$swiperContainer.find( '.elementor-screen-only[aria-live]' );
			}

			/**
			 * Controls whose activation counts as the visitor moving the slider.
			 */
			getNavigationControls() {
				return '.pp-slider-arrow, .swiper-pagination-bullet';
			}

			/**
			 * Whether a key press counts as the visitor moving the slider.
			 *
			 * @param {KeyboardEvent} e
			 * @param {Element|null}  onControl The navigation control the key landed on, if any.
			 */
			isNavigationIntentKey( e, onControl ) {
				/*
				 * Swiper's keyboard module, when on, moves the slider from the arrow keys
				 * wherever focus sits in the widget. Without it only the container's own
				 * key handler does, and only while the container itself has focus.
				 */
				const keyboardModule   = !! ( this.swiper && this.swiper.params.keyboard && this.swiper.params.keyboard.enabled );
				const isArrowKey       = ( 'ArrowLeft' === e.key || 'ArrowRight' === e.key );
				const isSliderArrowKey = isArrowKey && ( keyboardModule || e.target === this.elements.$swiperContainer[0] );
				const isActivation     = onControl && ( 'Enter' === e.key || ' ' === e.key );

				return !! ( isSliderArrowKey || isActivation );
			}

			/**
			 * Text appended to the announced position, naming the slide now showing.
			 * Carousels with nothing meaningful to name announce the position alone.
			 */
			getSlideLabel() {
				return '';
			}

			/**
			 * Runs once Swiper is initialised and the shared behaviour is bound.
			 */
			afterSliderInit() {}

			/**
			 * Runs on every slide change, before the position is announced.
			 */
			onCarouselSlideChange() {}

			bindEvents() {
				if ( this.elements.$swiperContainer.hasClass('pp-swiper-slider') ) {
					this.initSlider();
				}
			}

			/**
			 * Slides that are off screen have to leave the accessibility tree and the tab order
			 * together. Keying off the active index alone hid slides that were plainly visible
			 * whenever slidesPerView was above one — with the default of three, two of the three
			 * members on screen were erased for screen readers while their links stayed tabbable.
			 * watchSlidesProgress already maintains the class this reads.
			 */
			syncSlideVisibility() {
				const $slides = this.elements.$swiperContainer.find( '.swiper-slide' );

				// Effects such as cube never set the visibility class. Hiding every slide
				// because none is marked visible would be far worse than hiding none.
				const hasVisibilityClass = $slides.filter( '.swiper-slide-visible' ).length > 0;

				$slides.each( function() {
					// A slide is never itself a control, so it should hold no tabindex at all.
					this.removeAttribute( 'tabindex' );

					if ( ! hasVisibilityClass || this.classList.contains( 'swiper-slide-visible' ) ) {
						this.removeAttribute( 'aria-hidden' );
						this.removeAttribute( 'inert' );
					} else {
						this.setAttribute( 'aria-hidden', 'true' );
						// inert is what actually takes the links inside out of the tab order;
						// aria-hidden on its own is what created the mismatch.
						this.setAttribute( 'inert', '' );
					}
				} );
			}

			/**
			 * Announces the slide position, but only where the user asked for the move.
			 */
			announceSlidePosition() {
				if ( ! this.userNavigated ) {
					return;
				}

				this.userNavigated = false;

				const statusFormat = this.getI18n().slideStatus || 'Showing Slide %1$s of %2$s';

				let statusText = statusFormat
					.replace( '%1$s', this.swiper.realIndex + 1 )
					.replace( '%2$s', this.getSlidesCount() );

				const slideLabel = this.getSlideLabel();

				if ( slideLabel ) {
					statusText += ': ' + slideLabel;
				}

				this.getStatusElement().text( statusText );
			}

			async initSlider() {
				// A widget may rebuild its slider in the editor (Posts does when the columns
				// change), so take down the previous one and its listeners first.
				this.destroySlider();

				// The padding that makes room for the peeking slides is keyed off this class.
				const offsetSide = this.getOffsetSides();

				this.elements.$swiperContainer
					.removeClass( 'pp-swiper-offset-left pp-swiper-offset-right pp-swiper-offset-both' )
					.addClass( offsetSide ? 'pp-swiper-offset-' + offsetSide : '' );

				const Swiper = elementorFrontend.utils.swiper;
				this.swiper = await new Swiper( this.elements.$swiperContainer, this.getSwiperOptions() );

				this.bindCarouselA11y();

				await this.afterSliderInit( Swiper );
			}

			/**
			 * Everything the slider needs once Swiper is up: tab order, announcements and the
			 * ways the visitor can stop the autoplay.
			 */
			bindCarouselA11y() {
				const ns = this.getCarouselNamespace();

				/*
				 * params.autoplay.enabled, not the widget setting: it is true only where the
				 * autoplay actually started, so never in the editor and never once reduced
				 * motion has held it back. Swiper's autoplay.start() has no such guard, so a
				 * resume bound on a slider that is not autoplaying would start one.
				 */
				const autoplayStarted = !! ( this.swiper.params.autoplay && this.swiper.params.autoplay.enabled );

				if ( autoplayStarted && this.shouldPauseOnHover() ) {
					this.togglePauseOnHover( true );
				}

				// The keyboard equivalent of the hover pause, so it applies whatever Pause on Hover says.
				if ( autoplayStarted ) {
					this.togglePauseOnFocus( true );
				}

				this.syncSlideVisibility();

				// Autoplay must not speak. A position announcement answers the user having
				// navigated; on a timer it just interrupts whatever they are reading, every
				// few seconds, for as long as the page is open.
				this.userNavigated = false;

				/*
				 * Swiper emits navigationNext/navigationPrev only after slideNext() has run, by
				 * which time slideChange has already come and gone, so a flag set from those
				 * events was always one move behind and the first arrow press announced
				 * nothing. paginationUpdate was worse: it fires on autoplay moves too. Marking
				 * the intent on the way down, in the capture phase, gets there first.
				 */
				const controls = this.getNavigationControls();

				this.onNavigationIntent = ( e ) => {
					const onControl = e.target.closest ? e.target.closest( controls ) : null;

					if ( 'keydown' === e.type ) {
						if ( ! this.isNavigationIntentKey( e, onControl ) ) {
							return;
						}
					} else if ( ! onControl ) {
						return;
					}

					this.userNavigated = true;
				};

				this.$element[0].addEventListener( 'pointerdown', this.onNavigationIntent, true );
				this.$element[0].addEventListener( 'keydown', this.onNavigationIntent, true );

				// A swipe is deliberate too, and touchEnd lands before the transition.
				this.swiper.on( 'touchEnd', () => {
					this.userNavigated = true;
				} );

				/*
				 * The status region belongs to the widget, so take its id from the DOM rather
				 * than rebuilding it here: a widget that renders no status then leaves its
				 * arrows alone instead of pointing them at an element that does not exist.
				 */
				const statusId = this.getStatusElement().attr( 'id' );

				if ( statusId ) {
					/*
					 * Swiper points the arrows' aria-controls at the slides wrapper, which is
					 * correct and stays; the status region only describes the result. Swiper
					 * also makes that wrapper a polite live region, which would read the new
					 * slide a second time on top of the status announcement.
					 */
					this.$element.find(
						'.elementor-swiper-button-prev, .elementor-swiper-button-next, ' +
						'.swiper-button-prev-' + this.getID() + ', .swiper-button-next-' + this.getID()
					).attr( 'aria-describedby', statusId );

					if ( this.swiper.$wrapperEl ) {
						this.swiper.$wrapperEl.attr( 'aria-live', 'off' );
					}
				}

				/*
				 * In loop mode Swiper first jumps, unseen, from a duplicate to the matching
				 * real slide, and that jump fires slideChange as well. Announcing there spent
				 * the userNavigated flag on the slide being left, so the status lagged one
				 * slide behind after every wrap.
				 */
				this.swiper.on( 'beforeLoopFix', () => {
					this.isLoopFixing = true;
				} );

				this.swiper.on( 'loopFix', () => {
					this.isLoopFixing = false;
				} );

				this.swiper.on( 'slideChange', () => {
					this.onCarouselSlideChange();

					if ( ! this.isLoopFixing ) {
						this.announceSlidePosition();
					}
				} );

				// Swiper settles which slides are on screen only once the movement is over.
				this.swiper.on( 'slideChangeTransitionEnd resize breakpoint', () => {
					this.syncSlideVisibility();
				} );

				// Scoped to the container itself: while it was bound to every descendant,
				// arrow keys pressed inside a slide's own links and text moved the whole
				// carousel out from under the user.
				this.elements.$swiperContainer.on( 'keydown' + ns, ( e ) => {
					if ( e.target !== e.currentTarget ) {
						return;
					}

					if ( 'ArrowRight' === e.key ) {
						this.swiper.slideNext();
					}

					if ( 'ArrowLeft' === e.key ) {
						this.swiper.slidePrev();
					}
				} );

				// No Enter/Space handler on the arrows here: Swiper's a11y module, on by default
				// in Elementor's Swiper 8, already moves the slider from those keys. Firing a
				// click as well moved it twice per press wherever the loop was off.
			}

			togglePauseOnHover(toggleOn) {
				const ns = this.getCarouselNamespace();

				if (toggleOn) {
					this.$element.on( 'mouseenter' + ns, () => {
						if (this.swiper && this.swiper.autoplay && this.swiper.autoplay.running) {
							this.swiper.autoplay.stop();
						}
					} );

					this.$element.on( 'mouseleave' + ns, () => {
						// Focus inside still holds the pause. Resuming here would move the slide
						// on and make it inert, dropping that focus to the body.
						if ( this.$element[0].contains( document.activeElement ) ) {
							return;
						}

						if (this.swiper && this.swiper.autoplay && !this.swiper.autoplay.running) {
							this.swiper.autoplay.start();
						}
					} );
				} else {
					this.$element.off( 'mouseenter' + ns + ' mouseleave' + ns );
				}
			}

			togglePauseOnFocus(toggleOn) {
				const ns = this.getCarouselNamespace();

				if (toggleOn) {
					this.$element.on( 'focusin' + ns, () => {
						if (this.swiper && this.swiper.autoplay && this.swiper.autoplay.running) {
							this.swiper.autoplay.stop();
						}
					} );

					this.$element.on( 'focusout' + ns, ( e ) => {
						// Moving between two controls inside the widget is not leaving it.
						if ( e.relatedTarget && this.$element[0].contains( e.relatedTarget ) ) {
							return;
						}

						// A pointer still resting on the widget holds the hover pause.
						if ( this.shouldPauseOnHover() && this.$element[0].matches( ':hover' ) ) {
							return;
						}

						if (this.swiper && this.swiper.autoplay && !this.swiper.autoplay.running) {
							this.swiper.autoplay.start();
						}
					} );
				} else {
					this.$element.off( 'focusin' + ns + ' focusout' + ns );
				}
			}

			/**
			 * Take down everything initSlider() set up: the Swiper and every handler bound
			 * for it. Without this every editor re-render stacks another Swiper, with its own
			 * autoplay timer, over the same element.
			 */
			destroySlider() {
				const ns = this.getCarouselNamespace();

				this.$element.off( ns );

				if ( this.elements && this.elements.$swiperContainer ) {
					this.elements.$swiperContainer.off( ns );
				}

				if ( this.onNavigationIntent ) {
					this.$element[0].removeEventListener( 'pointerdown', this.onNavigationIntent, true );
					this.$element[0].removeEventListener( 'keydown', this.onNavigationIntent, true );
					this.onNavigationIntent = null;
				}

				if ( this.swiper && 'function' === typeof this.swiper.destroy ) {
					this.swiper.destroy( true, true );
				}

				this.swiper = null;
			}

			onDestroy() {
				this.destroySlider();

				super.onDestroy();
			}
		}

		window.PPCarouselBase = PPCarouselBase;
	} );
})(jQuery);
