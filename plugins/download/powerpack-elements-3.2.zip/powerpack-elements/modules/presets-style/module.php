<?php
namespace PowerpackElements\Modules\PresetsStyle;

use PowerpackElements\Base\Module_Base;
use PowerpackElements\Modules\PresetsStyle\Controls\Presets_Style;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Module.
 */
class Module extends Module_Base {

	/**
	 * Module should load or not.
	 *
	 * @since 2.9.0
	 * @access public
	 *
	 * @return bool true|false.
	 */
	public static function is_active() {
		return true;
	}

	/**
	 * Constructer.
	 *
	 * @since 2.9.0
	 * @access public
	 */
	public function __construct() {
		parent::__construct();
		if ( is_extension_enabled( 'presets-style' ) ) {
			$this->add_actions();
		}
	}

	/**
	 * Get Module Name.
	 *
	 * @since 2.9.0
	 * @access public
	 *
	 * @return string Module name.
	 */
	public function get_name() {
		return 'presets-style';
	}

	/**
	 * Get the presets of every widget, keyed by widget name.
	 *
	 * @since 3.2.0
	 *
	 * @return array Presets, e.g. [ 'pp-buttons' => [ 'preset-1' => [ ... ] ] ].
	 */
	public static function get_all_presets() {
		$presets = [];

		foreach ( (array) glob( POWERPACK_ELEMENTS_PATH . 'assets/presets-json/*.json' ) as $file ) {
			$widget_presets = json_decode( file_get_contents( $file ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents

			if ( is_array( $widget_presets ) ) {
				$presets[ 'pp-' . basename( $file, '.json' ) ] = $widget_presets;
			}
		}

		return $presets;
	}

	/**
	 * Get the names of a widget's presets, keyed as in assets/presets-json.
	 *
	 * These live here rather than in the JSON because translation tools can't scan JSON.
	 *
	 * @since 3.2.0
	 *
	 * @param string $widget_name Widget name, e.g. pp-buttons.
	 * @return array Preset names.
	 */
	public static function get_preset_labels( $widget_name ) {
		$labels = [
			'pp-advanced-accordion' => [
				'preset-1' => __( 'Purple Underline', 'powerpack' ),
				'preset-2' => __( 'Solid Blue', 'powerpack' ),
				'preset-3' => __( 'Solid Sand', 'powerpack' ),
				'preset-4' => __( 'Minimal with Divider', 'powerpack' ),
				'preset-5' => __( 'Minimal with Purple Accent', 'powerpack' ),
			],
			'pp-buttons'            => [
				'preset-1' => __( 'Joined Green Pill', 'powerpack' ),
				'preset-2' => __( 'Joined Amber', 'powerpack' ),
				'preset-3' => __( 'Outlined Purple Pill', 'powerpack' ),
				'preset-4' => __( 'Outlined Blue Pill with Icons', 'powerpack' ),
				'preset-5' => __( 'Outlined Green Pill', 'powerpack' ),
			],
			'pp-countdown'          => [
				'preset-1' => __( 'Large Numbers', 'powerpack' ),
				'preset-2' => __( 'Circles', 'powerpack' ),
				'preset-3' => __( 'Soft Cards', 'powerpack' ),
				'preset-4' => __( 'Outlined Boxes', 'powerpack' ),
			],
			'pp-counter'            => [
				'preset-1' => __( 'Icon Above', 'powerpack' ),
				'preset-2' => __( 'Icon Above with Divider', 'powerpack' ),
				'preset-3' => __( 'Icon Beside Number', 'powerpack' ),
			],
			'pp-dual-heading'       => [
				'preset-1' => __( 'Gradient Highlight', 'powerpack' ),
				'preset-2' => __( 'Stacked and Centered', 'powerpack' ),
			],
			'pp-image-accordion'    => [
				'preset-1' => __( 'Classic Overlay', 'powerpack' ),
				'preset-2' => __( 'Caption Card', 'powerpack' ),
				'preset-3' => __( 'Rounded Gallery', 'powerpack' ),
				'preset-4' => __( 'Color Wash', 'powerpack' ),
				'preset-5' => __( 'Framed Panels', 'powerpack' ),
			],
			'pp-info-box'           => [
				'preset-1' => __( 'Bordered and Centered', 'powerpack' ),
				'preset-2' => __( 'Left Aligned', 'powerpack' ),
				'preset-3' => __( 'Bordered with Button', 'powerpack' ),
				'preset-4' => __( 'Circle Icon with Divider', 'powerpack' ),
				'preset-5' => __( 'Icon Beside Text', 'powerpack' ),
			],
			'pp-info-list'          => [
				'preset-1' => __( 'Large Circle Icons', 'powerpack' ),
				'preset-2' => __( 'Horizontal Timeline', 'powerpack' ),
			],
			'pp-review-box'         => [
				'preset-1' => __( 'Percentage Bars', 'powerpack' ),
				'preset-2' => __( 'Stars with Pros and Cons', 'powerpack' ),
			],
			'pp-team-member'        => [
				'preset-1' => __( 'Round Photo', 'powerpack' ),
				'preset-2' => __( 'Large Photo, Left Aligned', 'powerpack' ),
				'preset-3' => __( 'Dark Caption', 'powerpack' ),
				'preset-4' => __( 'Soft Card', 'powerpack' ),
			],
		];

		return isset( $labels[ $widget_name ] ) ? $labels[ $widget_name ] : [];
	}

	/**
	 * Register Control
	 *
	 * @since 2.9.0
	 */
	public function register_controls() {
		$controls_manager = \Elementor\Plugin::$instance->controls_manager;
		$controls_manager->register( new Presets_Style() );
	}

	/**
	 * Add actions
	 *
	 * @since 2.9.0
	 */
	protected function add_actions() {
		add_action( 'elementor/controls/register', [ $this, 'register_controls' ] );
	}
}
