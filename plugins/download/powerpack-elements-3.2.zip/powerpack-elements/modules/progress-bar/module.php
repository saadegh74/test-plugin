<?php
namespace PowerpackElements\Modules\ProgressBar;

use PowerpackElements\Base\Module_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Module extends Module_Base {

	public function __construct() {
		parent::__construct();

		add_action( 'elementor/frontend/after_register_styles', [ $this, 'register_styles' ] );
	}

	/**
	 * Module is active or not.
	 *
	 * @since 2.11.0
	 *
	 * @access public
	 *
	 * @return bool true|false.
	 */
	public static function is_active() {
		return true;
	}

	/**
	 * Get Module Name.
	 *
	 * @since 2.11.0
	 *
	 * @access public
	 *
	 * @return string Module name.
	 */
	public function get_name() {
		return 'pp-progress-bar';
	}

	/**
	 * Get Widgets.
	 *
	 * @since 2.11.0
	 *
	 * @access public
	 *
	 * @return array Widgets.
	 */
	public function get_widgets() {
		return [
			'Progress_Bar',
		];
	}

	/**
	 * Register styles.
	 *
	 * @since 3.0.0
	 *
	 * @access public
	 *
	 * @return void
	 */
	public function register_styles() {
		wp_register_style(
			'widget-pp-progress-bar',
			$this->get_css_assets_url( 'widget-progress-bar', null, true, true ),
			[],
			POWERPACK_ELEMENTS_VER
		);
	}
}
