<?php
/**
 * Progress Bar Widget
 *
 * @package PPE
 */

namespace PowerpackElements\Modules\ProgressBar\Widgets;

use PowerpackElements\Base\Powerpack_Widget;
use PowerpackElements\Classes\PP_Helper;

// Elementor Classes.
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Repeater;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Progress Bar Widget
 */
class Progress_Bar extends Powerpack_Widget {

	/**
	 * Retrieve progress bar widget name.
	 *
	 * @since 2.11.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return parent::get_widget_name( 'Progress_Bar' );
	}

	/**
	 * Retrieve progress bar widget title.
	 *
	 * @since 2.11.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return parent::get_widget_title( 'Progress_Bar' );
	}

	/**
	 * Retrieve progress bar widget icon.
	 *
	 * @since 2.11.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return parent::get_widget_icon( 'Progress_Bar' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.11.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return parent::get_widget_keywords( 'Progress_Bar' );
	}

	/**
	 * Whether the widget renders dynamic content.
	 *
	 * Returning true prevents Elementor from caching the rendered markup so
	 * that dynamic-tag values (e.g. label, percentage) re-evaluate per request.
	 *
	 * @since 2.11.0
	 * @access protected
	 *
	 * @return bool
	 */
	protected function is_dynamic_content(): bool {
		return true;
	}

	/**
	 * Retrieve the list of scripts the progress bar widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 2.11.0
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [
			'pp-progress-bar',
		];
	}

	/**
	 * Retrieve the list of styles the progress bar widget depended on.
	 *
	 * Used to set styles dependencies required to run the widget.
	 *
	 * @since 3.0.0
	 * @access public
	 *
	 * @return array Widget styles dependencies.
	 */
	public function get_style_depends() {
		return [
			'widget-pp-progress-bar',
		];
	}

	/**
	 * Whether the widget renders an inner wrapper around its content.
	 *
	 * Disabled when Elementor's "Optimized Markup" experiment is active so
	 * the widget output stays compatible with that experiment.
	 *
	 * @since 2.11.0
	 * @access public
	 *
	 * @return bool
	 */
	public function has_widget_inner_wrapper(): bool {
		return ! PP_Helper::is_feature_active( 'e_optimized_markup' );
	}

	/**
	 * Register progress bar widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 2.11.0
	 * @access protected
	 */
	protected function register_controls() {
		/* Content Tab */
		$this->register_content_progress_controls();

		/* Style Tab */
		$this->register_style_progress_controls();
		$this->register_style_labels_controls();
		$this->register_style_indicator_controls();
		$this->register_style_prefix_suffix_controls();
	}

	/**
	 * Register progress bar controls in the Content tab.
	 *
	 * @since 2.11.0
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_content_progress_controls() {
		/**
		 * Content Tab: Progress Bar
		 * -------------------------------------------------
		 */
		$this->start_controls_section(
			'section_progress',
			[
				'label' => esc_html__( 'Progress Bar', 'powerpack' ),
			]
		);

		$this->add_control(
			'type',
			[
				'label'              => esc_html__( 'Type', 'powerpack' ),
				'type'               => Controls_Manager::SELECT,
				'options'            => [
					'line'        => esc_html__( 'Horizontal Line', 'powerpack' ),
					'vertical'    => esc_html__( 'Vertical Line', 'powerpack' ),
					'circle'      => esc_html__( 'Circle', 'powerpack' ),
					'circle_half' => esc_html__( 'Half Circle', 'powerpack' ),
				],
				'default'            => 'line',
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'labels_type',
			[
				'label'     => esc_html__( 'Labels Type', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'single'   => esc_html__( 'Single', 'powerpack' ),
					'multiple' => esc_html__( 'Multiple', 'powerpack' ),
				],
				'default'   => 'single',
				'condition' => [
					'type!' => [ 'circle', 'circle_half' ],
				],
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'                => esc_html__( 'Alignment', 'powerpack' ),
				'type'                 => Controls_Manager::CHOOSE,
				'default'              => '',
				'options'              => [
					'left'   => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-h-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-h-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'selectors_dictionary' => [
					'left'   => 'flex-start',
					'center' => 'center',
					'right'  => 'flex-end',
				],
				'selectors'            => [
					'{{WRAPPER}} .pp-progress-bar-container' => 'justify-content: {{VALUE}};',
				],
				'condition'            => [
					'labels_type!' => 'multiple',
					'type'         => [ 'vertical', 'circle', 'circle_half' ],
				],
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'text',
			[
				'label'       => esc_html__( 'Label', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'label_block' => true,
				'placeholder' => __( 'Label', 'powerpack' ),
				'default'     => __( 'Label', 'powerpack' ),
			]
		);

		$repeater->add_control(
			'number',
			[
				'label'   => esc_html__( 'Percentage', 'powerpack' ),
				'dynamic' => [
					'active' => true,
				],
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 100,
				'default' => 50,
			]
		);

		$this->add_control(
			'labels',
			[
				'label'       => esc_html__( 'Label', 'powerpack' ),
				'type'        => Controls_Manager::REPEATER,
				'default'     => [
					[
						'text'   => __( 'Label', 'powerpack' ),
						'number' => 50,
					],
				],
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ text + " - " + number + "%" }}}',
				'condition'   => [
					'labels_type' => 'multiple',
					'type!'       => [ 'circle', 'circle_half' ],
				],
			]
		);

		$this->add_control(
			'display_percentage_labels',
			[
				'label'       => esc_html__( 'Display Labels Percentage', 'powerpack' ),
				'type'        => Controls_Manager::SWITCHER,
				'default'     => 'yes',
				'condition'   => [
					'labels_type' => 'multiple',
					'type!'       => [ 'circle', 'circle_half' ],
				],
			]
		);

		$this->add_control(
			'labels_indicator',
			[
				'label'     => esc_html__( 'Labels Indicator', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'line_pin',
				'options'   => [
					''         => esc_html__( 'None', 'powerpack' ),
					'line_pin' => esc_html__( 'Pin', 'powerpack' ),
					'arrow'    => esc_html__( 'Arrow', 'powerpack' ),
				],
				'condition' => [
					'labels_type' => 'multiple',
					'type!'       => [ 'circle', 'circle_half' ],
				],
			]
		);

		$this->add_control(
			'labels_align',
			[
				'label'     => esc_html__( 'Labels Alignment', 'powerpack' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => 'center',
				'condition' => [
					'labels_type' => 'multiple',
					'type!'       => [ 'circle', 'circle_half', 'vertical' ],
				],
			]
		);

		$this->add_control(
			'bar_label',
			[
				'label'       => esc_html__( 'Label', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'default'     => __( 'Web design', 'powerpack' ),
				'label_block' => true,
				'conditions'  => [
					'relation' => 'or',
					'terms'    => [
						[
							'name'     => 'labels_type',
							'operator' => '==',
							'value'    => 'single',
						],
						[
							'name'     => 'type',
							'operator' => 'in',
							'value'    => [ 'circle', 'circle_half' ],
						],
					],
				],
			]
		);

		$this->add_control(
			'title_tag',
			[
				'label'      => esc_html__( 'Label HTML Tag', 'powerpack' ),
				'type'       => Controls_Manager::SELECT,
				'options'    => [
					'h1'   => 'H1',
					'h2'   => 'H2',
					'h3'   => 'H3',
					'h4'   => 'H4',
					'h5'   => 'H5',
					'h6'   => 'H6',
					'div'  => 'div',
					'span' => 'span',
					'p'    => 'p',
				],
				'default'    => 'span',
				'conditions' => [
					'relation' => 'or',
					'terms'    => [
						[
							'name'     => 'labels_type',
							'operator' => '==',
							'value'    => 'single',
						],
						[
							'name'     => 'type',
							'operator' => 'in',
							'value'    => [ 'circle', 'circle_half' ],
						],
					],
				],
			]
		);

		$this->add_control(
			'percentage',
			[
				'label'       => esc_html__( 'Percentage', 'powerpack' ),
				'type'        => Controls_Manager::NUMBER,
				'label_block' => false,
				'dynamic'     => [
					'active' => true,
				],
				'min'         => 0,
				'max'         => 100,
				'default'     => 80,
			]
		);

		$this->add_control(
			'display_percentage',
			[
				'label'        => esc_html__( 'Display Percentage', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'powerpack' ),
				'label_off'    => esc_html__( 'Hide', 'powerpack' ),
				'default'      => 'yes',
				'conditions'   => [
					'relation' => 'or',
					'terms'    => [
						[
							'name'     => 'labels_type',
							'operator' => '==',
							'value'    => 'single',
						],
						[
							'name'     => 'type',
							'operator' => 'in',
							'value'    => [ 'circle', 'circle_half' ],
						],
					],
				],
			]
		);

		$this->add_control(
			'percentage_position',
			[
				'label'      => esc_html__( 'Percentage Position', 'powerpack' ),
				'type'       => Controls_Manager::SELECT,
				'default'    => 'before',
				'options'    => [
					'before' => esc_html__( 'Before', 'powerpack' ),
					'after'  => esc_html__( 'After', 'powerpack' ),
				],
				'conditions' => [
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'display_percentage',
							'operator' => '==',
							'value'    => 'yes',
						],
						[
							'relation' => 'or',
							'terms'    => [
								[
									'relation' => 'and',
									'terms'    => [
										[
											'name'     => 'labels_type',
											'operator' => '==',
											'value'    => 'single',
										],
										[
											'name'     => 'type',
											'operator' => '==',
											'value'    => 'vertical',
										],
									],
								],
								[
									'name'     => 'type',
									'operator' => 'in',
									'value'    => [ 'circle', 'circle_half' ],
								],
							],
						],
					],
				],
			]
		);

		$this->add_control(
			'bar_style',
			[
				'label'     => esc_html__( 'Style', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'solid',
				'options'   => [
					'solid'    => esc_html__( 'Solid', 'powerpack' ),
					'striped'  => esc_html__( 'Striped', 'powerpack' ),
					'gradient' => esc_html__( 'Animated Gradient', 'powerpack' ),
					'rainbow'  => esc_html__( 'Rainbow', 'powerpack' ),
				],
				'condition' => [
					'type' => [ 'line', 'vertical' ],
				],
			]
		);

		$this->add_control(
			'striped_animation',
			[
				'label'        => esc_html__( 'Animated', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
				'condition'    => [
					'bar_style' => 'striped',
					'type'      => [ 'line', 'vertical' ],
				],
			]
		);

		$repeater_gradient = new Repeater();

		$repeater_gradient->add_control(
			'gradient_color',
			[
				'label'   => esc_html__( 'Color', 'powerpack' ),
				'type'    => Controls_Manager::COLOR,
				'default' => '',
			]
		);

		$this->add_control(
			'gradient_colors',
			[
				'label'              => esc_html__( 'Gradient Colors', 'powerpack' ),
				'type'               => Controls_Manager::REPEATER,
				'default'            => [
					[ 'gradient_color' => '#6EC1E4' ],
					[ 'gradient_color' => '#54595F' ],
				],
				'fields'             => $repeater_gradient->get_controls(),
				'title_field'        => '{{{ gradient_color }}}',
				'frontend_available' => true,
				'condition'          => [
					'bar_style' => 'gradient',
					'type'      => [ 'line', 'vertical' ],
				],
			]
		);

		$this->add_control(
			'show_suffix',
			[
				'label'        => esc_html__( 'Show Prefix/Suffix', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'powerpack' ),
				'label_off'    => esc_html__( 'Hide', 'powerpack' ),
				'return_value' => 'show',
				'default'      => 'show',
				'condition'    => [
					'type' => 'circle_half',
				],
			]
		);

		$this->add_control(
			'half_circle_prefix',
			[
				'label'     => esc_html__( 'Prefix Label', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'dynamic'   => [
					'active' => true,
				],
				'default'   => __( '0%', 'powerpack' ),
				'condition' => [
					'type'        => 'circle_half',
					'show_suffix' => 'show',
				],
			]
		);

		$this->add_control(
			'half_circle_suffix',
			[
				'label'     => esc_html__( 'Suffix Label', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'dynamic'   => [
					'active' => true,
				],
				'default'   => __( '100%', 'powerpack' ),
				'condition' => [
					'type'        => 'circle_half',
					'show_suffix' => 'show',
				],
			]
		);

		$this->add_control(
			'bar_speed',
			[
				'label'              => esc_html__( 'Speed (ms)', 'powerpack' ),
				'type'               => Controls_Manager::NUMBER,
				'min'                => 0,
				'default'            => 1500,
				'frontend_available' => true,
				'selectors'          => [
					'{{WRAPPER}}' => '--pp-bar-speed: {{VALUE}}ms;',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register progress bar controls in the Style tab.
	 *
	 * @since 2.11.0
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_style_progress_controls() {
		/**
		 * Style Tab: Progress Bar
		 * -------------------------------------------------
		 */
		$this->start_controls_section(
			'section_progress_style',
			[
				'label' => esc_html__( 'Progress Bar', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'bar_size',
			[
				'label'      => esc_html__( 'Thickness', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => 30,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--pp-bar-thickness: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'type' => [ 'line', 'vertical' ],
				],
			]
		);

		$this->add_control(
			'vertical_bar_height',
			[
				'label'      => esc_html__( 'Height', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 50,
						'max'  => 500,
						'step' => 1,
					],
				],
				'default'    => [
					'size' => 200,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-vertical-bar' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'type' => 'vertical',
				],
			]
		);

		$this->add_control(
			'bar_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => 10,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--pp-bar-radius: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'type' => [ 'line', 'vertical' ],
				],
			]
		);

		$this->add_control(
			'circle_size',
			[
				'label'      => esc_html__( 'Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 50,
						'max'  => 500,
						'step' => 1,
					],
				],
				'default'    => [
					'size' => 200,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--pp-circle-size: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'type' => [ 'circle', 'circle_half' ],
				],
			]
		);

		$this->add_control(
			'circle_border_width',
			[
				'label'      => esc_html__( 'Border Width', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 1,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default'    => [
					'size' => 10,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--pp-circle-border-width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'type' => [ 'circle', 'circle_half' ],
				],
			]
		);

		$this->add_control(
			'background_color_title',
			[
				'label'     => esc_html__( 'Background', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'bar_bg_color',
				'types'     => [ 'classic', 'gradient' ],
				'exclude'   => [ 'image' ],
				'selector'  => '{{WRAPPER}} .pp-progress-line, {{WRAPPER}} .pp-vertical-bar',
				'condition' => [
					'type' => [ 'line', 'vertical' ],
				],
			]
		);

		$this->add_control(
			'circle_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}' => '--pp-circle-track-color: {{VALUE}};',
				],
				'condition' => [
					'type' => [ 'circle', 'circle_half' ],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'bar_border',
				'label'     => esc_html__( 'Border', 'powerpack' ),
				'selector'  => '{{WRAPPER}} .pp-progress-line, {{WRAPPER}} .pp-vertical-bar',
				'condition' => [
					'type' => [ 'line', 'vertical' ],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'bar_box_shadow',
				'selector'  => '{{WRAPPER}} .pp-progress-line, {{WRAPPER}} .pp-vertical-bar',
				'condition' => [
					'type' => [ 'line', 'vertical' ],
				],
			]
		);

		$this->add_responsive_control(
			'bar_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', '%', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-progress-line, {{WRAPPER}} .pp-vertical-bar' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'type' => [ 'line', 'vertical' ],
				],
			]
		);

		$this->add_control(
			'fill_title',
			[
				'label'     => esc_html__( 'Fill', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'bar_style!' => [ 'gradient', 'rainbow' ],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'bar_color',
				'types'     => [ 'classic', 'gradient' ],
				'exclude'   => [ 'image' ],
				'selector'  => '{{WRAPPER}} .pp-progress-fill',
				'condition' => [
					'type'       => [ 'line', 'vertical' ],
					'bar_style!' => [ 'gradient', 'rainbow' ],
				],
			]
		);

		$this->add_control(
			'circle_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'global'    => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'selectors' => [
					'{{WRAPPER}}' => '--pp-circle-fill-color: {{VALUE}};',
				],
				'condition' => [
					'type' => [ 'circle', 'circle_half' ],
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register label controls in the Style tab.
	 *
	 * @since 2.11.0
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_style_labels_controls() {
		$this->start_controls_section(
			'section_title',
			[
				'label' => esc_html__( 'Labels', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'label_spacing',
			[
				'label'       => esc_html__( 'Spacing', 'powerpack' ),
				'description' => esc_html__( 'Spacing between label, percentage and bar', 'powerpack' ),
				'type'        => Controls_Manager::SLIDER,
				'size_units'  => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'     => [
					'size' => 10,
					'unit' => 'px',
				],
				'selectors'   => [
					'{{WRAPPER}}' => '--pp-label-spacing: {{SIZE}}{{UNIT}};',
				],
				'separator'   => 'after',
				'condition'   => [
					'labels_type!' => 'multiple',
					'type'         => [ 'line', 'vertical' ],
				],
			]
		);

		$this->add_control(
			'label_heading_style',
			[
				'label' => esc_html__( 'Label', 'powerpack' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'global'    => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'selectors' => [
					'{{WRAPPER}}' => '--pp-label-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'typography',
				'selector' => '{{WRAPPER}} .pp-progress-label, {{WRAPPER}} .pp-bar-center-label',
				'global'   => [
					'default' => Global_Typography::TYPOGRAPHY_TEXT,
				],
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name'     => 'title_shadow',
				'selector' => '{{WRAPPER}} .pp-progress-label, {{WRAPPER}} .pp-bar-center-label',
			]
		);

		$this->add_control(
			'percentage_heading_style',
			[
				'label'      => esc_html__( 'Percentage', 'powerpack' ),
				'type'       => Controls_Manager::HEADING,
				'separator'  => 'before',
				'conditions' => [
					'relation' => 'or',
					'terms'    => [
						[
							'name'     => 'display_percentage',
							'operator' => '==',
							'value'    => 'yes',
						],
						[
							'name'     => 'display_percentage_labels',
							'operator' => '==',
							'value'    => 'yes',
						],
					],
				],
			]
		);

		$this->add_control(
			'bar_counter_color',
			[
				'label'      => esc_html__( 'Color', 'powerpack' ),
				'type'       => Controls_Manager::COLOR,
				'selectors'  => [
					'{{WRAPPER}}' => '--pp-count-color: {{VALUE}};',
				],
				'conditions' => [
					'relation' => 'or',
					'terms'    => [
						[
							'name'     => 'display_percentage',
							'operator' => '==',
							'value'    => 'yes',
						],
						[
							'name'     => 'display_percentage_labels',
							'operator' => '==',
							'value'    => 'yes',
						],
					],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'       => 'bar_counter_typography',
				'selector'   => '{{WRAPPER}} .pp-progress-count, {{WRAPPER}} .pp-bar-label-percentage',
				'exclude'    => [
					'line_height',
				],
				'conditions' => [
					'relation' => 'or',
					'terms'    => [
						[
							'name'     => 'display_percentage',
							'operator' => '==',
							'value'    => 'yes',
						],
						[
							'name'     => 'display_percentage_labels',
							'operator' => '==',
							'value'    => 'yes',
						],
					],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name'       => 'bar_counter_shadow',
				'selector'   => '{{WRAPPER}} .pp-progress-count, {{WRAPPER}} .pp-bar-label-percentage',
				'conditions' => [
					'relation' => 'or',
					'terms'    => [
						[
							'name'     => 'display_percentage',
							'operator' => '==',
							'value'    => 'yes',
						],
						[
							'name'     => 'display_percentage_labels',
							'operator' => '==',
							'value'    => 'yes',
						],
					],
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register indicator controls in the Style tab.
	 *
	 * @since 2.11.0
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_style_indicator_controls() {
		$this->start_controls_section(
			'labels_indicator_section',
			[
				'label'     => esc_html__( 'Indicator', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'labels_type'       => 'multiple',
					'labels_indicator!' => '',
				],
			]
		);

		$this->add_control(
			'indicator_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'global'    => [
					'default' => Global_Colors::COLOR_SECONDARY,
				],
				'selectors' => [
					'{{WRAPPER}}' => '--pp-indicator-color: {{VALUE}};',
				],
				'condition' => [
					'labels_indicator!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'indicator_pin_size',
			[
				'label'      => esc_html__( 'Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}}' => '--pp-indicator-pin-size: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'labels_indicator' => 'line_pin',
				],
			]
		);

		$this->add_responsive_control(
			'indicator_arrow_size',
			[
				'label'      => esc_html__( 'Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}}' => '--pp-indicator-arrow-size: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'labels_indicator' => 'arrow',
				],
			]
		);

		$this->add_responsive_control(
			'indicator_pin_height',
			[
				'label'      => esc_html__( 'Height', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-bar-label-pin' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'labels_indicator' => 'line_pin',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register prefix/suffix controls in the Style tab.
	 *
	 * @since 2.11.0
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_style_prefix_suffix_controls() {
		$this->start_controls_section(
			'section_suffix',
			[
				'label'     => esc_html__( 'Prefix/Suffix', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'type'        => 'circle_half',
					'show_suffix' => 'show',
				],
			]
		);

		$this->add_control(
			'bar_suffix_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}' => '--pp-suffix-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'bar_suffix_typography',
				'selector' => '{{WRAPPER}} .pp-progress-bar-hf-label-left, {{WRAPPER}} .pp-progress-bar-hf-label-right',
				'exclude'  => [
					'line_height',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name'     => 'bar_suffix_shadow',
				'selector' => '{{WRAPPER}} .pp-progress-bar-hf-label-left, {{WRAPPER}} .pp-progress-bar-hf-label-right',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Bar types the widget knows how to render.
	 *
	 * @since 3.2.0
	 */
	const BAR_TYPES = [ 'line', 'vertical', 'circle', 'circle_half' ];

	/**
	 * Resolve the bar type, falling back to the default for unknown values.
	 *
	 * Documents saved before the unreleased "dots" type was removed can still
	 * carry it, so anything outside self::BAR_TYPES degrades to a line bar
	 * rather than rendering no bar at all.
	 *
	 * @since 3.2.0
	 * @access protected
	 *
	 * @param array $settings Widget settings.
	 * @return string One of self::BAR_TYPES.
	 */
	protected function get_bar_type( $settings ) {
		return in_array( $settings['type'], self::BAR_TYPES, true ) ? $settings['type'] : 'line';
	}

	/**
	 * Render the progress bar wrapper, label, percentage and inner markup.
	 *
	 * @since 2.11.0
	 * @access protected
	 *
	 * @return void
	 */
	protected function render_progress_bar() {
		$settings   = $this->get_settings_for_display();
		$type       = $this->get_bar_type( $settings );
		$title      = ! empty( $settings['bar_label'] ) ? $settings['bar_label'] : '';
		$percentage = is_numeric( $settings['percentage'] ) ? max( 0, min( 100, (int) $settings['percentage'] ) ) : 0;
		$style      = ! empty( $settings['bar_style'] ) ? $settings['bar_style'] : 'solid';
		$show_count = 'yes' === $settings['display_percentage'];
		$count_pos  = 'after' === $settings['percentage_position'] ? 'after' : 'before';
		$has_label  = ! Utils::is_empty( $title );
		$label_id   = 'pp-progress-label-' . $this->get_id();

		// Gathered once and handed to the per-type render methods, so each of
		// them takes one parameter instead of six.
		$args = [
			'settings'   => $settings,
			'title'      => $title,
			'label_id'   => $label_id,
			'percentage' => $percentage,
			'show_count' => $show_count,
			'count_pos'  => $count_pos,
			'has_label'  => $has_label,
		];

		$bar_setting_key = 'bar_wrapper';

		$this->add_render_attribute(
			$bar_setting_key,
			[
				'class'      => 'pp-progress-bar-wrapper',
				'data-value' => $percentage,
			]
		);

		/*
		 * role="progressbar" goes on the track - the element that actually
		 * depicts the value - rather than on the wrapper. A progressbar's
		 * children are presentational, so anything inside it is dropped by
		 * assistive tech; keeping the label and the percentage outside is what
		 * lets them be announced at all.
		 */
		$this->add_render_attribute(
			'bar_track',
			[
				'role'          => 'progressbar',
				'aria-valuemin' => '0',
				'aria-valuemax' => '100',
				'aria-valuenow' => $percentage,
			]
		);

		/*
		 * aria-labelledby may only point at an id that is actually in the
		 * document. render_circle_content() prints the label for both circle
		 * types whatever Labels Type is set to, but for line and vertical it is
		 * only printed for the single label, so pointing at it under "multiple"
		 * would leave the reference dangling. Without a label to point at, the
		 * bar still needs a name of its own, or it is announced as an unnamed
		 * progressbar.
		 */
		$is_circle    = in_array( $type, [ 'circle', 'circle_half' ], true );
		$label_is_set = $has_label && ( $is_circle || 'single' === $settings['labels_type'] );

		if ( $label_is_set ) {
			$this->add_render_attribute( 'bar_track', 'aria-labelledby', $label_id );
		} else {
			$this->add_render_attribute( 'bar_track', 'aria-label', esc_html__( 'Progress', 'powerpack' ) );
		}

		if ( 'striped' === $style ) {
			$this->add_render_attribute( $bar_setting_key, 'class', 'pp-progress-bar-striped' );

			if ( 'yes' === $settings['striped_animation'] ) {
				$this->add_render_attribute( $bar_setting_key, 'class', 'pp-progress-bar-active' );
			}
		} elseif ( 'gradient' === $style ) {
			$this->add_render_attribute( $bar_setting_key, 'class', 'pp-progress-bar-gradient' );
		} elseif ( 'rainbow' === $style ) {
			$this->add_render_attribute( $bar_setting_key, 'class', 'pp-progress-bar-rainbow' );
		}

		?>
		<div <?php $this->print_render_attribute_string( $bar_setting_key ); ?>>
			<?php
			if ( 'single' === $settings['labels_type'] && 'line' === $type ) {
				$this->render_label( $args );
			}

			if (
				$show_count &&
				'single' === $settings['labels_type'] &&
				(
					'line' === $type ||
					( 'vertical' === $type && 'before' === $count_pos )
				)
			) {
				$this->render_count( $args );
			}

			if ( 'multiple' === $settings['labels_type'] && ( 'line' === $type || 'vertical' === $type ) ) {
				$this->render_labels( $args );
			}

			switch ( $type ) :
				case 'circle':
					$this->render_circle_track( $args );
					break;

				case 'circle_half':
					$this->render_half_circle_track( $args );
					break;

				case 'vertical':
					$this->render_linear_track( $args, 'pp-vertical-bar', 'height' );
					break;

				case 'line':
				default:
					$this->render_linear_track( $args, 'pp-progress-line', 'width' );
					break;
			endswitch;

			if (
				$show_count &&
				'vertical' === $type &&
				'single' === $settings['labels_type'] &&
				'after' === $count_pos
			) {
				$this->render_count( $args );
			}

			if ( 'single' === $settings['labels_type'] && 'vertical' === $type ) {
				$this->render_label( $args );
			}
			?>
		</div>
		<?php
	}

	/**
	 * Render a line or vertical track and its fill.
	 *
	 * Both types differ only in the class they carry and the dimension the fill
	 * grows along, so they share one method.
	 *
	 * @since 3.2.0
	 * @access protected
	 *
	 * @param array  $args      Render arguments, see render_progress_bar().
	 * @param string $class     Class for the track element.
	 * @param string $dimension CSS property the fill grows along, width or height.
	 * @return void
	 */
	protected function render_linear_track( $args, $class, $dimension ) {
		$this->add_render_attribute( 'bar_track', 'class', $class );
		?>
		<div <?php $this->print_render_attribute_string( 'bar_track' ); ?>>
			<div class="pp-progress-fill" style="<?php echo esc_attr( $dimension ); ?>: <?php echo esc_attr( $args['percentage'] ); ?>%;"></div>
		</div>
		<?php
	}

	/**
	 * Render the full circle track.
	 *
	 * The fill is two half-circles: the left one rotates, and past the halfway
	 * point the right one is revealed and the clip lifted so the rotation can
	 * carry on round.
	 *
	 * @since 3.2.0
	 * @access protected
	 *
	 * @param array $args Render arguments, see render_progress_bar().
	 * @return void
	 */
	protected function render_circle_track( $args ) {
		$rotate   = $args['percentage'] * 3.6;
		$past_180 = $rotate > 180;

		$this->add_render_attribute( 'bar_track', 'class', 'pp-bar-circle' );

		if ( $past_180 ) {
			$this->add_render_attribute( 'bar_track', 'style', 'clip-path: inset(0);' );
		}
		?>
		<div class="pp-bar-circle-wrapper">
			<div <?php $this->print_render_attribute_string( 'bar_track' ); ?>>
				<div class="pp-progress-fill pp-progress-fill-left" style="transform: rotate(<?php echo esc_attr( $rotate ); ?>deg);"></div>
				<div class="pp-progress-fill pp-progress-fill-right"<?php echo $past_180 ? ' style="visibility: visible;"' : ''; ?>></div>
			</div>
			<?php $this->render_circle_content( $args ); ?>
		</div>
		<?php
	}

	/**
	 * Render the half circle track and its prefix/suffix labels.
	 *
	 * @since 3.2.0
	 * @access protected
	 *
	 * @param array $args Render arguments, see render_progress_bar().
	 * @return void
	 */
	protected function render_half_circle_track( $args ) {
		$settings = $args['settings'];
		$rotate   = $args['percentage'] * 1.8;

		$this->add_render_attribute( 'bar_track', 'class', 'pp-bar-circle' );
		?>
		<div class="pp-progress-circle-half">
			<div class="pp-bar-circle-wrapper">
				<div <?php $this->print_render_attribute_string( 'bar_track' ); ?>>
					<div class="pp-progress-fill pp-progress-fill-left" style="transform: rotate(<?php echo esc_attr( $rotate ); ?>deg);"></div>
				</div>
			</div>
			<?php $this->render_circle_content( $args ); ?>
		</div>
		<?php
		if ( 'show' !== $settings['show_suffix'] ) {
			return;
		}
		?>
		<div class="pp-progress-bar-hf-labels">
			<span class="pp-progress-bar-hf-label-left">
				<?php echo esc_html( $settings['half_circle_prefix'] ); ?>
			</span>
			<span class="pp-progress-bar-hf-label-right">
				<?php echo esc_html( $settings['half_circle_suffix'] ); ?>
			</span>
		</div>
		<?php
	}

	/**
	 * Render the bar label.
	 *
	 * The id is what role="progressbar" points its aria-labelledby at, so the
	 * label has to carry one even though nothing else references it.
	 *
	 * @since 3.2.0
	 * @access protected
	 *
	 * @param array $args Render arguments, see render_progress_bar().
	 * @return void
	 */
	protected function render_label( $args ) {
		if ( ! $args['has_label'] ) {
			return;
		}

		$tag = $args['settings']['title_tag'];
		?>
		<<?php Utils::print_validated_html_tag( $tag ); ?> class="pp-progress-label" id="<?php echo esc_attr( $args['label_id'] ); ?>">
			<?php echo esc_html( $args['title'] ); ?>
		</<?php Utils::print_validated_html_tag( $tag ); ?>>
		<?php
	}

	/**
	 * Render the percentage count.
	 *
	 * The real value is printed rather than a hardcoded 0% so the widget still
	 * reads correctly without JavaScript, in print, and in reader modes. The
	 * frontend script zeroes it on init before animating back up to it.
	 *
	 * Hidden from assistive tech: the track carries aria-valuenow, so the same
	 * percentage would otherwise be announced twice.
	 *
	 * @since 3.2.0
	 * @access protected
	 *
	 * @param array $args Render arguments, see render_progress_bar().
	 * @return void
	 */
	protected function render_count( $args ) {
		?>
		<div class="pp-progress-count" aria-hidden="true"><?php echo esc_html( $args['percentage'] ); ?>%</div>
		<?php
	}

	/**
	 * Render the percentage count and label inside a circle / half-circle.
	 *
	 * Output order honours the "Percentage Position" control: when set to
	 * "after", the label is rendered before the percentage; otherwise the
	 * percentage is rendered first.
	 *
	 * The wrapping element is skipped entirely when there is neither a label nor
	 * a percentage to put in it, rather than emitting an empty positioned div.
	 *
	 * @since 3.0.0
	 * @access protected
	 *
	 * @param array $args Render arguments, see render_progress_bar().
	 * @return void
	 */
	protected function render_circle_content( $args ) {
		if ( ! $args['has_label'] && ! $args['show_count'] ) {
			return;
		}
		?>
		<div class="pp-bar-circle-content">
			<?php
			if ( 'after' === $args['count_pos'] ) {
				$this->render_label( $args );
			}

			if ( $args['show_count'] ) {
				$this->render_count( $args );
			}

			if ( 'after' !== $args['count_pos'] ) {
				$this->render_label( $args );
			}
			?>
		</div>
		<?php
	}

	/**
	 * Render the multi-label list shown alongside the bar.
	 *
	 * Prints directly rather than returning a string: escaping now happens at
	 * each output point, where it can be seen, instead of being buried in a
	 * builder whose result the caller had to echo raw.
	 *
	 * @since 2.11.0
	 * @access protected
	 *
	 * @param array $args Render arguments, see render_progress_bar().
	 * @return void
	 */
	protected function render_labels( $args ) {
		$settings = $args['settings'];

		if ( empty( $settings['labels'] ) ) {
			return;
		}

		$indicator = 'none';

		if ( 'arrow' === $settings['labels_indicator'] ) {
			$indicator = 'arrow';
		} elseif ( 'line_pin' === $settings['labels_indicator'] ) {
			$indicator = 'pin';
		}

		$is_vertical = 'vertical' === $this->get_bar_type( $settings );
		?>
		<div class="pp-bar-container-label pp-bar-indicator-<?php echo esc_attr( $indicator ); ?> pp-bar-indicator-align-<?php echo esc_attr( $settings['labels_align'] ); ?>">
			<?php
			/*
			 * Emitted without whitespace between the elements: .pp-bar-label
			 * floats its label and indicator apart, and a stray text node
			 * between two floats is not free.
			 */
			foreach ( $settings['labels'] as $item ) {
				$number = is_numeric( $item['number'] ) ? max( 0, min( 100, (int) $item['number'] ) ) : 0;

				/*
				 * Logical property rather than an is_rtl() branch: the
				 * stylesheet positions .pp-bar-label with inset-inline-start,
				 * and a physical left/right here has to be kept in lockstep
				 * with the compiled RTL output by hand.
				 */
				if ( $is_vertical ) {
					$direction_style = 'top:' . ( 100 - $number ) . '%;';
				} else {
					$direction_style = 'inset-inline-start:' . $number . '%;';
				}
				?><div class="pp-bar-label" style="<?php echo esc_attr( $direction_style ); ?>"><p class="pp-bar-center-label"><?php echo esc_html( $item['text'] ); ?><?php if ( 'yes' === $settings['display_percentage_labels'] ) : ?> <span class="pp-bar-label-percentage"><?php echo esc_html( $number ); ?>%</span><?php endif; ?></p><?php $this->render_indicator( $settings['labels_indicator'] ); ?></div><?php
			}
			?>
		</div>
		<?php
	}

	/**
	 * Render the label indicator.
	 *
	 * The pin and the arrow are drawn entirely in CSS and carry no text, so
	 * they are decorative spans hidden from assistive tech rather than the
	 * empty paragraphs they used to be.
	 *
	 * @since 2.11.0
	 * @access private
	 *
	 * @param string $indicator The type of label indicator.
	 * @return void
	 */
	private function render_indicator( $indicator ) {
		switch ( $indicator ) {
			case 'arrow':
				echo '<span class="pp-bar-label-arrow" aria-hidden="true"></span>';
				break;
			case 'line_pin':
				echo '<span class="pp-bar-label-pin" aria-hidden="true"></span>';
				break;
		}
	}

	/**
	 * Render progress widget output on the frontend.
	 * Make sure value does not exceed 100%.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 2.11.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$type     = $this->get_bar_type( $settings );

		$this->add_render_attribute( 'container', 'class', [ 'pp-progress-bar-container', 'pp-progress-bar-' . $type ] );

		?>
		<div <?php $this->print_render_attribute_string( 'container' ); ?>>
			<?php $this->render_progress_bar(); ?>
		</div>
		<?php
	}
}
