<?php
namespace PowerpackElements\Modules\Posts\Widgets;

use PowerpackElements\Modules\Posts\Widgets\Posts_Base;
use PowerpackElements\Modules\Posts\Module;
use PowerpackElements\Classes\PP_Helper;
use PowerpackElements\Group_Control_Transition;

// Elementor Classes.
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Css_Filter;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Tiled Posts Widget
 */
class Tiled_Posts extends Posts_Base {

	/**
	 * Attributes kept when printing generated image markup.
	 *
	 * wp_kses_post() allows neither srcset nor sizes on an <img>, so running the
	 * output of wp_get_attachment_image() through it would silently throw away
	 * the responsive image set that is the whole point of rendering an <img>.
	 *
	 * @since 3.2.0
	 */
	const IMAGE_ALLOWED_HTML = [
		'img' => [
			'alt'           => true,
			'class'         => true,
			'decoding'      => true,
			'fetchpriority' => true,
			'height'        => true,
			'id'            => true,
			'loading'       => true,
			'sizes'         => true,
			'src'           => true,
			'srcset'        => true,
			'style'         => true,
			'title'         => true,
			'width'         => true,
		],
	];

	/**
	 * Retrieve tiled posts widget name.
	 *
	 * @since 2.0.3
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return parent::get_widget_name( 'Tiled_Posts' );
	}

	/**
	 * Retrieve tiled posts widget title.
	 *
	 * @since 2.0.3
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return parent::get_widget_title( 'Tiled_Posts' );
	}

	/**
	 * Retrieve tiled posts widget icon.
	 *
	 * @since 2.0.3
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return parent::get_widget_icon( 'Tiled_Posts' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 1.4.13.1
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return parent::get_widget_keywords( 'Tiled_Posts' );
	}

	/**
	 * Retrieve the list of styles the tiled posts widget depended on.
	 *
	 * Used to set styles dependencies required to run the widget.
	 *
	 * @since 2.10.26
	 * @access public
	 *
	 * @return array Widget styles dependencies.
	 */
	public function get_style_depends() {
		return [
			'widget-pp-tiled-posts',
		];
	}

	/**
	 * Whether the widget renders its own inner wrapper.
	 *
	 * Elementor's optimized markup mode removes the extra
	 * `.elementor-widget-container` element, so the wrapper is only reported
	 * when that experiment is inactive.
	 *
	 * @since 2.11.8
	 * @access public
	 *
	 * @return bool Whether the inner wrapper is rendered.
	 */
	public function has_widget_inner_wrapper(): bool {
		return ! PP_Helper::is_feature_active( 'e_optimized_markup' );
	}

	/**
	 * Register tiled posts widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 2.0.3
	 * @access protected
	 */
	protected function register_controls() {

		/* Content Tab: Layout */
		$this->register_content_layout_controls();

		/* Content Tab: Other Posts */
		$this->register_content_other_posts_controls();

		/* Content Tab: Query */
		$this->register_query_section_controls( '', 'tiled_posts', 'yes' );

		/* Content Tab: Post Meta */
		$this->register_content_post_meta_controls();

		/* Style Tab: Layout */
		$this->register_style_layout_controls();

		/* Style Tab: Image */
		$this->register_style_image_controls();

		/* Style Tab: Content */
		$this->register_style_content_controls();

		/* Style Tab: Title */
		$this->register_style_title_controls();

		/* Style Tab: Post Category */
		$this->register_style_post_category_controls();

		/* Style Tab: Post Meta */
		$this->register_style_post_meta_controls();

		/* Style Tab: Post Excerpt */
		$this->register_style_post_excerpt_controls();

		/* Style Tab: Button */
		$this->register_style_button_controls();

		/* Style Tab: Post Overlay */
		$this->register_style_overlay_controls();
	}

	/**
	 * Content Tab: Layout
	 */
	protected function register_content_layout_controls() {
		$this->start_controls_section(
			'section_post_settings',
			[
				'label' => esc_html__( 'Layout', 'powerpack' ),
			]
		);

		$this->add_control(
			'layout',
			[
				'label'       => esc_html__( 'Layout', 'powerpack' ),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => true,
				'toggle'      => false,
				'options'     => [
					'layout-1' => [
						'title' => esc_html__( 'Layout 1', 'powerpack' ),
						'icon'  => 'ppicon-layout-1',
					],
					'layout-2' => [
						'title' => esc_html__( 'Layout 2', 'powerpack' ),
						'icon'  => 'ppicon-layout-2',
					],
					'layout-3' => [
						'title' => esc_html__( 'Layout 3', 'powerpack' ),
						'icon'  => 'ppicon-layout-3',
					],
					'layout-4' => [
						'title' => esc_html__( 'Layout 4', 'powerpack' ),
						'icon'  => 'ppicon-layout-4',
					],
					'layout-5' => [
						'title' => esc_html__( 'Layout 5', 'powerpack' ),
						'icon'  => 'ppicon-layout-5',
					],
					'layout-6' => [
						'title' => esc_html__( 'Layout 6', 'powerpack' ),
						'icon'  => 'ppicon-layout-6',
					],
				],
				'separator'   => 'none',
				'default'     => 'layout-1',
			]
		);

		$this->add_control(
			'content_vertical_position',
			[
				'label'       => esc_html__( 'Content Position', 'powerpack' ),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => false,
				'options'     => [
					'top'    => [
						'title' => esc_html__( 'Top', 'powerpack' ),
						'icon'  => 'eicon-v-align-top',
					],
					'middle' => [
						'title' => esc_html__( 'Middle', 'powerpack' ),
						'icon'  => 'eicon-v-align-middle',
					],
					'bottom' => [
						'title' => esc_html__( 'Bottom', 'powerpack' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'separator'   => 'before',
				'default'     => 'bottom',
			]
		);

		$this->add_control(
			'content_text_alignment',
			[
				'label'       => esc_html__( 'Text Alignment', 'powerpack' ),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => false,
				'default'     => 'left',
				'options'     => [
					'left'   => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'selectors'   => [
					'{{WRAPPER}} .pp-tiled-post-content' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'post_title',
			[
				'label'        => esc_html__( 'Post Title', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'post_title_length',
			[
				'label'       => esc_html__( 'Title Length', 'powerpack' ),
				'title'       => esc_html__( 'In characters', 'powerpack' ),
				'description' => esc_html__( 'Leave blank to show full title', 'powerpack' ),
				'type'        => Controls_Manager::NUMBER,
				'step'        => 1,
				'condition'   => [
					'post_title' => 'yes',
				],
			]
		);

		$this->add_control(
			'post_title_html_tag',
			[
				'label'     => esc_html__( 'Title HTML Tag', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'h2',
				'options'   => [
					'h1'   => esc_html__( 'H1', 'powerpack' ),
					'h2'   => esc_html__( 'H2', 'powerpack' ),
					'h3'   => esc_html__( 'H3', 'powerpack' ),
					'h4'   => esc_html__( 'H4', 'powerpack' ),
					'h5'   => esc_html__( 'H5', 'powerpack' ),
					'h6'   => esc_html__( 'H6', 'powerpack' ),
					'div'  => esc_html__( 'div', 'powerpack' ),
					'span' => esc_html__( 'span', 'powerpack' ),
					'p'    => esc_html__( 'p', 'powerpack' ),
				],
				'condition' => [
					'post_title' => 'yes',
				],
			]
		);

		$this->add_control(
			'read_more_button',
			[
				'label'        => esc_html__( 'Read More Button', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'read_more_button_text',
			[
				'label'       => esc_html__( 'Button Text', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Read More', 'powerpack' ),
				'placeholder' => esc_html__( 'Read More', 'powerpack' ),
				'condition'   => [
					'read_more_button' => 'yes',
				],
			]
		);

		$this->add_control(
			'fallback_image',
			[
				'label'     => esc_html__( 'Fallback Image', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					''            => esc_html__( 'None', 'powerpack' ),
					'placeholder' => esc_html__( 'Placeholder', 'powerpack' ),
					'custom'      => esc_html__( 'Custom', 'powerpack' ),
				],
				'default'   => '',
				'separator' => 'before',
			]
		);

		$this->add_control(
			'fallback_image_custom',
			[
				'label'     => esc_html__( 'Fallback Image Custom', 'powerpack' ),
				'type'      => Controls_Manager::MEDIA,
				'condition' => [
					'fallback_image' => 'custom',
				],
			]
		);

		$this->add_control(
			'large_tile_heading',
			[
				'label'     => esc_html__( 'Large Tile', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'layout!' => 'layout-5',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'image_size',
				'label'     => esc_html__( 'Image Size', 'powerpack' ),
				'default'   => 'medium_large',
				'condition' => [
					'layout!' => 'layout-5',
				],
			]
		);

		$this->add_control(
			'post_excerpt',
			[
				'label'        => esc_html__( 'Post Excerpt', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'no',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'condition'    => [
					'layout!' => 'layout-5',
				],
			]
		);

		$this->add_control(
			'excerpt_length',
			[
				'label'     => esc_html__( 'Excerpt Length', 'powerpack' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 20,
				'min'       => 0,
				'max'       => 58,
				'step'      => 1,
				'condition' => [
					'layout!'      => 'layout-5',
					'post_excerpt' => 'yes',
				],
			]
		);

		$this->add_control(
			'small_tiles_heading',
			[
				'label'     => esc_html__( 'Small Tiles', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'    => 'image_size_small',
				'label'   => esc_html__( 'Image Size', 'powerpack' ),
				'default' => 'medium_large',
			]
		);

		$this->add_control(
			'post_excerpt_small',
			[
				'label'        => esc_html__( 'Post Excerpt', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'no',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'excerpt_length_small',
			[
				'label'     => esc_html__( 'Excerpt Length', 'powerpack' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 20,
				'min'       => 0,
				'max'       => 58,
				'step'      => 1,
				'condition' => [
					'post_excerpt_small' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Content Tab: Other Posts
	 */
	protected function register_content_other_posts_controls() {
		$this->start_controls_section(
			'section_other_posts',
			[
				'label' => esc_html__( 'Other Posts', 'powerpack' ),
			]
		);

		$this->add_control(
			'other_posts',
			[
				'label'        => esc_html__( 'Show Other Posts', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'no',
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'other_posts_count',
			[
				'label'       => esc_html__( 'Posts Count', 'powerpack' ),
				'description' => sprintf(
					/* translators: %d: Maximum number of posts shown when the field is left blank. */
					esc_html__( 'Leave blank to show up to %d posts.', 'powerpack' ),
					$this->get_max_other_posts()
				),
				'type'        => Controls_Manager::NUMBER,
				'step'        => 1,
				'default'     => 4,
				'condition'   => [
					'other_posts' => 'yes',
				],
			]
		);

		$this->add_control(
			'other_posts_columns',
			[
				'label'     => esc_html__( 'Columns', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'1' => esc_html__( '1', 'powerpack' ),
					'2' => esc_html__( '2', 'powerpack' ),
					'3' => esc_html__( '3', 'powerpack' ),
					'4' => esc_html__( '4', 'powerpack' ),
				],
				'default'   => '2',
				'condition' => [
					'other_posts' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Content Tab: Post Meta
	 */
	protected function register_content_post_meta_controls() {
		$this->start_controls_section(
			'section_post_meta',
			[
				'label' => esc_html__( 'Post Meta', 'powerpack' ),
			]
		);

		$this->add_control(
			'post_meta',
			[
				'label'        => esc_html__( 'Post Meta', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'post_meta_divider',
			[
				'label'     => esc_html__( 'Post Meta Divider', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => '-',
				'selectors' => [
					'{{WRAPPER}} .pp-tiled-posts-meta > span:not(:last-child):after' => 'content: "{{VALUE}}";',
				],
				'condition' => [
					'post_meta' => 'yes',
				],
			]
		);

		$this->add_control(
			'post_author',
			[
				'label'        => esc_html__( 'Post Author', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'condition'    => [
					'post_meta' => 'yes',
				],
			]
		);

		$this->add_control(
			'post_category',
			[
				'label'        => esc_html__( 'Post Category', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'condition'    => [
					'post_meta' => 'yes',
				],
			]
		);

		$this->add_control(
			'post_taxonomy',
			[
				'label'       => esc_html__( 'Taxonomy', 'powerpack' ),
				'description' => esc_html__( 'Taxonomy used for the displayed terms.', 'powerpack' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => $this->get_taxonomy_options(),
				'default'     => 'category',
				'condition'   => [
					'post_meta'     => 'yes',
					'post_category' => 'yes',
				],
			]
		);

		$this->add_control(
			'max_terms',
			[
				'label'       => esc_html__( 'Max Terms to Show', 'powerpack' ),
				'description' => esc_html__( 'Leave blank to show all terms.', 'powerpack' ),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 0,
				'step'        => 1,
				'default'     => 1,
				'label_block' => false,
				'condition'   => [
					'post_meta'     => 'yes',
					'post_category' => 'yes',
				],
			]
		);

		$this->add_control(
			'terms_separator',
			[
				'label'     => esc_html__( 'Terms Separator', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => ',',
				'selectors' => [
					'{{WRAPPER}} .pp-post-categories > span:not(:last-child):after' => 'content: "{{VALUE}}";',
				],
				'condition' => [
					'post_meta'     => 'yes',
					'post_category' => 'yes',
				],
			]
		);

		$this->add_control(
			'post_date',
			[
				'label'        => esc_html__( 'Post Date', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'condition'    => [
					'post_meta' => 'yes',
				],
			]
		);

		$this->add_control(
			'date_type',
			[
				'label'     => esc_html__( 'Date Type', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					''         => esc_html__( 'Published Date', 'powerpack' ),
					'modified' => esc_html__( 'Last Modified Date', 'powerpack' ),
					'ago'      => esc_html__( 'Time Ago', 'powerpack' ),
					'key'      => esc_html__( 'Custom Meta Key', 'powerpack' ),
				],
				'default'   => '',
				'condition' => [
					'post_meta' => 'yes',
					'post_date' => 'yes',
				],
			]
		);

		$this->add_control(
			'date_format',
			[
				'label'     => esc_html__( 'Date Format', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					''       => esc_html__( 'Default', 'powerpack' ),
					'F j, Y' => date_i18n( 'F j, Y' ),
					'Y-m-d'  => date_i18n( 'Y-m-d' ),
					'm/d/Y'  => date_i18n( 'm/d/Y' ),
					'd/m/Y'  => date_i18n( 'd/m/Y' ),
					'custom' => esc_html__( 'Custom', 'powerpack' ),
				],
				'default'   => '',
				'condition' => [
					'post_meta' => 'yes',
					'post_date' => 'yes',
					'date_type' => [ '', 'modified' ],
				],
			]
		);

		$this->add_control(
			'date_custom_format',
			[
				'label'       => esc_html__( 'Custom Format', 'powerpack' ),
				'description' => sprintf(
					/* translators: 1: Link opening tag, 2: Link closing tag. */
					esc_html__( 'Refer to PHP date formats %1$shere%2$s', 'powerpack' ),
					sprintf( '<a href="%s" target="_blank">', esc_url( 'https://wordpress.org/support/article/formatting-date-and-time/' ) ),
					'</a>'
				),
				'type'        => Controls_Manager::TEXT,
				'label_block' => false,
				'default'     => 'F j, Y',
				'ai'          => [
					'active' => false,
				],
				'condition'   => [
					'post_meta'   => 'yes',
					'post_date'   => 'yes',
					'date_type'   => [ '', 'modified' ],
					'date_format' => 'custom',
				],
			]
		);

		$this->add_control(
			'date_meta_key',
			[
				'label'       => esc_html__( 'Custom Meta Key', 'powerpack' ),
				'description' => esc_html__( 'Display the post date stored in custom meta key. Protected keys, such as those starting with an underscore, are not available.', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => false,
				'default'     => '',
				'ai'          => [
					'active' => false,
				],
				'condition'   => [
					'post_meta' => 'yes',
					'post_date' => 'yes',
					'date_type' => 'key',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Layout
	 */
	protected function register_style_layout_controls() {
		$this->start_controls_section(
			'section_layout_style',
			[
				'label' => esc_html__( 'Layout', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'height',
			[
				'label'      => esc_html__( 'Height', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'vh', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 200,
						'max'  => 1000,
						'step' => 1,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 535,
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-tiled-posts-grid' => '--pp-tiles-height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'horizontal_spacing',
			[
				'label'      => esc_html__( 'Horizontal Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 5,
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-tiled-posts-grid' => '--pp-tiles-gap-x: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'vertical_spacing',
			[
				'label'      => esc_html__( 'Vertical Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 5,
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-tiled-posts-grid' => '--pp-tiles-gap-y: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'tiles_style_heading',
			[
				'label'     => esc_html__( 'Tiles', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'fallback_img_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-media-background' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'tiles_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-tiled-post',
			]
		);

		$this->add_responsive_control(
			'tiles_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-tiled-post' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'tiles_box_shadow',
				'selector' => '{{WRAPPER}} .pp-tiled-post',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Image
	 */
	protected function register_style_image_controls() {
		$this->start_controls_section(
			'section_post_image_style',
			[
				'label' => esc_html__( 'Image', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'image_position',
			[
				'label'     => esc_html__( 'Image Position', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					''              => _x( 'Default', 'Background Image Position', 'powerpack' ),
					'center center' => _x( 'Center Center', 'Background Image Position', 'powerpack' ),
					'center left'   => _x( 'Center Left', 'Background Image Position', 'powerpack' ),
					'center right'  => _x( 'Center Right', 'Background Image Position', 'powerpack' ),
					'top center'    => _x( 'Top Center', 'Background Image Position', 'powerpack' ),
					'top left'      => _x( 'Top Left', 'Background Image Position', 'powerpack' ),
					'top right'     => _x( 'Top Right', 'Background Image Position', 'powerpack' ),
					'bottom center' => _x( 'Bottom Center', 'Background Image Position', 'powerpack' ),
					'bottom left'   => _x( 'Bottom Left', 'Background Image Position', 'powerpack' ),
					'bottom right'  => _x( 'Bottom Right', 'Background Image Position', 'powerpack' ),
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-media-background img' => 'object-position: {{VALUE}};',
				],
			]
		);

		$this->start_controls_tabs( 'thumbnail_effects_tabs' );

		$this->start_controls_tab(
			'tab_thumbnail_normal',
			[
				'label' => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_group_control(
			Group_Control_Css_Filter::get_type(),
			[
				'name'     => 'thumbnail_filters',
				'selector' => '{{WRAPPER}} .pp-media-background',
			]
		);

		$this->add_group_control(
			Group_Control_Transition::get_type(),
			[
				'name'     => 'image_transition',
				'selector' => '{{WRAPPER}} .pp-media-background, {{WRAPPER}} .pp-post-link:before',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_thumbnail_hover',
			[
				'label' => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_group_control(
			Group_Control_Css_Filter::get_type(),
			[
				'name'     => 'thumbnail_hover_filters',
				'selector' => '{{WRAPPER}} .pp-tiled-post:hover .pp-media-background',
			]
		);

		$this->add_control(
			'hover_animation',
			[
				'label' => esc_html__( 'Hover Animation', 'powerpack' ),
				'type'  => Controls_Manager::HOVER_ANIMATION,
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Content
	 */
	protected function register_style_content_controls() {
		$this->start_controls_section(
			'section_post_content_style',
			[
				'label' => esc_html__( 'Content', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'post_content_bg',
				'label'    => esc_html__( 'Post Content Background', 'powerpack' ),
				'types'    => [ 'classic', 'gradient' ],
				'exclude'  => [ 'image' ],
				'selector' => '{{WRAPPER}} .pp-tiled-post-content',
			]
		);

		$this->add_responsive_control(
			'post_content_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-tiled-post-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Title
	 */
	protected function register_style_title_controls() {
		$this->start_controls_section(
			'section_title_style',
			[
				'label'     => esc_html__( 'Title', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_title' => 'yes',
				],
			]
		);

		$this->add_control(
			'title_text_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-tiled-post-title' => 'color: {{VALUE}}',
				],
				'condition' => [
					'post_title' => 'yes',
				],
			]
		);

		$this->add_control(
			'title_text_color_hover',
			[
				'label'     => esc_html__( 'Hover Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-tiled-post:hover .pp-tiled-post-title' => 'color: {{VALUE}}',
				],
				'condition' => [
					'post_title' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'title_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'global'    => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector'  => '{{WRAPPER}} .pp-tiled-post-title',
				'condition' => [
					'post_title' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name'     => 'title_text_shadow',
				'selector' => '{{WRAPPER}} .pp-tiled-post-title',
			]
		);

		$this->add_responsive_control(
			'title_margin_bottom',
			[
				'label'      => esc_html__( 'Margin Bottom', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-tiled-post-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'post_title' => 'yes',
				],
			]
		);

		$this->add_control(
			'large_tile_title_heading',
			[
				'label'     => esc_html__( 'Large Tile', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'layout!'    => 'layout-5',
					'post_title' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'large_title_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'global'    => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector'  => '{{WRAPPER}} .pp-tiled-post-featured .pp-tiled-post-title',
				'condition' => [
					'layout!'    => 'layout-5',
					'post_title' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Post Category
	 */
	protected function register_style_post_category_controls() {
		$this->start_controls_section(
			'section_cat_style',
			[
				'label'     => esc_html__( 'Post Category', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_category' => 'yes',
				],
			]
		);

		$this->add_control(
			'category_style',
			[
				'label'     => esc_html__( 'Category Style', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'style-1' => esc_html__( 'Style 1', 'powerpack' ),
					'style-2' => esc_html__( 'Style 2', 'powerpack' ),
				],
				'default'   => 'style-1',
				'condition' => [
					'post_category' => 'yes',
				],
			]
		);

		$this->add_control(
			'cat_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'global'    => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'selectors' => [
					'{{WRAPPER}} .pp-post-categories-style-2 span' => 'background: {{VALUE}}',
				],
				'condition' => [
					'post_category'  => 'yes',
					'category_style' => 'style-2',
				],
			]
		);

		$this->add_control(
			'cat_text_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#fff',
				'selectors' => [
					'{{WRAPPER}} .pp-post-categories' => 'color: {{VALUE}}',
				],
				'condition' => [
					'post_category' => 'yes',
				],
			]
		);

		$this->add_control(
			'cat_text_color_hover',
			[
				'label'     => esc_html__( 'Hover Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-tiled-post:hover .pp-post-categories' => 'color: {{VALUE}}',
				],
				'condition' => [
					'post_category' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'cat_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'global'    => [
					'default' => Global_Typography::TYPOGRAPHY_SECONDARY,
				],
				'selector'  => '{{WRAPPER}} .pp-post-categories',
				'condition' => [
					'post_category' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'cat_margin_bottom',
			[
				'label'      => esc_html__( 'Margin Bottom', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-post-categories' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'post_category' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'cat_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-post-categories-style-2 span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'post_category'  => 'yes',
					'category_style' => 'style-2',
				],
			]
		);

		$this->add_control(
			'large_tile_cat_heading',
			[
				'label'     => esc_html__( 'Large Tile', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'layout!'       => 'layout-5',
					'post_category' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'large_cat_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'global'    => [
					'default' => Global_Typography::TYPOGRAPHY_SECONDARY,
				],
				'selector'  => '{{WRAPPER}} .pp-tiled-post-featured .pp-post-categories',
				'condition' => [
					'layout!'       => 'layout-5',
					'post_category' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Post Meta
	 */
	protected function register_style_post_meta_controls() {
		$this->start_controls_section(
			'section_meta_style',
			[
				'label'     => esc_html__( 'Post Meta', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_meta' => 'yes',
				],
			]
		);

		$this->add_control(
			'meta_text_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#fff',
				'selectors' => [
					'{{WRAPPER}} .pp-tiled-posts-meta' => 'color: {{VALUE}}',
				],
				'condition' => [
					'post_meta' => 'yes',
				],
			]
		);

		$this->add_control(
			'meta_text_color_hover',
			[
				'label'     => esc_html__( 'Hover Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-tiled-post:hover .pp-tiled-posts-meta' => 'color: {{VALUE}}',
				],
				'condition' => [
					'post_meta' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'meta_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'global'    => [
					'default' => Global_Typography::TYPOGRAPHY_SECONDARY,
				],
				'selector'  => '{{WRAPPER}} .pp-tiled-posts-meta',
				'condition' => [
					'post_meta' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'meta_items_spacing',
			[
				'label'      => esc_html__( 'Items Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-tiled-posts-meta > span:not(:last-child):after' => 'margin-left: calc({{SIZE}}{{UNIT}}/2); margin-right: calc({{SIZE}}{{UNIT}}/2);',
				],
				'condition'  => [
					'post_meta' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'meta_margin_bottom',
			[
				'label'      => esc_html__( 'Margin Bottom', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-tiled-posts-meta' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'post_meta' => 'yes',
				],
			]
		);

		$this->add_control(
			'large_tile_meta_heading',
			[
				'label'     => esc_html__( 'Large Tile', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'layout!'   => 'layout-5',
					'post_meta' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'large_meta_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'global'    => [
					'default' => Global_Typography::TYPOGRAPHY_SECONDARY,
				],
				'selector'  => '{{WRAPPER}} .pp-tiled-post-featured .pp-tiled-posts-meta',
				'condition' => [
					'layout!'   => 'layout-5',
					'post_meta' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Post Excerpt
	 */
	protected function register_style_post_excerpt_controls() {
		$this->start_controls_section(
			'section_excerpt_style',
			[
				'label'      => esc_html__( 'Post Excerpt', 'powerpack' ),
				'tab'        => Controls_Manager::TAB_STYLE,
				'conditions' => [
					'relation' => 'or',
					'terms' => [
						[
							'name'  => 'post_excerpt',
							'operator'  => '==',
							'value' => 'yes',
						],
						[
							'name'  => 'post_excerpt_small',
							'operator'  => '==',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$this->add_control(
			'excerpt_text_color',
			[
				'label'      => esc_html__( 'Color', 'powerpack' ),
				'type'       => Controls_Manager::COLOR,
				'default'    => '#fff',
				'selectors'  => [
					'{{WRAPPER}} .pp-tiled-post-excerpt' => 'color: {{VALUE}}',
				],
				'conditions' => [
					'relation' => 'or',
					'terms' => [
						[
							'name'  => 'post_excerpt',
							'operator'  => '==',
							'value' => 'yes',
						],
						[
							'name'  => 'post_excerpt_small',
							'operator'  => '==',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$this->add_control(
			'excerpt_text_color_hover',
			[
				'label'      => esc_html__( 'Hover Color', 'powerpack' ),
				'type'       => Controls_Manager::COLOR,
				'default'    => '',
				'selectors'  => [
					'{{WRAPPER}} .pp-tiled-post:hover .pp-tiled-post-excerpt' => 'color: {{VALUE}}',
				],
				'conditions' => [
					'relation' => 'or',
					'terms' => [
						[
							'name'  => 'post_excerpt',
							'operator'  => '==',
							'value' => 'yes',
						],
						[
							'name'  => 'post_excerpt_small',
							'operator'  => '==',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'       => 'excerpt_typography',
				'label'      => esc_html__( 'Typography', 'powerpack' ),
				'global'     => [
					'default' => Global_Typography::TYPOGRAPHY_TEXT,
				],
				'selector'   => '{{WRAPPER}} .pp-tiled-post-excerpt',
				'conditions' => [
					'relation' => 'or',
					'terms' => [
						[
							'name'  => 'post_excerpt',
							'operator'  => '==',
							'value' => 'yes',
						],
						[
							'name'  => 'post_excerpt_small',
							'operator'  => '==',
							'value' => 'yes',
						],
					],
				],
			]
		);

		$this->add_control(
			'large_tile_excerpt_heading',
			[
				'label'      => esc_html__( 'Large Tile', 'powerpack' ),
				'type'       => Controls_Manager::HEADING,
				'separator'  => 'before',
				'conditions' => [
					'relation' => 'or',
					'terms' => [
						[
							'relation' => 'and',
							'terms' => [
								[
									'name'  => 'post_excerpt',
									'operator'  => '==',
									'value' => 'yes',
								],
								[
									'name'  => 'layout',
									'operator'  => '!==',
									'value' => 'layout-5',
								],
							],
						],
						[
							'relation' => 'and',
							'terms' => [
								[
									'name'  => 'post_excerpt_small',
									'operator'  => '==',
									'value' => 'yes',
								],
								[
									'name'  => 'layout',
									'operator'  => '!==',
									'value' => 'layout-5',
								],
							],
						],
					],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'       => 'large_excerpt_typography',
				'label'      => esc_html__( 'Typography', 'powerpack' ),
				'global'     => [
					'default' => Global_Typography::TYPOGRAPHY_TEXT,
				],
				'selector'   => '{{WRAPPER}} .pp-tiled-post-featured .pp-tiled-post-excerpt',
				'conditions' => [
					'relation' => 'or',
					'terms' => [
						[
							'relation' => 'and',
							'terms' => [
								[
									'name'  => 'post_excerpt',
									'operator'  => '==',
									'value' => 'yes',
								],
								[
									'name'  => 'layout',
									'operator'  => '!==',
									'value' => 'layout-5',
								],
							],
						],
						[
							'relation' => 'and',
							'terms' => [
								[
									'name'  => 'post_excerpt_small',
									'operator'  => '==',
									'value' => 'yes',
								],
								[
									'name'  => 'layout',
									'operator'  => '!==',
									'value' => 'layout-5',
								],
							],
						],
					],
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Overlay
	 */
	protected function register_style_overlay_controls() {
		$this->start_controls_section(
			'section_overlay_style',
			[
				'label' => esc_html__( 'Overlay', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs( 'tabs_overlay_style' );

		$this->start_controls_tab(
			'tab_overlay_normal',
			[
				'label' => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'post_overlay_bg',
				'label'    => esc_html__( 'Overlay Background', 'powerpack' ),
				'types'    => [ 'classic', 'gradient' ],
				'exclude'  => [ 'image' ],
				'selector' => '{{WRAPPER}} .pp-tiled-posts .pp-post-link:before',
			]
		);

		$this->add_control(
			'post_overlay_opacity',
			[
				'label'     => esc_html__( 'Opacity', 'powerpack' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => 0,
						'max'  => 1,
						'step' => 0.1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .pp-tiled-posts .pp-post-link:before' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_overlay_hover',
			[
				'label' => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'post_overlay_bg_hover',
				'label'    => esc_html__( 'Overlay Background', 'powerpack' ),
				'types'    => [ 'classic', 'gradient' ],
				'exclude'  => [ 'image' ],
				'selector' => '{{WRAPPER}} .pp-tiled-post:hover .pp-post-link:before',
			]
		);

		$this->add_control(
			'post_overlay_opacity_hover',
			[
				'label'     => esc_html__( 'Opacity', 'powerpack' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => 0,
						'max'  => 1,
						'step' => 0.1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .pp-tiled-post:hover .pp-post-link:before' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Button
	 * -------------------------------------------------
	 */
	protected function register_style_button_controls() {
		$this->start_controls_section(
			'section_button_style',
			[
				'label'     => esc_html__( 'Read More Button', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'read_more_button' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'button_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'unit' => 'px',
					'size' => 20,
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 60,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-tiled-post-button' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'read_more_button' => 'yes',
				],
			]
		);

		$this->add_control(
			'button_size',
			[
				'label'     => esc_html__( 'Size', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'md',
				'options'   => [
					'xs' => esc_html__( 'Extra Small', 'powerpack' ),
					'sm' => esc_html__( 'Small', 'powerpack' ),
					'md' => esc_html__( 'Medium', 'powerpack' ),
					'lg' => esc_html__( 'Large', 'powerpack' ),
					'xl' => esc_html__( 'Extra Large', 'powerpack' ),
				],
				'condition' => [
					'read_more_button' => 'yes',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_button_style' );

		$this->start_controls_tab(
			'tab_button_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => [
					'read_more_button' => 'yes',
				],
			]
		);

		$this->add_control(
			'button_text_color_normal',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-tiled-post-button' => 'color: {{VALUE}}',
				],
				'condition' => [
					'read_more_button' => 'yes',
				],
			]
		);

		$this->add_control(
			'button_bg_color_normal',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'global'    => [
					'default' => Global_Colors::COLOR_ACCENT,
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-tiled-post-button' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'read_more_button' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'button_border_normal',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-tiled-post-button',
				'condition'   => [
					'read_more_button' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'button_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-tiled-post-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'read_more_button' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'button_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'global'    => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector'  => '{{WRAPPER}} .pp-tiled-post-button',
				'condition' => [
					'read_more_button' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'button_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-tiled-post-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'read_more_button' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'button_box_shadow',
				'selector'  => '{{WRAPPER}} .pp-tiled-post-button',
				'condition' => [
					'read_more_button' => 'yes',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_button_hover',
			[
				'label'     => esc_html__( 'Hover', 'powerpack' ),
				'condition' => [
					'read_more_button' => 'yes',
				],
			]
		);

		$this->add_control(
			'button_text_color_hover',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-tiled-post:hover .pp-tiled-post-button' => 'color: {{VALUE}}',
				],
				'condition' => [
					'read_more_button' => 'yes',
				],
			]
		);

		$this->add_control(
			'button_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-tiled-post:hover .pp-tiled-post-button' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'read_more_button' => 'yes',
				],
			]
		);

		$this->add_control(
			'button_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-tiled-post:hover .pp-tiled-post-button' => 'border-color: {{VALUE}}',
				],
				'condition' => [
					'read_more_button' => 'yes',
				],
			]
		);

		$this->add_control(
			'button_animation',
			[
				'label'     => esc_html__( 'Animation', 'powerpack' ),
				'type'      => Controls_Manager::HOVER_ANIMATION,
				'condition' => [
					'read_more_button' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'button_box_shadow_hover',
				'selector'  => '{{WRAPPER}} .pp-tiled-post:hover .pp-tiled-post-button',
				'condition' => [
					'read_more_button' => 'yes',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Render tiled posts widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 2.0.3
	 * @access protected
	 *
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute(
			[
				'tiled-posts'     => [
					'class' => [
						'pp-tiled-posts',
						'pp-tiled-posts-grid',
						'pp-tiled-posts-' . $settings['layout'],
					],
					'role'  => 'region',
					'aria-label' => esc_attr__( 'Tiled Posts', 'powerpack' ),
				],
				'post-content'    => [
					'class' => [
						'pp-tiled-post-content',
						'pp-tiled-post-content-' . $settings['content_vertical_position'],
					],
				],
				'post-categories' => [
					'class' => [
						'pp-post-categories',
						'pp-post-categories-' . $settings['category_style'],
					],
				],
			]
		);
		?>
		<div <?php $this->print_render_attribute_string( 'tiled-posts' ); ?>>
			<?php
			$layout      = $settings['layout'];
			$slots       = count( Module::get_layout_tiles( $layout ) );
			$posts_count = $slots;

			if ( 'yes' === $settings['other_posts'] ) {
				if ( ! empty( $settings['other_posts_count'] ) && is_numeric( $settings['other_posts_count'] ) ) {
					$posts_count += absint( $settings['other_posts_count'] );
				} else {
					$posts_count += $this->get_max_other_posts();
				}
			}

			$this->query_posts( [
				'widget_type'   => 'tiled_posts',
				'old_code'      => true,
				'posts_count'   => $posts_count,
				'no_found_rows' => true,
			] );

			$posts_query = $this->get_query();
			$found       = count( $posts_query->posts );
			$rendered    = 0;

			// Main grid. Tiles are placed by the stylesheet from their position,
			// so they are emitted as a flat list with no wrapper elements.
			$main = min( $slots, $found );

			while ( $rendered < $main ) {
				$posts_query->the_post();
				$rendered++;

				$this->render_post_body( $rendered, $layout );
			}

			// "Other Posts" grid, emitted only when posts are left over for it.
			if ( 'yes' === $settings['other_posts'] && $rendered < $found ) {
				printf(
					'<div class="pp-tiled-post-group pp-tiled-post-col-%s">',
					esc_attr( $settings['other_posts_columns'] )
				);

				while ( $rendered < $found ) {
					$posts_query->the_post();
					$rendered++;

					$this->render_post_body( $rendered, $layout );
				}

				echo '</div>';
			}

			wp_reset_postdata();
			?>
		</div>
		<?php
	}

	/**
	 * Get the ceiling for "Other Posts" when Posts Count is left blank.
	 *
	 * Blank used to mean an unbounded query (posts_per_page => -1), which loaded
	 * and rendered every post on the site on every page view. It is bounded here
	 * instead; raise or lower the ceiling with the filter below.
	 *
	 * @since 3.2.0
	 * @access protected
	 *
	 * @return int Maximum number of extra posts.
	 */
	protected function get_max_other_posts() {
		/**
		 * Filters how many "Other Posts" are shown when Posts Count is blank.
		 *
		 * @since 3.2.0
		 *
		 * @param int $max Maximum number of extra posts. Default 50.
		 */
		return max( 1, (int) apply_filters( 'ppe_tiled_posts_max_other_posts', 50 ) );
	}

	/**
	 * Get post date
	 *
	 * @since 2.3.7
	 * @access protected
	 *
	 * @return string Formatted post date.
	 */
	protected function get_post_date() {
		$settings = $this->get_settings_for_display();
		$date_type = $settings['date_type'];
		$date_format = $settings['date_format'];
		$date_custom_format = $settings['date_custom_format'];
		$date = '';

		if ( 'custom' === $date_format && $date_custom_format ) {
			$date_format = $date_custom_format;
		}

		if ( 'ago' === $date_type ) {
			/* translators: %s: Human-readable time difference. */
			$date = sprintf( _x( '%s ago', '%s = human-readable time difference', 'powerpack' ), human_time_diff( get_the_time( 'U' ), time() ) );
		} elseif ( 'modified' === $date_type ) {
			$date = get_the_modified_date( $date_format, get_the_ID() );
		} elseif ( 'key' === $date_type ) {
			$date_meta_key = $settings['date_meta_key'];

			/*
			 * Protected keys, meaning the leading-underscore convention plus
			 * anything a plugin has registered as protected, hold internal state
			 * that was never meant for the front end, so they are not readable
			 * from here.
			 */
			if ( $date_meta_key && ! is_protected_meta( $date_meta_key, 'post' ) ) {
				$date = get_post_meta( get_the_ID(), $date_meta_key, true );
			}
		} else {
			$date = get_the_date( $date_format );
		}

		if ( '' === $date ) {
			$date = get_the_date( $date_format );
		}

		/**
		 * Filters the formatted post date rendered by the Tiled Posts widget.
		 *
		 * @since 2.3.7
		 *
		 * @param string $date    Formatted post date.
		 * @param int    $post_id ID of the post the date belongs to.
		 */
		return apply_filters( 'ppe_tiled_posts_date', $date, get_the_ID() );
	}

	/**
	 * Render posts body output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 2.0.3
	 * @access protected
	 *
	 * @param  mixed  $count   Post count.
	 * @param  string $layout  Posts layout.
	 *
	 * @return void
	 */
	protected function render_post_body( $count, $layout ) {
		$settings = $this->get_settings_for_display();

		$has_title     = ( 'yes' === $settings['post_title'] );
		$post_title_id = 'pp-tiled-post-title-' . esc_attr( $this->get_id() ) . '-' . esc_attr( get_the_ID() ) . '-' . $count;
		$post_meta_id  = 'pp-tiled-post-meta-' . esc_attr( $this->get_id() ) . '-' . esc_attr( get_the_ID() ) . '-' . $count;
		$has_meta      = ( 'yes' === $settings['post_meta'] && ( 'yes' === $settings['post_date'] || 'yes' === $settings['post_author'] ) );
		$aria_desc     = $has_meta ? ' aria-describedby="' . esc_attr( $post_meta_id ) . '"' : '';

		$this->add_render_attribute(
			'post-' . $count,
			[
				'class'           => [
					'pp-tiled-post',
					'pp-tiled-post-' . intval( $count ),
					$this->get_post_class( $count, $layout ),
				],
				'role'            => 'article',
				'aria-labelledby' => $post_title_id,
			]
		);

		$image_html  = $this->get_tile_image_html( $count, $layout, $settings );
		$image_class = ! empty( $settings['hover_animation'] ) ? 'elementor-animation-' . $settings['hover_animation'] : '';

		/**
		 * Filters the tile link URL used by the Tiled Posts widget.
		 *
		 * @since 2.9.0
		 *
		 * @param string $permalink Post permalink.
		 * @param int    $post_id   ID of the post the tile represents.
		 * @param array  $settings  Widget settings.
		 */
		$posts_link = apply_filters( 'ppe_tiled_posts_link', get_the_permalink(), get_the_ID(), $settings );

		$this->add_render_attribute(
			'post-bg-' . $count,
			'class',
			[
				'pp-tiled-post-bg',
				'pp-media-background',
				$image_class,
			]
		);
		?>
		<div <?php $this->print_render_attribute_string( 'post-' . $count ); ?>>
			<div <?php $this->print_render_attribute_string( 'post-bg-' . $count ); ?>>
				<?php echo wp_kses( $image_html, self::IMAGE_ALLOWED_HTML ); ?>
				<a class="pp-post-link" href="<?php echo esc_url( $posts_link ); ?>" title="<?php the_title_attribute(); ?>" aria-label="<?php the_title_attribute(); ?>"<?php echo $has_title ? ' tabindex="-1" aria-hidden="true"' : ''; ?>><span class="elementor-screen-only"><?php the_title(); ?></span></a>
			</div>
			<div <?php $this->print_render_attribute_string( 'post-content' ); ?>>
				<?php if ( 'yes' === $settings['post_meta'] ) { ?>
					<?php
					if ( 'yes' === $settings['post_category'] ) {
						$taxonomy = ! empty( $settings['post_taxonomy'] ) ? $settings['post_taxonomy'] : 'category';
						$terms    = get_the_terms( get_the_ID(), $taxonomy );

						if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
							$max_terms = absint( $settings['max_terms'] );

							if ( $max_terms > 0 ) {
								$terms = array_slice( $terms, 0, $max_terms );
							}
							?>
							<div <?php $this->print_render_attribute_string( 'post-categories' ); ?>>
								<?php foreach ( $terms as $term ) : ?>
									<span class="pp-post-term"><?php echo esc_html( $term->name ); ?></span>
								<?php endforeach; ?>
							</div>
							<?php
						}
					}
					?>
				<?php } ?>

				<?php if ( 'yes' === $settings['post_title'] ) { ?>
					<?php $title_tag = PP_Helper::validate_html_tag( $settings['post_title_html_tag'] ); ?>
					<header>
						<<?php PP_Helper::print_validated_html_tag( $title_tag ); ?> class="pp-tiled-post-title" id="<?php echo esc_attr( $post_title_id ); ?>">
							<a href="<?php echo esc_url( $posts_link ); ?>"<?php echo $aria_desc; ?>>
								<?php echo wp_kses_post( $this->get_post_title_length( get_the_title() ) ); ?>
							</a>
						</<?php PP_Helper::print_validated_html_tag( $title_tag ); ?>>
					</header>
				<?php } ?>

				<?php if ( 'yes' === $settings['post_meta'] ) { ?>
					<div class="pp-tiled-posts-meta"<?php echo $has_meta ? ' id="' . esc_attr( $post_meta_id ) . '"' : ''; ?>>
						<?php if ( 'yes' === $settings['post_author'] ) { ?>
							<span class="pp-post-author">
								<?php echo esc_html( get_the_author() ); ?>
							</span>
						<?php } ?>
						<?php if ( 'yes' === $settings['post_date'] ) { ?>
							<?php
								printf(
									'<span class="pp-post-date"><span class="elementor-screen-only">%1$s </span>%2$s</span>',
									esc_html__( 'Posted on', 'powerpack' ),
									wp_kses_post( $this->get_post_date() )
								);
							?>
						<?php } ?>
					</div>
				<?php } ?>

				<?php $this->render_post_excerpt( $count, $layout ); ?>

				<?php if ( 'yes' === $settings['read_more_button'] ) { ?>
					<?php
					$this->add_render_attribute(
						'button-' . $count,
						'class',
						[
							'pp-tiled-post-button',
							'elementor-button',
							'elementor-size-' . $settings['button_size'],
						]
					);
					?>
					<a <?php $this->print_render_attribute_string( 'button-' . $count ); ?> href="<?php echo esc_url( get_permalink() ); ?>">
						<span class="pp-tiled-post-button-text">
							<?php echo esc_html( $settings['read_more_button_text'] ); ?>
							<span class="elementor-screen-only">: <?php the_title(); ?></span>
						</span>
					</a>
				<?php } ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Get the tile's image markup.
	 *
	 * Rendered as an <img> rather than a CSS background so the browser gets the
	 * attachment's srcset, its native lazy loading, and the alt text stored on
	 * the attachment, none of which a background-image can carry.
	 *
	 * @since 3.2.0
	 * @access protected
	 *
	 * @param  int    $count    1-based post position in the loop.
	 * @param  string $layout   Posts layout.
	 * @param  array  $settings Widget settings.
	 *
	 * @return string Image markup, or an empty string when the tile has no image.
	 */
	protected function get_tile_image_html( $count, $layout, $settings ) {
		$size_key = $this->is_featured_tile( $count, $layout ) ? 'image_size' : 'image_size_small';
		$image_id = '';

		if ( 'attachment' === $settings['post_type'] ) {
			$image_id = get_the_ID();
		} elseif ( has_post_thumbnail() ) {
			$image_id = get_post_thumbnail_id( get_the_ID() );
		} elseif ( 'placeholder' === $settings['fallback_image'] ) {
			return sprintf( '<img src="%s" alt="" />', esc_url( Utils::get_placeholder_image_src() ) );
		} elseif ( 'custom' === $settings['fallback_image'] && ! empty( $settings['fallback_image_custom']['url'] ) ) {
			if ( empty( $settings['fallback_image_custom']['id'] ) ) {
				// An external URL has no attachment to size or describe.
				return sprintf( '<img src="%s" alt="" />', esc_url( $settings['fallback_image_custom']['url'] ) );
			}

			$image_id = $settings['fallback_image_custom']['id'];
		}

		if ( ! $image_id ) {
			return '';
		}

		/*
		 * The hover animation class stays on the tile background wrapper, so it
		 * has to be cleared here or the image would carry a second copy of it.
		 */
		$settings['hover_animation'] = '';
		$settings[ $size_key ]       = [ 'id' => $image_id ];

		return Group_Control_Image_Size::get_attachment_image_html( $settings, $size_key );
	}

	/**
	 * Render post excerpt output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 2.0.3
	 * @access protected
	 *
	 * @param  mixed  $count   Post count.
	 * @param  string $layout  Posts layout.
	 *
	 * @return void
	 */
	protected function render_post_excerpt( $count, $layout ) {
		$settings = $this->get_settings_for_display();

		if ( $this->is_featured_tile( $count, $layout ) ) {
			$post_excerpt = $settings['post_excerpt'];
			$limit        = $settings['excerpt_length'];
		} else {
			$post_excerpt = $settings['post_excerpt_small'];
			$limit        = $settings['excerpt_length_small'];
		}

		if ( 'yes' === $post_excerpt ) {
			?>
			<div class="pp-tiled-post-excerpt">
				<?php echo wp_kses_post( $this->get_custom_post_excerpt( $limit ) ); ?>
			</div>
			<?php
		}
	}

	/**
	 * Get post class.
	 *
	 * @since 2.3.7
	 * @access protected
	 *
	 * @param  mixed  $count   Post count.
	 * @param  string $layout  Posts layout.
	 *
	 * @return string CSS class for the tile.
	 */
	protected function get_post_class( $count, $layout ) {
		$settings = $this->get_settings_for_display();

		// "Other Posts" tiles use a fixed class derived from the column count.
		if ( $this->check_other_posts( $count, $layout ) ) {
			$columns_class_map = [
				'1' => 'pp-tiled-post-large',
				'2' => 'pp-tiled-post-medium',
				'3' => 'pp-tiled-post-small',
				'4' => 'pp-tiled-post-xs',
			];

			return $columns_class_map[ $settings['other_posts_columns'] ] ?? '';
		}

		// Main-grid tiles: 1-based slot index into the layout's tile list.
		$tile_classes = Module::get_layout_tiles( $layout );

		return $tile_classes[ $count - 1 ] ?? '';
	}

	/**
	 * Disable SQL_CALC_FOUND_ROWS for the widget query.
	 *
	 * The widget does not paginate, so the row-count subquery is wasted work.
	 *
	 * Superseded by the 'no_found_rows' option on query_posts(); kept because it
	 * is public and may be hooked onto 'ppe_tiled_posts_query_args' externally.
	 *
	 * @since 3.0.0
	 *
	 * @access public
	 *
	 * @param  array $query_args WP_Query arguments.
	 * @return array
	 */
	public function set_no_found_rows( $query_args ) {
		$query_args['no_found_rows'] = true;

		return $query_args;
	}

	/**
	 * Get public taxonomies as a SELECT-options map.
	 *
	 * @since 3.0.0
	 *
	 * @access protected
	 *
	 * @return array Taxonomy slug => label.
	 */
	protected function get_taxonomy_options() {
		$options    = [];
		$taxonomies = get_taxonomies( [ 'public' => true ], 'objects' );

		foreach ( $taxonomies as $slug => $taxonomy ) {
			$options[ $slug ] = $taxonomy->label;
		}

		return $options;
	}

	/**
	 * Whether the given tile is the layout's "featured" (largest) tile.
	 *
	 * @since 3.0.0
	 * @access protected
	 *
	 * @param  int    $count  1-based post position in the loop.
	 * @param  string $layout Layout key.
	 *
	 * @return bool
	 */
	protected function is_featured_tile( $count, $layout ) {
		return Module::FEATURED_TILE_CLASS === $this->get_post_class( $count, $layout );
	}

	/**
	 * Check other posts.
	 *
	 * @since 2.3.7
	 * @access protected
	 *
	 * @param  mixed  $count   Post count.
	 * @param  string $layout  Posts layout.
	 *
	 * @return bool Whether the current tile belongs to the "Other Posts" group.
	 */
	protected function check_other_posts( $count, $layout ) {
		$settings = $this->get_settings_for_display();

		if ( 'yes' !== $settings['other_posts'] ) {
			return false;
		}

		// Anything past the layout's own slots belongs to the "Other Posts" group.
		return $count > count( Module::get_layout_tiles( $layout ) );
	}

	/**
	 * Get post title length.
	 *
	 * @since 2.0.3
	 * @access protected
	 *
	 * @param  string $title Post title.
	 *
	 * @return string Truncated post title.
	 */
	protected function get_post_title_length( $title ) {
		$settings = $this->get_settings_for_display();

		$length = absint( $settings['post_title_length'] );

		if ( $length ) {
			if ( strlen( $title ) > $length ) {
				$title = substr( $title, 0, $length ) . '&hellip;';
			}
		}

		return $title;
	}

}
