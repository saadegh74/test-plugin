<?php
namespace PowerpackElements\Modules\TeamMember\Widgets;

use PowerpackElements\Base\Powerpack_Widget;
use PowerpackElements\Classes\PP_Helper;

// Elementor Classes
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Control_Media;
use Elementor\Icons_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Modules\DynamicTags\Module as TagsModule;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Team Member Widget
 */
class Team_Member extends Powerpack_Widget {

	/**
	 * Retrieve team member widget name.
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return parent::get_widget_name( 'Team_Member' );
	}

	/**
	 * Retrieve team member widget title.
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return parent::get_widget_title( 'Team_Member' );
	}

	/**
	 * Retrieve team member widget icon.
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return parent::get_widget_icon( 'Team_Member' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return parent::get_widget_keywords( 'Team_Member' );
	}

	/**
	 * Whether the widget renders dynamic content.
	 *
	 * @since 2.10.19
	 * @access protected
	 *
	 * @return bool True - content can be supplied by dynamic tags.
	 */
	protected function is_dynamic_content(): bool {
		return true;
	}

	/**
	 * Retrieve the list of styles the team member widget depended on.
	 *
	 * Used to set styles dependencies required to run the widget.
	 *
	 * @access public
	 *
	 * @return array Widget styles dependencies.
	 */
	public function get_style_depends() {
		return [
			'widget-pp-team-member',
		];
	}

	/**
	 * Whether the widget wraps its output in Elementor's inner wrapper element.
	 *
	 * @access public
	 *
	 * @return bool
	 */
	public function has_widget_inner_wrapper(): bool {
		return ! PP_Helper::is_feature_active( 'e_optimized_markup' );
	}

	/**
	 * Register team member widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_controls() {

		/* Content Tab */
		$this->register_content_image_controls();
		$this->register_content_details_controls();
		$this->register_content_social_links_controls();
		$this->register_content_settings_controls();
		$this->register_presets_control();

		/* Style Tab */
		$this->register_style_content_controls();
		$this->register_style_overlay_controls();
		$this->register_style_image_controls();
		$this->register_style_name_controls();
		$this->register_style_position_controls();
		$this->register_style_description_controls();
		$this->register_style_social_links_controls();
	}

	/**
	 * Register image controls
	 *
	 * @return void
	 */
	protected function register_content_image_controls() {

		$this->start_controls_section(
			'section_image',
			[
				'label'                 => esc_html__( 'Image', 'powerpack' ),
			]
		);

		$this->add_control(
			'image',
			[
				'label'                 => esc_html__( 'Image', 'powerpack' ),
				'type'                  => Controls_Manager::MEDIA,
				'dynamic'               => [
					'active'   => true,
				],
				'default'               => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'                  => 'image',
				'label'                 => esc_html__( 'Image Size', 'powerpack' ),
				'default'               => 'medium_large',
			]
		);

		$this->add_responsive_control(
			'member_image_width',
			[
				'label'                 => esc_html__( 'Image Width', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => 200,
					'unit' => 'px',
				],
				'range'                 => [
					'px' => [
						'max' => 1200,
					],
				],
				'tablet_default'        => [
					'unit' => 'px',
				],
				'mobile_default'        => [
					'unit' => 'px',
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-image img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register details controls
	 *
	 * @return void
	 */
	protected function register_content_details_controls() {

		$this->start_controls_section(
			'section_details',
			[
				'label'                 => esc_html__( 'Details', 'powerpack' ),
			]
		);

		$this->add_control(
			'team_member_name',
			[
				'label'                 => esc_html__( 'Name', 'powerpack' ),
				'type'                  => Controls_Manager::TEXT,
				'dynamic'               => [
					'active'   => true,
				],
				'default'               => esc_html__( 'John Doe', 'powerpack' ),
			]
		);

		$this->add_control(
			'team_member_position',
			[
				'label'                 => esc_html__( 'Position', 'powerpack' ),
				'type'                  => Controls_Manager::TEXT,
				'dynamic'               => [
					'active'   => true,
				],
				'default'               => esc_html__( 'WordPress Developer', 'powerpack' ),
			]
		);

		$this->add_control(
			'team_member_description_switch',
			[
				'label'                 => esc_html__( 'Show Description', 'powerpack' ),
				'type'                  => Controls_Manager::SWITCHER,
				'default'               => 'yes',
				'label_on'              => esc_html__( 'Yes', 'powerpack' ),
				'label_off'             => esc_html__( 'No', 'powerpack' ),
				'return_value'          => 'yes',
			]
		);

		$this->add_control(
			'team_member_description',
			[
				'label'                 => esc_html__( 'Description', 'powerpack' ),
				'type'                  => Controls_Manager::WYSIWYG,
				'dynamic'               => [
					'active'   => true,
				],
				'default'               => esc_html__( 'Enter member description here which describes the position of member in company', 'powerpack' ),
				'condition'             => [
					'team_member_description_switch' => 'yes',
				],
			]
		);

		$this->add_control(
			'link_type',
			[
				'label'                 => esc_html__( 'Link Type', 'powerpack' ),
				'type'                  => Controls_Manager::SELECT,
				'default'               => 'none',
				'options'               => [
					'none'      => esc_html__( 'None', 'powerpack' ),
					'image'     => esc_html__( 'Image', 'powerpack' ),
					'title'     => esc_html__( 'Title', 'powerpack' ),
				],
			]
		);

		$this->add_control(
			'link',
			[
				'label'                 => esc_html__( 'Link', 'powerpack' ),
				'type'                  => Controls_Manager::URL,
				'dynamic'               => [
					'active'        => true,
					'categories'    => [
						TagsModule::POST_META_CATEGORY,
						TagsModule::URL_CATEGORY,
					],
				],
				'placeholder'           => 'https://www.your-link.com',
				'condition'             => [
					'link_type!'   => 'none',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register social links controls
	 *
	 * @return void
	 */
	protected function register_content_social_links_controls() {

		$this->start_controls_section(
			'section_member_social_links',
			[
				'label'                 => esc_html__( 'Social Links', 'powerpack' ),
			]
		);

		$this->add_control(
			'member_social_links',
			[
				'label'                 => esc_html__( 'Show Social Links', 'powerpack' ),
				'type'                  => Controls_Manager::SWITCHER,
				'default'               => 'yes',
				'label_on'              => esc_html__( 'Yes', 'powerpack' ),
				'label_off'             => esc_html__( 'No', 'powerpack' ),
				'return_value'          => 'yes',
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'select_social_icon',
			[
				'label'                 => esc_html__( 'Social Icon', 'powerpack' ),
				'type'                  => Controls_Manager::ICONS,
				'fa4compatibility'      => 'social_icon',
				'recommended' => [
					'fa-brands' => [
						'android',
						'apple',
						'behance',
						'bitbucket',
						'codepen',
						'delicious',
						'deviantart',
						'digg',
						'dribbble',
						'elementor',
						'facebook',
						'flickr',
						'foursquare',
						'free-code-camp',
						'github',
						'gitlab',
						'globe',
						'houzz',
						'instagram',
						'jsfiddle',
						'linkedin',
						'medium',
						'meetup',
						'mixcloud',
						'odnoklassniki',
						'pinterest',
						'product-hunt',
						'reddit',
						'shopping-cart',
						'skype',
						'slideshare',
						'snapchat',
						'soundcloud',
						'spotify',
						'stack-overflow',
						'steam',
						'stumbleupon',
						'telegram',
						'thumb-tack',
						'tripadvisor',
						'tumblr',
						'twitch',
						'twitter',
						'twitter-square',
						'x-twitter',
						'x-twitter-square',
						'viber',
						'vimeo',
						'vk',
						'weibo',
						'weixin',
						'whatsapp',
						'wordpress',
						'xing',
						'yelp',
						'youtube',
						'500px',
					],
					'fa-solid' => [
						'envelope',
						'link',
						'rss',
					],
				],
			]
		);

		$repeater->add_control(
			'social_link',
			[
				'label'                 => esc_html__( 'Social Link', 'powerpack' ),
				'type'                  => Controls_Manager::URL,
				'dynamic'               => [
					'active'  => true,
				],
				'label_block'           => true,
				'placeholder'           => esc_html__( 'Enter URL', 'powerpack' ),
			]
		);

		$this->add_control(
			'team_member_social',
			[
				'label'                 => esc_html__( 'Add Social Links', 'powerpack' ),
				'type'                  => Controls_Manager::REPEATER,
				'default'               => [
					[
						'select_social_icon' => [
							'value'   => 'fab fa-facebook',
							'library' => 'fa-brands',
						],
					],
					[
						'select_social_icon' => [
							'value'   => 'fab fa-x-twitter',
							'library' => 'fa-brands',
						],
					],
					[
						'select_social_icon' => [
							'value'   => 'fab fa-instagram',
							'library' => 'fa-brands',
						],
					],
				],
				'fields'                => $repeater->get_controls(),
				'title_field' => '<# var migrated = "undefined" !== typeof __fa4_migrated, social = ( "undefined" === typeof social ) ? false : social; #>{{{ elementor.helpers.getSocialNetworkNameFromIcon( select_social_icon, social, true, migrated, true ) }}}',
				'condition'             => [
					'member_social_links' => 'yes',
				],
			]
		);

		$this->add_control(
			'social_links_style',
			[
				'label'   => esc_html__( 'Links Style', 'powerpack' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'icon',
				'options' => [
					'icon'   => esc_html__( 'Icon', 'powerpack' ),
					'button' => esc_html__( 'Button', 'powerpack' ),
				],
			]
		);

		$this->add_control(
			'shape',
			[
				'label'        => esc_html__( 'Shape', 'powerpack' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'rounded',
				'options'      => [
					'rounded' => esc_html__( 'Rounded', 'powerpack' ),
					'square'  => esc_html__( 'Square', 'powerpack' ),
					'circle'  => esc_html__( 'Circle', 'powerpack' ),
				],
				'prefix_class' => 'elementor-shape-',
				'condition'    => [
					'social_links_style' => 'button',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register settings controls
	 *
	 * @return void
	 */
	protected function register_content_settings_controls() {

		$this->start_controls_section(
			'section_member_box_settings',
			[
				'label'                 => esc_html__( 'Settings', 'powerpack' ),
			]
		);

		$this->add_control(
			'name_html_tag',
			[
				'label'                => esc_html__( 'Name HTML Tag', 'powerpack' ),
				'type'                 => Controls_Manager::SELECT,
				'default'              => 'h4',
				'options'              => [
					'h1'     => esc_html__( 'H1', 'powerpack' ),
					'h2'     => esc_html__( 'H2', 'powerpack' ),
					'h3'     => esc_html__( 'H3', 'powerpack' ),
					'h4'     => esc_html__( 'H4', 'powerpack' ),
					'h5'     => esc_html__( 'H5', 'powerpack' ),
					'h6'     => esc_html__( 'H6', 'powerpack' ),
					'div'    => esc_html__( 'div', 'powerpack' ),
					'span'   => esc_html__( 'span', 'powerpack' ),
					'p'      => esc_html__( 'p', 'powerpack' ),
				],
			]
		);

		$this->add_control(
			'position_html_tag',
			[
				'label'                => esc_html__( 'Position HTML Tag', 'powerpack' ),
				'type'                 => Controls_Manager::SELECT,
				'default'              => 'div',
				'options'              => [
					'h1'     => esc_html__( 'H1', 'powerpack' ),
					'h2'     => esc_html__( 'H2', 'powerpack' ),
					'h3'     => esc_html__( 'H3', 'powerpack' ),
					'h4'     => esc_html__( 'H4', 'powerpack' ),
					'h5'     => esc_html__( 'H5', 'powerpack' ),
					'h6'     => esc_html__( 'H6', 'powerpack' ),
					'div'    => esc_html__( 'div', 'powerpack' ),
					'span'   => esc_html__( 'span', 'powerpack' ),
					'p'      => esc_html__( 'p', 'powerpack' ),
				],
			]
		);

		$this->add_control(
			'social_links_position',
			[
				'label'                => esc_html__( 'Social Links Position', 'powerpack' ),
				'type'                 => Controls_Manager::SELECT,
				'default'              => 'after_desc',
				'options'              => [
					'before_desc'      => esc_html__( 'Before Description', 'powerpack' ),
					'after_desc'       => esc_html__( 'After Description', 'powerpack' ),
				],
				'condition'            => [
					'member_social_links' => 'yes',
					'overlay_content'     => [ 'none', 'all_content' ],
				],
			]
		);

		$this->add_control(
			'overlay_content',
			[
				'label'                => esc_html__( 'Overlay Content', 'powerpack' ),
				'type'                 => Controls_Manager::SELECT,
				'default'              => 'none',
				'options'              => [
					'none'         => esc_html__( 'None', 'powerpack' ),
					'social_icons' => esc_html__( 'Social Icons', 'powerpack' ),
					'content'      => esc_html__( 'Description', 'powerpack' ),
					'all_content'  => esc_html__( 'Description + Social Icons', 'powerpack' ),
				],
			]
		);

		$this->add_control(
			'member_title_divider',
			[
				'label'                 => esc_html__( 'Divider after Name', 'powerpack' ),
				'type'                  => Controls_Manager::SWITCHER,
				'default'               => 'no',
				'label_on'              => esc_html__( 'Show', 'powerpack' ),
				'label_off'             => esc_html__( 'Hide', 'powerpack' ),
				'return_value'          => 'yes',
			]
		);

		$this->add_control(
			'member_position_divider',
			[
				'label'                 => esc_html__( 'Divider after Position', 'powerpack' ),
				'type'                  => Controls_Manager::SWITCHER,
				'default'               => 'yes',
				'label_on'              => esc_html__( 'Show', 'powerpack' ),
				'label_off'             => esc_html__( 'Hide', 'powerpack' ),
				'return_value'          => 'yes',
				'condition'             => [
					'team_member_position!'  => '',
				],
			]
		);

		$this->add_control(
			'member_description_divider',
			[
				'label'                 => esc_html__( 'Divider after Description', 'powerpack' ),
				'type'                  => Controls_Manager::SWITCHER,
				'default'               => '',
				'label_on'              => esc_html__( 'Show', 'powerpack' ),
				'label_off'             => esc_html__( 'Hide', 'powerpack' ),
				'return_value'          => 'yes',
				'condition'             => [
					'team_member_description_switch'  => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/*-----------------------------------------------------------------------------------*/
	/*	STYLE TAB
	/*-----------------------------------------------------------------------------------*/

	/**
	 * Register content style controls
	 *
	 * @return void
	 */
	protected function register_style_content_controls() {

		$this->start_controls_section(
			'section_content_style',
			[
				'label'                 => esc_html__( 'Content', 'powerpack' ),
				'tab'                   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'member_box_alignment',
			[
				'label'                 => esc_html__( 'Alignment', 'powerpack' ),
				'type'                  => Controls_Manager::CHOOSE,
				'options'               => [
					'left'      => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center'    => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'     => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'               => 'center',
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-wrapper' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'                  => 'content_background',
				'label'                 => esc_html__( 'Background', 'powerpack' ),
				'types'                 => [ 'classic', 'gradient' ],
				'separator'             => 'before',
				'selector'              => '{{WRAPPER}} .pp-tm-content-normal',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'                  => 'member_content_border',
				'label'                 => esc_html__( 'Border', 'powerpack' ),
				'placeholder'           => '1px',
				'default'               => '1px',
				'separator'             => 'before',
				'selector'              => '{{WRAPPER}} .pp-tm-content-normal',
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'                  => 'content_box_shadow',
				'selector'              => '{{WRAPPER}} .pp-tm-content-normal',
			]
		);

		$this->add_responsive_control(
			'member_box_content_margin',
			[
				'label'                 => esc_html__( 'Margin', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'separator'             => 'before',
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-content-normal' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'member_box_content_padding',
			[
				'label'                 => esc_html__( 'Padding', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-content-normal' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register overlay style controls
	 *
	 * @return void
	 */
	protected function register_style_overlay_controls() {

		$this->start_controls_section(
			'section_member_overlay_style',
			[
				'label'                 => esc_html__( 'Overlay', 'powerpack' ),
				'tab'                   => Controls_Manager::TAB_STYLE,
				'condition'             => [
					'overlay_content!'  => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'overlay_alignment',
			[
				'label'                 => esc_html__( 'Alignment', 'powerpack' ),
				'type'                  => Controls_Manager::CHOOSE,
				'options'               => [
					'left'      => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center'    => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'     => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-overlay-content-wrap' => 'text-align: {{VALUE}};',
				],
				'condition'             => [
					'overlay_content!'  => 'none',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'                  => 'overlay_background',
				'types'                 => [ 'classic', 'gradient' ],
				'selector'              => '{{WRAPPER}} .pp-tm-overlay-content-wrap:before',
				'condition'             => [
					'overlay_content!'  => 'none',
				],
			]
		);

		$this->add_control(
			'overlay_opacity',
			[
				'label'                 => esc_html__( 'Opacity', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'default'               => [
					'size' => 0.5,
				],
				'range'                 => [
					'px' => [
						'min'   => 0,
						'max'   => 1,
						'step'  => 0.1,
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-overlay-content-wrap:before' => 'opacity: {{SIZE}};',
				],
				'condition'             => [
					'overlay_content!'  => 'none',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register image style controls
	 *
	 * @return void
	 */
	protected function register_style_image_controls() {

		$this->start_controls_section(
			'section_member_image_style',
			[
				'label'                 => esc_html__( 'Image', 'powerpack' ),
				'tab'                   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'                  => 'member_image_border',
				'label'                 => esc_html__( 'Border', 'powerpack' ),
				'placeholder'           => '1px',
				'default'               => '1px',
				'selector'              => '{{WRAPPER}} .pp-tm-image img',
			]
		);

		$this->add_control(
			'member_image_border_radius',
			[
				'label'                 => esc_html__( 'Border Radius', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-image img, {{WRAPPER}} .pp-tm-overlay-content-wrap:before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'member_image_margin',
			[
				'label'                 => esc_html__( 'Margin', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-image' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register name style controls
	 *
	 * @return void
	 */
	protected function register_style_name_controls() {

		$this->start_controls_section(
			'section_member_name_style',
			[
				'label'                 => esc_html__( 'Name', 'powerpack' ),
				'tab'                   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'                  => 'member_name_typography',
				'label'                 => esc_html__( 'Typography', 'powerpack' ),
				'global'                => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector'              => '{{WRAPPER}} .pp-tm-name',
			]
		);

		$this->add_control(
			'member_name_text_color',
			[
				'label'                 => esc_html__( 'Text Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'global'                => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-name' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'member_name_margin',
			[
				'label'                 => esc_html__( 'Margin Bottom', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => 10,
					'unit' => 'px',
				],
				'range'                 => [
					'px' => [
						'max' => 100,
					],
				],
				'tablet_default'        => [
					'unit' => 'px',
				],
				'mobile_default'        => [
					'unit' => 'px',
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-name' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'name_divider_heading',
			[
				'label'                 => esc_html__( 'Divider', 'powerpack' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
				'condition'             => [
					'member_title_divider' => 'yes',
				],
			]
		);

		$this->add_control(
			'name_divider_color',
			[
				'label'                 => esc_html__( 'Divider Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'global'                => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-title-divider' => 'border-bottom-color: {{VALUE}}',
				],
				'condition'             => [
					'member_title_divider' => 'yes',
				],
			]
		);

		$this->add_control(
			'name_divider_style',
			[
				'label'                => esc_html__( 'Divider Style', 'powerpack' ),
				'type'                 => Controls_Manager::SELECT,
				'default'              => 'solid',
				'options'              => [
					'solid'     => esc_html__( 'Solid', 'powerpack' ),
					'dotted'    => esc_html__( 'Dotted', 'powerpack' ),
					'dashed'    => esc_html__( 'Dashed', 'powerpack' ),
					'double'    => esc_html__( 'Double', 'powerpack' ),
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-title-divider' => 'border-bottom-style: {{VALUE}}',
				],
				'condition'             => [
					'member_title_divider' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'name_divider_width',
			[
				'label'                 => esc_html__( 'Divider Width', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => 100,
					'unit' => 'px',
				],
				'range'                 => [
					'px' => [
						'max' => 800,
					],
				],
				'tablet_default'        => [
					'unit' => 'px',
				],
				'mobile_default'        => [
					'unit' => 'px',
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-title-divider' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'             => [
					'member_title_divider' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'name_divider_height',
			[
				'label'                 => esc_html__( 'Divider Height', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => 4,
				],
				'range'                 => [
					'px' => [
						'max' => 20,
					],
				],
				'tablet_default'        => [
					'unit' => 'px',
				],
				'mobile_default'        => [
					'unit' => 'px',
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-title-divider' => 'border-bottom-width: {{SIZE}}{{UNIT}};',
				],
				'condition'             => [
					'member_title_divider' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'name_divider_margin',
			[
				'label'                 => esc_html__( 'Margin Bottom', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => 10,
					'unit' => 'px',
				],
				'range'                 => [
					'px' => [
						'max' => 100,
					],
				],
				'tablet_default'        => [
					'unit' => 'px',
				],
				'mobile_default'        => [
					'unit' => 'px',
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-title-divider-wrap' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition'             => [
					'member_title_divider' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register position style controls
	 *
	 * @return void
	 */
	protected function register_style_position_controls() {

		$this->start_controls_section(
			'section_member_position_style',
			[
				'label'                 => esc_html__( 'Position', 'powerpack' ),
				'tab'                   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'                  => 'member_position_typography',
				'label'                 => esc_html__( 'Typography', 'powerpack' ),
				'global'                => [
					'default' => Global_Typography::TYPOGRAPHY_SECONDARY,
				],
				'selector'              => '{{WRAPPER}} .pp-tm-position',
			]
		);

		$this->add_control(
			'member_position_text_color',
			[
				'label'                 => esc_html__( 'Text Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'global'                => [
					'default' => Global_Colors::COLOR_SECONDARY,
				],
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-position' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'member_position_margin',
			[
				'label'                 => esc_html__( 'Margin Bottom', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => 10,
					'unit' => 'px',
				],
				'range'                 => [
					'px' => [
						'max' => 100,
					],
				],
				'tablet_default'        => [
					'unit' => 'px',
				],
				'mobile_default'        => [
					'unit' => 'px',
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-position' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'position_divider_heading',
			[
				'label'                 => esc_html__( 'Divider', 'powerpack' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
				'condition'             => [
					'member_position_divider' => 'yes',
				],
			]
		);

		$this->add_control(
			'position_divider_color',
			[
				'label'                 => esc_html__( 'Divider Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'global'                => [
					'default' => Global_Colors::COLOR_ACCENT,
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-position-divider' => 'border-bottom-color: {{VALUE}}',
				],
				'condition'             => [
					'member_position_divider' => 'yes',
				],
			]
		);

		$this->add_control(
			'position_divider_style',
			[
				'label'                => esc_html__( 'Divider Style', 'powerpack' ),
				'type'                 => Controls_Manager::SELECT,
				'default'              => 'solid',
				'options'              => [
					'solid'     => esc_html__( 'Solid', 'powerpack' ),
					'dotted'    => esc_html__( 'Dotted', 'powerpack' ),
					'dashed'    => esc_html__( 'Dashed', 'powerpack' ),
					'double'    => esc_html__( 'Double', 'powerpack' ),
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-position-divider' => 'border-bottom-style: {{VALUE}}',
				],
				'condition'             => [
					'member_position_divider' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'position_divider_width',
			[
				'label'                 => esc_html__( 'Divider Width', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => 100,
					'unit' => 'px',
				],
				'range'                 => [
					'px' => [
						'max' => 800,
					],
				],
				'tablet_default'        => [
					'unit' => 'px',
				],
				'mobile_default'        => [
					'unit' => 'px',
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-position-divider' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'             => [
					'member_position_divider' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'position_divider_height',
			[
				'label'                 => esc_html__( 'Divider Height', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => 3,
				],
				'range'                 => [
					'px' => [
						'max' => 20,
					],
				],
				'tablet_default'        => [
					'unit' => 'px',
				],
				'mobile_default'        => [
					'unit' => 'px',
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-position-divider' => 'border-bottom-width: {{SIZE}}{{UNIT}};',
				],
				'condition'             => [
					'member_position_divider' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'position_divider_margin',
			[
				'label'                 => esc_html__( 'Margin Bottom', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => 10,
					'unit' => 'px',
				],
				'range'                 => [
					'px' => [
						'max' => 100,
					],
				],
				'tablet_default'        => [
					'unit' => 'px',
				],
				'mobile_default'        => [
					'unit' => 'px',
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-position-divider-wrap' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition'             => [
					'member_position_divider' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register description style controls
	 *
	 * @return void
	 */
	protected function register_style_description_controls() {

		$this->start_controls_section(
			'section_member_description_style',
			[
				'label'                 => esc_html__( 'Description', 'powerpack' ),
				'tab'                   => Controls_Manager::TAB_STYLE,
				'condition'             => [
					'team_member_description_switch' => 'yes',
					'team_member_description!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'                  => 'member_description_typography',
				'label'                 => esc_html__( 'Typography', 'powerpack' ),
				'global'                => [
					'default' => Global_Typography::TYPOGRAPHY_TEXT,
				],
				'selector'              => '{{WRAPPER}} .pp-tm-description',
				'condition'             => [
					'team_member_description_switch' => 'yes',
					'team_member_description!' => '',
				],
			]
		);

		$this->add_control(
			'member_description_text_color',
			[
				'label'                 => esc_html__( 'Text Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'global'                => [
					'default' => Global_Colors::COLOR_TEXT,
				],
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-description' => 'color: {{VALUE}}',
				],
				'condition'             => [
					'team_member_description_switch' => 'yes',
					'team_member_description!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'member_description_margin',
			[
				'label'                 => esc_html__( 'Margin Bottom', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => 10,
					'unit' => 'px',
				],
				'range'                 => [
					'px' => [
						'max' => 100,
					],
				],
				'tablet_default'        => [
					'unit' => 'px',
				],
				'mobile_default'        => [
					'unit' => 'px',
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-description' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition'             => [
					'team_member_description_switch' => 'yes',
					'team_member_description!' => '',
				],
			]
		);

		$this->add_control(
			'description_divider_heading',
			[
				'label'                 => esc_html__( 'Divider', 'powerpack' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
				'condition'             => [
					'team_member_description_switch' => 'yes',
					'team_member_description!' => '',
					'member_description_divider' => 'yes',
				],
			]
		);

		$this->add_control(
			'description_divider_color',
			[
				'label'                 => esc_html__( 'Divider Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'global'                => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-description-divider' => 'border-bottom-color: {{VALUE}}',
				],
				'condition'             => [
					'team_member_description_switch' => 'yes',
					'team_member_description!' => '',
					'member_description_divider' => 'yes',
				],
			]
		);

		$this->add_control(
			'description_divider_style',
			[
				'label'                => esc_html__( 'Divider Style', 'powerpack' ),
				'type'                 => Controls_Manager::SELECT,
				'default'              => 'solid',
				'options'              => [
					'solid'     => esc_html__( 'Solid', 'powerpack' ),
					'dotted'    => esc_html__( 'Dotted', 'powerpack' ),
					'dashed'    => esc_html__( 'Dashed', 'powerpack' ),
					'double'    => esc_html__( 'Double', 'powerpack' ),
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-description-divider' => 'border-bottom-style: {{VALUE}}',
				],
				'condition'             => [
					'team_member_description_switch' => 'yes',
					'team_member_description!' => '',
					'member_description_divider' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'description_divider_width',
			[
				'label'                 => esc_html__( 'Divider Width', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => 100,
					'unit' => 'px',
				],
				'range'                 => [
					'px' => [
						'max' => 800,
					],
				],
				'tablet_default'        => [
					'unit' => 'px',
				],
				'mobile_default'        => [
					'unit' => 'px',
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-description-divider' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'             => [
					'team_member_description_switch' => 'yes',
					'team_member_description!' => '',
					'member_description_divider' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'description_divider_height',
			[
				'label'                 => esc_html__( 'Divider Height', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => 4,
				],
				'range'                 => [
					'px' => [
						'max' => 20,
					],
				],
				'tablet_default'        => [
					'unit' => 'px',
				],
				'mobile_default'        => [
					'unit' => 'px',
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-description-divider' => 'border-bottom-width: {{SIZE}}{{UNIT}};',
				],
				'condition'             => [
					'team_member_description_switch' => 'yes',
					'team_member_description!' => '',
					'member_description_divider' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'description_divider_margin',
			[
				'label'                 => esc_html__( 'Margin Bottom', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => 10,
					'unit' => 'px',
				],
				'range'                 => [
					'px' => [
						'max' => 100,
					],
				],
				'tablet_default'        => [
					'unit' => 'px',
				],
				'mobile_default'        => [
					'unit' => 'px',
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-description-divider-wrap' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition'             => [
					'team_member_description_switch' => 'yes',
					'team_member_description!' => '',
					'member_description_divider' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Conditions reused by the social-links style controls that should only
	 * apply when the links render as plain icons, or as buttons with a
	 * custom (non-official) color.
	 *
	 * @since 3.0.0
	 *
	 * @return array
	 */
	protected function get_social_links_style_conditions() {
		return [
			'relation' => 'or',
			'terms'    => [
				[
					'name'     => 'social_links_style',
					'operator' => '===',
					'value'    => 'icon',
				],
				[
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'social_links_style',
							'operator' => '===',
							'value'    => 'button',
						],
						[
							'name'     => 'member_icon_color',
							'operator' => '==',
							'value'    => 'custom',
						],
					],
				],
			],
		];
	}

	/**
	 * Register social links style controls
	 *
	 * @return void
	 */
	protected function register_style_social_links_controls() {

		$this->start_controls_section(
			'section_member_social_links_style',
			[
				'label'                 => esc_html__( 'Social Links', 'powerpack' ),
				'tab'                   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'member_icons_gap',
			[
				'label'                 => esc_html__( 'Icons Gap', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range'                 => [
					'px' => [
						'max' => 60,
					],
				],
				'tablet_default'        => [
					'unit' => 'px',
				],
				'mobile_default'        => [
					'unit' => 'px',
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-social-links li:not(:last-child)' => 'margin-inline-end: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'member_icon_size',
			[
				'label'                 => esc_html__( 'Icon Size', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'range'                 => [
					'px' => [
						'max' => 30,
					],
				],
				'default'    => [
					'size' => '14',
					'unit' => 'px',
				],
				'tablet_default'        => [
					'unit' => 'px',
				],
				'mobile_default'        => [
					'unit' => 'px',
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-social-links .pp-tm-social-icon-wrap' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'member_icon_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'default',
				'options'   => [
					'default' => esc_html__( 'Official Color', 'powerpack' ),
					'custom'  => esc_html__( 'Custom', 'powerpack' ),
				],
				'condition' => [
					'social_links_style' => 'button',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_links_style' );

		$this->start_controls_tab(
			'tab_links_normal',
			[
				'label'      => esc_html__( 'Normal', 'powerpack' ),
				'conditions' => $this->get_social_links_style_conditions(),
			]
		);

		$this->add_control(
			'member_links_icons_color',
			[
				'label'      => esc_html__( 'Color', 'powerpack' ),
				'type'       => Controls_Manager::COLOR,
				'default'    => '',
				'selectors'  => [
					'{{WRAPPER}} .pp-tm-social-links .pp-tm-social-icon-wrap' => 'color: {{VALUE}};',
					'{{WRAPPER}} .pp-tm-social-links .pp-tm-social-icon-wrap svg' => 'fill: {{VALUE}};',
				],
				'conditions' => $this->get_social_links_style_conditions(),
			]
		);

		$this->add_control(
			'member_links_bg_color',
			[
				'label'      => esc_html__( 'Background Color', 'powerpack' ),
				'type'       => Controls_Manager::COLOR,
				'default'    => '',
				'selectors'  => [
					'{{WRAPPER}} .pp-tm-social-links .pp-tm-social-icon-wrap' => 'background-color: {{VALUE}};',
				],
				'conditions' => $this->get_social_links_style_conditions(),
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'                  => 'member_links_border',
				'label'                 => esc_html__( 'Border', 'powerpack' ),
				'placeholder'           => '1px',
				'default'               => '1px',
				'separator'             => 'before',
				'selector'              => '{{WRAPPER}} .pp-tm-social-links .pp-tm-social-icon-wrap',
			]
		);

		$this->add_control(
			'member_links_border_radius',
			[
				'label'                 => esc_html__( 'Border Radius', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-social-links .pp-tm-social-icon-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'member_links_padding',
			[
				'label'                 => esc_html__( 'Padding', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'separator'             => 'before',
				'selectors'             => [
					'{{WRAPPER}} .pp-tm-social-links .pp-tm-social-icon-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_links_hover',
			[
				'label'      => esc_html__( 'Hover', 'powerpack' ),
				'conditions' => $this->get_social_links_style_conditions(),
			]
		);

		$this->add_control(
			'member_links_icons_color_hover',
			[
				'label'      => esc_html__( 'Color', 'powerpack' ),
				'type'       => Controls_Manager::COLOR,
				'default'    => '',
				'selectors'  => [
					'{{WRAPPER}} .pp-tm-social-links .pp-tm-social-icon-wrap:hover, {{WRAPPER}} .pp-tm-social-links .pp-tm-social-link:focus-visible .pp-tm-social-icon-wrap' => 'color: {{VALUE}};',
					'{{WRAPPER}} .pp-tm-social-links .pp-tm-social-icon-wrap:hover svg, {{WRAPPER}} .pp-tm-social-links .pp-tm-social-link:focus-visible .pp-tm-social-icon-wrap svg' => 'fill: {{VALUE}};',
				],
				'conditions' => $this->get_social_links_style_conditions(),
			]
		);

		$this->add_control(
			'member_links_bg_color_hover',
			[
				'label'      => esc_html__( 'Background Color', 'powerpack' ),
				'type'       => Controls_Manager::COLOR,
				'default'    => '',
				'selectors'  => [
					'{{WRAPPER}} .pp-tm-social-links .pp-tm-social-icon-wrap:hover, {{WRAPPER}} .pp-tm-social-links .pp-tm-social-link:focus-visible .pp-tm-social-icon-wrap' => 'background-color: {{VALUE}};',
				],
				'conditions' => $this->get_social_links_style_conditions(),
			]
		);

		$this->add_control(
			'member_links_border_color_hover',
			[
				'label'      => esc_html__( 'Border Color', 'powerpack' ),
				'type'       => Controls_Manager::COLOR,
				'default'    => '',
				'selectors'  => [
					'{{WRAPPER}} .pp-tm-social-links .pp-tm-social-icon-wrap:hover, {{WRAPPER}} .pp-tm-social-links .pp-tm-social-link:focus-visible .pp-tm-social-icon-wrap' => 'border-color: {{VALUE}};',
				],
				'conditions' => $this->get_social_links_style_conditions(),
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Resolve which content blocks a region renders, in order.
	 *
	 * Social links and description move between the overlay and the normal
	 * content box depending on `overlay_content`, and their relative order is
	 * only user-controlled when `social_links_position` is actually available.
	 *
	 * @since 3.2.0
	 * @access protected
	 *
	 * @param array  $settings Widget settings.
	 * @param string $region   Region to plan, either 'overlay' or 'normal'.
	 * @return array Ordered block slugs, drawn from 'social' and 'description'.
	 */
	protected function get_content_blocks( $settings, $region ) {
		$overlay = $settings['overlay_content'];
		$social  = 'yes' === $settings['member_social_links'];

		if ( 'overlay' === $region ) {
			$has_social      = $social && in_array( $overlay, [ 'social_icons', 'all_content' ], true );
			$has_description = in_array( $overlay, [ 'content', 'all_content' ], true );
		} else {
			$has_social      = $social && in_array( $overlay, [ 'none', 'content' ], true );
			$has_description = in_array( $overlay, [ 'none', 'social_icons' ], true );
		}

		if ( ! $has_social ) {
			return $has_description ? [ 'description' ] : [];
		}

		if ( ! $has_description ) {
			return [ 'social' ];
		}

		// The position control is only exposed for these two overlay modes;
		// anywhere else the stored value must not be honoured.
		$positionable = in_array( $overlay, [ 'none', 'all_content' ], true );
		$position     = $positionable ? $settings['social_links_position'] : 'before_desc';

		return 'before_desc' === $position
			? [ 'social', 'description' ]
			: [ 'description', 'social' ];
	}

	/**
	 * Render the blocks resolved by get_content_blocks().
	 *
	 * @since 3.2.0
	 * @access protected
	 *
	 * @param array $blocks Ordered block slugs.
	 * @return void
	 */
	protected function render_content_blocks( $blocks ) {
		foreach ( $blocks as $block ) {
			if ( 'social' === $block ) {
				$this->render_social_links();
			} else {
				$this->render_description();
			}
		}
	}

	/**
	 * Render a divider element below a text section.
	 *
	 * @since 3.0.0
	 *
	 * @param string $slug Divider slug, e.g. 'title', 'position', 'description'.
	 * @return void
	 */
	protected function render_divider( $slug ) {
		?>
		<div class="pp-tm-<?php echo esc_attr( $slug ); ?>-divider-wrap">
			<div class="pp-tm-divider pp-tm-<?php echo esc_attr( $slug ); ?>-divider"></div>
		</div>
		<?php
	}

	/**
	 * Render the member image, optionally wrapped in the widget link.
	 *
	 * @since 1.3.3
	 * @access protected
	 *
	 * @return void
	 */
	protected function render_image() {
		$settings = $this->get_settings_for_display();
		$link_key = 'link';

		if ( ! empty( $settings['image']['url'] ) ) {
			if ( ! empty( $settings['image']['id'] ) ) {
				$settings['image']['id'] = apply_filters( 'wpml_object_id', $settings['image']['id'], 'attachment', true );
			}

			$image_html = Group_Control_Image_Size::get_attachment_image_html( $settings );

			if ( 'image' === $settings['link_type'] && $settings['link']['url'] ) {
				// The attachment alt text is often empty, which would leave this link
				// without an accessible name. Fall back to the member name.
				$image_alt = Control_Media::get_image_alt( $settings['image'] );

				if ( '' === trim( (string) $image_alt ) && ! empty( $settings['team_member_name'] ) ) {
					$this->add_render_attribute( $link_key, 'aria-label', $settings['team_member_name'] );
				}
				?>
				<a <?php $this->print_render_attribute_string( $link_key ); ?>><?php echo wp_kses_post( $image_html ); ?></a>
				<?php
			} else {
				echo wp_kses_post( $image_html );
			}
		}
	}

	/**
	 * Render the member name, optionally wrapped in the widget link.
	 *
	 * @since 1.3.3
	 * @access protected
	 *
	 * @return void
	 */
	protected function render_name() {
		$settings = $this->get_settings_for_display();

		$member_key   = 'team_member_name';
		$link_key     = 'link';
		$wrap_in_link = 'title' === $settings['link_type'] && ! empty( $settings['link']['url'] );

		if ( ! $wrap_in_link ) {
			$this->add_inline_editing_attributes( $member_key, 'none' );
		}

		$this->add_render_attribute( $member_key, 'class', 'pp-tm-name' );

		if ( $settings[ $member_key ] ) {
			?>
			<<?php PP_Helper::print_validated_html_tag( $settings['name_html_tag'] ); ?> <?php $this->print_render_attribute_string( $member_key ); ?>>
				<?php if ( $wrap_in_link ) : ?>
					<a <?php $this->print_render_attribute_string( $link_key ); ?>><?php echo esc_html( $settings['team_member_name'] ); ?></a>
				<?php else : ?>
					<?php echo esc_html( $settings['team_member_name'] ); ?>
				<?php endif; ?>
			</<?php PP_Helper::print_validated_html_tag( $settings['name_html_tag'] ); ?>>
			<?php
			if ( 'yes' === $settings['member_title_divider'] ) {
				$this->render_divider( 'title' );
			}
		}
	}

	/**
	 * Render the member position.
	 *
	 * @since 1.3.3
	 * @access protected
	 *
	 * @return void
	 */
	protected function render_position() {
		$settings = $this->get_settings_for_display();
		$this->add_inline_editing_attributes( 'team_member_position', 'none' );
		$this->add_render_attribute( 'team_member_position', 'class', 'pp-tm-position' );

		if ( $settings['team_member_position'] ) {
			?>
			<<?php PP_Helper::print_validated_html_tag( $settings['position_html_tag'] ); ?> <?php $this->print_render_attribute_string( 'team_member_position' ); ?>>
				<?php echo wp_kses_post( $settings['team_member_position'] ); ?>
			</<?php PP_Helper::print_validated_html_tag( $settings['position_html_tag'] ); ?>>
			<?php
			if ( 'yes' === $settings['member_position_divider'] ) {
				$this->render_divider( 'position' );
			}
		}
	}

	/**
	 * Render the member description.
	 *
	 * @since 1.3.3
	 * @access protected
	 *
	 * @return void
	 */
	protected function render_description() {
		$settings = $this->get_settings_for_display();
		$this->add_inline_editing_attributes( 'team_member_description', 'advanced' );
		$this->add_render_attribute( 'team_member_description', 'class', 'pp-tm-description' );

		if ( 'yes' === $settings['team_member_description_switch'] && $settings['team_member_description'] ) {
			?>
			<div <?php $this->print_render_attribute_string( 'team_member_description' ); ?>>
				<?php echo wp_kses_post( $this->parse_text_editor( $settings['team_member_description'] ) ); ?>
			</div>
			<?php
			if ( 'yes' === $settings['member_description_divider'] ) {
				$this->render_divider( 'description' );
			}
		}
	}

	/**
	 * Get the accessible name for a single social link.
	 *
	 * Uses the network name derived from the icon, falling back to a generic
	 * label so the link is never announced without a name.
	 *
	 * @since 3.1.0
	 *
	 * @param string $social Network slug from the icon. Empty for SVG icons.
	 * @return string
	 */
	protected function get_social_link_label( $social ) {
		if ( $social ) {
			return ucwords( str_replace( '-', ' ', $social ) );
		}

		return esc_html__( 'Social link', 'powerpack' );
	}

	/**
	 * Render a single social icon, hidden from assistive technology.
	 *
	 * @since 3.1.0
	 *
	 * @param array $item     Repeater item settings.
	 * @param bool  $is_new   Whether the item uses the icons control.
	 * @param bool  $migrated Whether the item was migrated from Font Awesome 4.
	 * @return void
	 */
	protected function render_social_icon( $item, $is_new, $migrated ) {
		if ( $is_new || $migrated ) {
			Icons_Manager::render_icon( $item['select_social_icon'], [ 'aria-hidden' => 'true' ] );
		} else {
			?>
			<i class="<?php echo esc_attr( $item['social_icon'] ); ?>" aria-hidden="true"></i>
			<?php
		}
	}

	/**
	 * Render the member social links list.
	 *
	 * @since 1.3.3
	 * @access protected
	 *
	 * @return void
	 */
	protected function render_social_links() {
		$settings = $this->get_settings_for_display();

		$fallback_defaults = [
			'fa fa-facebook',
			'fa fa-x-twitter',
			'fa fa-instagram',
		];

		$migration_allowed = Icons_Manager::is_migration_allowed();
		$list_label        = $settings['team_member_name']
			/* translators: %s: team member name. */
			? sprintf( esc_html__( '%s social links', 'powerpack' ), $settings['team_member_name'] )
			: esc_html__( 'Social links', 'powerpack' );

		$this->add_render_attribute( 'social-links', [
			'class'      => 'pp-tm-social-links',
			'aria-label' => $list_label,
		] );
		?>
		<div class="pp-tm-social-links-wrap">
			<ul <?php $this->print_render_attribute_string( 'social-links' ); ?>>
				<?php foreach ( $settings['team_member_social'] as $index => $item ) : ?>
					<?php
					$migrated = isset( $item['__fa4_migrated']['select_social_icon'] );
					$is_new = empty( $item['social_icon'] ) && $migration_allowed;
					$social = '';

					// add old default
					if ( empty( $item['social_icon'] ) && ! $migration_allowed ) {
						$item['social_icon'] = isset( $fallback_defaults[ $index ] ) ? $fallback_defaults[ $index ] : 'fa fa-wordpress';
					}

					if ( ! empty( $item['social_icon'] ) ) {
						$social = str_replace( 'fa fa-', '', $item['social_icon'] );
					}

					$icon_library = isset( $item['select_social_icon']['library'] ) ? $item['select_social_icon']['library'] : '';

					if ( ( $is_new || $migrated ) && 'svg' !== $icon_library ) {
						$social = explode( ' ', isset( $item['select_social_icon']['value'] ) ? $item['select_social_icon']['value'] : '', 2 );
						if ( empty( $social[1] ) ) {
							$social = '';
						} else {
							$social = str_replace( 'fa-', '', $social[1] );
						}
					}
					if ( 'svg' === $icon_library ) {
						$social = '';
					}

					$has_icon = ! empty( $item['social_icon'] ) || ! empty( $item['select_social_icon']['value'] );
					$has_link = ! empty( $item['social_link']['url'] );

					// An item with neither an icon nor a link has nothing to show or do.
					if ( ! $has_icon && ! $has_link ) {
						continue;
					}

					$social_link_key = 'social_link' . $index;
					$icon_wrap_key   = 'icon_wrap' . $index;

					$this->add_render_attribute( $social_link_key, 'class', 'pp-tm-social-link' );
					$this->add_render_attribute( $icon_wrap_key, 'class', 'pp-tm-social-icon-wrap' );

					if ( 'button' === $settings['social_links_style'] ) {
						$this->add_render_attribute( $icon_wrap_key, 'class', [
							'elementor-icon',
							'elementor-social-icon',
							'elementor-social-icon-' . $social,
						] );
					}

					if ( $has_link ) {
						$this->add_link_attributes( $social_link_key, $item['social_link'] );
					}

					$link_label = $this->get_social_link_label( $social );
					?>
					<li>
						<?php if ( $has_link ) : ?>
							<a <?php $this->print_render_attribute_string( $social_link_key ); ?>>
								<span <?php $this->print_render_attribute_string( $icon_wrap_key ); ?>>
									<span class="elementor-screen-only"><?php echo esc_html( $link_label ); ?></span>
									<span class="pp-tm-social-icon pp-icon">
										<?php $this->render_social_icon( $item, $is_new, $migrated ); ?>
									</span>
								</span>
							</a>
						<?php else : ?>
							<span <?php $this->print_render_attribute_string( $icon_wrap_key ); ?>>
								<span class="pp-tm-social-icon pp-icon">
									<?php $this->render_social_icon( $item, $is_new, $migrated ); ?>
								</span>
							</span>
						<?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php
	}

	/**
	 * Render team member widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$link_key = 'link';

		if ( 'none' !== $settings['link_type'] && ! empty( $settings['link']['url'] ) ) {
			$this->add_link_attributes( $link_key, $settings['link'] );
		}
		?>
		<div class="pp-tm-wrapper">
			<div class="pp-tm">
				<?php if ( ! empty( $settings['image']['url'] ) || 'none' !== $settings['overlay_content'] ) { ?>
				<div class="pp-tm-image">
					<?php $this->render_image(); ?>

					<?php if ( 'none' !== $settings['overlay_content'] ) { ?>
						<div class="pp-tm-overlay-content-wrap">
							<div class="pp-tm-content">
								<?php $this->render_content_blocks( $this->get_content_blocks( $settings, 'overlay' ) ); ?>
							</div>
						</div>
					<?php } ?>
				</div>
				<?php } ?>
				<div class="pp-tm-content pp-tm-content-normal">
					<?php
					$this->render_name();
					$this->render_position();
					$this->render_content_blocks( $this->get_content_blocks( $settings, 'normal' ) );
					?>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render team member widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 2.4.0
	 * @access protected
	 */
	protected function content_template() {
		?>
		<#
			function link_attributes( link ) {
				var attrs = 'href="' + _.escape( elementor.helpers.sanitizeUrl( link.url ) ) + '"';

				if ( link.is_external ) {
					attrs += ' target="_blank"';
				}

				if ( link.nofollow ) {
					attrs += ' rel="nofollow"';
				}

				return attrs;
			}

			// Mirrors ucwords() in get_social_link_label().
			function ucwords( text ) {
				return text.replace( /(^|\s)\S/g, function( c ) {
					return c.toUpperCase();
				} );
			}

			// Mirrors get_content_blocks(): which blocks a region renders, in order.
			function content_blocks( region ) {
				var overlay = settings.overlay_content,
					social = settings.member_social_links == 'yes',
					hasSocial, hasDescription, positionable, position;

				if ( 'overlay' === region ) {
					hasSocial = social && ( overlay == 'social_icons' || overlay == 'all_content' );
					hasDescription = ( overlay == 'content' || overlay == 'all_content' );
				} else {
					hasSocial = social && ( overlay == 'none' || overlay == 'content' );
					hasDescription = ( overlay == 'none' || overlay == 'social_icons' );
				}

				if ( ! hasSocial ) {
					return hasDescription ? [ 'description' ] : [];
				}

				if ( ! hasDescription ) {
					return [ 'social' ];
				}

				positionable = ( overlay == 'none' || overlay == 'all_content' );
				position = positionable ? settings.social_links_position : 'before_desc';

				return position == 'before_desc'
					? [ 'social', 'description' ]
					: [ 'description', 'social' ];
			}

			function render_content_blocks( region ) {
				_.each( content_blocks( region ), function( block ) {
					if ( 'social' === block ) {
						member_social_links();
					} else {
						member_description();
					}
				} );
			}

			function member_image() {
				if ( '' !== settings.image.url ) {
					var image = {
						id: settings.image.id,
						url: settings.image.url,
						size: settings.image_size,
						dimension: settings.image_custom_dimension,
						model: view.getEditModel()
					};

					var image_url = elementor.imagesManager.getImageUrl( image );

					var imageHtml = '<img src="' + _.escape( image_url ) + '" alt="" />';

					if ( settings.link_type == 'image' && settings.link.url != '' ) {
						var imageLinkLabel = settings.team_member_name ? ' aria-label="' + _.escape( settings.team_member_name ) + '"' : '';

						imageHtml = '<a ' + link_attributes( settings.link ) + imageLinkLabel + '>' + imageHtml + '</a>';
					}

					print( imageHtml );
				}
			}

			function member_name() {
				if ( settings.team_member_name != '' ) {
					var wrapInLink = settings.link_type == 'title' && settings.link.url != '',
						nameContent = settings.team_member_name;

					view.addRenderAttribute( 'team_member_name', 'class', 'pp-tm-name' );

					if ( ! wrapInLink ) {
						view.addInlineEditingAttributes( 'team_member_name' );
					} else {
						nameContent = '<a ' + link_attributes( settings.link ) + '>' + nameContent + '</a>';
					}

					var nameHTMLTag = elementor.helpers.validateHTMLTag( settings.name_html_tag ),
						name_html = '<' + nameHTMLTag  + ' ' + view.getRenderAttributeString( 'team_member_name' ) + '>' + nameContent + '</' + nameHTMLTag + '>';

					print( name_html );

					if ( settings.member_title_divider == 'yes' ) { #>
						<div class="pp-tm-title-divider-wrap">
							<div class="pp-tm-divider pp-tm-title-divider"></div>
						</div>
					<# }
				}
			}

			function member_position() {
				if ( settings.team_member_position != '' ) {
					var position = settings.team_member_position;

					view.addRenderAttribute( 'team_member_position', 'class', 'pp-tm-position' );

					view.addInlineEditingAttributes( 'team_member_position' );

					var positionHTMLTag = elementor.helpers.validateHTMLTag( settings.position_html_tag ),
						position_html = '<' + positionHTMLTag  + ' ' + view.getRenderAttributeString( 'team_member_position' ) + '>' + position + '</' + positionHTMLTag + '>';

					print( position_html );

					if ( settings.member_position_divider == 'yes' ) { #>
						<div class="pp-tm-position-divider-wrap">
							<div class="pp-tm-divider pp-tm-position-divider"></div>
						</div>
					<# }
				}
			}

			function member_description() {
				if ( settings.team_member_description_switch == 'yes' && settings.team_member_description != '' ) {
					var description = settings.team_member_description;

					view.addRenderAttribute( 'team_member_description', 'class', 'pp-tm-description' );

					view.addInlineEditingAttributes( 'team_member_description', 'advanced' );

					var description_html = '<div ' + view.getRenderAttributeString( 'team_member_description' ) + '>' + description + '</div>';

					print( description_html );

					if ( settings.member_description_divider == 'yes' ) { #>
						<div class="pp-tm-description-divider-wrap">
							<div class="pp-tm-divider pp-tm-description-divider"></div>
						</div>
					<# }
				}
			}

			function member_social_links() {
				var listLabel = settings.team_member_name
					? '<?php echo esc_js( __( '%s social links', 'powerpack' ) ); ?>'.replace( '%s', settings.team_member_name )
					: '<?php echo esc_js( __( 'Social links', 'powerpack' ) ); ?>';
				#>
				<# var iconsHTML = {}; #>
				<div class="pp-tm-social-links-wrap">
					<ul class="pp-tm-social-links" aria-label="{{ listLabel }}">
						<# _.each( settings.team_member_social, function( item, index ) {
							var hasIcon = !! ( item.social_icon || ( item.select_social_icon && item.select_social_icon.value ) ),
								hasLink = !! ( item.social_link && item.social_link.url );

							// An item with neither an icon nor a link has nothing to show or do.
							if ( ! hasIcon && ! hasLink ) {
								return;
							}

							var migrated = elementor.helpers.isIconMigrated( item, 'select_social_icon' ),
								social = elementor.helpers.getSocialNetworkNameFromIcon( item.select_social_icon, item.social_icon, false, migrated );

							var socialLinkKey = view.getRepeaterSettingKey( 'text', 'social_link', index );
							var iconWrapKey = view.getRepeaterSettingKey( 'text', 'icon_wrap', index );

							view.addRenderAttribute( socialLinkKey, 'class', 'pp-tm-social-link' );
							view.addRenderAttribute( iconWrapKey, 'class', 'pp-tm-social-icon-wrap' );

							if ( 'button' == settings.social_links_style ) {
								view.addRenderAttribute( iconWrapKey, 'class', [
									'elementor-icon',
									'elementor-social-icon',
									'elementor-social-icon-' + social,
								] );
							}

							if ( hasLink ) {
								view.addRenderAttribute( socialLinkKey, 'href', elementor.helpers.sanitizeUrl( item.social_link.url ) );
							}

							var linkLabel = social ? ucwords( social.replace( /-/g, ' ' ) ) : '<?php echo esc_js( __( 'Social link', 'powerpack' ) ); ?>';

							iconsHTML[ index ] = elementor.helpers.renderIcon( view, item.select_social_icon, { 'aria-hidden': 'true' }, 'i', 'object' );
						#>
							<li>
								<# if ( hasLink ) { #>
									<a {{{ view.getRenderAttributeString( socialLinkKey ) }}}>
										<span {{{ view.getRenderAttributeString( iconWrapKey ) }}}>
											<span class="elementor-screen-only">{{ linkLabel }}</span>
											<span class="pp-tm-social-icon pp-icon">
												<# if ( ( ! item.social_icon || migrated ) && iconsHTML[ index ] && iconsHTML[ index ].rendered ) { #>
													{{{ iconsHTML[ index ].value }}}
												<# } else { #>
													<i class="{{ item.social_icon }}" aria-hidden="true"></i>
												<# } #>
											</span>
										</span>
									</a>
								<# } else { #>
									<span {{{ view.getRenderAttributeString( iconWrapKey ) }}}>
										<span class="pp-tm-social-icon pp-icon">
											<# if ( ( ! item.social_icon || migrated ) && iconsHTML[ index ] && iconsHTML[ index ].rendered ) { #>
												{{{ iconsHTML[ index ].value }}}
											<# } else { #>
												<i class="{{ item.social_icon }}" aria-hidden="true"></i>
											<# } #>
										</span>
									</span>
								<# } #>
							</li>
						<# } ); #>
					</ul>
				</div>
		<# } #>

		<div class="pp-tm-wrapper">
			<div class="pp-tm">
				<# if ( '' !== settings.image.url || settings.overlay_content != 'none' ) { #>
				<div class="pp-tm-image">
					<# member_image(); #>

					<# if ( settings.overlay_content != 'none' ) { #>
						<div class="pp-tm-overlay-content-wrap">
							<div class="pp-tm-content">
								<# render_content_blocks( 'overlay' ); #>
							</div>
						</div>
					<# } #>
				</div>
				<# } #>
				<div class="pp-tm-content pp-tm-content-normal">
					<#
						member_name();
						member_position();
						render_content_blocks( 'normal' );
					#>
				</div>
			</div>
		</div>
		<?php
	}
}
