<?php
namespace PowerpackElements\Modules\Testimonials\Widgets;

use PowerpackElements\Base\Powerpack_Widget;
use PowerpackElements\Classes\PP_Helper;

// Elementor Classes
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Control_Media;
use Elementor\Repeater;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Modules\DynamicTags\Module as TagsModule;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Testimonials Widget
 */
class Testimonials extends Powerpack_Widget {

	/**
	 * Retrieve testimonials widget name.
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return parent::get_widget_name( 'Testimonials' );
	}

	/**
	 * Retrieve testimonials widget title.
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return parent::get_widget_title( 'Testimonials' );
	}

	/**
	 * Retrieve testimonials widget icon.
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return parent::get_widget_icon( 'Testimonials' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return parent::get_widget_keywords( 'Testimonials' );
	}

	/**
	 * Whether the widget renders query-dependent content.
	 *
	 * Testimonials are authored in the widget's own repeater, so the output
	 * never depends on the current query.
	 *
	 * @access protected
	 *
	 * @return bool Always false.
	 */
	protected function is_dynamic_content(): bool {
		return false;
	}

	/**
	 * Retrieve the list of scripts the testimonials widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		if ( PP_Helper::is_edit_mode() || PP_Helper::is_preview_mode() ) {
			return [
				'swiper',
				'imagesloaded',
				'pp-testimonials',
			];
		}

		$settings = $this->get_settings_for_display();
		$scripts = [];

		if ( 'carousel' === $settings['layout'] || 'slideshow' === $settings['layout'] ) {
			array_push( $scripts, 'swiper', 'pp-testimonials' );

			// imagesLoaded only drives applyVerticalHeight(), which bails out on
			// horizontal sliders before it ever calls it.
			if ( 'vertical' === $settings['orientation'] ) {
				$scripts[] = 'imagesloaded';
			}
		}

		if ( 'masonry' === $settings['layout'] ) {
			array_push( $scripts, 'imagesloaded', 'pp-testimonials' );
		}

		return $scripts;
	}

	/**
	 * Retrieve the list of styles the offcanvas content widget depended on.
	 *
	 * Used to set styles dependencies required to run the widget.
	 *
	 * @access public
	 *
	 * @return array Widget styles dependencies.
	 */
	public function get_style_depends() {
		if ( PP_Helper::is_edit_mode() || PP_Helper::is_preview_mode() ) {
			return [
				'e-swiper',
				'pp-swiper',
				'widget-pp-testimonials'
			];
		}

		$settings = $this->get_settings_for_display();
		$styles = ['widget-pp-testimonials'];

		if ( 'carousel' === $settings['layout'] || 'slideshow' === $settings['layout'] ) {
			array_push( $styles, 'e-swiper', 'pp-swiper' );
		}

		return $styles;
	}

	/**
	 * Whether Elementor should render its inner wrapper element.
	 *
	 * The widget supplies its own '.pp-testimonials-wrap' container, so the
	 * extra wrapper is only kept while the optimized markup experiment is off.
	 *
	 * @access public
	 *
	 * @return bool True when the inner wrapper should be rendered.
	 */
	public function has_widget_inner_wrapper(): bool {
		return ! PP_Helper::is_feature_active( 'e_optimized_markup' );
	}

	/**
	 * Register testimonials widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 2.0.3
	 * @access protected
	 */
	protected function register_controls() {
		/* Content Tab */
		$this->register_content_testimonials_controls();
		$this->register_style_order_controls();
		$this->register_content_slider_options_controls();

		/* Style Tab */
		$this->register_style_testimonial_controls();
		$this->register_style_content_controls();
		$this->register_style_image_controls();
		$this->register_style_rating_controls();
		$this->register_style_arrows_controls();
		$this->register_style_dots_controls();
		$this->register_style_thumbnail_nav_controls();
	}

	/*-----------------------------------------------------------------------------------*/
	/*	CONTENT TAB
	/*-----------------------------------------------------------------------------------*/

	/**
	 * Content Tab: Testimonials
	 */
	protected function register_content_testimonials_controls() {
		$this->start_controls_section(
			'section_testimonials',
			[
				'label'                 => esc_html__( 'Testimonials', 'powerpack' ),
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'content',
			[
				'label'                => esc_html__( 'Content', 'powerpack' ),
				'type'                 => Controls_Manager::TEXTAREA,
				'default'              => '',
				'dynamic'              => [
					'active'  => true,
				],
			]
		);

		$repeater->add_control(
			'image',
			[
				'label'                => esc_html__( 'Image', 'powerpack' ),
				'type'                 => Controls_Manager::MEDIA,
				'dynamic'              => [
					'active'  => true,
				],
				'default'              => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'name',
			[
				'label'                => esc_html__( 'Name', 'powerpack' ),
				'type'                 => Controls_Manager::TEXT,
				'default'              => esc_html__( 'John Doe', 'powerpack' ),
				'dynamic'              => [
					'active'  => true,
				],
			]
		);

		$repeater->add_control(
			'position',
			[
				'label'                => esc_html__( 'Position', 'powerpack' ),
				'type'                 => Controls_Manager::TEXT,
				'default'              => esc_html__( 'CEO', 'powerpack' ),
				'dynamic'              => [
					'active'  => true,
				],
			]
		);

		$repeater->add_control(
			'rating',
			[
				'label'                => esc_html__( 'Rating', 'powerpack' ),
				'type'                 => Controls_Manager::NUMBER,
				'min'                  => 0,
				'max'                  => 5,
				'step'                 => 0.1,
			]
		);

		$repeater->add_control(
			'link',
			[
				'label'                => esc_html__( 'Link', 'powerpack' ),
				'type'                 => Controls_Manager::URL,
				'dynamic'              => [
					'active'     => true,
					'categories' => [
						TagsModule::POST_META_CATEGORY,
						TagsModule::URL_CATEGORY,
					],
				],
				'placeholder'          => 'https://www.your-link.com',
			]
		);

		$this->add_control(
			'testimonials',
			[
				'label'                => '',
				'type'                 => Controls_Manager::REPEATER,
				'default'              => [
					[
						'name'        => esc_html__( 'John Doe', 'powerpack' ),
						'position'    => esc_html__( 'CEO', 'powerpack' ),
						'content'     => esc_html__( 'I am slide content. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'powerpack' ),
					],
					[
						'name'        => esc_html__( 'John Doe', 'powerpack' ),
						'position'    => esc_html__( 'CEO', 'powerpack' ),
						'content'     => esc_html__( 'I am slide content. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'powerpack' ),
					],
					[
						'name'        => esc_html__( 'John Doe', 'powerpack' ),
						'position'    => esc_html__( 'CEO', 'powerpack' ),
						'content'     => esc_html__( 'I am slide content. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'powerpack' ),
					],
				],
				'fields'            => $repeater->get_controls(),
				'title_field'       => '{{{ position !== "" ? name + " - " + position : name }}}',
			]
		);

		$this->add_control(
			'layout',
			[
				'label'                => esc_html__( 'Layout', 'powerpack' ),
				'type'                 => Controls_Manager::SELECT,
				'default'              => 'carousel',
				'options'              => [
					'carousel'  => esc_html__( 'Carousel', 'powerpack' ),
					'slideshow' => esc_html__( 'Slideshow', 'powerpack' ),
					'grid'      => esc_html__( 'Grid', 'powerpack' ),
					'masonry'   => esc_html__( 'Masonry', 'powerpack' ),
				],
				'separator'            => 'before',
			]
		);

		$this->add_responsive_control(
			'columns',
			[
				'label'                 => esc_html__( 'Columns', 'powerpack' ),
				'type'                  => Controls_Manager::SELECT,
				'default'               => '3',
				'tablet_default'        => '2',
				'mobile_default'        => '1',
				'options'               => [
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
					'5' => '5',
					'6' => '6',
					'7' => '7',
					'8' => '8',
				],
				'prefix_class'          => 'elementor-grid%s-',
				'selectors'             => [
					// Exposed as a CSS var so the masonry script can read the current-device
					// column count reliably (grid uses Elementor core's .elementor-grid columns).
					'{{WRAPPER}} .pp-testimonials' => '--pp-gallery-columns: {{VALUE}};',
				],
				'condition'             => [
					'layout' => [ 'grid', 'masonry' ],
				],
			]
		);

		$this->add_control(
			'skin',
			[
				'label'                => esc_html__( 'Skin', 'powerpack' ),
				'type'                 => Controls_Manager::SELECT,
				'default'              => 'skin-1',
				'options'              => [
					'skin-1'    => esc_html__( 'Skin 1', 'powerpack' ),
					'skin-2'    => esc_html__( 'Skin 2', 'powerpack' ),
					'skin-3'    => esc_html__( 'Skin 3', 'powerpack' ),
					'skin-4'    => esc_html__( 'Skin 4', 'powerpack' ),
					'skin-5'    => esc_html__( 'Skin 5', 'powerpack' ),
					'skin-6'    => esc_html__( 'Skin 6', 'powerpack' ),
					'skin-7'    => esc_html__( 'Skin 7', 'powerpack' ),
					'skin-8'    => esc_html__( 'Skin 8', 'powerpack' ),
				],
			]
		);

		$this->add_control(
			'content_style',
			[
				'label'                => esc_html__( 'Content Style', 'powerpack' ),
				'type'                 => Controls_Manager::SELECT,
				'default'              => 'default',
				'options'              => [
					'default'   => esc_html__( 'Default', 'powerpack' ),
					'bubble'    => esc_html__( 'Bubble', 'powerpack' ),
				],
				'prefix_class'          => 'pp-testimonials-content-',
			]
		);

		$this->add_control(
			'name_html_tag',
			[
				'label'                => esc_html__( 'Name HTML Tag', 'powerpack' ),
				'type'                 => Controls_Manager::SELECT,
				'default'              => 'div',
				'options'              => [
					'h1'    => 'H1',
					'h2'    => 'H2',
					'h3'    => 'H3',
					'h4'    => 'H4',
					'h5'    => 'H5',
					'h6'    => 'H6',
					'div'   => 'div',
					'span'  => 'span',
					'p'     => 'p',
				],
			]
		);

		$this->add_control(
			'show_image',
			[
				'label'                => esc_html__( 'Show Image', 'powerpack' ),
				'type'                 => Controls_Manager::SELECT,
				'default'              => '',
				'options'              => [
					''      => esc_html__( 'Yes', 'powerpack' ),
					'no'    => esc_html__( 'No', 'powerpack' ),
				],
			]
		);

		$this->add_control(
			'image_position',
			[
				'label'                => esc_html__( 'Image Position', 'powerpack' ),
				'type'                 => Controls_Manager::SELECT,
				'default'              => 'inline',
				'options'              => [
					'inline'    => esc_html__( 'Inline', 'powerpack' ),
					'stacked'   => esc_html__( 'Stacked', 'powerpack' ),
				],
				'condition'             => [
					'show_image'    => '',
					'skin'          => [ 'skin-1', 'skin-2', 'skin-3', 'skin-4' ],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'                  => 'thumbnail',
				'default'               => 'full',
				'condition'             => [
					'show_image'    => '',
				],
			]
		);

		$this->add_control(
			'show_quote',
			[
				'label'                => esc_html__( 'Show Quote', 'powerpack' ),
				'type'                 => Controls_Manager::SELECT,
				'default'              => 'no',
				'options'              => [
					''      => esc_html__( 'Yes', 'powerpack' ),
					'no'    => esc_html__( 'No', 'powerpack' ),
				],
			]
		);

		$this->add_control(
			'quote_position',
			[
				'label'                => esc_html__( 'Quote Position', 'powerpack' ),
				'type'                 => Controls_Manager::SELECT,
				'default'              => 'above',
				'options'              => [
					'above'         => esc_html__( 'Above Content', 'powerpack' ),
					'before'        => esc_html__( 'Before Content', 'powerpack' ),
					'before-after'  => esc_html__( 'Before/After Content', 'powerpack' ),
				],
				'prefix_class'          => 'pp-testimonials-quote-position-',
				'condition'             => [
					'show_quote'    => '',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Order
	 */
	protected function register_style_order_controls() {
		$this->start_controls_section(
			'section_order_style',
			[
				'label'                 => esc_html__( 'Order', 'powerpack' ),
				'condition'             => [
					'image_position'    => 'stacked',
				],
			]
		);

		$this->add_control(
			'image_order',
			[
				'label'                 => esc_html__( 'Image', 'powerpack' ),
				'type'                  => Controls_Manager::NUMBER,
				'default'               => 1,
				'min'                   => 1,
				'max'                   => 4,
				'step'                  => 1,
				'condition'             => [
					'image_position'    => 'stacked',
				],
			]
		);

		$this->add_control(
			'name_order',
			[
				'label'                 => esc_html__( 'Name', 'powerpack' ),
				'type'                  => Controls_Manager::NUMBER,
				'default'               => 2,
				'min'                   => 1,
				'max'                   => 4,
				'step'                  => 1,
				'condition'             => [
					'image_position'    => 'stacked',
				],
			]
		);

		$this->add_control(
			'position_order',
			[
				'label'                 => esc_html__( 'Position', 'powerpack' ),
				'type'                  => Controls_Manager::NUMBER,
				'default'               => 3,
				'min'                   => 1,
				'max'                   => 4,
				'step'                  => 1,
				'condition'             => [
					'image_position'    => 'stacked',
				],
			]
		);

		$this->add_control(
			'rating_order',
			[
				'label'                 => esc_html__( 'Rating', 'powerpack' ),
				'type'                  => Controls_Manager::NUMBER,
				'default'               => 4,
				'min'                   => 1,
				'max'                   => 4,
				'step'                  => 1,
				'condition'             => [
					'image_position'    => 'stacked',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Content Tab: Slider Options
	 */
	protected function register_content_slider_options_controls() {
		$this->start_controls_section(
			'section_slider_options',
			[
				'label'                 => esc_html__( 'Slider Options', 'powerpack' ),
				'condition'             => [
					'layout'    => [ 'carousel', 'slideshow' ],
				],
			]
		);

		$this->add_control(
			'effect',
			[
				'label'                => esc_html__( 'Effect', 'powerpack' ),
				'type'                 => Controls_Manager::SELECT,
				'default'              => 'slide',
				'options'              => [
					'slide'     => esc_html__( 'Slide', 'powerpack' ),
					'fade'      => esc_html__( 'Fade', 'powerpack' ),
				],
				'condition'             => [
					'layout'    => 'slideshow',
				],
			]
		);

		$slides_per_view = range( 1, 10 );
		$slides_per_view = array_combine( $slides_per_view, $slides_per_view );

		$this->add_responsive_control(
			'slides_per_view',
			[
				'type'                  => Controls_Manager::SELECT,
				'label'                 => esc_html__( 'Slides Per View', 'powerpack' ),
				'options'               => $slides_per_view,
				'default'               => '3',
				'tablet_default'        => '2',
				'mobile_default'        => '1',
				'condition'             => [
					'layout'    => 'carousel',
				],
			]
		);

		$this->add_responsive_control(
			'slides_to_scroll',
			[
				'type'                  => Controls_Manager::SELECT,
				'label'                 => esc_html__( 'Slides to Scroll', 'powerpack' ),
				'description'           => esc_html__( 'Set how many slides are scrolled per swipe.', 'powerpack' ),
				'options'               => $slides_per_view,
				'default'               => '1',
				'tablet_default'        => '1',
				'mobile_default'        => '1',
				'condition'             => [
					'layout'       => 'carousel',
					'center_mode!' => 'yes',
				],
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'                 => esc_html__( 'Autoplay', 'powerpack' ),
				'type'                  => Controls_Manager::SWITCHER,
				'default'               => 'yes',
				'label_on'              => esc_html__( 'Yes', 'powerpack' ),
				'label_off'             => esc_html__( 'No', 'powerpack' ),
				'return_value'          => 'yes',
				'separator'             => 'before',
				'condition'             => [
					'layout'    => [ 'carousel', 'slideshow' ],
				],
			]
		);

		$this->add_control(
			'autoplay_speed',
			[
				'label'                 => esc_html__( 'Autoplay Speed', 'powerpack' ),
				'type'                  => Controls_Manager::NUMBER,
				'default'               => 3000,
				'condition'             => [
					'layout'    => [ 'carousel', 'slideshow' ],
					'autoplay'  => 'yes',
				],
			]
		);

		$this->add_control(
			'pause_on_hover',
			[
				'label'                 => esc_html__( 'Pause on Hover', 'powerpack' ),
				'type'                  => Controls_Manager::SWITCHER,
				'default'               => 'yes',
				'label_on'              => esc_html__( 'Yes', 'powerpack' ),
				'label_off'             => esc_html__( 'No', 'powerpack' ),
				'return_value'          => 'yes',
				'frontend_available'    => true,
				'condition'             => [
					'layout'    => [ 'carousel', 'slideshow' ],
					'autoplay'  => 'yes',
				],
			]
		);

		$this->add_control(
			'pause_on_interaction',
			[
				'label'                 => esc_html__( 'Pause on Interaction', 'powerpack' ),
				'description'           => esc_html__( 'Disables autoplay completely on first interaction with the carousel.', 'powerpack' ),
				'type'                  => Controls_Manager::SWITCHER,
				'default'               => '',
				'label_on'              => esc_html__( 'Yes', 'powerpack' ),
				'label_off'             => esc_html__( 'No', 'powerpack' ),
				'return_value'          => 'yes',
				'frontend_available'    => true,
				'condition'             => [
					'layout'    => [ 'carousel', 'slideshow' ],
					'autoplay'  => 'yes',
				],
			]
		);

		$this->add_control(
			'infinite_loop',
			[
				'label'                 => esc_html__( 'Infinite Loop', 'powerpack' ),
				'type'                  => Controls_Manager::SWITCHER,
				'default'               => 'yes',
				'label_on'              => esc_html__( 'Yes', 'powerpack' ),
				'label_off'             => esc_html__( 'No', 'powerpack' ),
				'return_value'          => 'yes',
				'condition'             => [
					'layout'    => [ 'carousel', 'slideshow' ],
				],
			]
		);

		$this->add_control(
			'animation_speed',
			[
				'label'                 => esc_html__( 'Animation Speed', 'powerpack' ),
				'type'                  => Controls_Manager::NUMBER,
				'default'               => 600,
				'condition'             => [
					'layout'    => [ 'carousel', 'slideshow' ],
				],
			]
		);

		$this->add_control(
			'center_mode',
			[
				'label'                 => esc_html__( 'Center Mode', 'powerpack' ),
				'type'                  => Controls_Manager::SWITCHER,
				'default'               => '',
				'label_on'              => esc_html__( 'Yes', 'powerpack' ),
				'label_off'             => esc_html__( 'No', 'powerpack' ),
				'return_value'          => 'yes',
				'separator'             => 'before',
			]
		);

		$this->add_responsive_control(
			'center_padding',
			[
				'label'                 => esc_html__( 'Center Padding', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				// px only: this value is handed to Swiper as a number, not emitted as CSS.
				'size_units'            => [ 'px' ],
				'default'               => [
					'size' => 40,
					'unit' => 'px',
				],
				'range'                 => [
					'px' => [
						'max' => 500,
					],
				],
				'tablet_default'        => [
					'unit' => 'px',
				],
				'mobile_default'        => [
					'unit' => 'px',
				],
				'condition'             => [
					'center_mode'   => 'yes',
				],
			]
		);

		$this->add_control(
			'name_navigation_heading',
			[
				'label'                 => esc_html__( 'Navigation', 'powerpack' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
				'condition'             => [
					'layout'    => [ 'carousel', 'slideshow' ],
				],
			]
		);

		$this->add_control(
			'arrows',
			[
				'label'                 => esc_html__( 'Arrows', 'powerpack' ),
				'type'                  => Controls_Manager::SWITCHER,
				'default'               => 'yes',
				'label_on'              => esc_html__( 'Yes', 'powerpack' ),
				'label_off'             => esc_html__( 'No', 'powerpack' ),
				'return_value'          => 'yes',
				'condition'             => [
					'layout'    => [ 'carousel', 'slideshow' ],
				],
			]
		);

		$this->add_control(
			'thumbnail_nav',
			[
				'label'                 => esc_html__( 'Thumbnail Navigation', 'powerpack' ),
				'type'                  => Controls_Manager::SWITCHER,
				'default'               => 'yes',
				'label_on'              => esc_html__( 'Yes', 'powerpack' ),
				'label_off'             => esc_html__( 'No', 'powerpack' ),
				'return_value'          => 'yes',
				'frontend_available'    => true,
				'condition'             => [
					'layout'    => 'slideshow',
				],
			]
		);

		$this->add_control(
			'dots',
			[
				'label'                 => esc_html__( 'Dots', 'powerpack' ),
				'type'                  => Controls_Manager::SWITCHER,
				'default'               => 'yes',
				'label_on'              => esc_html__( 'Yes', 'powerpack' ),
				'label_off'             => esc_html__( 'No', 'powerpack' ),
				'return_value'          => 'yes',
				'conditions'            => [
					'relation' => 'or',
					'terms' => [
						[
							'name' => 'layout',
							'operator' => '==',
							'value' => 'carousel',
						],
						[
							'relation' => 'and',
							'terms' => [
								[
									'name' => 'layout',
									'operator' => '==',
									'value' => 'slideshow',
								],
								[
									'name' => 'thumbnail_nav',
									'operator' => '!==',
									'value' => 'yes',
								],
							],
						],
					],
				],
			]
		);

		$this->add_control(
			'orientation',
			[
				'label'                 => esc_html__( 'Orientation', 'powerpack' ),
				'type'                  => Controls_Manager::SELECT,
				'default'               => 'horizontal',
				'options'               => [
					'horizontal'    => esc_html__( 'Horizontal', 'powerpack' ),
					'vertical'      => esc_html__( 'Vertical', 'powerpack' ),
				],
				'separator'             => 'before',
				'condition'             => [
					'layout'    => [ 'carousel', 'slideshow' ],
				],
			]
		);

		$this->end_controls_section();
	}

	/*-----------------------------------------------------------------------------------*/
	/*	STYLE TAB
	/*-----------------------------------------------------------------------------------*/

	/**
	 * Style Tab: Testimonial
	 */
	protected function register_style_testimonial_controls() {
		$this->start_controls_section(
			'section_testimonial_style',
			[
				'label'                 => esc_html__( 'Testimonial', 'powerpack' ),
				'tab'                   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'column_spacing',
			[
				'label'                 => esc_html__( 'Column Spacing', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'default'               => [
					'size'      => 20,
				],
				'range'         => [
					'px'        => [
						'min'   => 0,
						'max'   => 100,
					],
				],
				'selectors'             => [
					'{{WRAPPER}}' => '--grid-column-gap: {{SIZE}}{{UNIT}}',
				],
				'render_type'           => 'template',
				'separator'             => 'after',
				'condition'             => [
					'layout!'   => 'slideshow',
				],
			]
		);

		$this->add_responsive_control(
			'row_spacing',
			[
				'label'                 => esc_html__( 'Row Spacing', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'default'               => [
					'size'      => 20,
				],
				'range'         => [
					'px'        => [
						'min'   => 0,
						'max'   => 100,
					],
				],
				'selectors'             => [
					'{{WRAPPER}}' => '--grid-row-gap: {{SIZE}}{{UNIT}}',
				],
				'condition'             => [
					'layout' => [ 'grid', 'masonry' ],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'                  => 'slide_background',
				'types'                 => [ 'classic', 'gradient' ],
				'selector'              => '{{WRAPPER}} .pp-testimonial, {{WRAPPER}} .pp-testimonials-wrap .pp-testimonials-thumb-item:before',
			]
		);

		$this->add_control(
			'slide_border',
			[
				'label'                 => esc_html__( 'Border', 'powerpack' ),
				'type'                  => Controls_Manager::SWITCHER,
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonial, {{WRAPPER}} .pp-testimonials-wrap .pp-testimonials-thumb-item:before' => 'border-style: solid',
				],
				'separator'             => 'before',
			]
		);

		$this->add_control(
			'slide_border_color',
			[
				'label'                 => esc_html__( 'Border Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonial' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .pp-testimonials-wrap .pp-testimonials-thumb-item:before' => 'border-color: transparent transparent {{VALUE}} {{VALUE}};',
				],
				'condition'             => [
					'slide_border'   => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'slide_border_width',
			[
				'label'                 => esc_html__( 'Border Width', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'range'                 => [
					'px' => [
						'min' => 0,
						'max' => 20,
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonial, {{WRAPPER}} .pp-testimonials-wrap .pp-testimonials-thumb-item:before' => 'border-width: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .pp-testimonials-wrap .pp-testimonials-thumb-item:before' => 'top: -{{SIZE}}{{UNIT}}',
				],
				'condition'             => [
					'slide_border'   => 'yes',
				],
			]
		);

		$this->add_control(
			'slide_border_radius',
			[
				'label'                 => esc_html__( 'Border Radius', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonial' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'                  => 'slide_box_shadow',
				'selector'              => '{{WRAPPER}} .pp-testimonial',
			]
		);

		$this->add_responsive_control(
			'slide_padding',
			[
				'label'                 => esc_html__( 'Inner Padding', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonial' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
				],
				'separator'             => 'before',
			]
		);

		$this->add_responsive_control(
			'slide_outer_padding',
			[
				'label'                 => esc_html__( 'Outer Padding', 'powerpack' ),
				'description'           => esc_html__( 'You must add outer padding for showing box shadow', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonial-slide' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
					'{{WRAPPER}} .pp-testimonials-wrap .pp-testimonials-thumb-item:before' => 'margin-top: -{{BOTTOM}}{{UNIT}}',
				],
				'condition'             => [
					'layout'    => [ 'carousel', 'slideshow' ],
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Content
	 */
	protected function register_style_content_controls() {

		/**
		 * Style Tab: Content
		 */
		$this->start_controls_section(
			'section_content_style',
			[
				'label'                 => esc_html__( 'Content', 'powerpack' ),
				'tab'                   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'content_bg_color',
			[
				'label'                 => esc_html__( 'Background Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonial-content, {{WRAPPER}} .pp-testimonial-content:after' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'content_text_color',
			[
				'label'                 => esc_html__( 'Text Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'global'                => [
					'default' => Global_Colors::COLOR_TEXT,
				],
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonial-content' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'                  => 'content_typography',
				'label'                 => esc_html__( 'Typography', 'powerpack' ),
				'global'                => [
					'default' => Global_Typography::TYPOGRAPHY_TEXT,
				],
				'selector'              => '{{WRAPPER}} .pp-testimonial-content',
			]
		);

		$this->add_control(
			'border',
			[
				'label'                 => esc_html__( 'Border', 'powerpack' ),
				'type'                  => Controls_Manager::SWITCHER,
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonial-content, {{WRAPPER}} .pp-testimonial-content:after' => 'border-style: solid',
				],
				'separator'             => 'before',
			]
		);

		$this->add_control(
			'border_color',
			[
				'label'                 => esc_html__( 'Border Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '#000',
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonial-content' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .pp-testimonial-content:after' => 'border-color: transparent {{VALUE}} {{VALUE}} transparent',
				],
				'condition'             => [
					'border'   => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'border_width',
			[
				'label'                 => esc_html__( 'Border Width', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'range'                 => [
					'px' => [
						'min' => 0,
						'max' => 20,
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonial-content, {{WRAPPER}} .pp-testimonial-content:after' => 'border-width: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .pp-testimonial-skin-1 .pp-testimonial-content:after' => 'margin-top: -{{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .pp-testimonial-skin-2 .pp-testimonial-content:after' => 'margin-bottom: -{{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .pp-testimonial-skin-3 .pp-testimonial-content:after' => 'margin-inline-start: -{{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .pp-testimonial-skin-4 .pp-testimonial-content:after' => 'margin-inline-end: -{{SIZE}}{{UNIT}}',
				],
				'condition'             => [
					'border'   => 'yes',
				],
			]
		);

		$this->add_control(
			'content_border_radius',
			[
				'label'                 => esc_html__( 'Border Radius', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonial-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'content_gap',
			[
				'label'                 => esc_html__( 'Gap', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => '',
					'unit' => 'px',
				],
				'range'                 => [
					'px' => [
						'max' => 100,
					],
				],
				'tablet_default'        => [
					'unit' => 'px',
				],
				'mobile_default'        => [
					'unit' => 'px',
				],
				'separator'             => 'before',
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonial-skin-1 .pp-testimonial-content, {{WRAPPER}} .pp-testimonial-skin-5 .pp-testimonial-content, {{WRAPPER}} .pp-testimonial-skin-6 .pp-testimonial-content, {{WRAPPER}} .pp-testimonial-skin-7 .pp-testimonial-content' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .pp-testimonial-skin-2 .pp-testimonial-content' => 'margin-top: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .pp-testimonial-skin-3 .pp-testimonial-content' => 'margin-inline-start: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .pp-testimonial-skin-4 .pp-testimonial-content' => 'margin-inline-end: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'content_text_alignment',
			[
				'label'                 => esc_html__( 'Text Alignment', 'powerpack' ),
				'type'                  => Controls_Manager::CHOOSE,
				'options'               => [
					'left'      => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center'    => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'     => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					],
					'justify'   => [
						'title' => esc_html__( 'Justified', 'powerpack' ),
						'icon'  => 'eicon-text-align-justify',
					],
				],
				'default'               => 'center',
				'separator'             => 'before',
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonial-content' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'details_h_alignment',
			[
				'label'                 => esc_html__( 'Name and Position Alignment', 'powerpack' ),
				'type'                  => Controls_Manager::CHOOSE,
				'toggle'                => false,
				'options'               => [
					'left'          => [
						'title'     => esc_html__( 'Left', 'powerpack' ),
						'icon'      => 'eicon-h-align-left',
					],
					'center'        => [
						'title'     => esc_html__( 'Center', 'powerpack' ),
						'icon'      => 'eicon-h-align-center',
					],
					'right'         => [
						'title'     => esc_html__( 'Right', 'powerpack' ),
						'icon'      => 'eicon-h-align-right',
					],
				],
				'default'               => 'center',
				'prefix_class'          => 'pp-testimonials-h-align-',
				'condition'             => [
					'skin'    => [ 'skin-1', 'skin-2', 'skin-5', 'skin-6', 'skin-7' ],
				],
			]
		);

		$this->add_control(
			'details_v_alignment',
			[
				'label'                 => esc_html__( 'Name and Position Alignment', 'powerpack' ),
				'type'                  => Controls_Manager::CHOOSE,
				'toggle'                => false,
				'default'               => 'middle',
				'options'               => [
					'top'          => [
						'title'    => esc_html__( 'Top', 'powerpack' ),
						'icon'     => 'eicon-v-align-top',
					],
					'middle'       => [
						'title'    => esc_html__( 'Center', 'powerpack' ),
						'icon'     => 'eicon-v-align-middle',
					],
					'bottom'       => [
						'title'    => esc_html__( 'Bottom', 'powerpack' ),
						'icon'     => 'eicon-v-align-bottom',
					],
				],
				'selectors_dictionary'  => [
					'top'          => 'flex-start',
					'middle'       => 'center',
					'bottom'       => 'flex-end',
				],
				'prefix_class'          => 'pp-testimonials-v-align-',
				'condition'             => [
					'skin'    => [ 'skin-3', 'skin-4' ],
				],
			]
		);

		$this->add_control(
			'image_v_alignment',
			[
				'label'                 => esc_html__( 'Image Alignment', 'powerpack' ),
				'type'                  => Controls_Manager::CHOOSE,
				'toggle'                => false,
				'default'               => 'middle',
				'options'               => [
					'top'          => [
						'title'    => esc_html__( 'Top', 'powerpack' ),
						'icon'     => 'eicon-v-align-top',
					],
					'middle'       => [
						'title'    => esc_html__( 'Center', 'powerpack' ),
						'icon'     => 'eicon-v-align-middle',
					],
					'bottom'       => [
						'title'    => esc_html__( 'Bottom', 'powerpack' ),
						'icon'     => 'eicon-v-align-bottom',
					],
				],
				'selectors_dictionary'  => [
					'top'          => 'flex-start',
					'middle'       => 'center',
					'bottom'       => 'flex-end',
				],
				'prefix_class'          => 'pp-testimonials-v-align-',
				'condition'             => [
					'skin'    => [ 'skin-5', 'skin-6' ],
				],
			]
		);

		$this->add_responsive_control(
			'content_padding',
			[
				'label'                 => esc_html__( 'Padding', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonial-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator'             => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'                  => 'content_box_shadow',
				'selector'              => '{{WRAPPER}} .pp-testimonial-content',
			]
		);

		$this->add_control(
			'name_style_heading',
			[
				'label'                 => esc_html__( 'Name', 'powerpack' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
			]
		);

		$this->add_control(
			'name_text_color',
			[
				'label'                 => esc_html__( 'Text Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'global'                => [
					'default' => Global_Colors::COLOR_TEXT,
				],
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonial-name' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'                  => 'name_typography',
				'label'                 => esc_html__( 'Typography', 'powerpack' ),
				'global'                => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector'              => '{{WRAPPER}} .pp-testimonial-name',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name'                  => 'name_text_shadow',
				'selector'              => '{{WRAPPER}} .pp-testimonial-name',
			]
		);

		$this->add_responsive_control(
			'name_gap',
			[
				'label'                 => esc_html__( 'Gap', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => '',
					'unit' => 'px',
				],
				'range'                 => [
					'px' => [
						'max' => 100,
					],
				],
				'tablet_default'        => [
					'unit' => 'px',
				],
				'mobile_default'        => [
					'unit' => 'px',
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonial-name' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'position_style_heading',
			[
				'label'                 => esc_html__( 'Position', 'powerpack' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
			]
		);

		$this->add_control(
			'position_text_color',
			[
				'label'                 => esc_html__( 'Text Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'global'                => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonial-position' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'                  => 'position_typography',
				'label'                 => esc_html__( 'Typography', 'powerpack' ),
				'global'                => [
					'default' => Global_Typography::TYPOGRAPHY_SECONDARY,
				],
				'selector'              => '{{WRAPPER}} .pp-testimonial-position',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name'                  => 'position_text_shadow',
				'selector'              => '{{WRAPPER}} .pp-testimonial-position',
			]
		);

		$this->add_responsive_control(
			'position_gap',
			[
				'label'                 => esc_html__( 'Gap', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => '',
					'unit' => 'px',
				],
				'range'                 => [
					'px' => [
						'max' => 100,
					],
				],
				'tablet_default'        => [
					'unit' => 'px',
				],
				'mobile_default'        => [
					'unit' => 'px',
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonial-position' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'quote_style_heading',
			[
				'label'                 => esc_html__( 'Quote', 'powerpack' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
				'condition'             => [
					'show_quote'    => '',
				],
			]
		);

		$this->add_control(
			'quote_color',
			[
				'label'                 => esc_html__( 'Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonial-text:before, {{WRAPPER}} .pp-testimonial-text:after' => 'color: {{VALUE}}',
				],
				'condition'             => [
					'show_quote'    => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'                  => 'quote_typography',
				'label'                 => esc_html__( 'Typography', 'powerpack' ),
				'selector'              => '{{WRAPPER}} .pp-testimonial-text:before, {{WRAPPER}} .pp-testimonial-text:after',
				'condition'             => [
					'show_quote'    => '',
				],
			]
		);

		$this->add_responsive_control(
			'quote_margin',
			[
				'label'                 => esc_html__( 'Margin', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'allowed_dimensions'    => 'vertical',
				'placeholder'           => [
					'top'      => '',
					'right'    => 'auto',
					'bottom'   => '',
					'left'     => 'auto',
				],
				'selectors'             => [
					'{{WRAPPER}}.pp-testimonials-quote-position-above .pp-testimonial-text:before' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'             => [
					'show_quote'        => '',
					'quote_position'    => [ 'above', 'before' ],
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Image
	 */
	protected function register_style_image_controls() {
		$this->start_controls_section(
			'section_image_style',
			[
				'label'                 => esc_html__( 'Image', 'powerpack' ),
				'tab'                   => Controls_Manager::TAB_STYLE,
				'condition'             => [
					'show_image'    => '',
				],
			]
		);

		$this->add_responsive_control(
			'image_size',
			[
				'label'                 => esc_html__( 'Size', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range'                 => [
					'px' => [
						'max' => 200,
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonial-image img' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}}.pp-testimonials-content-bubble.pp-testimonials-h-align-right .pp-testimonial-skin-1 .pp-testimonial-content:after, {{WRAPPER}}.pp-testimonials-content-bubble.pp-testimonials-h-align-right .pp-testimonial-skin-2 .pp-testimonial-content:after' => 'inset-inline-end: calc({{SIZE}}{{UNIT}}/2);',
					'{{WRAPPER}}.pp-testimonials-content-bubble.pp-testimonials-h-align-left .pp-testimonial-skin-1 .pp-testimonial-content:after, {{WRAPPER}}.pp-testimonials-content-bubble.pp-testimonials-h-align-left .pp-testimonial-skin-2 .pp-testimonial-content:after' => 'inset-inline-start: calc({{SIZE}}{{UNIT}}/2);',
				],
				'condition'             => [
					'show_image'    => '',
				],
			]
		);

		$this->add_responsive_control(
			'image_gap',
			[
				'label'                 => esc_html__( 'Gap', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => 10,
					'unit' => 'px',
				],
				'range'                 => [
					'px' => [
						'max' => 100,
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonials-image-stacked .pp-testimonial-image, {{WRAPPER}} .pp-testimonial-skin-7 .pp-testimonial-image' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .pp-testimonials-image-inline .pp-testimonial-image, {{WRAPPER}} .pp-testimonial-skin-5 .pp-testimonial-image, {{WRAPPER}} .pp-testimonial-skin-8 .pp-testimonial-image' => 'margin-inline-end: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}}.pp-testimonials-h-align-right .pp-testimonials-image-inline .pp-testimonial-image, {{WRAPPER}} .pp-testimonial-skin-6 .pp-testimonial-image' => 'margin-inline-start: {{SIZE}}{{UNIT}}; margin-inline-end: 0;',
				],
				'condition'             => [
					'show_image'    => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'                  => 'image_border',
				'label'                 => esc_html__( 'Border', 'powerpack' ),
				'placeholder'           => '1px',
				'default'               => '1px',
				'selector'              => '{{WRAPPER}} .pp-testimonial-image img',
				'condition'             => [
					'show_image'    => '',
				],
			]
		);

		$this->add_control(
			'image_border_radius',
			[
				'label'                 => esc_html__( 'Border Radius', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonial-image, {{WRAPPER}} .pp-testimonial-image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'             => [
					'show_image'    => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'                  => 'image_box_shadow',
				'selector'              => '{{WRAPPER}} .pp-testimonial-image img',
				'condition'             => [
					'show_image'    => '',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Rating
	 */
	protected function register_style_rating_controls() {
		$this->start_controls_section(
			'section_rating_style',
			[
				'label'                 => esc_html__( 'Rating', 'powerpack' ),
				'tab'                   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'star_style',
			[
				'label'                 => esc_html__( 'Icon', 'powerpack' ),
				'type'                  => Controls_Manager::SELECT,
				'options'               => [
					'star_fontawesome' => 'Font Awesome',
					'star_unicode' => 'Unicode',
				],
				'default'               => 'star_fontawesome',
				'render_type'           => 'template',
				'prefix_class'          => 'elementor--star-style-',
				'separator'             => 'before',
			]
		);

		$this->add_control(
			'unmarked_star_style',
			[
				'label'                 => esc_html__( 'Unmarked Style', 'powerpack' ),
				'type'                  => Controls_Manager::CHOOSE,
				'label_block'           => false,
				'options'               => [
					'solid' => [
						'title' => esc_html__( 'Solid', 'powerpack' ),
						'icon' => 'eicon-star',
					],
					'outline' => [
						'title' => esc_html__( 'Outline', 'powerpack' ),
						'icon' => 'eicon-star-o',
					],
				],
				'default'               => 'solid',
			]
		);

		$this->add_control(
			'star_size',
			[
				'label'                 => esc_html__( 'Size', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'range'                 => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonials' => '--e-rating-icon-font-size: {{SIZE}}{{UNIT}}',
				],
				'separator'             => 'before',
			]
		);

		$this->add_control(
			'star_space',
			[
				'label'                 => esc_html__( 'Spacing', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'range'                 => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .elementor-star-rating i:not(:last-of-type)' => 'margin-inline-end: {{SIZE}}{{UNIT}}',
					'{{WRAPPER}} .pp-testimonials .e-rating-wrapper' => '--e-rating-gap: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'stars_color',
			[
				'label'                 => esc_html__( 'Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonials' => '--e-rating-icon-marked-color: {{VALUE}}',
				],
				'separator'             => 'before',
			]
		);

		$this->add_control(
			'stars_unmarked_color',
			[
				'label'                 => esc_html__( 'Unmarked Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonials' => '--e-rating-icon-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Conditions under which the pagination dots are shown.
	 *
	 * Dots exist for the carousel layout, and for the slideshow layout only when
	 * the thumbnail navigation is not standing in for them.
	 *
	 * Elementor applies a section's own condition to the panel, not to whether the
	 * controls inside it count as active - so each control still carries this.
	 * Dropping them would start emitting their CSS and prefix classes on layouts
	 * that have no dots. Shared from here so the 39 lines exist once, not 14 times.
	 *
	 * @access protected
	 *
	 * @return array Elementor conditions array.
	 */
	protected function get_dots_conditions() {
		return [
			'relation' => 'or',
			'terms'    => [
				[
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'layout',
							'operator' => '==',
							'value'    => 'carousel',
						],
						[
							'name'     => 'dots',
							'operator' => '==',
							'value'    => 'yes',
						],
					],
				],
				[
					'relation' => 'and',
					'terms'    => [
						[
							'name'     => 'layout',
							'operator' => '==',
							'value'    => 'slideshow',
						],
						[
							'name'     => 'dots',
							'operator' => '==',
							'value'    => 'yes',
						],
						[
							'name'     => 'thumbnail_nav',
							'operator' => '!==',
							'value'    => 'yes',
						],
					],
				],
			],
		];
	}

	/**
	 * Condition under which the navigation arrows are shown.
	 *
	 * @access protected
	 *
	 * @return array Elementor condition array.
	 */
	protected function get_arrows_condition() {
		return [
			'layout' => [ 'carousel', 'slideshow' ],
			'arrows' => 'yes',
		];
	}

	/**
	 * Condition under which the thumbnail navigation is shown.
	 *
	 * @access protected
	 *
	 * @return array Elementor condition array.
	 */
	protected function get_thumbnail_nav_condition() {
		return [
			'layout'        => 'slideshow',
			'thumbnail_nav' => 'yes',
		];
	}

	/**
	 * Style Tab: Navigation Arrows
	 */
	protected function register_style_arrows_controls() {
		$this->start_controls_section(
			'section_arrows_style',
			[
				'label'                 => esc_html__( 'Navigation Arrows', 'powerpack' ),
				'tab'                   => Controls_Manager::TAB_STYLE,
				'condition'             => $this->get_arrows_condition(),
			]
		);

		$this->add_control(
			'select_arrow',
			[
				'label'                  => esc_html__( 'Choose Arrow', 'powerpack' ),
				'type'                   => Controls_Manager::ICONS,
				'fa4compatibility'       => 'arrow',
				'label_block'            => false,
				'default'                => [
					'value'   => 'fas fa-angle-right',
					'library' => 'fa-solid',
				],
				'skin'                   => 'inline',
				'exclude_inline_options' => 'svg',
				'recommended'            => [
					'fa-regular' => [
						'arrow-alt-circle-right',
						'caret-square-right',
						'hand-point-right',
					],
					'fa-solid'   => [
						'angle-right',
						'angle-double-right',
						'chevron-right',
						'chevron-circle-right',
						'arrow-right',
						'long-arrow-alt-right',
						'caret-right',
						'caret-square-right',
						'arrow-circle-right',
						'arrow-alt-circle-right',
						'toggle-right',
						'hand-point-right',
					],
				],
				'condition'             => $this->get_arrows_condition(),
			]
		);

		$this->add_responsive_control(
			'arrows_size',
			[
				'label'                 => esc_html__( 'Arrows Size', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'default'               => [ 'size' => '22' ],
				'range'                 => [
					'px' => [
						'min'   => 15,
						'max'   => 100,
						'step'  => 1,
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-slider-arrow' => 'font-size: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
				],
				'condition'             => $this->get_arrows_condition(),
			]
		);

		$this->add_responsive_control(
			'arrows_horitonal_position',
			[
				'label'                 => esc_html__( 'Horizontal Alignment', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range'                 => [
					'px' => [
						'min'   => -100,
						'max'   => 450,
						'step'  => 1,
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-arrow-next' => 'inset-inline-end: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .pp-arrow-prev' => 'inset-inline-start: {{SIZE}}{{UNIT}};',
				],
				'condition'             => $this->get_arrows_condition(),
			]
		);

		$this->add_responsive_control(
			'arrows_vertical_position',
			[
				'label'                 => esc_html__( 'Vertical Alignment', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range'                 => [
					'px' => [
						'min'   => -400,
						'max'   => 400,
						'step'  => 1,
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-arrow-next, {{WRAPPER}} .pp-arrow-prev' => 'top: {{SIZE}}{{UNIT}};',
				],
				'condition'             => $this->get_arrows_condition(),
			]
		);

		$this->start_controls_tabs( 'tabs_arrows_style' );

		$this->start_controls_tab(
			'tab_arrows_normal',
			[
				'label'                 => esc_html__( 'Normal', 'powerpack' ),
				'condition'             => $this->get_arrows_condition(),
			]
		);

		$this->add_control(
			'arrows_color_normal',
			[
				'label'                 => esc_html__( 'Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-slider-arrow' => 'color: {{VALUE}};',
				],
				'condition'             => $this->get_arrows_condition(),
			]
		);

		$this->add_control(
			'arrows_bg_color_normal',
			[
				'label'                 => esc_html__( 'Background Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-slider-arrow' => 'background-color: {{VALUE}};',
				],
				'condition'             => $this->get_arrows_condition(),
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'                  => 'arrows_border_normal',
				'label'                 => esc_html__( 'Border', 'powerpack' ),
				'placeholder'           => '1px',
				'default'               => '1px',
				'selector'              => '{{WRAPPER}} .pp-slider-arrow',
				'separator'             => 'before',
				'condition'             => $this->get_arrows_condition(),
			]
		);

		$this->add_control(
			'arrows_border_radius_normal',
			[
				'label'                 => esc_html__( 'Border Radius', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'             => [
					'{{WRAPPER}} .pp-slider-arrow' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'             => $this->get_arrows_condition(),
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_arrows_hover',
			[
				'label'                 => esc_html__( 'Hover', 'powerpack' ),
				'condition'             => $this->get_arrows_condition(),
			]
		);

		$this->add_control(
			'arrows_color_hover',
			[
				'label'                 => esc_html__( 'Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-slider-arrow:hover' => 'color: {{VALUE}};',
				],
				'condition'             => $this->get_arrows_condition(),
			]
		);

		$this->add_control(
			'arrows_bg_color_hover',
			[
				'label'                 => esc_html__( 'Background Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-slider-arrow:hover' => 'background-color: {{VALUE}};',
				],
				'condition'             => $this->get_arrows_condition(),
			]
		);

		$this->add_control(
			'arrows_border_color_hover',
			[
				'label'                 => esc_html__( 'Border Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-slider-arrow:hover' => 'border-color: {{VALUE}};',
				],
				'condition'             => $this->get_arrows_condition(),
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			'arrows_padding',
			[
				'label'                 => esc_html__( 'Padding', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'             => [
					'{{WRAPPER}} .pp-slider-arrow' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator'             => 'before',
				'condition'             => $this->get_arrows_condition(),
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Dots
	 */
	protected function register_style_dots_controls() {
		$this->start_controls_section(
			'section_dots_style',
			[
				'label'                 => esc_html__( 'Pagination: Dots', 'powerpack' ),
				'tab'                   => Controls_Manager::TAB_STYLE,
				'conditions'            => $this->get_dots_conditions(),
			]
		);

		$this->add_control(
			'dots_position',
			[
				'label'                 => esc_html__( 'Position', 'powerpack' ),
				'type'                  => Controls_Manager::SELECT,
				'options'               => [
					'inside'     => esc_html__( 'Inside', 'powerpack' ),
					'outside'    => esc_html__( 'Outside', 'powerpack' ),
				],
				'default'               => 'outside',
				'prefix_class'          => 'pp-swiper-slider-dots-',
				'conditions'            => $this->get_dots_conditions(),
			]
		);

		$this->add_responsive_control(
			'dots_size',
			[
				'label'                 => esc_html__( 'Size', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'range'                 => [
					'px' => [
						'min'   => 2,
						'max'   => 40,
						'step'  => 1,
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-swiper-slider .swiper-pagination-bullet' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}}',
				],
				'conditions'            => $this->get_dots_conditions(),
			]
		);

		$this->add_responsive_control(
			'dots_gap',
			[
				'label'                 => esc_html__( 'Gap Between Dots', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'range'                 => [
					'px' => [
						'min'   => 0,
						'max'   => 30,
						'step'  => 1,
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-swiper-slider .swiper-pagination-bullet' => 'margin-left: {{SIZE}}{{UNIT}}; margin-right: {{SIZE}}{{UNIT}}',
				],
				'conditions'            => $this->get_dots_conditions(),
			]
		);

		$this->add_responsive_control(
			'dots_top_spacing',
			[
				'label'                 => esc_html__( 'Top Spacing', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'range'                 => [
					'px' => [
						'min'   => 0,
						'max'   => 100,
						'step'  => 1,
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-swiper-slider .swiper-pagination' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
				'conditions'            => $this->get_dots_conditions(),
			]
		);

		$this->add_responsive_control(
			'dots_vertical_alignment',
			[
				'label'                 => esc_html__( 'Vertical Alignment', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'range'                 => [
					'px' => [
						'min'   => -100,
						'max'   => 100,
						'step'  => 1,
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-swiper-slider .swiper-pagination' => 'bottom: {{SIZE}}{{UNIT}};',
				],
				'conditions'            => $this->get_dots_conditions(),
			]
		);

		$this->start_controls_tabs( 'tabs_dots_style' );

		$this->start_controls_tab(
			'tab_dots_normal',
			[
				'label'                 => esc_html__( 'Normal', 'powerpack' ),
				'conditions'            => $this->get_dots_conditions(),
			]
		);

		$this->add_control(
			'dots_color_normal',
			[
				'label'                 => esc_html__( 'Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-swiper-slider .swiper-pagination-bullet' => 'background: {{VALUE}};',
				],
				'conditions'            => $this->get_dots_conditions(),
			]
		);

		$this->add_control(
			'active_dot_color_normal',
			[
				'label'                 => esc_html__( 'Active Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-swiper-slider .swiper-pagination-bullet-active' => 'background: {{VALUE}};',
				],
				'conditions'            => $this->get_dots_conditions(),
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'                  => 'dots_border_normal',
				'label'                 => esc_html__( 'Border', 'powerpack' ),
				'placeholder'           => '1px',
				'default'               => '1px',
				'selector'              => '{{WRAPPER}} .pp-swiper-slider .swiper-pagination-bullet',
				'conditions'            => $this->get_dots_conditions(),
			]
		);

		$this->add_control(
			'dots_border_radius_normal',
			[
				'label'                 => esc_html__( 'Border Radius', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'             => [
					'{{WRAPPER}} .pp-swiper-slider .swiper-pagination-bullet' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'conditions'            => $this->get_dots_conditions(),
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_dots_hover',
			[
				'label'                 => esc_html__( 'Hover', 'powerpack' ),
				'conditions'            => $this->get_dots_conditions(),
			]
		);

		$this->add_control(
			'dots_color_hover',
			[
				'label'                 => esc_html__( 'Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-swiper-slider .swiper-pagination-bullet:hover' => 'background: {{VALUE}};',
				],
				'conditions'            => $this->get_dots_conditions(),
			]
		);

		$this->add_control(
			'dots_border_color_hover',
			[
				'label'                 => esc_html__( 'Border Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-swiper-slider .swiper-pagination-bullet:hover' => 'border-color: {{VALUE}};',
				],
				'conditions'            => $this->get_dots_conditions(),
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Thumbnail Navigation
	 * -------------------------------------------------
	 */
	protected function register_style_thumbnail_nav_controls() {
		$this->start_controls_section(
			'section_thumbnail_nav_style',
			[
				'label'                 => esc_html__( 'Thumbnail Navigation', 'powerpack' ),
				'tab'                   => Controls_Manager::TAB_STYLE,
				'condition'             => $this->get_thumbnail_nav_condition(),
			]
		);

		$this->add_responsive_control(
			'thumbnail_nav_thumbs_size',
			[
				'label'                 => esc_html__( 'Thumbnails Size', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range'                 => [
					'px' => [
						'max' => 200,
					],
				],
				'tablet_default'    => [
					'unit' => 'px',
				],
				'mobile_default'    => [
					'unit' => 'px',
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonials-thumb-item img' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
				'condition'             => $this->get_thumbnail_nav_condition(),
			]
		);

		$this->add_responsive_control(
			'thumbnail_nav_thumbs_gap',
			[
				'label'                 => esc_html__( 'Thumbnails Gap', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => 10,
					'unit' => 'px',
				],
				'range'                 => [
					'px' => [
						'max' => 100,
					],
				],
				'tablet_default'        => [
					'unit' => 'px',
				],
				'mobile_default'        => [
					'unit' => 'px',
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonials-thumb-item-wrap' => 'padding-inline-start: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .pp-testimonials-thumb-pagination' => 'margin-inline-start: -{{SIZE}}{{UNIT}};',
				],
				'condition'             => $this->get_thumbnail_nav_condition(),
			]
		);

		$this->add_responsive_control(
			'thumbnail_nav_thumbs_arrow_size',
			[
				'label'                 => esc_html__( 'Arrow Size', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'range'                 => [
					'px' => [
						'max' => 200,
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonials-wrap .pp-testimonials-thumb-item:before' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
				'condition'             => $this->get_thumbnail_nav_condition(),
			]
		);

		$this->add_responsive_control(
			'thumbnail_nav_thumb_nav_spacing',
			[
				'label'                 => esc_html__( 'Top Spacing', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'               => [
					'size' => 30,
					'unit' => 'px',
				],
				'range'                 => [
					'px' => [
						'max' => 100,
					],
				],
				'tablet_default'        => [
					'unit' => 'px',
				],
				'mobile_default'        => [
					'unit' => 'px',
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonials-thumb-item' => 'padding-top: {{SIZE}}{{UNIT}};',
				],
				'condition'             => $this->get_thumbnail_nav_condition(),
			]
		);

		$this->start_controls_tabs( 'tabs_thumbnail_nav_style' );

		$this->start_controls_tab(
			'tab_thumbnail_nav_normal',
			[
				'label'                 => esc_html__( 'Normal', 'powerpack' ),
				'condition'             => $this->get_thumbnail_nav_condition(),
			]
		);

		$this->add_control(
			'thumbnail_nav_grayscale_normal',
			[
				'label'                 => esc_html__( 'Grayscale', 'powerpack' ),
				'type'                  => Controls_Manager::SWITCHER,
				'default'               => 'no',
				'label_on'              => esc_html__( 'Yes', 'powerpack' ),
				'label_off'             => esc_html__( 'No', 'powerpack' ),
				'return_value'          => 'yes',
				'condition'             => $this->get_thumbnail_nav_condition(),
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'                  => 'thumbnail_nav_border',
				'label'                 => esc_html__( 'Border', 'powerpack' ),
				'placeholder'           => '1px',
				'default'               => '1px',
				'selector'              => '{{WRAPPER}} .pp-testimonials-thumb-image',
				'condition'             => $this->get_thumbnail_nav_condition(),
			]
		);

		$this->add_control(
			'thumbnail_nav_border_radius',
			[
				'label'                 => esc_html__( 'Border Radius', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonials-thumb-image, {{WRAPPER}} .pp-testimonials-thumb-image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'             => $this->get_thumbnail_nav_condition(),
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'                  => 'thumbnail_nav_box_shadow',
				'selector'              => '{{WRAPPER}} .pp-testimonials-thumb-image',
				'condition'             => $this->get_thumbnail_nav_condition(),
			]
		);

		$this->add_control(
			'thumbnail_nav_scale_normal',
			[
				'label'                 => esc_html__( 'Scale', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'range'                 => [
					'px' => [
						'min'  => 0.5,
						'max'  => 2,
						'step' => 0.01,
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonials-thumb-image' => 'transform: scale({{SIZE}});',
				],
				'condition'             => $this->get_thumbnail_nav_condition(),
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_thumbnail_nav_hover',
			[
				'label'                 => esc_html__( 'Hover', 'powerpack' ),
				'condition'             => $this->get_thumbnail_nav_condition(),
			]
		);

		$this->add_control(
			'thumbnail_nav_grayscale_hover',
			[
				'label'                 => esc_html__( 'Grayscale', 'powerpack' ),
				'type'                  => Controls_Manager::SWITCHER,
				'default'               => 'no',
				'label_on'              => esc_html__( 'Yes', 'powerpack' ),
				'label_off'             => esc_html__( 'No', 'powerpack' ),
				'return_value'          => 'yes',
				'condition'             => $this->get_thumbnail_nav_condition(),
			]
		);

		$this->add_control(
			'thumbnail_nav_border_color_hover',
			[
				'label'                 => esc_html__( 'Border Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonials-thumb-image:hover' => 'border-color: {{VALUE}}',
				],
				'condition'             => $this->get_thumbnail_nav_condition(),
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'                  => 'thumbnail_nav_box_shadow_hover',
				'selector'              => '{{WRAPPER}} .pp-testimonials-thumb-image:hover',
				'condition'             => $this->get_thumbnail_nav_condition(),
			]
		);

		$this->add_control(
			'thumbnail_nav_scale_hover',
			[
				'label'                 => esc_html__( 'Scale', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'range'                 => [
					'px' => [
						'min'  => 0.5,
						'max'  => 2,
						'step' => 0.01,
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-testimonials-thumb-image:hover' => 'transform: scale({{SIZE}});',
				],
				'condition'             => $this->get_thumbnail_nav_condition(),
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_thumbnail_nav_active',
			[
				'label'                 => esc_html__( 'Active', 'powerpack' ),
				'condition'             => $this->get_thumbnail_nav_condition(),
			]
		);

		$this->add_control(
			'thumbnail_nav_grayscale_active',
			[
				'label'                 => esc_html__( 'Grayscale', 'powerpack' ),
				'type'                  => Controls_Manager::SWITCHER,
				'default'               => 'no',
				'label_on'              => esc_html__( 'Yes', 'powerpack' ),
				'label_off'             => esc_html__( 'No', 'powerpack' ),
				'return_value'          => 'yes',
				'condition'             => $this->get_thumbnail_nav_condition(),
			]
		);

		$this->add_control(
			'thumbnail_nav_border_color_active',
			[
				'label'                 => esc_html__( 'Border Color', 'powerpack' ),
				'type'                  => Controls_Manager::COLOR,
				'default'               => '',
				'selectors'             => [
					'{{WRAPPER}} .pp-active-slide .pp-testimonials-thumb-image' => 'border-color: {{VALUE}}',
				],
				'condition'             => $this->get_thumbnail_nav_condition(),
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'                  => 'thumbnail_nav_box_shadow_active',
				'selector'              => '{{WRAPPER}} .pp-active-slide .pp-testimonials-thumb-image',
				'condition'             => $this->get_thumbnail_nav_condition(),
			]
		);

		$this->add_control(
			'thumbnail_nav_scale_active',
			[
				'label'                 => esc_html__( 'Scale', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'range'                 => [
					'px' => [
						'min'  => 0.5,
						'max'  => 2,
						'step' => 0.01,
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-active-slide .pp-testimonials-thumb-image' => 'transform: scale({{SIZE}});',
				],
				'condition'             => $this->get_thumbnail_nav_condition(),
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Read a slider control's size in pixels.
	 *
	 * Swiper 8 takes spaceBetween and the slide offsets as plain numbers of pixels.
	 * A value saved in em or rem cannot be resolved server side, and absint() would
	 * quietly turn 1.5em into a 1px gap, so anything that is not px falls back to
	 * the control's own default instead.
	 *
	 * @access protected
	 *
	 * @param array $value   Slider control value, with `size` and `unit` keys.
	 * @param int   $default Fallback used when the value is empty or not in pixels.
	 *
	 * @return int Size in pixels.
	 */
	protected function get_slider_px_size( $value, $default = 0 ) {
		if ( ! is_array( $value ) || ! isset( $value['size'] ) || '' === $value['size'] ) {
			return $default;
		}

		$unit = empty( $value['unit'] ) ? 'px' : $value['unit'];

		if ( 'px' !== $unit ) {
			return $default;
		}

		return (int) round( (float) $value['size'] );
	}

	/**
	 * Slider Settings.
	 *
	 * @access public
	 */
	public function slider_settings() {
		$settings = $this->get_settings();

		if ( 'carousel' === $settings['layout'] ) {
			$slides_per_view         = $settings['slides_per_view'] ? absint( $settings['slides_per_view'] ) : 3;
			$slides_per_view_tablet  = ! empty( $settings['slides_per_view_tablet'] ) ? absint( $settings['slides_per_view_tablet'] ) : 2;
			$slides_per_view_mobile  = ! empty( $settings['slides_per_view_mobile'] ) ? absint( $settings['slides_per_view_mobile'] ) : 1;
			$slides_to_scroll        = $settings['slides_to_scroll'] ? absint( $settings['slides_to_scroll'] ) : 1;
			$slides_to_scroll_tablet = ! empty( $settings['slides_to_scroll_tablet'] ) ? absint( $settings['slides_to_scroll_tablet'] ) : 1;
			$slides_to_scroll_mobile = ! empty( $settings['slides_to_scroll_mobile'] ) ? absint( $settings['slides_to_scroll_mobile'] ) : 1;
		} else {
			$slides_per_view = 1;
			$slides_per_view_tablet = 1;
			$slides_per_view_mobile = 1;
			$slides_to_scroll = 1;
			$slides_to_scroll_tablet = 1;
			$slides_to_scroll_mobile = 1;
		}

		$space_between        = $this->get_slider_px_size( $settings['column_spacing'], 20 );
		$space_between_tablet = ! empty( $settings['column_spacing_tablet']['size'] ) ? $this->get_slider_px_size( $settings['column_spacing_tablet'], $space_between ) : $space_between;
		$space_between_mobile = ! empty( $settings['column_spacing_mobile']['size'] ) ? $this->get_slider_px_size( $settings['column_spacing_mobile'], $space_between ) : $space_between;

		$slider_options = [
			'slides_per_view'  => $slides_per_view,
			'slides_to_scroll' => $slides_to_scroll,
			'space_between'    => $space_between,
			'autoplay'         => ( 'yes' === $settings['autoplay'] ),
			'speed'            => ( $settings['animation_speed'] ) ? $settings['animation_speed'] : 600,
			'fade'             => ( 'fade' === $settings['effect'] && 'slideshow' === $settings['layout'] ),
			'vertical'         => ( 'vertical' === $settings['orientation'] ),
			'arrows'           => ( 'yes' === $settings['arrows'] ),
			'loop'             => ( 'yes' === $settings['infinite_loop'] ),
			'rtl'              => is_rtl(),
		];

		if ( 'yes' === $settings['autoplay'] ) {
			if ( $settings['autoplay_speed'] ) {
				$slider_options['autoplay_speed'] = $settings['autoplay_speed'];
			}

			$slider_options['pause_on_hover']       = ( 'yes' === $settings['pause_on_hover'] );
			$slider_options['pause_on_interaction'] = ( 'yes' === $settings['pause_on_interaction'] );
		}

		if ( 'yes' === $settings['center_mode'] ) {
			$center_mode = true;
			$center_padding        = $this->get_slider_px_size( $settings['center_padding'] ) . 'px';
			$center_padding_tablet = $this->get_slider_px_size( $settings['center_padding_tablet'] ) . 'px';
			$center_padding_mobile = $this->get_slider_px_size( $settings['center_padding_mobile'] ) . 'px';

			$slider_options['center_mode'] = $center_mode;
			$slider_options['center_padding'] = $center_padding;
		} else {
			$center_mode = false;
			$center_padding_tablet = '0px';
			$center_padding_mobile = '0px';
		}

		if ( 'carousel' === $settings['layout'] && 'yes' === $settings['dots'] ) {
			$slider_options['dots'] = true;
		} elseif ( 'slideshow' === $settings['layout'] && 'yes' === $settings['dots'] && 'yes' !== $settings['thumbnail_nav'] ) {
			$slider_options['dots'] = true;
		} else {
			$slider_options['dots'] = false;
		}

		$breakpoints = PP_Helper::elementor()->breakpoints->get_active_breakpoints();

		foreach ( $breakpoints as $device => $breakpoint ) {
			if ( in_array( $device, [ 'mobile', 'tablet', 'desktop' ] ) ) {
				switch ( $device ) {
					case 'desktop':
						$slider_options['slides_per_view'] = absint( $slides_per_view );
						$slider_options['slides_to_scroll'] = absint( $slides_to_scroll );
						$slider_options['space_between'] = $space_between;

						if ( $center_mode ) {
							$slider_options['center_padding'] = $center_padding;
						}
						break;
					case 'tablet':
						$slider_options['slides_per_view_tablet'] = absint( $slides_per_view_tablet );
						$slider_options['slides_to_scroll_tablet'] = absint( $slides_to_scroll_tablet );
						$slider_options['space_between_tablet'] = $space_between_tablet;

						if ( $center_mode ) {
							$slider_options['center_padding_tablet'] = $center_padding_tablet;
						}
						break;
					case 'mobile':
						$slider_options['slides_per_view_mobile'] = absint( $slides_per_view_mobile );
						$slider_options['slides_to_scroll_mobile'] = absint( $slides_to_scroll_mobile );
						$slider_options['space_between_mobile'] = $space_between_mobile;

						if ( $center_mode ) {
							$slider_options['center_padding_mobile'] = $center_padding_mobile;
						}
						break;
				}
			} else {
				if ( ! empty( $settings[ 'slides_per_view_' . $device ] ) ) {
					$slider_options[ 'slides_per_view_' . $device ] = absint( $settings[ 'slides_per_view_' . $device ] );
				}

				if ( ! empty( $settings[ 'slides_to_scroll_' . $device ] ) ) {
					$slider_options[ 'slides_to_scroll_' . $device ] = absint( $settings[ 'slides_to_scroll_' . $device ] );
				}

				if ( ! empty( $settings[ 'column_spacing_' . $device ]['size'] ) ) {
					$slider_options[ 'space_between_' . $device ] = $this->get_slider_px_size( $settings[ 'column_spacing_' . $device ], $space_between );
				}

				if ( $center_mode ) {
					if ( ! empty( $settings[ 'center_padding_' . $device ]['size'] ) ) {
						$slider_options[ 'center_padding_' . $device ] = $this->get_slider_px_size( $settings[ 'center_padding_' . $device ] ) . 'px';
					}
				}
			}
		}

		/*
		 * Swiper 8 registers its a11y module with `enabled: true`, so the arrows and
		 * dots are already named and operable, but in English, from Swiper's own
		 * defaults. This flag is what makes the script hand the module the localised
		 * strings from PP_Helper::get_carousel_a11y_strings(), and it carries the
		 * keyboard module along with it; that module listens on the document, so
		 * enabling it unconditionally would let one arrow key move every slider on
		 * the page.
		 */
		$slider_options['a11y'] = 'yes';

		$this->add_render_attribute(
			'testimonials-wrap',
			[
				'data-slider-settings' => wp_json_encode( $slider_options ),
			]
		);
	}

	/**
	 * Render the slider navigation arrows.
	 *
	 * Handles the Font Awesome 4 to 5 migration so instances saved before the
	 * migration keep the arrow icon they were saved with.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function render_arrows() {
		PP_Helper::render_arrows(
			$this,
			[
				'classes' => [ 'pp-arrow-{dir}', 'pp-arrow-{dir}-{id}' ],
			]
		);
	}

	/**
	 * Whether the item has a visible image.
	 *
	 * @access protected
	 *
	 * @param array $item Repeater item settings.
	 *
	 * @return bool
	 */
	protected function has_item_image( $item ) {
		$settings = $this->get_settings_for_display();

		return '' === $settings['show_image'] && ! empty( $item['image']['url'] );
	}

	/**
	 * Whether the item has any author details to show.
	 *
	 * Mirrors the early returns in render_name(), render_position() and
	 * render_stars() so an empty footer is never emitted.
	 *
	 * @access protected
	 *
	 * @param array $item        Repeater item settings.
	 * @param bool  $with_rating Whether the rating counts towards the footer content.
	 *
	 * @return bool
	 */
	protected function has_item_cite( $item, $with_rating = true ) {
		if ( '' !== $item['name'] || '' !== $item['position'] ) {
			return true;
		}

		return $with_rating && ! empty( $item['rating'] );
	}

	/**
	 * Render the testimonial footer.
	 *
	 * Outputs the image, name, position and rating - in the sequence set by the
	 * Order section when the image position is stacked, otherwise in the
	 * default image-then-details order.
	 *
	 * @access protected
	 *
	 * @param array $item  Repeater item settings.
	 * @param int   $index Repeater item index.
	 *
	 * @return void
	 */
	protected function render_testimonial_footer( $item, $index ) {
		$settings = $this->get_settings_for_display();

		if ( ! $this->has_item_image( $item ) && ! $this->has_item_cite( $item ) ) {
			return;
		}
		?>
		<div class="pp-testimonial-footer">
			<div class="pp-testimonial-footer-inner">
				<?php
				if ( 'stacked' === $settings['image_position'] ) {
					$elements_order = [];

					/*
					 * Cast: clearing one of the order fields leaves an empty string in the
					 * settings, and a strict comparison against it never matched, so that
					 * element silently vanished from the stacked layout. (int) '' is 0,
					 * which the loop below skips, so fall back to the control's default.
					 */
					$elements_order['image']    = (int) $settings['image_order'] ? (int) $settings['image_order'] : 1;
					$elements_order['name']     = (int) $settings['name_order'] ? (int) $settings['name_order'] : 2;
					$elements_order['position'] = (int) $settings['position_order'] ? (int) $settings['position_order'] : 3;
					$elements_order['rating']   = (int) $settings['rating_order'] ? (int) $settings['rating_order'] : 4;

					// The four order controls are all min 1, so position 0 never matches.
					for ( $i = 1; $i <= 4; $i++ ) {
						if ( $i === $elements_order['image'] ) {
							$this->render_image( $item, $index );
						}

						if ( $i === $elements_order['name'] ) {
							$this->render_name( $item, $index );
						}

						if ( $i === $elements_order['position'] ) {
							$this->render_position( $item, $index );
						}

						if ( $i === $elements_order['rating'] ) {
							$this->render_stars( $item, $settings );
						}
					}
				} else {
					$this->render_image( $item, $index );
					?>
					<div class="pp-testimonial-cite">
						<?php
							$this->render_name( $item, $index );

							$this->render_position( $item, $index );

							$this->render_stars( $item, $settings );
						?>
					</div>
					<?php
				} ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Render a single testimonial using the default skin.
	 *
	 * @access protected
	 *
	 * @param array $item  Repeater item settings.
	 * @param int   $index Repeater item index.
	 *
	 * @return void
	 */
	protected function render_testimonial_default( $item, $index ) {
		?>
		<div class="pp-testimonial-content">
			<?php
				$this->render_description( $item );
			?>
		</div>
		<?php
		$this->render_testimonial_footer( $item, $index );
	}

	/**
	 * Render a single testimonial using skin 2.
	 *
	 * @access protected
	 *
	 * @param array $item  Repeater item settings.
	 * @param int   $index Repeater item index.
	 *
	 * @return void
	 */
	protected function render_testimonial_skin_2( $item, $index ) {
		$this->render_testimonial_footer( $item, $index );
		?>
		<div class="pp-testimonial-content">
			<?php
				$this->render_description( $item );
			?>
		</div>
		<?php
	}

	/**
	 * Render a single testimonial using skin 3.
	 *
	 * @access protected
	 *
	 * @param array $item  Repeater item settings.
	 * @param int   $index Repeater item index.
	 *
	 * @return void
	 */
	protected function render_testimonial_skin_3( $item, $index ) {
		$this->render_testimonial_footer( $item, $index );
		?>
		<div class="pp-testimonial-content">
			<?php
				$this->render_description( $item );
			?>
		</div>
		<?php
	}

	/**
	 * Render a single testimonial using skin 4.
	 *
	 * @access protected
	 *
	 * @param array $item  Repeater item settings.
	 * @param int   $index Repeater item index.
	 *
	 * @return void
	 */
	protected function render_testimonial_skin_4( $item, $index ) {
		$this->render_testimonial_footer( $item, $index );
		?>
		<div class="pp-testimonial-content">
			<?php
				$this->render_description( $item );
			?>
		</div>
		<?php
	}

	/**
	 * Render a single testimonial using skins 5, 6 and 7.
	 *
	 * @access protected
	 *
	 * @param array $item  Repeater item settings.
	 * @param int   $index Repeater item index.
	 *
	 * @return void
	 */
	protected function render_testimonial_skin_5( $item, $index ) {
		$settings = $this->get_settings_for_display();

		$this->render_image( $item, $index );
		?>
		<div class="pp-testimonial-content-wrap">
			<div class="pp-testimonial-content">
				<?php
					$this->render_description( $item );
				?>
			</div>
			<?php if ( $this->has_item_cite( $item ) ) : ?>
			<div class="pp-testimonial-footer">
				<div class="pp-testimonial-footer-inner">
					<div class="pp-testimonial-cite">
						<?php
							$this->render_name( $item, $index );

							$this->render_position( $item, $index );

							$this->render_stars( $item, $settings );
						?>
					</div>
				</div>
			</div>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Render a single testimonial using skin 8.
	 *
	 * @access protected
	 *
	 * @param array $item  Repeater item settings.
	 * @param int   $index Repeater item index.
	 *
	 * @return void
	 */
	protected function render_testimonial_skin_8( $item, $index ) {
		$settings = $this->get_settings_for_display();
		?>
		<div class="pp-testimonial-content">
			<?php $this->render_image( $item, $index ); ?>
			<div class="pp-testimonial-content-wrap">
				<?php
					$this->render_description( $item );

					$this->render_stars( $item, $settings );
				?>
			</div>
		</div>
		<?php if ( $this->has_item_cite( $item, false ) ) : ?>
		<div class="pp-testimonial-footer">
			<div class="pp-testimonial-footer-inner">
				<div class="pp-testimonial-cite">
					<?php
						$this->render_name( $item, $index );

						$this->render_position( $item, $index );
					?>
				</div>
			</div>
		</div>
		<?php endif; ?>
		<?php
	}

	/**
	 * Render the thumbnail navigation for the slideshow layout.
	 *
	 * Only repeater items that have an image produce a thumbnail.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function render_thumbnails() {
		$settings   = $this->get_settings_for_display();
		$thumbnails = $settings['testimonials'];
		$thumb_size = $settings['thumbnail_size'];
		$total      = count( $thumbnails );

		$registered_sizes   = get_intermediate_image_sizes();
		$registered_sizes[] = 'full';
		?>
		<div class="pp-testimonials-thumb-pagination" role="group" aria-label="<?php echo esc_attr__( 'Choose a testimonial', 'powerpack' ); ?>">
			<?php
			foreach ( $thumbnails as $index => $item ) {
				if ( $item['image']['url'] ) {
					/*
					 * alt is empty on purpose: the control already carries "Go to slide N",
					 * so the attachment's alt would be announced twice. That custom alt is
					 * why this calls wp_get_attachment_image() directly rather than
					 * get_attachment_image_html(), which accepts no attributes.
					 */
					if ( $item['image']['id'] && in_array( $thumb_size, $registered_sizes, true ) ) {
						$image_html = wp_get_attachment_image( $item['image']['id'], $thumb_size, false, [ 'alt' => '' ] );
					} else {
						// Custom dimensions or an external URL: no registered size to look up.
						$image_url = $item['image']['id']
							? Group_Control_Image_Size::get_attachment_image_src( $item['image']['id'], 'thumbnail', $settings )
							: $item['image']['url'];

						$image_html = $image_url
							? sprintf( '<img src="%s" alt="" loading="lazy" decoding="async" />', esc_url( $image_url ) )
							: '';
					}

					if ( ! $image_html ) {
						continue;
					}

					$thumb_key = $this->get_repeater_setting_key( 'thumb', 'testimonials', $index );

					if ( $item['name'] ) {
						$thumb_label = sprintf(
							/* translators: 1: slide number, 2: total slides, 3: name of the person quoted */
							esc_html__( 'Go to slide %1$d of %2$d: %3$s', 'powerpack' ),
							$index + 1,
							$total,
							wp_strip_all_tags( $item['name'] )
						);
					} else {
						$thumb_label = sprintf(
							/* translators: 1: slide number, 2: total slides */
							esc_html__( 'Go to slide %1$d of %2$d', 'powerpack' ),
							$index + 1,
							$total
						);
					}

					$this->add_render_attribute(
						$thumb_key,
						[
							'class'            => [ 'pp-testimonials-thumb-item-wrap', 'pp-grid-item-wrap' ],
							/*
							 * div[role=button] rather than a native <button>: themes style bare
							 * button rules at a specificity the widget's own colour controls
							 * cannot beat. The script wires Enter and Space by hand.
							 */
							'role'             => 'button',
							'tabindex'         => '0',
							'aria-label'       => $thumb_label,
							'aria-current'     => 'false',
							/*
							 * A testimonial with no image renders no thumbnail, which shifts
							 * the DOM position of every thumbnail after it. The script needs
							 * the real slide index, not the position in this list.
							 */
							'data-slide-index' => $index,
						]
					);
					?>
					<div <?php $this->print_render_attribute_string( $thumb_key ); ?>>
						<div class="pp-grid-item pp-testimonials-thumb-item">
							<div class="pp-testimonials-thumb-image">
								<?php
								// Not wp_kses_post(): it would strip srcset, sizes and decoding.
								echo $image_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								?>
							</div>
						</div>
					</div>
					<?php
				}
			}
			?>
		</div>
		<?php
	}

	/**
	 * Render the testimonial image, optionally wrapped in the item link.
	 *
	 * @access protected
	 *
	 * @param array $item  Repeater item settings.
	 * @param int   $index Repeater item index.
	 *
	 * @return void
	 */
	protected function render_image( $item, $index ) {
		$settings = $this->get_settings_for_display();

		if ( ! $this->has_item_image( $item ) ) {
			return;
		}

		$link_key = $this->get_repeater_setting_key( 'image_link', 'testimonials', $index );

		if ( ! empty( $item['link']['url'] ) ) {
			$this->add_link_attributes( $link_key, $item['link'] );
		}

		/*
		 * get_attachment_image_html() routes attachments through
		 * wp_get_attachment_image(), which restores the srcset, sizes, intrinsic
		 * width/height and loading="lazy" that the hand-built <img> threw away -
		 * the avatar renders at 50px but the tag used to request the full-size
		 * original. It still falls back to a plain tag for custom dimensions and
		 * external URLs.
		 */
		$image_html = Group_Control_Image_Size::get_attachment_image_html(
			array_merge( $settings, [ 'image' => $item['image'] ] ),
			'thumbnail',
			'image'
		);

		if ( ! $image_html ) {
			return;
		}

		if ( ! empty( $item['link']['url'] ) ) {
			/*
			 * The name is announced right below, so an unlinked photo is decorative.
			 * A linked one has to carry the name, or the link is announced with no
			 * accessible name at all.
			 */
			if ( '' === Control_Media::get_image_alt( $item['image'] ) && '' !== $item['name'] ) {
				$this->add_render_attribute( $link_key, 'aria-label', wp_strip_all_tags( $item['name'] ) );
			}

			$image_html = '<a ' . $this->get_render_attribute_string( $link_key ) . '>' . $image_html . $this->get_new_tab_notice( $item['link'] ) . '</a>';
		}
		?>
		<div class="pp-testimonial-image">
			<?php
			/*
			 * Deliberately not wp_kses_post(): its img allowlist has no srcset,
			 * sizes or decoding, so it would strip the attributes this exists for.
			 * Both branches of get_attachment_image_html() already escape.
			 */
			echo $image_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			?>
		</div>
		<?php
	}

	/**
	 * Render the testimonial author name.
	 *
	 * @access protected
	 *
	 * @param array $item  Repeater item settings.
	 * @param int   $index Repeater item index.
	 *
	 * @return void
	 */
	protected function render_name( $item, $index ) {
		if ( '' === $item['name'] ) {
			return;
		}

		$member_key = $this->get_repeater_setting_key( 'name', 'testimonials', $index );
		$link_key = $this->get_repeater_setting_key( 'name_link', 'testimonials', $index );

		if ( ! empty( $item['link']['url'] ) ) {
			$this->add_link_attributes( $link_key, $item['link'] );
		}

		$this->add_render_attribute( $member_key, 'class', 'pp-testimonial-name' );

		$name_html_tag = PP_Helper::validate_html_tag( $this->get_settings_for_display( 'name_html_tag' ) );

		if ( ! empty( $item['link']['url'] ) ) :
			?>
			<<?php echo esc_html( $name_html_tag ); ?> <?php $this->print_render_attribute_string( $member_key ); ?>><a <?php $this->print_render_attribute_string( $link_key ); ?>><?php echo wp_kses_post( $item['name'] ); ?><?php echo wp_kses_post( $this->get_new_tab_notice( $item['link'] ) ); ?></a></<?php echo esc_html( $name_html_tag ); ?>>
			<?php
		else :
			?>
			<<?php echo esc_html( $name_html_tag ); ?> <?php $this->print_render_attribute_string( $member_key ); ?>><?php echo wp_kses_post( $item['name'] ); ?></<?php echo esc_html( $name_html_tag ); ?>>
			<?php
		endif;
	}

	/**
	 * Render the testimonial author position.
	 *
	 * @access protected
	 *
	 * @param array $item  Repeater item settings.
	 * @param int   $index Repeater item index.
	 *
	 * @return void
	 */
	protected function render_position( $item, $index ) {
		if ( '' === $item['position'] ) {
			return;
		}

		$position_key = $this->get_repeater_setting_key( 'position', 'testimonials', $index );
		$link_key = $this->get_repeater_setting_key( 'position_link', 'testimonials', $index );

		if ( ! empty( $item['link']['url'] ) ) {
			$this->add_link_attributes( $link_key, $item['link'] );
		}

		$this->add_render_attribute( $position_key, 'class', 'pp-testimonial-position' );

		if ( ! empty( $item['link']['url'] ) ) :
			?>
			<a <?php $this->print_render_attribute_string( $position_key ); ?> <?php $this->print_render_attribute_string( $link_key ); ?>><?php echo wp_kses_post( $item['position'] ); ?><?php echo wp_kses_post( $this->get_new_tab_notice( $item['link'] ) ); ?></a>
			<?php
		else :
			?>
			<div <?php $this->print_render_attribute_string( $position_key ); ?>><?php echo wp_kses_post( $item['position'] ); ?></div>
			<?php
		endif;
	}

	/**
	 * Render the testimonial content.
	 *
	 * @access protected
	 *
	 * @param array $item Repeater item settings.
	 *
	 * @return void
	 */
	protected function render_description( $item ) {
		if ( '' === $item['content'] ) {
			return;
		}
		?>
		<div class="pp-testimonial-text">
			<?php echo $this->parse_text_editor( $item['content'] ); //phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</div>
		<?php
	}

	/**
	 * Get the filled width of a single rating icon.
	 *
	 * @access protected
	 *
	 * @param int   $icon_index   Position of the icon within the rating, starting at 1.
	 * @param float $rating_value The rating value.
	 *
	 * @return string Width as a CSS percentage.
	 */
	protected function get_icon_marked_width( $icon_index, $rating_value ): string {
		$width = '0%';

		if ( $rating_value >= $icon_index ) {
			$width = '100%';
		} elseif ( intval( ceil( $rating_value ) ) === $icon_index ) {
			$width = ( $rating_value - ( $icon_index - 1 ) ) * 100 . '%';
		}

		return $width;
	}

	/**
	 * Get the HTML markup for star rating icons.
	 *
	 * @access protected
	 *
	 * @param float $rating The rating value.
	 *
	 * @return string HTML output of the icon markup.
	 */
	protected function get_icon_markup( $rating ): string {
		$settings     = $this->get_settings_for_display();
		$rating_scale = 5;

		$icon_marked = [
			'value'   => 'eicon-star',
			'library' => 'eicons',
		];

		// Cap rating to 5.
		$rating         = min( (float) $rating, $rating_scale );
		$floored_rating = (int) $rating;

		ob_start();

		for ( $index = 1; $index <= $rating_scale; $index++ ) {
			// Default unmarked icon.
			$icon_unmarked = [
				'value'   => 'eicon-star',
				'library' => 'eicons',
			];

			// Modify unmarked icon based on style and rating.
			if ( 'outline' === $settings['unmarked_star_style'] ) {
				$icon_unmarked['value'] = 'eicon-star-o';

				if ( $index <= $floored_rating ) {
					$icon_unmarked['value'] = 'eicon-star';
				} elseif ( $index === $floored_rating + 1 && $rating !== $floored_rating ) {
					// Keep as half (or slightly unfilled).
					$icon_unmarked['value'] = 'eicon-star-o';
				}
			}

			$icon_marked_width = $this->get_icon_marked_width( $index, $rating );
			?>
			<div class="e-icon">
				<div class="e-icon-wrapper e-icon-marked" style="--e-rating-icon-marked-width: <?php echo esc_attr( $icon_marked_width ); ?>;">
					<?php echo Icons_Manager::try_get_icon_html( $icon_marked, [ 'aria-hidden' => 'true' ] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
				<div class="e-icon-wrapper e-icon-unmarked">
					<?php echo Icons_Manager::try_get_icon_html( $icon_unmarked, [ 'aria-hidden' => 'true' ] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
			</div>
			<?php
		}

		return ob_get_clean();
	}

	/**
	 * Render the star rating for a testimonial.
	 *
	 * @access protected
	 *
	 * @param array $item     Repeater item settings.
	 * @param array $settings Widget settings.
	 *
	 * @return void
	 */
	protected function render_stars( $item, $settings ) {
		if ( ! empty( $item['rating'] ) ) {
			$rating_value = (float) $item['rating'];

			/*
			 * The rating is a NUMBER control, but WPML exposes it to translators as a
			 * text field. A value typed in localised digits casts to 0.0, which would
			 * otherwise render five empty stars - showing nothing is the better wrong
			 * answer. Ratings of 0 are excluded by the ! empty() above either way.
			 */
			if ( $rating_value <= 0 ) {
				return;
			}

			$rating_value = min( $rating_value, 5 );

			/*
			 * The icons are all aria-hidden, so the rating only reaches assistive
			 * technology through this label on the wrapper.
			 */
			$rating_label = sprintf(
				/* translators: 1: rating value, 2: highest possible rating. */
				__( 'Rated %1$s out of %2$s', 'powerpack' ),
				number_format_i18n( $rating_value, ( floor( $rating_value ) === $rating_value ) ? 0 : 1 ),
				number_format_i18n( 5 )
			);

			$rating_attrs = ' role="img" aria-label="' . esc_attr( $rating_label ) . '"';

			if ( 'star_fontawesome' === $settings['star_style'] ) {
				echo '<div class="e-rating-wrapper"' . $rating_attrs . '>' . $this->get_icon_markup( $rating_value ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Icons_Manager markup, label escaped above.
			} elseif ( 'star_unicode' === $settings['star_style'] ) {
				$floored_rating = (int) $rating_value;
				$stars_html = '';
				$icon = '&#9733;';

				if ( 'outline' === $settings['unmarked_star_style'] ) {
					$icon = '&#9734;';
				}

				for ( $stars = 1; $stars <= 5; $stars++ ) {
					if ( $stars <= $floored_rating ) {
						$stars_html .= '<i class="elementor-star-full" aria-hidden="true">' . $icon . '</i>';
					} elseif ( $floored_rating + 1 === $stars && $rating_value > $floored_rating ) {
						$stars_html .= '<i class="elementor-star-' . ( $rating_value - $floored_rating ) * 10 . '" aria-hidden="true">' . $icon . '</i>';
					} else {
						$stars_html .= '<i class="elementor-star-empty" aria-hidden="true">' . $icon . '</i>';
					}
				}

				echo '<div class="elementor-star-rating"' . $rating_attrs . '>' . wp_kses_post( $stars_html ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $rating_attrs is escaped above.
			}
		}
	}

	/**
	 * Render testimonials widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'testimonials-wrap', 'class', 'pp-testimonials-wrap' );

		$this->add_render_attribute( [
			'testimonials' => [
				'class' => [
					'pp-testimonials',
					'pp-testimonials-' . $settings['layout'],
					'pp-testimonials-image-' . $settings['image_position'],
				],
				'data-layout' => $settings['layout'],
			],
			'testimonial' => [
				'class' => [
					'pp-testimonial',
					'pp-testimonial-' . $settings['skin'],
				],
			],
		] );

		if ( 'carousel' === $settings['layout'] || 'slideshow' === $settings['layout'] ) {
			$this->add_render_attribute( 'testimonials', 'class', [ 'pp-swiper-slider', 'swiper' ] );

			if ( is_rtl() ) {
				$this->add_render_attribute( 'testimonials', 'dir', 'rtl' );
			}

			$this->add_render_attribute(
				'testimonials',
				[
					'role'                 => 'region',
					// aria-roledescription is ignored on a generic div, so the role has to come with it.
					'aria-roledescription' => esc_attr__( 'carousel', 'powerpack' ),
					'aria-label'           => esc_attr__( 'Testimonials carousel', 'powerpack' ),
				]
			);

			$this->slider_settings();

			$this->add_render_attribute( 'testimonial-wrap', 'class', [ 'swiper-slide', 'pp-testimonial-slide' ] );
		} else {
			if ( 'masonry' !== $settings['layout'] ) {
				$this->add_render_attribute( 'testimonials', 'class', 'elementor-grid' );
			}

			// .pp-grid-item-wrap is PPMasonry's itemSelector - see initMasonryLayout().
			$this->add_render_attribute( 'testimonial-wrap', 'class', [ 'pp-grid-item-wrap', 'elementor-grid-item' ] );
		}

		if ( 'slideshow' === $settings['layout'] && 'yes' === $settings['thumbnail_nav'] ) {
			if ( 'yes' === $settings['thumbnail_nav_grayscale_normal'] ) {
				$this->add_render_attribute( 'testimonials-wrap', 'class', 'pp-thumb-nav-gray' );
			}
			if ( 'yes' === $settings['thumbnail_nav_grayscale_hover'] ) {
				$this->add_render_attribute( 'testimonials-wrap', 'class', 'pp-thumb-nav-gray-hover' );
			}
			if ( 'yes' === $settings['thumbnail_nav_grayscale_active'] ) {
				$this->add_render_attribute( 'testimonials-wrap', 'class', 'pp-thumb-nav-gray-active' );
			}
		}

		$is_slider = ( 'carousel' === $settings['layout'] || 'slideshow' === $settings['layout'] );
		?>
		<div <?php $this->print_render_attribute_string( 'testimonials-wrap' ); ?>>
			<?php if ( $is_slider ) { ?>
			<div class="pp-testimonials-container">
			<?php } ?>

				<div <?php $this->print_render_attribute_string( 'testimonials' ); ?>>
					<?php if ( $is_slider ) { ?><div class="swiper-wrapper"><?php } ?>
						<?php foreach ( $settings['testimonials'] as $index => $item ) : ?>
							<div <?php $this->print_render_attribute_string( 'testimonial-wrap' ); ?>>
								<div <?php $this->print_render_attribute_string( 'testimonial' ); ?>>
									<?php
									switch ( $settings['skin'] ) {
										case 'skin-2':
											$this->render_testimonial_skin_2( $item, $index );
											break;
										case 'skin-3':
											$this->render_testimonial_skin_3( $item, $index );
											break;
										case 'skin-4':
											$this->render_testimonial_skin_4( $item, $index );
											break;
										case 'skin-5':
										case 'skin-6':
										case 'skin-7':
											$this->render_testimonial_skin_5( $item, $index );
											break;
										case 'skin-8':
											$this->render_testimonial_skin_8( $item, $index );
											break;
										default:
											$this->render_testimonial_default( $item, $index );
											break;
									}
									?>
								</div>
							</div>
						<?php endforeach; ?>
					<?php if ( $is_slider ) { ?></div><?php } ?>
					<?php
					if ( $is_slider ) {
						/*
						 * Swiper announces a move only from its own Enter/Space handler, and
						 * silences the slides wrapper entirely while autoplay runs, so a
						 * pointer user gets no feedback at all without this. The script fills
						 * it in only where the user asked for the move.
						 */
						printf(
							'<div class="elementor-screen-only pp-testimonials-status" aria-live="polite" aria-atomic="true" id="pp-testimonials-status-%1$s">%2$s</div>',
							esc_attr( $this->get_id() ),
							esc_html( PP_Helper::get_slide_status_text( 1, count( $settings['testimonials'] ) ) )
						);
					}
					?>
					<?php if ( $is_slider && 'yes' === $settings['dots'] && ! ( 'slideshow' === $settings['layout'] && 'yes' === $settings['thumbnail_nav'] ) ) { ?>
						<div class="swiper-pagination pp-testimonials-pagination-<?php echo esc_attr( $this->get_id() ); ?>"></div>
					<?php } ?>
				</div>
			<?php if ( $is_slider ) { ?>
				<?php $this->render_arrows(); ?>
			</div>
			<?php
			}
			if ( 'slideshow' === $settings['layout'] && 'yes' === $settings['thumbnail_nav'] ) {
				$this->render_thumbnails();
			}
			?>
		</div>
		<?php
	}
}
