<?php
namespace PowerpackElements\Modules\Instafeed\Widgets;

use PowerpackElements\Base\Powerpack_Widget;
use PowerpackElements\Classes\PP_Admin_Settings;
use PowerpackElements\Classes\PP_Config;
use PowerpackElements\Classes\PP_Helper;

// Elementor Classes
use Elementor\Controls_Manager;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Instagram Feed Widget
 */
class Instafeed extends Powerpack_Widget {

	/**
	 * How long a failed feed lookup is remembered, in seconds (5 minutes).
	 *
	 * Long enough that a dead token cannot hammer the API on every page view,
	 * short enough that a corrected token recovers without manual cache clearing.
	 *
	 * @since 3.2.0
	 * @var   int
	 */
	const ERROR_CACHE_DURATION = 300;

	/**
	 * Instagram Access token.
	 *
	 * @since 2.2.6
	 * @var   string
	 */
	private $insta_access_token = null;

	/**
	 * Official Instagram API URL.
	 *
	 * @since 2.2.6
	 * @var   string
	 */
	private $insta_official_api_url = 'https://graph.instagram.com/';

	/**
	 * Retrieve instagram feed widget name.
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return parent::get_widget_name( 'Instafeed' );
	}

	/**
	 * Retrieve instagram feed widget title.
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return parent::get_widget_title( 'Instafeed' );
	}

	/**
	 * Retrieve instagram feed widget icon.
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return parent::get_widget_icon( 'Instafeed' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return parent::get_widget_keywords( 'Instafeed' );
	}

	/**
	 * Whether the widget renders dynamic content.
	 *
	 * True: the output is a remote feed on its own cache schedule, so Elementor
	 * must not freeze the rendered markup in the element cache — doing so would
	 * silently override the widget's Cache Timeout control.
	 *
	 * @since 2.10.20
	 * @access protected
	 *
	 * @return bool
	 */
	protected function is_dynamic_content(): bool {
		return true;
	}

	/**
	 * Retrieve the list of scripts the instagram feed widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		if ( PP_Helper::is_edit_mode() || PP_Helper::is_preview_mode() ) {
			return [
				'imagesloaded',
				'swiper',
				'pp-instafeed',
			];
		}

		$settings = $this->get_settings_for_display();
		$scripts = [];

		if ( 'masonry' === $settings['feed_layout'] ) {
			array_push( $scripts, 'imagesloaded', 'pp-instafeed' );
		}

		if ( 'carousel' === $settings['feed_layout'] ) {
			array_push( $scripts, 'swiper', 'pp-instafeed' );
		}

		if ( 'yes' === $settings['insta_image_popup'] ) {
			array_push( $scripts, 'swiper' );
		}

		return $scripts;
	}

	/**
	 * Get style dependencies.
	 *
	 * Retrieve the list of style dependencies the widget requires.
	 *
	 * @since 2.11.0
	 * @access public
	 *
	 * @return array Widget style dependencies.
	 */
	public function get_style_depends(): array {
		if ( PP_Helper::is_edit_mode() || PP_Helper::is_preview_mode() ) {
			return [ 'e-swiper', 'pp-swiper', 'widget-pp-instagram-feed' ];
		}

		$settings = $this->get_settings_for_display();
		$styles = [ 'widget-pp-instagram-feed' ];

		if ( 'carousel' === $settings['feed_layout'] ) {
			array_push( $styles, 'e-swiper', 'pp-swiper' );
		}

		if ( 'yes' === $settings['insta_image_popup'] ) {
			array_push( $styles, 'e-swiper' );
		}

		return $styles;
	}

	/**
	 * Whether the widget has an inner wrapper.
	 *
	 * Disabled when Elementor's "Optimized Markup" experiment is active so the
	 * widget output participates in the leaner DOM.
	 *
	 * @since 2.11.8
	 * @access public
	 *
	 * @return bool
	 */
	public function has_widget_inner_wrapper(): bool {
		return ! PP_Helper::is_feature_active( 'e_optimized_markup' );
	}

	/**
	 * Register instagram feed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 2.0.3
	 * @access protected
	 */
	protected function register_controls() {
		/* Content Tab: Instagram Account */
		$this->register_content_instaaccount_controls();

		/* Content Tab: General Settings */
		$this->register_content_general_settings_controls();

		/* Content Tab: Carousel Settings */
		$this->register_content_carousel_settings_controls();

		/* Style Tab: Layout */
		$this->register_style_layout_controls();

		/* Style Tab: Images */
		$this->register_style_images_controls();

		/* Style Tab: Content */
		$this->register_style_content_controls();

		/* Style Tab: Overlay */
		$this->register_style_overlay_controls();

		/* Style Tab: Feed Title */
		$this->register_style_feed_title_controls();

		/* Style Tab: Arrows */
		$this->register_style_arrows_controls();

		/* Style Tab: Dots */
		$this->register_style_dots_controls();

		/* Style Tab: Fraction */
		$this->register_style_fraction_controls();
	}

	/**
	 * Content Tab: Instagram Account
	 */
	protected function register_content_instaaccount_controls() {
		$this->start_controls_section(
			'section_instaaccount',
			[
				'label' => esc_html__( 'Instagram Account', 'powerpack' ),
			]
		);

		if ( ! $this->get_insta_global_access_token() ) {
			$this->add_control(
				'access_token_missing',
				[
					'type'            => Controls_Manager::RAW_HTML,
					'raw'             => sprintf(
						/* translators: %1$s: opening anchor tag, %2$s: closing anchor tag. */
						esc_html__( 'Your Instagram Access Token is missing, %1$sclick here%2$s to configure.', 'powerpack' ),
						'<a href="' . esc_url( PP_Admin_Settings::get_page_url( 'integration' ) ) . '"><strong>',
						'</strong></a>'
					),
					'content_classes' => 'pp-editor-info',
				]
			);
		}

		$this->add_control(
			'access_token',
			[
				'label'       => esc_html__( 'Custom Access Token', 'powerpack' ),
				'description' => esc_html__( 'Overrides global Instagram access token', 'powerpack' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'ai'          => [
					'active' => false,
				],
			]
		);

		$this->add_control(
			'cache_timeout',
			[
				'label'   => esc_html__( 'Cache Timeout', 'powerpack' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'hour',
				'options' => [
					'none'   => esc_html__( 'None', 'powerpack' ),
					'minute' => esc_html__( 'Minute', 'powerpack' ),
					'hour'   => esc_html__( 'Hour', 'powerpack' ),
					'day'    => esc_html__( 'Day', 'powerpack' ),
					'week'   => esc_html__( 'Week', 'powerpack' ),
				],
			]
		);

		$this->add_control(
			'images_count',
			[
				'label'      => esc_html__( 'Images Count', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'default'    => [ 'size' => 5 ],
				'range'      => [
					'px' => [
						'min'  => 1,
						'max'  => 100,
						'step' => 1,
					],
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Content Tab: General Settings
	 */
	protected function register_content_general_settings_controls() {
		$this->start_controls_section(
			'section_general_settings',
			[
				'label' => esc_html__( 'General Settings', 'powerpack' ),
			]
		);

		$this->add_control(
			'feed_layout',
			[
				'label'              => esc_html__( 'Layout', 'powerpack' ),
				'type'               => Controls_Manager::SELECT,
				'default'            => 'grid',
				'options'            => [
					'grid'     => esc_html__( 'Grid', 'powerpack' ),
					'masonry'  => esc_html__( 'Masonry', 'powerpack' ),
					'carousel' => esc_html__( 'Carousel', 'powerpack' ),
				],
				'frontend_available' => true,
			]
		);

		$this->add_control(
			'square_images',
			[
				'label'        => esc_html__( 'Square Images', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'condition'    => [
					'feed_layout' => [ 'grid', 'carousel' ],
				],
			]
		);

		$this->add_responsive_control(
			'grid_cols',
			[
				'label'          => esc_html__( 'Grid Columns', 'powerpack' ),
				'type'           => Controls_Manager::SELECT,
				'label_block'    => false,
				'default'        => '5',
				'tablet_default' => '3',
				'mobile_default' => '2',
				'options'        => [
					'1' => esc_html__( '1', 'powerpack' ),
					'2' => esc_html__( '2', 'powerpack' ),
					'3' => esc_html__( '3', 'powerpack' ),
					'4' => esc_html__( '4', 'powerpack' ),
					'5' => esc_html__( '5', 'powerpack' ),
					'6' => esc_html__( '6', 'powerpack' ),
					'7' => esc_html__( '7', 'powerpack' ),
					'8' => esc_html__( '8', 'powerpack' ),
				],
				'selectors'      => [
					'{{WRAPPER}} .pp-instafeed-grid:not(.pp-instafeed-masonry) .pp-feed-item' => 'width: calc( 100% / {{VALUE}} )',
					'{{WRAPPER}} .pp-instafeed-grid' => '--pp-gallery-columns: {{VALUE}};',
				],
				'render_type'    => 'template',
				'condition'      => [
					'feed_layout' => [ 'grid', 'masonry' ],
				],
			]
		);

		$this->add_control(
			'insta_caption',
			[
				'label'              => esc_html__( 'Caption', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => '',
				'label_on'           => esc_html__( 'Show', 'powerpack' ),
				'label_off'          => esc_html__( 'Hide', 'powerpack' ),
				'return_value'       => 'yes',
			]
		);

		$this->add_control(
			'insta_caption_length',
			[
				'label'     => esc_html__( 'Caption Length', 'powerpack' ),
				'type'      => Controls_Manager::NUMBER,
				'dynamic'   => [
					'active' => true,
				],
				'default'   => 30,
				'condition' => [
					'insta_caption' => 'yes',
				],
			]
		);

		$this->add_control(
			'content_visibility',
			[
				'label'     => esc_html__( 'Content Visibility', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'always',
				'options'   => [
					'always' => esc_html__( 'Always', 'powerpack' ),
					'hover'  => esc_html__( 'On Hover', 'powerpack' ),
				],
				'condition' => [
					'insta_caption' => 'yes',
				],
			]
		);

		$this->add_control(
			'insta_image_popup',
			[
				'label'        => esc_html__( 'Lightbox', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'no',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'insta_image_link',
			[
				'label'        => esc_html__( 'Image Link', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'condition'    => [
					'insta_image_popup!' => 'yes',
				],
			]
		);

		$this->add_control(
			'insta_profile_link',
			[
				'label'        => esc_html__( 'Show Link to Instagram Profile?', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'no',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'separator'    => 'before',
			]
		);

		$this->add_control(
			'insta_link_title',
			[
				'label'     => esc_html__( 'Link Title', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'dynamic'   => [
					'active'  => true,
				],
				'default'   => esc_html__( 'Follow Us @ Instagram', 'powerpack' ),
				'condition' => [
					'insta_profile_link' => 'yes',
				],
			]
		);

		$this->add_control(
			'insta_profile_url',
			[
				'label'       => esc_html__( 'Instagram Profile URL', 'powerpack' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => 'https://www.your-link.com',
				'dynamic'     => [
					'active'  => true,
				],
				'default'     => [
					'url' => '#',
				],
				'condition'   => [
					'insta_profile_link' => 'yes',
				],
			]
		);

		$this->add_control(
			'title_icon',
			[
				'label'            => esc_html__( 'Title Icon', 'powerpack' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'insta_title_icon',
				'recommended'      => [
					'fa-brands' => [
						'instagram',
					],
					'fa-regular' => [
						'user',
						'user-circle',
					],
					'fa-solid'  => [
						'user',
						'user-circle',
						'user-check',
						'user-graduate',
						'user-md',
						'user-plus',
						'user-tie',
					],
				],
				'default'          => [
					'value'   => 'fab fa-instagram',
					'library' => 'fa-brands',
				],
				'condition'        => [
					'insta_profile_link' => 'yes',
				],
			]
		);

		$this->add_control(
			'insta_title_icon_position',
			[
				'label'     => esc_html__( 'Icon Position', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'before_title' => esc_html__( 'Before Title', 'powerpack' ),
					'after_title'  => esc_html__( 'After Title', 'powerpack' ),
				],
				'default'   => 'before_title',
				'condition' => [
					'insta_profile_link' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Content Tab: Carousel Settings
	 */
	protected function register_content_carousel_settings_controls() {
		$this->start_controls_section(
			'section_carousel_settings',
			[
				'label'     => esc_html__( 'Carousel Settings', 'powerpack' ),
				'condition' => [
					'feed_layout' => 'carousel',
				],
			]
		);

		$this->add_responsive_control(
			'items',
			[
				'label'      => esc_html__( 'Visible Items', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'default'    => [ 'size' => 3 ],
				'range'      => [
					'px' => [
						'min'  => 1,
						'max'  => 10,
						'step' => 1,
					],
				],
				'condition'  => [
					'feed_layout' => 'carousel',
				],
			]
		);

		$this->add_responsive_control(
			'margin',
			[
				'label'      => esc_html__( 'Items Gap', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'default'    => [ 'size' => 10 ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'condition'  => [
					'feed_layout' => 'carousel',
				],
			]
		);

		$this->add_control(
			'slider_speed',
			[
				'label'       => esc_html__( 'Slider Speed', 'powerpack' ),
				'description' => esc_html__( 'Duration of transition between slides (in ms)', 'powerpack' ),
				'type'        => Controls_Manager::SLIDER,
				'default'     => [ 'size' => 600 ],
				'range'       => [
					'px' => [
						'min'  => 100,
						'max'  => 3000,
						'step' => 1,
					],
				],
				'separator'   => 'before',
				'condition'   => [
					'feed_layout' => 'carousel',
				],
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'        => esc_html__( 'Autoplay', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'condition'    => [
					'feed_layout' => 'carousel',
				],
			]
		);

		$this->add_control(
			'pause_on_hover',
			[
				'label'                 => esc_html__( 'Pause on Hover', 'powerpack' ),
				'description'           => '',
				'type'                  => Controls_Manager::SWITCHER,
				'default'               => '',
				'label_on'              => esc_html__( 'Yes', 'powerpack' ),
				'label_off'             => esc_html__( 'No', 'powerpack' ),
				'return_value'          => 'yes',
				'frontend_available'    => true,
				'condition'             => [
					'autoplay'      => 'yes',
				],
			]
		);

		$this->add_control(
			'pause_on_interaction',
			[
				'label'              => esc_html__( 'Pause on Interaction', 'powerpack' ),
				'description'        => esc_html__( 'Disables autoplay completely on first interaction with the carousel.', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => '',
				'label_on'           => esc_html__( 'Yes', 'powerpack' ),
				'label_off'          => esc_html__( 'No', 'powerpack' ),
				'return_value'       => 'yes',
				'frontend_available' => true,
				'condition'          => [
					'autoplay'    => 'yes',
					'feed_layout' => 'carousel',
				],
			]
		);

		$this->add_control(
			'autoplay_speed',
			[
				'label'     => esc_html__( 'Autoplay Speed', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => 3000,
				'title'     => esc_html__( 'Enter carousel speed', 'powerpack' ),
				'ai'        => [
					'active' => false,
				],
				'condition' => [
					'autoplay'    => 'yes',
					'feed_layout' => 'carousel',
				],
			]
		);

		$this->add_control(
			'infinite_loop',
			[
				'label'        => esc_html__( 'Infinite Loop', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'condition'    => [
					'feed_layout' => 'carousel',
				],
			]
		);

		$this->add_control(
			'grab_cursor',
			[
				'label'        => esc_html__( 'Grab Cursor', 'powerpack' ),
				'description'  => esc_html__( 'Shows grab cursor when you hover over the slider', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '',
				'label_on'     => esc_html__( 'Show', 'powerpack' ),
				'label_off'    => esc_html__( 'Hide', 'powerpack' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'navigation_heading',
			[
				'label'     => esc_html__( 'Navigation', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'arrows',
			[
				'label'        => esc_html__( 'Arrows', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'condition'    => [
					'feed_layout' => 'carousel',
				],
			]
		);

		$this->add_control(
			'dots',
			[
				'label'        => esc_html__( 'Pagination', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'condition'    => [
					'feed_layout' => 'carousel',
				],
			]
		);

		$this->add_control(
			'pagination_type',
			[
				'label'     => esc_html__( 'Pagination Type', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'bullets',
				'options'   => [
					'bullets'  => esc_html__( 'Dots', 'powerpack' ),
					'fraction' => esc_html__( 'Fraction', 'powerpack' ),
				],
				'condition' => [
					'dots' => 'yes',
				],
			]
		);

		$this->add_control(
			'direction',
			[
				'label'     => esc_html__( 'Direction', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'left',
				'options'   => [
					'left'  => esc_html__( 'Left', 'powerpack' ),
					'right' => esc_html__( 'Right', 'powerpack' ),
				],
				'separator' => 'before',
			]
		);

		$this->end_controls_section();
	}

	/*-----------------------------------------------------------------------------------*/
	/* STYLE TAB
	/*-----------------------------------------------------------------------------------*/

	/**
	 * Style Tab: Layout
	 */
	protected function register_style_layout_controls() {
		$this->start_controls_section(
			'section_layout_style',
			[
				'label'     => esc_html__( 'Layout', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'feed_layout' => [ 'grid', 'masonry' ],
				],
			]
		);

		$this->add_responsive_control(
			'columns_gap',
			[
				'label'          => esc_html__( 'Columns Gap', 'powerpack' ),
				'type'           => Controls_Manager::SLIDER,
				'size_units'     => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'        => [
					'size' => '',
					'unit' => 'px',
				],
				'range'          => [
					'px' => [
						'max' => 100,
					],
				],
				'tablet_default' => [
					'unit' => 'px',
				],
				'mobile_default' => [
					'unit' => 'px',
				],
				'selectors'      => [
					'{{WRAPPER}}' => '--grid-column-gap: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .pp-instafeed-grid:not(.pp-instafeed-masonry) .pp-feed-item' => 'padding-left: calc({{SIZE}}{{UNIT}}/2); padding-right: calc({{SIZE}}{{UNIT}}/2);',
					'{{WRAPPER}} .pp-instafeed-grid:not(.pp-instafeed-masonry)' => 'margin-left: calc(-{{SIZE}}{{UNIT}}/2); margin-right: calc(-{{SIZE}}{{UNIT}}/2);',
				],
				'render_type'    => 'template',
				'condition'      => [
					'feed_layout' => [ 'grid', 'masonry' ],
				],
			]
		);

		$this->add_responsive_control(
			'rows_gap',
			[
				'label'          => esc_html__( 'Rows Gap', 'powerpack' ),
				'type'           => Controls_Manager::SLIDER,
				'size_units'     => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'        => [
					'size' => '',
					'unit' => 'px',
				],
				'range'          => [
					'px' => [
						'max' => 100,
					],
				],
				'tablet_default' => [
					'unit' => 'px',
				],
				'mobile_default' => [
					'unit' => 'px',
				],
				'selectors'      => [
					'{{WRAPPER}}' => '--grid-row-gap: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .pp-instafeed-grid:not(.pp-instafeed-masonry) .pp-feed-item' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'render_type'    => 'template',
				'condition'      => [
					'feed_layout' => [ 'grid', 'masonry' ],
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Images
	 */
	protected function register_style_images_controls() {
		$this->start_controls_section(
			'section_image_style',
			[
				'label' => esc_html__( 'Images', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs( 'tabs_image_style' );

		$this->start_controls_tab(
			'tab_image_normal',
			[
				'label' => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_control(
			'insta_image_grayscale',
			[
				'label'        => esc_html__( 'Grayscale Image', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'no',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'images_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-instagram-feed .pp-if-img',
			]
		);

		$this->add_control(
			'images_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-instagram-feed .pp-if-img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_image_hover',
			[
				'label' => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_control(
			'insta_image_grayscale_hover',
			[
				'label'        => esc_html__( 'Grayscale Image', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'no',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'images_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-instagram-feed .pp-feed-item:hover .pp-if-img, {{WRAPPER}} .pp-instagram-feed .pp-feed-item:focus-within .pp-if-img' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Content
	 */
	protected function register_style_content_controls() {
		$this->start_controls_section(
			'section_content_style',
			[
				'label'     => esc_html__( 'Content', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'insta_caption' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'content_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'selector'  => '{{WRAPPER}} .pp-feed-item .pp-overlay-container',
				'condition' => [
					'insta_caption' => 'yes',
				],
			]
		);

		$this->add_control(
			'likes_comments_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-feed-item .pp-overlay-container' => 'color: {{VALUE}};',
				],
				'condition' => [
					'insta_caption' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'content_vertical_align',
			[
				'label'                => esc_html__( 'Vertical Align', 'powerpack' ),
				'type'                 => Controls_Manager::CHOOSE,
				'label_block'          => false,
				'toggle'               => false,
				'default'              => 'middle',
				'options'              => [
					'top'    => [
						'title' => esc_html__( 'Top', 'powerpack' ),
						'icon'  => 'eicon-v-align-top',
					],
					'middle' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-v-align-middle',
					],
					'bottom' => [
						'title' => esc_html__( 'Bottom', 'powerpack' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'selectors_dictionary' => [
					'top'    => 'flex-start',
					'middle' => 'center',
					'bottom' => 'flex-end',
				],
				'selectors'            => [
					'{{WRAPPER}} .pp-overlay-container' => 'justify-content: {{VALUE}};',
				],
				'condition'            => [
					'insta_caption' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'content_horizontal_align',
			[
				'label'                => esc_html__( 'Horizontal Align', 'powerpack' ),
				'type'                 => Controls_Manager::CHOOSE,
				'label_block'          => false,
				'toggle'               => false,
				'default'              => 'center',
				'options'              => [
					'left'   => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-h-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-h-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'selectors_dictionary' => [
					'left'   => 'flex-start',
					'center' => 'center',
					'right'  => 'flex-end',
				],
				'selectors'            => [
					'{{WRAPPER}} .pp-overlay-container' => 'align-items: {{VALUE}};',
				],
				'condition'            => [
					'insta_caption' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'text_align',
			[
				'label'    => esc_html__( 'Text Align', 'powerpack' ),
				'type'     => Controls_Manager::CHOOSE,
				'options'  => [
					'left' => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => 'center',
				'selectors' => [
					'{{WRAPPER}} .pp-overlay-container' => 'text-align: {{VALUE}};',
				],
				'condition' => [
					'insta_caption' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'content_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-overlay-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'insta_caption' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Overlay
	 */
	protected function register_style_overlay_controls() {
		$this->start_controls_section(
			'section_overlay_style',
			[
				'label' => esc_html__( 'Overlay', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'overlay_blend_mode',
			[
				'label'     => esc_html__( 'Blend Mode', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'normal',
				'options'   => [
					'normal'      => esc_html__( 'Normal', 'powerpack' ),
					'multiply'    => esc_html__( 'Multiply', 'powerpack' ),
					'screen'      => esc_html__( 'Screen', 'powerpack' ),
					'overlay'     => esc_html__( 'Overlay', 'powerpack' ),
					'darken'      => esc_html__( 'Darken', 'powerpack' ),
					'lighten'     => esc_html__( 'Lighten', 'powerpack' ),
					'color-dodge' => esc_html__( 'Color Dodge', 'powerpack' ),
					'color'       => esc_html__( 'Color', 'powerpack' ),
					'hue'         => esc_html__( 'Hue', 'powerpack' ),
					'hard-light'  => esc_html__( 'Hard Light', 'powerpack' ),
					'soft-light'  => esc_html__( 'Soft Light', 'powerpack' ),
					'difference'  => esc_html__( 'Difference', 'powerpack' ),
					'exclusion'   => esc_html__( 'Exclusion', 'powerpack' ),
					'saturation'  => esc_html__( 'Saturation', 'powerpack' ),
					'luminosity'  => esc_html__( 'Luminosity', 'powerpack' ),
				],
				'selectors' => [
					'{{WRAPPER}} .pp-instagram-feed .pp-overlay-container' => 'mix-blend-mode: {{VALUE}};',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_overlay_style' );

		$this->start_controls_tab(
			'tab_overlay_normal',
			[
				'label' => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'image_overlay_normal',
				'label'    => esc_html__( 'Overlay', 'powerpack' ),
				'types'    => [ 'classic', 'gradient' ],
				'exclude'  => [
					'image',
				],
				'selector' => '{{WRAPPER}} .pp-instagram-feed .pp-overlay-container',
			]
		);

		$this->add_control(
			'overlay_margin_normal',
			[
				'label'      => esc_html__( 'Margin', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-instagram-feed .pp-overlay-container' => 'inset: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'image_overlay_opacity_normal',
			[
				'label'      => esc_html__( 'Overlay Opacity', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1,
						'step' => 0.1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-instagram-feed .pp-overlay-container' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_overlay_hover',
			[
				'label' => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'image_overlay_hover',
				'label'    => esc_html__( 'Overlay', 'powerpack' ),
				'types'    => [ 'classic', 'gradient' ],
				'exclude'  => [
					'image',
				],
				'selector' => '{{WRAPPER}} .pp-instagram-feed .pp-feed-item:hover .pp-overlay-container, {{WRAPPER}} .pp-instagram-feed .pp-feed-item:focus-within .pp-overlay-container',
			]
		);

		$this->add_control(
			'image_overlay_opacity_hover',
			[
				'label'      => esc_html__( 'Overlay Opacity', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1,
						'step' => 0.1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-instagram-feed .pp-feed-item:hover .pp-overlay-container, {{WRAPPER}} .pp-instagram-feed .pp-feed-item:focus-within .pp-overlay-container' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Feed Title
	 */
	protected function register_style_feed_title_controls() {
		$this->start_controls_section(
			'section_feed_title_style',
			[
				'label'     => esc_html__( 'Feed Title', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'insta_profile_link' => 'yes',
				],
			]
		);

		$this->add_control(
			'feed_title_position',
			[
				'label'        => esc_html__( 'Position', 'powerpack' ),
				'type'         => Controls_Manager::CHOOSE,
				'label_block'  => false,
				'default'      => 'middle',
				'options'      => [
					'top'    => [
						'title' => esc_html__( 'Top', 'powerpack' ),
						'icon'  => 'eicon-v-align-top',
					],
					'middle' => [
						'title' => esc_html__( 'Middle', 'powerpack' ),
						'icon'  => 'eicon-v-align-middle',
					],
					'bottom' => [
						'title' => esc_html__( 'Bottom', 'powerpack' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'prefix_class' => 'pp-insta-title-',
				'condition'    => [
					'insta_profile_link' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'feed_title_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'global'    => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector'  => '{{WRAPPER}} .pp-instagram-feed-title',
				'condition' => [
					'insta_profile_link' => 'yes',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_title_style' );

		$this->start_controls_tab(
			'tab_title_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => [
					'insta_profile_link' => 'yes',
				],
			]
		);

		$this->add_control(
			'title_color_normal',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-instagram-feed-title-wrap a' => 'color: {{VALUE}};',
					'{{WRAPPER}} .pp-instagram-feed-title-wrap .pp-icon svg' => 'fill: {{VALUE}};',
				],
				'condition' => [
					'insta_profile_link' => 'yes',
				],
			]
		);

		$this->add_control(
			'title_bg_color_normal',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-instagram-feed-title-wrap' => 'background: {{VALUE}};',
				],
				'condition' => [
					'insta_profile_link' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'title_border_normal',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-instagram-feed-title-wrap',
			]
		);

		$this->add_control(
			'title_border_radius_normal',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-instagram-feed-title-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_title_hover',
			[
				'label'     => esc_html__( 'Hover', 'powerpack' ),
				'condition' => [
					'insta_profile_link' => 'yes',
				],
			]
		);

		$this->add_control(
			'title_color_hover',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-instagram-feed-title-wrap a:hover, {{WRAPPER}} .pp-instagram-feed-title-wrap a:focus-visible' => 'color: {{VALUE}};',
					'{{WRAPPER}} .pp-instagram-feed-title-wrap a:hover .pp-icon svg, {{WRAPPER}} .pp-instagram-feed-title-wrap a:focus-visible .pp-icon svg' => 'fill: {{VALUE}};',
				],
				'condition' => [
					'insta_profile_link' => 'yes',
				],
			]
		);

		$this->add_control(
			'title_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-instagram-feed-title-wrap:hover, {{WRAPPER}} .pp-instagram-feed-title-wrap:focus-within' => 'background: {{VALUE}};',
				],
				'condition' => [
					'insta_profile_link' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'title_border_hover',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-instagram-feed-title-wrap:hover, {{WRAPPER}} .pp-instagram-feed-title-wrap:focus-within',
			]
		);

		$this->add_control(
			'title_border_radius_hover',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-instagram-feed-title-wrap:hover, {{WRAPPER}} .pp-instagram-feed-title-wrap:focus-within' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'title_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-instagram-feed-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'insta_profile_link' => 'yes',
				],
				'separator'  => 'before',
			]
		);

		$this->add_control(
			'title_icon_heading',
			[
				'label'     => esc_html__( 'Icon', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'insta_profile_link' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'title_icon_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [ 'size' => 4 ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 30,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-instagram-feed .pp-icon-before_title' => 'margin-inline-end: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .pp-instagram-feed .pp-icon-after_title' => 'margin-inline-start: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'insta_profile_link' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Arrows
	 */
	protected function register_style_arrows_controls() {
		$this->start_controls_section(
			'section_arrows_style',
			[
				'label'     => esc_html__( 'Arrows', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'feed_layout' => 'carousel',
					'arrows'      => 'yes',
				],
			]
		);

		$this->add_control(
			'select_arrow',
			[
				'label'                  => esc_html__( 'Choose Arrow', 'powerpack' ),
				'type'                   => Controls_Manager::ICONS,
				'fa4compatibility'       => 'arrow',
				'label_block'            => false,
				'default'                => [
					'value'   => 'fas fa-angle-right',
					'library' => 'fa-solid',
				],
				'skin'                   => 'inline',
				'exclude_inline_options' => 'svg',
				'recommended'            => [
					'fa-regular' => [
						'arrow-alt-circle-right',
						'caret-square-right',
						'hand-point-right',
					],
					'fa-solid'   => [
						'angle-right',
						'angle-double-right',
						'chevron-right',
						'chevron-circle-right',
						'arrow-right',
						'long-arrow-alt-right',
						'caret-right',
						'caret-square-right',
						'arrow-circle-right',
						'arrow-alt-circle-right',
						'toggle-right',
						'hand-point-right',
					],
				],
				'condition'             => [
					'feed_layout' => 'carousel',
					'arrows'      => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'arrows_size',
			[
				'label'      => esc_html__( 'Arrows Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [ 'size' => '22' ],
				'range'      => [
					'px' => [
						'min'  => 15,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-instagram-feed .pp-slider-arrow' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'left_arrow_position',
			[
				'label'      => esc_html__( 'Align Left Arrow', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => -100,
						'max'  => 40,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-instagram-feed .elementor-swiper-button-prev' => 'left: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'right_arrow_position',
			[
				'label'      => esc_html__( 'Align Right Arrow', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => -100,
						'max'  => 40,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-instagram-feed .elementor-swiper-button-next' => 'right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_arrows_style' );

		$this->start_controls_tab(
			'tab_arrows_normal',
			[
				'label' => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_control(
			'arrows_bg_color_normal',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-instagram-feed .pp-slider-arrow' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'arrows_color_normal',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-instagram-feed .pp-slider-arrow' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'arrows_border_normal',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-instagram-feed .pp-slider-arrow',
			]
		);

		$this->add_control(
			'arrows_border_radius_normal',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-instagram-feed .pp-slider-arrow' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_arrows_hover',
			[
				'label' => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_control(
			'arrows_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-instagram-feed .pp-slider-arrow:hover, {{WRAPPER}} .pp-instagram-feed .pp-slider-arrow:focus-visible' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'arrows_color_hover',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-instagram-feed .pp-slider-arrow:hover, {{WRAPPER}} .pp-instagram-feed .pp-slider-arrow:focus-visible' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'arrows_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-instagram-feed .pp-slider-arrow:hover, {{WRAPPER}} .pp-instagram-feed .pp-slider-arrow:focus-visible' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			'arrows_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-instagram-feed .pp-slider-arrow' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator'  => 'before',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Pagination: Dots
	 */
	protected function register_style_dots_controls() {
		$this->start_controls_section(
			'section_dots_style',
			[
				'label'     => esc_html__( 'Pagination: Dots', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'feed_layout'     => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'bullets',
				],
			]
		);

		$this->add_control(
			'dots_position',
			[
				'label'        => esc_html__( 'Position', 'powerpack' ),
				'type'         => Controls_Manager::SELECT,
				'options'      => [
					'inside'  => esc_html__( 'Inside', 'powerpack' ),
					'outside' => esc_html__( 'Outside', 'powerpack' ),
				],
				'default'      => 'outside',
				'prefix_class' => 'swiper-container-dots-',
				'condition'    => [
					'feed_layout'     => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'bullets',
				],
			]
		);

		$this->add_responsive_control(
			'dots_size',
			[
				'label'      => esc_html__( 'Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 2,
						'max'  => 40,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-instagram-feed .swiper-pagination-bullet' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}}',
				],
				'condition'  => [
					'feed_layout'     => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'bullets',
				],
			]
		);

		$this->add_responsive_control(
			'dots_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 1,
						'max'  => 30,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-instagram-feed .swiper-pagination-bullet' => 'margin-left: {{SIZE}}{{UNIT}}; margin-right: {{SIZE}}{{UNIT}}',
				],
				'condition'  => [
					'feed_layout'     => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'bullets',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_dots_style' );

		$this->start_controls_tab(
			'tab_dots_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => [
					'feed_layout'     => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'bullets',
				],
			]
		);

		$this->add_control(
			'dots_color_normal',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-instagram-feed .swiper-pagination-bullet' => 'background: {{VALUE}};',
				],
				'condition' => [
					'feed_layout'     => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'bullets',
				],
			]
		);

		$this->add_control(
			'active_dot_color_normal',
			[
				'label'     => esc_html__( 'Active Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-instagram-feed .swiper-pagination-bullet-active' => 'background: {{VALUE}};',
				],
				'condition' => [
					'feed_layout'     => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'bullets',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'dots_border_normal',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-instagram-feed .swiper-pagination-bullet',
				'condition'   => [
					'feed_layout'     => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'bullets',
				],
			]
		);

		$this->add_control(
			'dots_border_radius_normal',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-instagram-feed .swiper-pagination-bullet' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'feed_layout'     => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'bullets',
				],
			]
		);

		$this->add_responsive_control(
			'dots_margin',
			[
				'label'              => esc_html__( 'Margin', 'powerpack' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'allowed_dimensions' => 'vertical',
				'placeholder'        => [
					'top'    => '',
					'right'  => 'auto',
					'bottom' => '',
					'left'   => 'auto',
				],
				'selectors'          => [
					'{{WRAPPER}} .pp-instagram-feed .swiper-pagination-bullets' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'          => [
					'feed_layout'     => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'bullets',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_dots_hover',
			[
				'label'     => esc_html__( 'Hover', 'powerpack' ),
				'condition' => [
					'feed_layout'     => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'bullets',
				],
			]
		);

		$this->add_control(
			'dots_color_hover',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-instagram-feed .swiper-pagination-bullet:hover, {{WRAPPER}} .pp-instagram-feed .swiper-pagination-bullet:focus-visible' => 'background: {{VALUE}};',
				],
				'condition' => [
					'feed_layout'     => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'bullets',
				],
			]
		);

		$this->add_control(
			'dots_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-instagram-feed .swiper-pagination-bullet:hover, {{WRAPPER}} .pp-instagram-feed .swiper-pagination-bullet:focus-visible' => 'border-color: {{VALUE}};',
				],
				'condition' => [
					'feed_layout'     => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'bullets',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Pagination: Fraction
	 * -------------------------------------------------
	 */
	protected function register_style_fraction_controls() {
		$this->start_controls_section(
			'section_fraction_style',
			[
				'label'     => esc_html__( 'Pagination: Fraction', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'feed_layout'     => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'fraction',
				],
			]
		);

		$this->add_control(
			'fraction_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-pagination-fraction' => 'color: {{VALUE}};',
				],
				'condition' => [
					'feed_layout'     => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'fraction',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'fraction_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'global'    => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector'  => '{{WRAPPER}} .swiper-pagination-fraction',
				'condition' => [
					'feed_layout'     => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'fraction',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Get Instagram access token.
	 *
	 * @since 2.2.6
	 * @return string
	 */
	public function get_insta_access_token() {
		$settings = $this->get_settings_for_display();

		if ( ! $this->insta_access_token ) {
			$custom_access_token = isset( $settings['access_token'] ) ? $settings['access_token'] : '';

			if ( '' !== trim( $custom_access_token ) ) {
				$this->insta_access_token = $custom_access_token;
			} else {
				$this->insta_access_token = $this->get_insta_global_access_token();
			}
		}

		return $this->insta_access_token;
	}

	/**
	 * Get Instagram access token from PowerPack options.
	 *
	 * @since 2.2.6
	 * @return string
	 */
	public function get_insta_global_access_token() {
		return \PowerpackElements\Classes\PP_Admin_Settings::get_option( 'pp_instagram_access_token' );
	}

	/**
	 * Retrieve a URL for own photos.
	 *
	 * @since  2.2.6
	 * @return string
	 */
	public function get_feed_endpoint() {
		return $this->insta_official_api_url . 'me/media/';
	}

	/**
	 * Retrieve a grab URL.
	 *
	 * @since  2.2.6
	 * @return string
	 */
	public function get_fetch_url() {
		$settings = $this->get_settings_for_display();

		$images_count = ! empty( $settings['images_count']['size'] ) ? $settings['images_count']['size'] : 5;

		$url = $this->get_feed_endpoint();
		$url = add_query_arg( [
			'fields'       => 'id,media_type,media_url,thumbnail_url,permalink,caption',
			'access_token' => $this->get_insta_access_token(),
			'limit'        => $images_count,
		], $url );

		return $url;
	}

	/**
	 * Get data from response
	 *
	 * @param  $response
	 * @since  2.2.6
	 *
	 * @return array
	 */
	public function get_insta_feed_response_data( $response ) {
		$settings = $this->get_settings_for_display();

		if ( ! array_key_exists( 'data', $response ) ) { // Avoid PHP notices
			return;
		}

		$response_posts = $response['data'];

		if ( empty( $response_posts ) ) {
			return [];
		}

		$return_data  = [];
		$images_count = ! empty( $settings['images_count']['size'] ) ? $settings['images_count']['size'] : 5;
		$posts = array_slice( $response_posts, 0, $images_count, true );

		foreach ( $posts as $post ) {
			$_post              = [];

			$_post['id']        = $post['id'];
			$_post['link']      = $post['permalink'];
			$_post['caption']   = '';
			$_post['image']     = 'VIDEO' === $post['media_type'] ? $post['thumbnail_url'] : $post['media_url'];

			if ( ! empty( $post['caption'] ) ) {
				$_post['caption'] = wp_html_excerpt( $post['caption'], $this->get_settings_for_display( 'insta_caption_length' ), '&hellip;' );
			}

			$return_data[] = $_post;
		}

		return $return_data;
	}

	/**
	 * Retrieve response from API
	 *
	 * @since  2.2.6
	 * @return array|WP_Error
	 */
	public function get_insta_remote( $url ) {
		$response       = wp_remote_get( $url, [
			// This call blocks page rendering, so it must not be allowed to hang.
			// TLS verification is left at WordPress's default of on: the URL carries
			// the account's access token, so an unverified connection would hand it
			// to anyone able to present a certificate for graph.instagram.com.
			'timeout' => 10,
		] );

		$response_code  = wp_remote_retrieve_response_code( $response );
		$result         = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $response_code ) {
			$message = is_array( $result ) && isset( $result['error']['message'] ) ? $result['error']['message'] : esc_html__( 'No posts found', 'powerpack' );

			return new \WP_Error( $response_code, $message );
		}

		if ( ! is_array( $result ) ) {
			return new \WP_Error( 'error', esc_html__( 'Data Error', 'powerpack' ) );
		}

		return $result;
	}

	/**
	 * Get transient key.
	 *
	 * @since  2.2.6
	 * @return string
	 */
	public function get_transient_key() {
		$settings = $this->get_settings_for_display();

		$insta_caption_length = ( $settings['insta_caption_length'] ) ? $settings['insta_caption_length'] : 30;
		$images_count = ! empty( $settings['images_count']['size'] ) ? $settings['images_count']['size'] : 5;

		/*
		 * The token is part of the key: without it two widgets pointing at
		 * different Instagram accounts share a cache entry whenever their image
		 * count and caption length match, and whichever renders first decides
		 * which account both of them show. Hashed so no credential is stored in
		 * the option name.
		 */
		$token = substr( md5( (string) $this->get_insta_access_token() ), 0, 12 );

		return sprintf( 'ppe_instagram_feed_users_posts_count_%s_caption_%s_token_%s',
			$images_count,
			$insta_caption_length,
			$token
		);
	}

	/**
	 * Render Title Icon.
	 *
	 * @since  2.3.2
	 */
	public function render_title_icon() {
		$settings = $this->get_settings_for_display();

		if ( ! isset( $settings['insta_title_icon'] ) && ! Icons_Manager::is_migration_allowed() ) {
			// add old default
			$settings['insta_title_icon'] = 'fa fa-instagram';
		}

		$has_icon = ! empty( $settings['insta_title_icon'] );

		if ( $has_icon ) {
			$this->add_render_attribute( 'i', 'class', $settings['insta_title_icon'] );
			$this->add_render_attribute( 'i', 'aria-hidden', 'true' );
		}

		if ( ! $has_icon && ! empty( $settings['title_icon']['value'] ) ) {
			$has_icon = true;
		}
		$migrated = isset( $settings['__fa4_migrated']['title_icon'] );
		$is_new   = ! isset( $settings['insta_title_icon'] ) && Icons_Manager::is_migration_allowed();

		if ( $has_icon ) {
			?>
			<span <?php $this->print_render_attribute_string( 'title-icon' ); ?>>
				<?php
				if ( $is_new || $migrated ) {
					Icons_Manager::render_icon( $settings['title_icon'], [ 'aria-hidden' => 'true' ] );
				} elseif ( ! empty( $settings['insta_title_icon'] ) ) {
					?>
					<i <?php $this->print_render_attribute_string( 'i' ); ?>></i>
					<?php
				}
				?>
			</span>
			<?php
		}
	}

	/**
	 * Render Instagram profile link.
	 *
	 * @since  2.2.6
	 * @param  array $settings
	 * @return array
	 */
	public function get_insta_profile_link() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'title-icon', 'class', 'pp-icon pp-icon-' . $settings['insta_title_icon_position'] );

		$this->add_render_attribute( 'instagram-profile-link', 'class', 'pp-instagram-feed-title' );

		if ( 'yes' === $settings['insta_profile_link'] && $settings['insta_link_title'] ) {
			// An anchor with no href is neither focusable nor a link, so the title is plain text when the URL is cleared.
			$tag = ! empty( $settings['insta_profile_url']['url'] ) ? 'a' : 'span';
			?>
			<span class="pp-instagram-feed-title-wrap">
				<<?php echo esc_html( $tag ); ?> <?php $this->print_render_attribute_string( 'instagram-profile-link' ); ?>>
					<?php
					if ( 'before_title' === $settings['insta_title_icon_position'] ) {
						$this->render_title_icon();
					}

					echo esc_html( $settings['insta_link_title'] );

					if ( 'after_title' === $settings['insta_title_icon_position'] ) {
						$this->render_title_icon();
					}

					if ( 'a' === $tag && ! empty( $settings['insta_profile_url']['is_external'] ) ) {
						echo $this->get_new_tab_notice_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					}
					?>
				</<?php echo esc_html( $tag ); ?>>
			</span>
			<?php
		}
	}

	/**
	 * Get the feed cache duration, in seconds.
	 *
	 * Maps the Cache Timeout control to a transient expiry. Returns 0 when
	 * caching is switched off.
	 *
	 * @since 2.8.0
	 * @access protected
	 *
	 * @return int
	 */
	protected function get_cache_duration() {
		$settings = $this->get_settings_for_display();
		$cache_duration = $settings['cache_timeout'];
		$duration = 0;

		switch ( $cache_duration ) {
			case 'minute':
				$duration = MINUTE_IN_SECONDS;
				break;
			case 'hour':
				$duration = HOUR_IN_SECONDS;
				break;
			case 'day':
				$duration = DAY_IN_SECONDS;
				break;
			case 'week':
				$duration = WEEK_IN_SECONDS;
				break;
			default:
				break;
		}

		return $duration;
	}

	/**
	 * Retrieve Instagram posts.
	 *
	 * @since  2.2.6
	 * @return array|\WP_Error
	 */
	public function get_insta_posts() {
		$settings      = $this->get_settings_for_display();
		$transient_key = md5( $this->get_transient_key() );
		$error_key     = $transient_key . '_error';
		$duration      = $this->get_cache_duration();

		if ( $duration ) {
			$data = get_transient( $transient_key );

			if ( ! empty( $data ) ) {
				return $data;
			}
		}

		/*
		 * Failures are cached even when feed caching is switched off. Instagram
		 * tokens expire every 60 days, and without this a dead token means a
		 * blocking API call on every single uncached page view. The editor skips
		 * the short-circuit so a corrected token takes effect immediately.
		 */
		if ( ! PP_Helper::is_edit_mode() ) {
			$error = get_transient( $error_key );

			if ( ! empty( $error ) ) {
				return new \WP_Error( 'pp_instafeed_cached_error', $error );
			}
		}

		$response = $this->get_insta_remote( $this->get_fetch_url() );

		if ( is_wp_error( $response ) ) {
			set_transient( $error_key, $response->get_error_message(), self::ERROR_CACHE_DURATION );

			return $response;
		}

		$data = $this->get_insta_feed_response_data( $response );

		if ( empty( $data ) ) {
			set_transient( $error_key, esc_html__( 'No posts found', 'powerpack' ), self::ERROR_CACHE_DURATION );

			return [];
		}

		delete_transient( $error_key );

		/*
		 * set_transient() with an expiry of 0 means "never expires", and WordPress
		 * stores those as an autoloaded option — so writing here with caching off
		 * would add an autoloaded blob of feed JSON and rewrite it on every render.
		 */
		if ( $duration ) {
			set_transient( $transient_key, $data, $duration );
		}

		return $data;
	}

	/**
	 * Render promo box widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( '' !== $settings['access_token'] ) {
			if ( $this->get_insta_global_access_token() !== $settings['access_token'] ) {
				$access_token = $this->get_insta_access_token();
				$widget_id    = $this->get_id();

				\PowerpackElements\Classes\PP_Admin_Settings::refresh_instagram_access_token( $access_token, $widget_id );
			}
		}

		if ( 'carousel' === $settings['feed_layout'] ) {
			$layout = 'carousel';
		} else {
			$layout = 'grid';
		}

		$this->add_render_attribute(
			'insta-feed-wrap',
			'class',
			[
				'pp-instagram-feed',
				'pp-instagram-feed-' . $layout,
			]
		);

		if ( 'hover' === $settings['content_visibility'] ) {
			$this->add_render_attribute( 'insta-feed-wrap', 'class', 'pp-instagram-feed-hover' );
		}

		if ( 'yes' === $settings['insta_image_grayscale'] ) {
			$this->add_render_attribute( 'insta-feed-wrap', 'class', 'pp-instagram-feed-gray' );
		}

		if ( 'yes' === $settings['insta_image_grayscale_hover'] ) {
			$this->add_render_attribute( 'insta-feed-wrap', 'class', 'pp-instagram-feed-hover-gray' );
		}

		if ( 'masonry' !== $settings['feed_layout'] && 'yes' === $settings['square_images'] ) {
			$this->add_render_attribute( 'insta-feed-wrap', 'class', 'pp-if-square-images' );
		}

		$this->add_render_attribute( 'insta-feed-container', 'class', 'pp-instafeed' );

		$this->add_render_attribute(
			'insta-feed',
			[
				'id'    => 'pp-instafeed-' . esc_attr( $this->get_id() ),
				'class' => 'pp-instafeed-grid',
			]
		);

		if ( 'masonry' === $settings['feed_layout'] ) {
			$this->add_render_attribute( 'insta-feed', 'class', 'pp-instafeed-masonry' );
		}

		if ( 'carousel' === $settings['feed_layout'] ) {
			$this->add_render_attribute(
				[
					'container-wrap'     => [
						'class' => [
							'pp-insta-feed-inner',
							'swiper-container-wrap',
						],
					],
					'insta-feed-container' => [
						'class' => [
							'pp-swiper-slider',
							'swiper'
						],
					],
					'insta-feed'           => [
						'class' => [
							'swiper-wrapper',
						],
					],
				]
			);

			$slider_options = $this->get_swiper_slider_settings( $settings, false );

			/*
			 * Swiper 8 registers its a11y module with enabled:true, so without this flag the
			 * arrows, bullets and slides are already named, in Swiper's own hardcoded English,
			 * which addElLabel() writes straight over the translated aria-label rendered in PHP.
			 * The flag swaps in PP_Helper::get_carousel_a11y_strings().
			 */
			$slider_options['a11y'] = 'yes';

			// The region holds the slides, the dots, the arrows and the status message.
			$this->add_render_attribute(
				'container-wrap',
				[
					'role'                 => 'region',
					'aria-roledescription' => esc_attr__( 'carousel', 'powerpack' ),
					'aria-label'           => esc_attr__( 'Instagram feed', 'powerpack' ),
				]
			);

			$this->add_render_attribute(
				'insta-feed-container',
				[
					'data-slider-settings' => wp_json_encode( $slider_options ),
				]
			);

			if ( 'right' === $settings['direction'] ) {
				$this->add_render_attribute( 'insta-feed-container', 'dir', 'rtl' );
			}
		}

		if ( ! empty( $settings['insta_profile_url']['url'] ) ) {
			$this->add_link_attributes( 'instagram-profile-link', $settings['insta_profile_url'] );
		}

		$this->render_api_images();
	}

	/**
	 * Render load more button output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  2.2.6
	 * @access protected
	 */
	protected function render_api_images() {
		$settings = $this->get_settings_for_display();

		$gallery = $this->get_insta_posts();

		if ( empty( $gallery ) || is_wp_error( $gallery ) ) {
			$placeholder = sprintf(
				/* translators: %1$s: widget title */
				esc_html__( 'Click here to edit the "%1$s" settings and change the source of photos.', 'powerpack' ),
				esc_html( $this->get_title() )
			);

			// Surface what the API actually said — otherwise an expired token looks
			// identical to an empty account. Editor-only, so nothing leaks publicly.
			if ( is_wp_error( $gallery ) ) {
				$placeholder = esc_html( $gallery->get_error_message() ) . ' ' . $placeholder;
			}

			$this->render_editor_placeholder(
				[
					'title' => esc_html__( 'No Posts Found!', 'powerpack' ),
					'body' => $placeholder,
				]
			);

			return;
		}

		$is_carousel = 'carousel' === $settings['feed_layout'];
		$total       = count( $gallery );

		// The carousel's slides are groups inside a region; the grid and masonry are a plain list of posts.
		if ( ! $is_carousel ) {
			$this->add_render_attribute( 'insta-feed', 'role', 'list' );
		}
		?>
		<div <?php $this->print_render_attribute_string( 'insta-feed-wrap' ); ?>>
			<?php if ( $is_carousel ) : ?>
			<div <?php $this->print_render_attribute_string( 'container-wrap' ); ?>>
			<?php endif; ?>
				<div <?php $this->print_render_attribute_string( 'insta-feed-container' ); ?>>
					<?php $this->get_insta_profile_link(); ?>
					<div <?php $this->print_render_attribute_string( 'insta-feed' ); ?>>
						<?php
						foreach ( $gallery as $index => $item ) {
							$item_key = $this->get_repeater_setting_key( 'item', 'insta_images', $index );
							$this->add_render_attribute( $item_key, 'class', 'pp-feed-item' );

							if ( $is_carousel ) {
								$this->add_render_attribute(
									$item_key,
									[
										'class'                => 'swiper-slide',
										// aria-roledescription is ignored on a generic div, so the group role has to come with it.
										'role'                 => 'group',
										'aria-roledescription' => esc_attr__( 'slide', 'powerpack' ),
										/* translators: 1: slide number, 2: total slides */
										'aria-label'           => sprintf( esc_html__( 'Slide %1$s of %2$s', 'powerpack' ), $index + 1, $total ),
									]
								);
							} else {
								$this->add_render_attribute( $item_key, 'role', 'listitem' );
							}
							?>
							<figure <?php $this->print_render_attribute_string( $item_key ); ?>>
								<?php $this->render_image_thumbnail( $item, $index, $settings ); ?>
							</figure>
							<?php
						}
						?>
					</div>
				</div>
				<?php
				$this->render_dots();

				$this->render_arrows();

				if ( $is_carousel ) {
					printf(
						'<div class="elementor-screen-only" aria-live="polite" aria-atomic="true" id="pp-instafeed-status-%1$s">%2$s</div>',
						esc_attr( $this->get_id() ),
						esc_html( PP_Helper::get_slide_status_text( 1, $total ) )
					);
				}
				?>
			<?php if ( $is_carousel ) : ?>
			</div>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Render Image Thumbnail
	 *
	 * @since  2.2.6
	 *
	 * @param array $item     Feed item.
	 * @param int   $index    Zero-based position in the feed.
	 * @param array $settings Widget settings, hoisted out of the render loop.
	 * @return void
	 */
	protected function render_image_thumbnail( $item, $index, $settings ) {
		$thumbnail_url = $this->get_insta_image_url( $item );
		$caption       = $item['caption'];
		$image_key     = $this->get_repeater_setting_key( 'image', 'insta', $index );
		$link_key      = $this->get_repeater_setting_key( 'link', 'image', $index );
		$caption_shown = ( 'yes' === $settings['insta_caption'] && '' !== $caption );
		$has_link      = ( 'yes' === $settings['insta_image_popup'] || 'yes' === $settings['insta_image_link'] );
		$item_link     = '';
		$new_tab       = '';

		/*
		 * URLs arrive from the Instagram API, so filter protocols at the source
		 * rather than relying on the kses pass further down. esc_url_raw() is the
		 * non-display variant: Elementor escapes for output when it prints the tag.
		 *
		 * The caption is the only text Instagram gives us, so it is either the image's
		 * alt or the visible caption, never both: inside one link the two are joined
		 * into the link's name and read twice. A post with no caption still gets an
		 * explicit empty alt, so the image is not announced as its CDN filename.
		 *
		 * No title attribute: it repeated the alt word for word, and only a mouse could reach it.
		 */
		$this->add_render_attribute( $image_key, [
			'src'      => esc_url_raw( $thumbnail_url ),
			'alt'      => $caption_shown ? '' : $caption,
			'decoding' => 'async',
		] );

		if ( $index >= $this->get_eager_image_count( $settings ) ) {
			$this->add_render_attribute( $image_key, 'loading', 'lazy' );
		}

		if ( 'yes' === $settings['insta_image_popup'] ) {
			$item_link = $thumbnail_url;

			$this->add_render_attribute( $link_key, [
				'data-elementor-open-lightbox'      => 'yes',
				'data-elementor-lightbox-title'     => $caption,
				'data-elementor-lightbox-slideshow' => 'pp-ig-' . $this->get_id(),
				// The link opens Elementor's lightbox dialog rather than navigating.
				'aria-haspopup'                     => 'dialog',
			] );
		} elseif ( 'yes' === $settings['insta_image_link'] ) {
			$item_link = $item['link'];

			$this->add_render_attribute( $link_key, [
				'target' => '_blank',
				'rel'    => 'noopener noreferrer',
			] );

			// Nothing else tells a screen reader user that the tab is about to change.
			$new_tab = $this->get_new_tab_notice_html();
		}

		if ( $has_link ) {
			$this->add_render_attribute( $link_key, [
				'href'  => esc_url_raw( $item_link ),
				'class' => 'pp-if-img',
			] );

			// With no caption the link holds nothing but a decorative image, so it would be announced as its URL.
			if ( '' === $caption ) {
				$this->add_render_attribute(
					$link_key,
					'aria-label',
					/* translators: %d: position of the post in the feed */
					sprintf( esc_html__( 'Instagram post %d', 'powerpack' ), $index + 1 )
				);
			}

			$image_html = '<a ' . $this->get_render_attribute_string( $link_key ) . '>';
		} else {
			$image_html = '<div class="pp-if-img">';
		}

		$image_html .= '<div class="pp-overlay-container pp-media-overlay">';
		if ( $caption_shown ) {
			$image_html .= esc_html( $caption );
		}
		$image_html .= '</div>';
		$image_html .= '<img ' . $this->get_render_attribute_string( $image_key ) . '/>';
		$image_html .= $has_link ? $new_tab . '</a>' : '</div>';

		echo wp_kses( $image_html, $this->get_allowed_item_html() );
	}

	/**
	 * Allowed HTML for a feed item.
	 *
	 * The post allowlist, widened by the attributes it omits that this widget
	 * needs. Feed items are remote data, so the markup stays filtered rather than
	 * being printed unchecked to get `decoding` and `aria-haspopup` through.
	 *
	 * @since 3.2.0
	 * @access protected
	 *
	 * @return array
	 */
	protected function get_allowed_item_html() {
		static $allowed = null;

		if ( null === $allowed ) {
			$allowed = wp_kses_allowed_html( 'post' );
			$allowed['img']['decoding']    = true;
			$allowed['a']['aria-haspopup'] = true;
		}

		return $allowed;
	}

	/**
	 * Number of images to load eagerly, i.e. the first visible row.
	 *
	 * Lazy-loading an above-the-fold image costs LCP, so the first row opts out.
	 *
	 * @since 3.2.0
	 * @access protected
	 *
	 * @param array $settings Widget settings.
	 * @return int
	 */
	protected function get_eager_image_count( $settings ) {
		if ( 'carousel' === $settings['feed_layout'] ) {
			return ! empty( $settings['items']['size'] ) ? absint( $settings['items']['size'] ) : 3;
		}

		return ! empty( $settings['grid_cols'] ) ? absint( $settings['grid_cols'] ) : 5;
	}

	/**
	 * Get Insta Thumbnail Image URL
	 *
	 * The Graph API returns a single URL per item with no size variants, so there
	 * is nothing to choose between.
	 *
	 * @since  2.2.6
	 *
	 * @param array $item Feed item.
	 * @return string The url of the instagram post image
	 */
	protected function get_insta_image_url( $item ) {
		$image_url = isset( $item['image'] ) ? $item['image'] : '';

		return $image_url;
	}

	/**
	 * Render insta feed carousel dots output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render_dots() {
		$settings = $this->get_settings_for_display();

		if ( 'carousel' === $settings['feed_layout'] && 'yes' === $settings['dots'] ) {
			?>
			<!-- Add Pagination -->
			<div class="swiper-pagination swiper-pagination-<?php echo esc_attr( $this->get_id() ); ?>"></div>
			<?php
		}
	}

	/**
	 * Render insta feed carousel arrows output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render_arrows() {
		$settings = $this->get_settings_for_display();

		if ( 'carousel' === $settings['feed_layout'] && 'yes' === $settings['arrows'] ) {
			PP_Helper::render_arrows( $this );
		}
	}
}
