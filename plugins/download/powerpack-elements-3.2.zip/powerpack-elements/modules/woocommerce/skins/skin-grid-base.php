<?php
/**
 * PowerPack WooCommerce Skin Grid - Default.
 *
 * @package PowerPack
 */

namespace PowerpackElements\Modules\Woocommerce\Skins;

use PowerpackElements\Classes\PP_Helper;

use Elementor\Controls_Manager;
use Elementor\Skin_Base;
use Elementor\Icons_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Skin_Grid_Base
 *
 * @property Products $parent
 */
abstract class Skin_Grid_Base extends Skin_Base {

	/**
	 * Holds add to cart button text for simple products.
	 *
	 * @since 2.9.7
	 */
	public static $add_to_cart_text;

	/**
	 * Holds add to cart button text for variable products.
	 *
	 * @since 2.9.7
	 */
	public static $select_options_text;

	/**
	 * Holds add to cart button text for grouped products.
	 *
	 * @since 2.9.7
	 */
	public static $view_products_text;

	/**
	 * Holds read more button text for simple and variable products.
	 *
	 * @since 2.9.7
	 */
	public static $read_more_text;

	/**
	 * Build the icon descriptor for an action icon.
	 *
	 * @since 2.7.7
	 * @access private
	 * @param string $network_name Font Awesome icon name, without the fa- prefix.
	 * @return array Icon value and library, as Icons_Manager expects them.
	 */
	private static function get_network_icon_data( $network_name ) {
		$prefix = 'fa ';
		$library = '';

		if ( Icons_Manager::is_migration_allowed() ) {
			$prefix = 'fas ';
			$library = 'fa-solid';
		}

		return [
			'value' => $prefix . 'fa-' . $network_name,
			'library' => $library,
		];
	}

	/**
	 * Settings the skin renders with during an AJAX request.
	 *
	 * Holds the settings of the widget rebuilt from stored data by
	 * prepare_ajax_render(). Null on a normal render, when get_skin_settings()
	 * reads from the parent widget instead. Instance scoped, so two widgets
	 * rendered in the same request keep their own settings.
	 *
	 * @since 2.4.0
	 * @var array|null
	 */
	private $ajax_settings = null;

	/**
	 * ID of the widget prepare_ajax_render() has already queried for.
	 *
	 * @since 3.2.0
	 * @var string
	 */
	private $ajax_prepared_for = '';

	/**
	 * Settings derived values shared by every item of the loop being rendered.
	 *
	 * Built by render_woo_loop() before it iterates and cleared when the loop
	 * ends, so it lives no longer than the render it belongs to.
	 *
	 * @since 3.2.0
	 * @var array|null
	 */
	private $loop_context = null;

	/**
	 * Get the settings this skin renders with.
	 *
	 * During an AJAX pagination request the widget is rebuilt from stored data and
	 * its settings reach the skin through $this->ajax_settings. Every other render
	 * reads them from the parent widget.
	 *
	 * Reads through get_settings_for_display(), so dynamic tags resolve - the
	 * four Add to Cart text controls accept one. That also means a control whose
	 * condition is not met comes back as null, so every read of a conditional
	 * control is made behind the same condition that gates it.
	 *
	 * The result is not cached here. Elementor memoises it and clears the memo
	 * between loop iterations, which is what lets a dynamic tag resolve afresh
	 * for each post of a Loop Grid.
	 *
	 * @since 3.0.0
	 * @access protected
	 * @return array Widget settings.
	 */
	protected function get_skin_settings() {
		if ( ! empty( $this->ajax_settings ) ) {
			return $this->ajax_settings;
		}

		return $this->parent->get_settings_for_display();
	}

	/**
	 * Point WooCommerce at this widget's pagination template.
	 *
	 * Filter callback for 'wc_get_template', added only while the pagination is
	 * being printed.
	 *
	 * @since 1.3.3
	 * @access public
	 * @param string $located location.
	 * @param string $template_name template name.
	 * @param array  $args arguments.
	 * @param string $template_path path.
	 * @param string $default_path default path.
	 * @return string template location
	 */
	public function woo_pagination_template( $located, $template_name, $args, $template_path, $default_path ) {

		if ( 'loop/pagination.php' === $template_name ) {
			$located = POWERPACK_ELEMENTS_PATH . 'modules/woocommerce/templates/loop/pagination.php';
		}

		return $located;
	}

	/**
	 * Apply the widget's pagination settings to the links.
	 *
	 * Filter callback for 'pp_woocommerce_pagination_args'. Turns the previous
	 * and next arrows on for the arrows pagination type and applies the labels
	 * set on the widget.
	 *
	 * @since 1.3.3
	 * @access public
	 * @param array $args pagination args.
	 * @return array
	 */
	public function woo_pagination_options( $args ) {

		$settings = $this->get_skin_settings();

		$pagination_arrow = false;

		if ( 'numbers_arrow' === $settings['pagination_type'] ) {
			$pagination_arrow = true;
		}

		$args['prev_next'] = $pagination_arrow;

		/*
		 * The visible labels default to bare arrows, which screen readers read as
		 * "leftwards arrow". Hide the glyph and say what the link does instead.
		 *
		 * Both labels belong to the arrows pagination type and are null for any
		 * other, so test for content rather than for an empty string.
		 */
		$prev_label = ! empty( $settings['pagination_prev_label'] ) ? $settings['pagination_prev_label'] : '&larr;';
		$next_label = ! empty( $settings['pagination_next_label'] ) ? $settings['pagination_next_label'] : '&rarr;';

		$args['prev_text'] = '<span aria-hidden="true">' . $prev_label . '</span><span class="elementor-screen-only">' . esc_html__( 'Previous page', 'powerpack' ) . '</span>';
		$args['next_text'] = '<span aria-hidden="true">' . $next_label . '</span><span class="elementor-screen-only">' . esc_html__( 'Next page', 'powerpack' ) . '</span>';

		// A bare "2" link reads as "Page 2".
		$args['before_page_number'] = '<span class="elementor-screen-only">' . esc_html__( 'Page', 'powerpack' ) . ' </span>';

		return $args;
	}

	/**
	 * Attach the Swiper options to the wrapper as JSON.
	 *
	 * Read by frontend-woo-product.js from the data-woo_slider attribute. Does
	 * nothing outside the carousel layout.
	 *
	 * @since 1.3.3
	 * @access public
	 */
	public function set_slider_attr() {

		$settings = $this->get_skin_settings();

		if ( 'slider' !== $settings['products_layout_type'] ) {
			return;
		}

		$responsive = $this->get_slider_responsive_options( $settings );

		$slider_options = [
			'direction'             => 'horizontal',
			'slidesPerView'         => $responsive['desktop']['slidesPerView'],
			'slidesPerGroup'        => $responsive['desktop']['slidesPerGroup'],
			'speed'                 => ( $settings['transition_speed'] ) ? absint( $settings['transition_speed'] ) : 400,
			'spaceBetween'          => $responsive['desktop']['spaceBetween'],
			'loop'                  => ( 'yes' === $settings['infinite'] ),
			'grabCursor'            => ( 'yes' === $settings['grab_cursor'] ),
			'autoHeight'            => true,
			'watchSlidesVisibility' => true,
			'observer'              => true,
			'observeParents'        => true,
		];

		if ( 'yes' === $settings['autoplay'] ) {
			// Swiper reads both of these from inside the autoplay object; at the
			// top level of the config it ignores them.
			$slider_options['autoplay'] = [
				'delay'                => ! empty( $settings['autoplay_speed'] ) ? absint( $settings['autoplay_speed'] ) : 2000,
				'pauseOnMouseEnter'    => ( 'yes' === $settings['pause_on_hover'] ),
				'disableOnInteraction' => false,
			];
		} else {
			$slider_options['autoplay'] = false;
		}

		if ( 'yes' === $settings['arrows'] ) {
			$slider_options['navigation'] = [
				'nextEl' => '.swiper-button-next-' . esc_attr( $this->parent->get_id() ),
				'prevEl' => '.swiper-button-prev-' . esc_attr( $this->parent->get_id() ),
			];
		}

		if ( 'yes' === $settings['carousel_pagination'] ) {
			$slider_options['pagination'] = [
				'el'        => '.swiper-pagination-' . esc_attr( $this->parent->get_id() ),
				'clickable' => true,
			];
		}

		$slider_options['breakpoints'] = $responsive['breakpoints'];

		$this->parent->add_render_attribute(
			'wrapper', [
				'data-woo_slider' => wp_json_encode( $slider_options ),
			]
		);
	}

	/**
	 * Build the per device carousel options.
	 *
	 * Walks every breakpoint the site has active, so the responsive controls
	 * Elementor generates for custom breakpoints are honoured alongside the
	 * standard desktop, tablet and mobile ones.
	 *
	 * Elementor breakpoints are max-widths and inherit downwards, while Swiper
	 * breakpoints are min-widths. A device therefore starts one pixel above the
	 * next smaller breakpoint, and a device with no value of its own reuses the
	 * value resolved for the next larger one.
	 *
	 * @since 3.0.0
	 * @access protected
	 * @param array $settings Widget settings.
	 * @return array {
	 *     @type array $desktop     Options for the largest device.
	 *     @type array $breakpoints Swiper breakpoints keyed by min-width.
	 * }
	 */
	protected function get_slider_responsive_options( $settings ) {
		$active = PP_Helper::elementor()->breakpoints->get_active_breakpoints();

		// Elementor mixes two kinds of breakpoint. The max-width ones sit below
		// desktop; widescreen is min-width and sits above it.
		$below = [];
		$above = [];

		foreach ( $active as $device => $breakpoint ) {
			if ( 'min' === $breakpoint->get_direction() ) {
				$above[ $device ] = $breakpoint;
			} else {
				$below[ $device ] = $breakpoint;
			}
		}

		// Narrowest to widest, with desktop between the two groups.
		$devices = array_merge( array_keys( $below ), [ 'desktop' ], array_keys( $above ) );

		// Desktop is the base that every other device falls back to. The
		// max-width devices then inherit down from it and widescreen inherits up,
		// which is how Elementor's own responsive values cascade.
		$resolved = [];
		$base     = [
			'slidesPerView'  => $this->get_slider_number( $settings, 'slides_to_show', 'desktop', 4 ),
			'slidesPerGroup' => $this->get_slider_number( $settings, 'slides_to_scroll', 'desktop', 1 ),
			'spaceBetween'   => $this->get_slider_size( $settings, 'column_gap', 'desktop', 10 ),
		];

		$resolved['desktop'] = $base;

		$chains = [
			array_reverse( array_keys( $below ) ), // Widest max-width device first.
			array_keys( $above ),                  // Narrowest min-width device first.
		];

		foreach ( $chains as $chain ) {
			$inherited = $base;

			foreach ( $chain as $device ) {
				$inherited = [
					'slidesPerView'  => $this->get_slider_number( $settings, 'slides_to_show', $device, $inherited['slidesPerView'] ),
					'slidesPerGroup' => $this->get_slider_number( $settings, 'slides_to_scroll', $device, $inherited['slidesPerGroup'] ),
					'spaceBetween'   => $this->get_slider_size( $settings, 'column_gap', $device, $inherited['spaceBetween'] ),
				];

				$resolved[ $device ] = $inherited;
			}
		}

		$breakpoints = [];
		$min_width   = 0;

		foreach ( $devices as $device ) {
			if ( isset( $above[ $device ] ) ) {
				// A min-width breakpoint starts at its own value.
				$min_width = $above[ $device ]->get_value();
			}

			$breakpoints[ $min_width ] = $resolved[ $device ];

			if ( isset( $below[ $device ] ) ) {
				// A max-width breakpoint hands over one pixel later.
				$min_width = $below[ $device ]->get_value() + 1;
			}
		}

		return [
			'desktop'     => $resolved['desktop'],
			'breakpoints' => $breakpoints,
		];
	}

	/**
	 * Read one device's value from a responsive number control.
	 *
	 * @since 3.0.0
	 * @access protected
	 * @param array  $settings Widget settings.
	 * @param string $key      Base control name.
	 * @param string $device   Device name, or 'desktop' for the base key.
	 * @param int    $fallback Value to inherit when this device sets none.
	 * @return int
	 */
	protected function get_slider_number( $settings, $key, $device, $fallback ) {
		$setting_key = ( 'desktop' === $device ) ? $key : $key . '_' . $device;

		// Custom breakpoint variants only exist once that breakpoint is enabled.
		if ( ! empty( $settings[ $setting_key ] ) ) {
			return absint( $settings[ $setting_key ] );
		}

		return $fallback;
	}

	/**
	 * Read one device's size from a responsive slider control.
	 *
	 * @since 3.0.0
	 * @access protected
	 * @param array  $settings Widget settings.
	 * @param string $key      Base control name.
	 * @param string $device   Device name, or 'desktop' for the base key.
	 * @param int    $fallback Value to inherit when this device sets none.
	 * @return int
	 */
	protected function get_slider_size( $settings, $key, $device, $fallback ) {
		$setting_key = ( 'desktop' === $device ) ? $key : $key . '_' . $device;

		if ( ! empty( $settings[ $setting_key ]['size'] ) ) {
			return absint( $settings[ $setting_key ]['size'] );
		}

		return $fallback;
	}

	/**
	 * Run the products query for this render.
	 *
	 * @since 1.1.0
	 * @access public
	 */
	public function render_query() {

		$settings = $this->get_skin_settings();

		$this->parent->query_posts( $settings );
	}

	/**
	 * Set the WooCommerce loop properties for this render.
	 *
	 * WooCommerce reads the column count from these when it opens the product
	 * list, and the page count and current page when it prints the pagination.
	 *
	 * @since 1.1.0
	 * @access public
	 */
	public function render_loop_args() {

		$query = $this->parent->get_query();

		global $woocommerce_loop;

		$settings = $this->get_skin_settings();

		if ( 'grid' === $settings['products_layout_type'] ) {
			$woocommerce_loop['columns'] = (int) $settings['products_columns'];

			if ( 'main' !== $settings['source'] ) {
				if ( '' !== $settings['pagination_type'] ) {
					/* Pagination */
					// Resolved the same way query_posts() resolves them, so the page
					// count and the current page describe the products on screen.
					// Upsells and cross-sells allow an unlimited page size because
					// their post__in already bounds the query.
					$paged = $this->parent->get_current_page();

					$allow_all = in_array( $settings['source'], [ 'upsells', 'cross_sells' ], true );
					$per_page  = $this->parent->get_products_per_page( $settings, $allow_all );

					$woocommerce_loop['paged']        = $paged;
					$woocommerce_loop['total']        = $query->found_posts;
					$woocommerce_loop['post_count']   = $query->post_count;
					$woocommerce_loop['per_page']     = $per_page;
					$woocommerce_loop['total_pages']  = ( $per_page > 0 ) ? ceil( $query->found_posts / $per_page ) : 1;
					$woocommerce_loop['current_page'] = $paged;
				}
			}

			// pp-woocommerce.css styles the column count from both this wrapper
			// and the list inside it, through .pp-woo-products-inner[class*=columns-]
			// and ul.products.columns-N, so the class goes on both.
			$this->parent->add_render_attribute(
				'inner', [
					'class' => [
						'columns-' . $woocommerce_loop['columns'],
					],
				]
			);
		}
	}

	/**
	 * Print the pagination links below a paginated grid.
	 *
	 * WooCommerce's own pagination template is swapped for this widget's while it
	 * runs, so the markup and the previous and next labels come from here.
	 *
	 * @since 1.1.0
	 * @access public
	 */
	public function render_pagination_structure() {

		$settings = $this->get_skin_settings();

		if ( 'grid' === $settings['products_layout_type'] ) {
			if ( '' !== $settings['pagination_type'] ) {
				add_filter( 'wc_get_template', [ $this, 'woo_pagination_template' ], 10, 5 );
				add_filter( 'pp_woocommerce_pagination_args', [ $this, 'woo_pagination_options' ] );
				woocommerce_pagination();
				remove_filter( 'pp_woocommerce_pagination_args', [ $this, 'woo_pagination_options' ] );
				remove_filter( 'wc_get_template', [ $this, 'woo_pagination_template' ], 10, 5 );
			}
		}
	}

	/**
	 * Open the widget wrapper.
	 *
	 * Carries the layout, skin and query source classes, the ids the pagination
	 * script posts back, and, for a carousel, the Swiper options as JSON.
	 *
	 * @since 1.1.0
	 * @access public
	 */
	public function render_wrapper_start() {
		global $product;

		$settings = $this->get_skin_settings();

		$skin = $this->get_id();
		$page_id = 0;

		if ( null !== \Elementor\Plugin::$instance->documents->get_current() ) {
			$page_id = \Elementor\Plugin::$instance->documents->get_current()->get_main_id();
		}

		// is_product() describes the query; the global is only populated once
		// WooCommerce has set up the product, so both are checked.
		$product_id = ( is_product() && $product instanceof \WC_Product ) ? $product->get_id() : 0;

		$this->parent->add_render_attribute(
			'wrapper', [
				'class' => [
					'pp-woocommerce',
					'pp-woo-products-' . $settings['products_layout_type'],
					'pp-woo-skin-' . $this->get_id(),
					'pp-woo-query-' . $settings['source'],
				],
				'data-page'        => $page_id,
				'data-skin'        => $skin,
				'data-product-id' => $product_id,
			]
		);

		if ( 'slider' === $settings['products_layout_type'] ) {
			$this->parent->add_render_attribute( 'wrapper', 'class', 'swiper-container-wrap' );

			if ( $settings['dots_position'] ) {
				$this->parent->add_render_attribute( 'wrapper', 'class', 'swiper-container-wrap-dots-' . $settings['dots_position'] );
			}

			// The region wraps the arrows and dots too, so they are announced as
			// part of the carousel they control.
			$this->parent->add_render_attribute(
				'wrapper', [
					'role'                 => 'region',
					'aria-roledescription' => __( 'carousel', 'powerpack' ),
					'aria-label'           => __( 'Products', 'powerpack' ),
				]
			);
		}

		$this->set_slider_attr();

		// The attribute list is escaped value by value as it is built, so it is
		// printed as it stands.
		echo '<div ';
		$this->parent->print_render_attribute_string( 'wrapper' );
		echo '>';
	}

	/**
	 * Close the widget wrapper.
	 *
	 * @since 1.1.0
	 * @access public
	 */
	public function render_wrapper_end() {
		echo '</div>';
	}

	/**
	 * Open the container that holds the product list.
	 *
	 * Doubles as the Swiper root in the carousel layout, and carries the image
	 * hover effect class.
	 *
	 * @since 1.1.0
	 * @access public
	 */
	public function render_inner_start() {
		$settings = $this->get_skin_settings();

		// Column widths come from the elementor-grid%s- prefix class on the widget
		// and the columns-N class render_loop_args() adds below, so this wrapper
		// only carries the widget's own classes.
		$this->parent->add_render_attribute(
			'inner', [
				'class' => [
					'pp-woo-products-inner',
				],
			]
		);

		if ( '' !== $settings['products_hover_style'] ) {
			$this->parent->add_render_attribute(
				'inner', [
					'class' => [
						'pp-woo-product__hover-' . $settings['products_hover_style'],
					],
				]
			);
		}

		if ( 'slider' === $settings['products_layout_type'] ) {
			$this->parent->add_render_attribute(
				'inner', [
					'class' => [
						'pp-swiper-slider',
						'swiper'
					],
				]
			);

			if ( is_rtl() ) {
				$this->parent->add_render_attribute( 'inner', 'dir', 'rtl' );
			}
		}

		// Escaped value by value as it is built; see render_wrapper_start().
		echo '<div ';
		$this->parent->print_render_attribute_string( 'inner' );
		echo '>';
	}

	/**
	 * Close the container that holds the product list.
	 *
	 * @since 1.1.0
	 * @access public
	 */
	public function render_inner_end() {
		echo '</div>';
	}

	/**
	 * Render the live region that announces a page loaded by AJAX pagination.
	 *
	 * Printed with the first render and left alone by the AJAX response, so it is
	 * already in the accessibility tree when its text changes. Screen readers
	 * often ignore a live region inserted at the moment it speaks.
	 *
	 * @since 3.1.0
	 * @access public
	 */
	public function render_pagination_status() {
		$settings = $this->get_skin_settings();

		// Main query pagination reloads the page, so there is nothing to announce.
		if ( 'grid' !== $settings['products_layout_type'] || '' === $settings['pagination_type'] || 'main' === $settings['source'] ) {
			return;
		}
		?>
		<div class="pp-woo-products-status elementor-screen-only" role="status" aria-live="polite" aria-atomic="true"></div>
		<?php
	}

	/**
	 * Open the product list element.
	 *
	 * @since 1.1.0
	 * @access public
	 */
	public function render_woo_loop_start() {
		$settings = $this->get_skin_settings();

		include POWERPACK_ELEMENTS_PATH . 'modules/woocommerce/templates/loop/loop-start.php';
	}

	/**
	 * Swap the add to cart label for the one set on the widget.
	 *
	 * Filter callback for 'woocommerce_product_add_to_cart_text', added only
	 * while the loop runs.
	 *
	 * @since 2.9.7
	 * @access public
	 * @param string     $text    Default button text.
	 * @param WC_Product $product Product being rendered.
	 * @return string Button text.
	 */
	public function add_to_cart_button_text( $text, $product ) {
		if ( 'simple' === $product->get_type() ) {
			$text = $product->is_purchasable() && $product->is_in_stock() ? self::$add_to_cart_text : self::$read_more_text;
		}

		if ( 'variable' === $product->get_type() ) {
			$text = $product->is_purchasable() ? self::$select_options_text : self::$read_more_text;
		}

		if ( 'grouped' === $product->get_type() ) {
			$text = self::$view_products_text;
		}

		return $text;
	}

	/**
	 * Keep the add to cart aria-label in step with the text set on the widget.
	 *
	 * WooCommerce builds the loop button's aria-label from its own wording, so a
	 * button relabelled "Buy now" was still announced as "Add to cart", and voice
	 * control users could not activate it by the name they could see (WCAG 2.5.3).
	 *
	 * Filter callback for 'woocommerce_product_add_to_cart_description', added
	 * only while the loop runs.
	 *
	 * @since 3.1.0
	 * @access public
	 * @param string     $description Default aria-label.
	 * @param WC_Product $product     Product being rendered.
	 * @return string Aria-label.
	 */
	public function add_to_cart_button_description( $description, $product ) {
		return $this->get_action_label( $product->add_to_cart_text(), $product );
	}

	/**
	 * Build the accessible name of a product action.
	 *
	 * Starts with the visible text, so the name still contains the label a voice
	 * control user reads off the screen, then names the product so a list of
	 * "Quick View" buttons can be told apart.
	 *
	 * @since 3.1.0
	 * @access public
	 * @param string     $text    Visible button text.
	 * @param WC_Product $product Product the action belongs to.
	 * @return string Unescaped label.
	 */
	public function get_action_label( $text, $product ) {
		return sprintf(
			/* translators: 1: button text, for example "Quick View". 2: product name. */
			__( '%1$s: %2$s', 'powerpack' ),
			wp_strip_all_tags( $text ),
			wp_strip_all_tags( $product->get_name() )
		);
	}

	/**
	 * Get the message WooCommerce announces once a product is added to the cart.
	 *
	 * WooCommerce's add to cart script only speaks when the clicked button carries
	 * data-success_message, which the loop template adds but the skins' own
	 * action links did not.
	 *
	 * @since 3.1.0
	 * @access public
	 * @param WC_Product $product Product being rendered.
	 * @return string Unescaped message, or an empty string before WooCommerce 9.
	 */
	public function get_add_to_cart_success_message( $product ) {
		return method_exists( $product, 'add_to_cart_success_message' ) ? $product->add_to_cart_success_message() : '';
	}

	/**
	 * Render every product in the query.
	 *
	 * The Add to Cart label filter is added around the loop only when the widget
	 * overrides the button text, so it never affects anything else on the page.
	 *
	 * @since 1.1.0
	 * @access public
	 */
	public function render_woo_loop() {
		$settings = $this->get_skin_settings();

		$query = $this->parent->get_query();

		if ( 'yes' === $settings['show_add_cart'] && 'yes' === $settings['change_add_to_cart_text'] ) {
			self::$add_to_cart_text = $settings['add_to_cart_simple_text'] ? $settings['add_to_cart_simple_text'] : esc_html__( 'Add to cart', 'powerpack' );
			self::$select_options_text = $settings['add_to_cart_variable_text'] ? $settings['add_to_cart_variable_text'] : esc_html__( 'Select options', 'powerpack' );
			self::$view_products_text = $settings['add_to_cart_group_text'] ? $settings['add_to_cart_group_text'] : esc_html__( 'View products', 'powerpack' );
			self::$read_more_text = $settings['add_to_cart_read_more_text'] ? $settings['add_to_cart_read_more_text'] : esc_html__( 'Read more', 'powerpack' );

			add_filter( 'woocommerce_product_add_to_cart_text', [ $this, 'add_to_cart_button_text' ], 10, 2 );
			add_filter( 'woocommerce_product_add_to_cart_description', [ $this, 'add_to_cart_button_description' ], 10, 2 );
		}

		// Built once here rather than per product inside the item template.
		$this->loop_context = $this->build_loop_context( $settings );

		while ( $query->have_posts() ) :
			$query->the_post();
			$this->render_woo_loop_template();
		endwhile;

		$this->loop_context = null;

		if ( 'yes' === $settings['show_add_cart'] && 'yes' === $settings['change_add_to_cart_text'] ) {
			remove_filter( 'woocommerce_product_add_to_cart_text', [ $this, 'add_to_cart_button_text' ], 10, 2 );
			remove_filter( 'woocommerce_product_add_to_cart_description', [ $this, 'add_to_cart_button_description' ], 10, 2 );
		}
	}

	/**
	 * Resolve the values every product in the loop shares.
	 *
	 * The item template is included once per product, so anything derived from
	 * the settings alone is worked out here instead and handed to all of them:
	 * the badge positions, the Quick View label, the thumbnail size and whether
	 * YITH Wishlist is available. The YITH check is the one worth hoisting - on a
	 * store without the plugin, class_exists() walks the registered autoloaders
	 * on every call.
	 *
	 * Called once by render_woo_loop(); reachable through get_loop_context().
	 *
	 * The 'pp_woo_out_of_stock_string' and 'pp_woo_products_content_structure'
	 * filters stay in the per product path so they keep firing once per product.
	 *
	 * @since 3.2.0
	 * @access protected
	 * @param array $settings Widget settings.
	 * @return array Context shared by every item in the loop.
	 */
	protected function build_loop_context( $settings ) {
		$image_size = $settings['thumbnail_size'];

		if ( 'custom' === $image_size ) {
			$custom_image_size = $settings['thumbnail_custom_dimension'];
			$image_size        = [ $custom_image_size['width'], $custom_image_size['height'] ];
		}

		if ( ! $image_size ) {
			$image_size = 'woocommerce_thumbnail';
		}

		// ! empty(): the control is conditioned on Quick View being switched on,
		// so it resolves to null while it is off.
		$quick_view_text = $settings['quick_view_text'];

		if ( empty( $quick_view_text ) ) {
			$quick_view_text = esc_html__( 'Quick View', 'powerpack' );
		}

		return [
			'sale_badge_position'         => $settings['sale_badge_position'],
			'featured_badge_position'     => $settings['featured_badge_position'],
			'top_rating_badge_position'   => $settings['top_rating_badge_position'],
			'best_selling_badge_position' => $settings['best_selling_badge_position'],
			'quick_view_type'             => $settings['quick_view_type'],
			'quick_view_text'             => $quick_view_text,
			'image_size'                  => $image_size,
			'has_yith_wishlist'           => class_exists( 'YITH_WCWL' ),
		];
	}

	/**
	 * Get the loop context, building it if the loop did not.
	 *
	 * Returns the context render_woo_loop() built for the current loop, or
	 * builds a fresh one for a caller that renders an item outside the loop.
	 *
	 * @since 3.2.0
	 * @access public
	 * @param array $settings Widget settings.
	 * @return array Context shared by every item in the loop.
	 */
	public function get_loop_context( $settings ) {
		if ( null === $this->loop_context ) {
			return $this->build_loop_context( $settings );
		}

		return $this->loop_context;
	}

	/**
	 * Get the layout class for one product list item.
	 *
	 * Shared by every skin template so the grid and carousel classes cannot
	 * drift apart between them again.
	 *
	 * @since 3.2.0
	 * @access public
	 * @param array $settings Widget settings.
	 * @return string Class to hand to post_class().
	 */
	public function get_product_item_class( $settings ) {
		if ( 'slider' === $settings['products_layout_type'] ) {
			return 'swiper-slide';
		}

		// Elementor's `.elementor-grid .elementor-grid-item` rule sets min-width: 0,
		// which is what keeps a long unbreakable title or SKU from stretching its
		// track past 1fr and overflowing the grid.
		return 'elementor-grid-item';
	}

	/**
	 * Build the list of summary entries for one product.
	 *
	 * The five skins share one summary: category, title, rating, price and short
	 * description, each behind its own toggle. They differ only in whether the
	 * wishlist and the add to cart button belong in the summary or in the actions
	 * bar over the thumbnail, which is what $extras selects.
	 *
	 * Called once per product, so the 'pp_woo_products_content_structure' filter
	 * fires per product.
	 *
	 * @since 3.2.0
	 * @access public
	 * @param array $settings Widget settings.
	 * @param array $extras {
	 *     Entries this skin renders in the summary rather than its actions bar.
	 *
	 *     @type bool $wishlist Include the YITH wishlist button. Default false.
	 *     @type bool $add_cart Include the add to cart button. Default false.
	 * }
	 * @return array Entries for loop/summary-structure.php.
	 */
	public function get_shop_structure( $settings, $extras = [] ) {
		$extras = wp_parse_args(
			$extras,
			[
				'wishlist' => false,
				'add_cart' => false,
			]
		);

		$toggles = [
			'show_category'   => 'category',
			'show_title'      => 'title',
			'show_ratings'    => 'ratings',
			'show_price'      => 'price',
			'show_short_desc' => 'short_desc',
		];

		$shop_structure = [];

		foreach ( $toggles as $setting => $entry ) {
			if ( 'yes' === $settings[ $setting ] ) {
				$shop_structure[] = $entry;
			}
		}

		$context = $this->get_loop_context( $settings );

		// The show_add_to_wishlist control only exists while YITH is active, so
		// the class check guards the settings read.
		if ( $extras['wishlist'] && $context['has_yith_wishlist'] && 'yes' === $settings['show_add_to_wishlist'] ) {
			$shop_structure[] = 'yith_wishlist';
		}

		if ( $extras['add_cart'] && 'yes' === $settings['show_add_cart'] ) {
			$shop_structure[] = 'add_cart';
		}

		/**
		 * Filters the entries rendered in a product's summary.
		 *
		 * @since 1.3.3
		 *
		 * @param array $shop_structure Summary entries.
		 */
		return apply_filters( 'pp_woo_products_content_structure', $shop_structure );
	}

	/**
	 * Render one product.
	 *
	 * Each skin overrides this to include its own item template.
	 *
	 * @since 1.1.0
	 * @access public
	 */
	public function render_woo_loop_template() {

		$settings = $this->get_skin_settings();

		include POWERPACK_ELEMENTS_PATH . 'modules/woocommerce/templates/content-product-skin-1.php';
	}
	/**
	 * Close the product list element.
	 *
	 * @since 1.1.0
	 * @access public
	 */
	public function render_woo_loop_end() {
		include POWERPACK_ELEMENTS_PATH . 'modules/woocommerce/templates/loop/loop-end.php';
	}

	/**
	 * Restore the global post and the WooCommerce loop properties.
	 *
	 * @since 1.1.0
	 * @access public
	 */
	public function render_reset_loop() {

		woocommerce_reset_loop();

		wp_reset_postdata();
	}

	/**
	 * Print the Quick View dialog for this widget.
	 *
	 * Prints an empty shell; the script moves it onto the body and fills it from
	 * the pp_woo_quick_view endpoint when a Quick View button is used.
	 *
	 * @since 1.3.3
	 * @access public
	 */
	public function quick_view_modal() {

		$settings = $this->get_skin_settings();

		$quick_view_type = $settings['quick_view_type'];

		if ( '' !== $quick_view_type ) {
			wp_enqueue_script( 'wc-add-to-cart-variation' );
			wp_enqueue_script( 'flexslider' );

			$widget_id = $this->parent->get_id();

			include POWERPACK_ELEMENTS_PATH . 'modules/woocommerce/templates/quick-view-modal.php';
		}
	}

	/**
	 * Whether a product has sold enough to earn the Best Selling badge.
	 *
	 * @since 1.3.3
	 * @access public
	 * @param int $product_id Product ID to test.
	 * @return bool Whether the product has at least the configured number of sales.
	 */
	public function is_best_selling_product( $product_id ) {

		$settings = $this->get_skin_settings();
		$number_of_sales = $settings['number_of_sales'];

		if ( empty( $number_of_sales ) ) {
			return false;
		}

		$total_sales = get_post_meta( $product_id, 'total_sales', true );

		if ( ! $total_sales || empty( $total_sales ) ) {
			return false;
		}

		return $total_sales >= $number_of_sales;
	}

	/**
	 * Whether a product is rated highly enough to earn the Top Rated badge.
	 *
	 * @since 1.3.3
	 * @access public
	 * @param int $product_id Product ID to test.
	 * @return bool Whether the product's average rating meets the configured minimum.
	 */
	public function is_top_rated_product( $product_id ) {

		$settings = $this->get_skin_settings();
		$rating = $settings['number_of_ratings'];

		if ( empty( $rating ) ) {
			return false;
		}

		$total_rating = get_post_meta( $product_id, '_wc_average_rating', true );

		if ( ! $total_rating || empty( $total_rating ) ) {
			return false;
		}

		return $total_rating >= $rating;
	}

	/**
	 * Render the product list for an AJAX pagination request.
	 *
	 * Returns just the <ul> of products, which the script swaps in place of the
	 * one on the page.
	 *
	 * @since 2.4.0
	 * @access public
	 * @param \Elementor\Widget_Base $widget Widget instance rebuilt from stored data.
	 * @return string Product list markup.
	 */
	public function render_ajax_product_body( $widget ) {
		ob_start();

		$this->prepare_ajax_render( $widget );

		$this->render_woo_loop_start();
			$this->render_woo_loop();
		$this->render_woo_loop_end();

		return ob_get_clean();
	}

	/**
	 * Render product pagination HTML via AJAX call.
	 *
	 * @since 2.4.0
	 * @access public
	 * @param \Elementor\Widget_Base $widget Widget instance rebuilt from stored data.
	 * @return string Pagination markup.
	 */
	public function render_ajax_pagination( $widget ) {
		ob_start();

		$this->prepare_ajax_render( $widget );

		$this->render_pagination_structure();

		return ob_get_clean();
	}

	/**
	 * Run the query and set the loop properties for an AJAX render.
	 *
	 * A pagination request asks for the product list and the pagination markup in
	 * turn, and both need the same query and the same $woocommerce_loop
	 * properties. The work runs on the first call and is reused by the second,
	 * keyed on the widget ID, so one request issues one query. Either AJAX
	 * renderer can therefore be called on its own.
	 *
	 * @since 3.2.0
	 * @access protected
	 * @param \Elementor\Widget_Base $widget Widget instance rebuilt from stored data.
	 */
	protected function prepare_ajax_render( $widget ) {
		if ( $this->ajax_prepared_for === $widget->get_id() ) {
			return;
		}

		$this->ajax_settings = $widget->get_settings_for_display();

		$this->render_query();
		$this->render_loop_args();

		$this->ajax_prepared_for = $widget->get_id();
	}

	/**
	 * Print an action icon, as an SVG or a font icon depending on the site.
	 *
	 * @since 2.7.7
	 * @access protected
	 * @param string $network_name Font Awesome icon name, without the fa- prefix.
	 */
	protected static function render_product_icon( $network_name ) {
		$network_icon_data = self::get_network_icon_data( $network_name );

		if ( PP_Helper::is_feature_active( 'e_font_icon_svg' ) ) {
			// Elementor adds no aria-hidden to the inline SVG, and every action
			// already carries its name as text or aria-label.
			$icon = Icons_Manager::render_font_icon( $network_icon_data, [ 'aria-hidden' => 'true' ] );
		} else {
			$icon = sprintf( '<i class="%s" aria-hidden="true"></i>', $network_icon_data['value'] );
		}

		\Elementor\Utils::print_unescaped_internal_string( $icon );
	}

	/**
	 * Print the carousel pagination bullets.
	 *
	 * Swiper fills the element; the widget ID in the class ties it to this
	 * instance's slider, so two carousels on a page do not share bullets.
	 * Prints nothing outside the carousel layout or with Dots switched off.
	 *
	 * @since 2.8.0
	 * @access protected
	 */
	protected function render_dots() {
		$settings = $this->get_skin_settings();

		if ( 'slider' !== $settings['products_layout_type'] ) {
			return;
		}

		if ( 'yes' === $settings['carousel_pagination'] ) {
			?>
			<!-- Add Pagination -->
			<div class="swiper-pagination swiper-pagination-<?php echo esc_attr( $this->parent->get_id() ); ?>"></div>
			<?php
		}
	}

	/**
	 * Print the carousel previous and next buttons.
	 *
	 * Resolves the arrow icon across the Font Awesome 4 to 5 migration: sites
	 * that never migrated keep the plain 'arrow' class string, migrated ones use
	 * the 'select_arrow' icon control. The left hand arrow is derived from the
	 * right hand one. Prints nothing outside the carousel layout or with Arrows
	 * switched off.
	 *
	 * @since 2.8.0
	 * @access protected
	 */
	protected function render_arrows() {
		$settings = $this->get_skin_settings();

		if ( 'slider' !== $settings['products_layout_type'] ) {
			return;
		}

		PP_Helper::render_arrows( $this->parent, [ 'settings' => $settings ] );
	}

	/**
	 * Get no products found message.
	 *
	 * Returns the no products found message HTML.
	 *
	 * @since 2.7.7
	 * @access public
	 */
	public function render_empty() {
		$settings = $this->get_skin_settings();

		/*
		 * Two classes on purpose: pp-woo-products-empty follows the prefix every
		 * other class in this widget uses, and pp-wooproducts-empty is kept for
		 * the custom CSS sites have written against it since 2.7.7.
		 */
		?>
		<div class="pp-woo-products-empty pp-wooproducts-empty">
			<p><?php echo wp_kses_post( $settings['no_products_message'] ); ?></p>
		</div>
		<?php
	}

	/**
	 * Render the widget.
	 *
	 * Runs the query, then prints the wrapper, the product list, the pagination
	 * and, for a carousel, the dots and arrows. Prints the no products message
	 * instead when the query comes back empty.
	 *
	 * @since 1.3.3
	 * @access public
	 */
	public function render() {
		$settings = $this->get_skin_settings();
		$this->render_query();

		$query = $this->parent->get_query();

		if ( ! $query->have_posts() ) {
			$this->render_empty();
			return;
		}

		$this->render_loop_args();
		$this->render_wrapper_start();
			$this->render_inner_start();
				$this->render_woo_loop_start();
					$this->render_woo_loop();
				$this->render_woo_loop_end();
				$this->render_pagination_structure();
				$this->render_reset_loop();
			$this->render_inner_end();
			$this->render_pagination_status();
			if ( 'slider' === $settings['products_layout_type'] ) {
				$this->render_dots();
				$this->render_arrows();
			}
		$this->render_wrapper_end();

		$this->quick_view_modal();

	}
}
