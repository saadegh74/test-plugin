<?php
/**
 * PowerPack WooCommerce Products - Product Badges.
 *
 * Renders the sale, featured, top rated and best selling badges for one side of
 * the product thumbnail. Included once per side with $badge_side set to 'left'
 * or 'right' beforehand.
 *
 * Each badge has its own position setting of left, right or none, so a badge is
 * printed here only when its position matches the side being rendered.
 *
 * The sale badge can carry custom text with a [value] placeholder, which is
 * replaced by the discount worked out from the product's regular and sale price.
 * The top rated and best selling badges are compared against the thresholds on
 * the widget, through the skin's two helpers.
 *
 * Expects $settings and $badge_side in scope, the global $product, and $this
 * bound to the skin.
 *
 * @since 3.2.0
 *
 * @package PowerPack
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

global $post, $product;

$side      = ( isset( $badge_side ) && 'right' === $badge_side ) ? 'right' : 'left';
$wrap_attr = esc_attr( 'pp-' . $side . '-badge-wrap' );
$badge_attr = esc_attr( 'pp-' . $side . '-badge' );

$sale_badge_position         = $settings['sale_badge_position'];
$featured_badge_position     = $settings['featured_badge_position'];
$top_rating_badge_position   = $settings['top_rating_badge_position'];
$best_selling_badge_position = $settings['best_selling_badge_position'];

$badge_text = esc_html__( 'Sale!', 'powerpack' );
$badge_text = apply_filters( 'woocommerce_sale_flash', $badge_text, $post, $product );

if ( $side === $sale_badge_position ) {

	if ( '' !== $settings['sale_badge_custom_text'] ) {

		if ( 'variable' === $product->get_type() ) {
			$regular_price = $product->get_variation_regular_price();
			$sale_price    = $product->get_variation_sale_price();
		} else {
			$regular_price = $product->get_regular_price();
			$sale_price    = $product->get_sale_price();
		}

		$badge_text = $settings['sale_badge_custom_text'];
		// A free product can be on sale, so guard the division.
		$regular_price = (float) $regular_price;

		if ( $sale_price && $regular_price > 0 ) {
			$percent_sale = round( ( ( $regular_price - (float) $sale_price ) / $regular_price ) * 100 );
			$badge_text   = $badge_text ? $badge_text : '-[value]%';
			$badge_text   = str_replace( '[value]', $percent_sale, $badge_text );
		}

		if ( 'grouped' === $product->get_type() ) {
			if ( $badge_text ) {
				$badge_text = $settings['sale_badge_custom_text'];
			}
		}
	}

	if ( $product->is_on_sale() ) {

		$sale_badge = sprintf(
			'<div class="%1$s"><span class="%2$s pp-sale-badge">%3$s</span></div>',
			$wrap_attr,
			$badge_attr,
			wp_kses_post( $badge_text )
		);

		/**
		 * Filters the sale badge markup.
		 *
		 * @since 1.3.3
		 *
		 * @param string     $sale_badge Badge markup.
		 * @param WP_Post    $post       Product post object.
		 * @param WC_Product $product    Product object.
		 */
		echo wp_kses_post( apply_filters( 'pp_woo_products_sale_flash', $sale_badge, $post, $product ) );
	}
}

if ( $side === $featured_badge_position ) {

	$badge_text = esc_html__( 'New', 'powerpack' );

	if ( '' !== $settings['featured_badge_custom_text'] ) {
		$badge_text = $settings['featured_badge_custom_text'];
	}

	if ( $product->is_featured() ) {

		$featured_badge = sprintf(
			'<div class="%1$s"><span class="%2$s pp-featured-badge">%3$s</span></div>',
			$wrap_attr,
			$badge_attr,
			wp_kses_post( $badge_text )
		);

		/**
		 * Filters the featured badge markup.
		 *
		 * @since 1.3.3
		 *
		 * @param string     $featured_badge Badge markup.
		 * @param WP_Post    $post           Product post object.
		 * @param WC_Product $product        Product object.
		 */
		echo wp_kses_post( apply_filters( 'pp_woo_products_featured_flash', $featured_badge, $post, $product ) );
	}
}

if ( $side === $top_rating_badge_position ) {

	$badge_text = esc_html__( 'Top Rated', 'powerpack' );

	if ( '' !== $settings['top_rating_badge_custom_text'] ) {
		$badge_text = $settings['top_rating_badge_custom_text'];
	}

	if ( $this->is_top_rated_product( $product->get_id() ) ) {
		printf(
			'<div class="%1$s"><span class="%2$s pp-top-rated-badge">%3$s</span></div>',
			$wrap_attr, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above.
			$badge_attr, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above.
			wp_kses_post( $badge_text )
		);
	}
}

if ( $side === $best_selling_badge_position ) {

	$badge_text = esc_html__( 'Best Selling', 'powerpack' );

	if ( '' !== $settings['best_selling_badge_custom_text'] ) {
		$badge_text = $settings['best_selling_badge_custom_text'];
	}

	if ( $this->is_best_selling_product( $product->get_id() ) ) {
		printf(
			'<div class="%1$s"><span class="%2$s pp-best-selling-badge">%3$s</span></div>',
			$wrap_attr, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above.
			$badge_attr, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above.
			wp_kses_post( $badge_text )
		);
	}
}
