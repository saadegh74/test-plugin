<?php
/**
 * PowerPack WooCommerce Products - Template.
 *
 * @package PowerPack
 */

use PowerpackElements\Classes\PP_Woo_Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

global $product;

// Ensure visibility.
if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}

$post_id = $product->get_id();

// Values shared by every product in this loop, resolved once by the skin.
$loop = $this->get_loop_context( $settings );

$sale_badge_position         = $loop['sale_badge_position'];
$featured_badge_position     = $loop['featured_badge_position'];
$top_rating_badge_position   = $loop['top_rating_badge_position'];
$best_selling_badge_position = $loop['best_selling_badge_position'];
$quick_view_type             = $loop['quick_view_type'];
$quick_view_text             = $loop['quick_view_text'];
$image_size                  = $loop['image_size'];

$out_of_stock        = ! $product->is_in_stock();
$out_of_stock_string = apply_filters( 'pp_woo_out_of_stock_string', ( $settings['out_of_stock_text'] ? $settings['out_of_stock_text'] : esc_html__( 'Out of Stock', 'powerpack' ) ) );

?>
<li <?php post_class( $this->get_product_item_class( $settings ) ); ?>>
	<div class="pp-woo-product-wrapper">
		<?php
		echo '<div class="pp-woo-products-thumbnail-wrap">';

		$badge_positions = [ $sale_badge_position, $featured_badge_position, $top_rating_badge_position, $best_selling_badge_position ];

		// One container per side, left then right. loop/badge.php prints the
		// badges whose position matches the side it is given, and a side with no
		// badges on it gets no container.
		foreach ( [ 'left', 'right' ] as $badge_side ) {

			if ( ! in_array( $badge_side, $badge_positions, true ) ) {
				continue;
			}

			echo '<div class="pp-badge-container pp-' . esc_attr( $badge_side ) . '-badge-container">';
			include POWERPACK_ELEMENTS_PATH . 'modules/woocommerce/templates/loop/badge.php';
			echo '</div>';
		}

		if ( 'yes' === $settings['link_image'] ) {
			if ( 'yes' === $settings['link_image_target'] ) {
				echo '<a href="' . esc_url( get_the_permalink() ) . '" target="_blank" rel="noopener" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">';
			} else {
				woocommerce_template_loop_product_link_open();
			}
		}

		// WooCommerce returns escaped markup; wp_kses_post() would strip srcset/sizes.
		echo woocommerce_get_product_thumbnail( $image_size ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		if ( 'swap' === $settings['products_hover_style'] ) {
			PP_Woo_Helper::get_instance()->woo_shop_product_flip_image( $image_size );
		}

		if ( 'yes' === $settings['link_image'] ) {
			woocommerce_template_loop_product_link_close();
		}

		/* Out of stock */
		if ( $out_of_stock ) {
			echo '<span class="pp-out-of-stock">' . esc_html( $out_of_stock_string ) . '</span>';
		}

		echo '</div>';

		$shop_structure = $this->get_shop_structure( $settings, [ 'wishlist' => true ] );

		$shop_structure = is_array( $shop_structure ) ? $shop_structure : [];

		// The actions bar lives inside the summary wrap, so the wrap has to render
		// whenever either has something to show. Guarding it on $shop_structure
		// alone made Add to Cart and Quick View vanish once every content toggle
		// was switched off.
		$has_actions = ( 'yes' === $settings['show_add_cart'] || '' !== $quick_view_type );

		if ( ! empty( $shop_structure ) || $has_actions ) {

			do_action( 'pp_woo_products_before_summary_wrap', $post_id, $settings );
			echo '<div class="pp-woo-products-summary-wrap">';
			do_action( 'pp_woo_products_summary_wrap_top', $post_id, $settings );

			include POWERPACK_ELEMENTS_PATH . 'modules/woocommerce/templates/loop/summary-structure.php';

			/* Product Actions */
			if ( $has_actions ) {

				echo '<div class="pp-product-actions">';

				if ( 'yes' === $settings['show_add_cart'] ) {

					$cart_class = $product->is_purchasable() && $product->is_in_stock() ? 'pp-add-to-cart-btn' : '';

					echo '<a href="' . esc_url( $product->add_to_cart_url() ) . '" class="pp-action-item-wrap pp-cart-section ajax_add_to_cart add_to_cart_button ' . esc_attr( $cart_class ) . ' product_type_' . esc_attr( $product->get_type() ) . '" aria-label="' . esc_attr( $this->get_action_label( $product->add_to_cart_text(), $product ) ) . '" data-success_message="' . esc_attr( $this->get_add_to_cart_success_message( $product ) ) . '" data-quantity="1" data-product_id="' . esc_attr( $post_id ) . '">';
						echo '<span class="pp-action-text"> ' . wp_kses_post( $product->add_to_cart_text() ) . '</span>';
					echo '</a>';
				}

				if ( '' !== $quick_view_type ) {

					echo '<button type="button" class="pp-quick-view-btn pp-action-item-wrap" aria-haspopup="dialog" aria-label="' . esc_attr( $this->get_action_label( $quick_view_text, $product ) ) . '" data-product_id="' . esc_attr( $post_id ) . '">';
						echo '<span class="pp-action-text">' . wp_kses_post( $quick_view_text ) . '</span>';
					echo '</button>';
				}

				echo '</div>';
			}

			do_action( 'pp_woo_products_summary_wrap_bottom', $post_id, $settings );
			echo '</div>';
			do_action( 'pp_woo_products_after_summary_wrap', $post_id, $settings );
		}
		?>
	</div>
</li>
