<?php
namespace PowerpackElements\Modules\DisplayConditions;

use PowerpackElements\Base\Module_Base;
use PowerpackElements\Extensions\Extension_Display_Conditions;

// Elementor Classes
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Repeater;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * \Modules\DisplayConditions\Module
 *
 * @since  2.2.2
 */
class Module extends Module_Base {

	/**
	 * Display Conditions
	 *
	 * Holds all the conditions for display on the frontend
	 *
	 * @since 1.4.7
	 * @access protected
	 *
	 * @var bool
	 */
	protected $conditions = [];

	/**
	 * Display Conditions
	 *
	 * Holds all the conditions classes
	 *
	 * @since 1.4.7
	 * @access protected
	 *
	 * @var bool
	 */
	protected $_conditions = [];

	/**
	 * Conditions Repeater
	 *
	 * The repeater control
	 *
	 * @since 1.4.13
	 * @access protected
	 *
	 * @var bool
	 */
	protected $_conditions_repeater;

	const USER_GROUP        = 'user';
	const SINGLE_GROUP      = 'single';
	const ARCHIVE_GROUP     = 'archive';
	const DATE_TIME_GROUP   = 'date_time';
	const ACF_GROUP         = 'acf';
	const PODS_GROUP        = 'pods';
	const EDD_GROUP         = 'edd';
	const MISC_GROUP        = 'misc';
	const WOO_GROUP         = 'woo';

	/**
	 * Option that tracks the plain-text backfill.
	 *
	 * Holds the last post ID processed, or 'done'.
	 *
	 * @since 3.2.0
	 */
	const PLAIN_TEXT_BACKFILL_OPTION = 'pp_display_conditions_plain_text_backfill';

	/**
	 * Posts rewritten per admin request by the plain-text backfill.
	 *
	 * @since 3.2.0
	 */
	const PLAIN_TEXT_BACKFILL_BATCH = 20;

	/**
	 * Seconds a single plain-text backfill run may spend before it queues the next.
	 *
	 * @since 3.2.0
	 */
	const PLAIN_TEXT_BACKFILL_TIME_LIMIT = 10;

	/**
	 * WP-Cron hook that runs the plain-text backfill.
	 *
	 * @since 3.2.0
	 */
	const PLAIN_TEXT_BACKFILL_HOOK = 'pp_display_conditions_plain_text_backfill';

	public function get_groups() {
		return [
			self::USER_GROUP => [
				'label' => esc_html__( 'User', 'powerpack' ),
			],
			self::SINGLE_GROUP => [
				'label' => esc_html__( 'Singular', 'powerpack' ),
			],
			self::ARCHIVE_GROUP => [
				'label' => esc_html__( 'Archive', 'powerpack' ),
			],
			self::DATE_TIME_GROUP => [
				'label' => esc_html__( 'Date and Time', 'powerpack' ),
			],
			self::ACF_GROUP => [
				'label' => esc_html__( 'Advanced Custom Fields', 'powerpack' ),
			],
			self::PODS_GROUP => [
				'label' => esc_html__( 'Pods', 'powerpack' ),
			],
			self::MISC_GROUP => [
				'label' => esc_html__( 'Misc', 'powerpack' ),
			],
			self::WOO_GROUP => [
				'label' => esc_html__( 'WooCommerce', 'powerpack' ),
			],
		];
	}

	/**
	 * Display Conditions
	 *
	 * Holds all the conditions for display on the frontend
	 *
	 * @since 2.0.0
	 * @access protected
	 *
	 * @var bool
	 */
	protected $conditions_options = [];

	public function __construct() {
		parent::__construct();

		$this->register_conditions();

		// Registered here, not in add_actions(), because add_actions() only runs
		// while the extension is enabled.
		add_action( 'update_option_pp_elementor_extensions', [ $this, 'restart_backfill_on_enable' ], 10, 2 );
		add_action( 'delete_option', [ $this, 'restart_backfill_on_delete' ] );
	}

	/**
	 * Run the plain-text backfill again when the extension is switched back on.
	 *
	 * While the extension is off nothing strips gated elements, so posts saved
	 * in that time get their hidden text written to post_content. That is
	 * harmless while the conditions are not applied, but turns into a leak the
	 * moment the extension is enabled again, after the backfill has already
	 * marked itself done.
	 *
	 * @since 3.2.0
	 *
	 * @param mixed $old_value Previous enabled extensions.
	 * @param mixed $value     New enabled extensions.
	 */
	public function restart_backfill_on_enable( $old_value, $value ) {
		if ( ! self::is_enabled_in( $old_value ) && self::is_enabled_in( $value ) ) {
			delete_option( self::PLAIN_TEXT_BACKFILL_OPTION );
		}
	}

	/**
	 * Same as restart_backfill_on_enable(), for the setting being deleted.
	 *
	 * A missing option means every extension is on, so deleting it switches
	 * Display Conditions on if the stored value had it off. Creating the option
	 * can never switch it on, for the same reason, so that case needs no hook.
	 *
	 * @since 3.2.0
	 *
	 * @param string $option Option about to be deleted.
	 */
	public function restart_backfill_on_delete( $option ) {
		if ( 'pp_elementor_extensions' === $option && ! self::is_enabled_in( get_option( 'pp_elementor_extensions' ) ) ) {
			delete_option( self::PLAIN_TEXT_BACKFILL_OPTION );
		}
	}

	/**
	 * Whether a 'pp_elementor_extensions' value has Display Conditions enabled.
	 *
	 * Mirrors pp_get_enabled_extensions() and Extensions_Manager: 'disabled'
	 * switches every extension off, a list switches on what it holds, and any
	 * other value, such as a missing option, means every extension is on.
	 *
	 * @since 3.2.0
	 *
	 * @param mixed $value Option value.
	 *
	 * @return bool
	 */
	private static function is_enabled_in( $value ) {
		if ( 'disabled' === $value ) {
			return false;
		}

		if ( ! is_array( $value ) ) {
			return true;
		}

		return in_array( 'pp-display-conditions', $value, true ) || isset( $value['pp-display-conditions'] );
	}

	/**
	 * @since 1.4.7
	 */
	public function register_conditions() {

		$available_conditions = [
			// User
			'authentication',
			'user',
			'role',
			'visitor_type',

			// Singular
			'page',
			'post',
			'static_page',
			'post_term',
			'post_type',

			// Archive
			'taxonomy_archive',
			'term_archive',
			'post_type_archive',
			'date_archive',
			'author_archive',
			'search_results',

			// Date & Time
			'date',
			'date_time_before',
			'time',
			'day',

			// ACF
			'acf_text',
			'acf_choice',
			'acf_true_false',
			'acf_post',
			'acf_taxonomy',
			'acf_date_time',

			// ACF
			'pods_text',
			'pods_date_time',
			'pods_yes_no',

			// Misc
			'os',
			'browser',
			'device_type',
			'search_bot',
			'shortcode',
			'request_parameter',
			'url_string',

			// WooCommerce
			'woo_product_category',
			'woo_product_price',
			'woo_product_rating',
			'woo_product_stock',
			'woo_product_type',
			'woo_cart_products_category',
			'woo_cart_products_count',
			'woo_cart_products',
			'woo_cart_total',
			'woo_cart_subtotal',
			'woo_category_page',
			'woo_last_purchase',
			'woo_orders_placed',
			'woo_purchased_category',
		];

		foreach ( $available_conditions as $condition_name ) {

			$class_name = str_replace( '-', ' ', $condition_name );
			$class_name = str_replace( ' ', '', ucwords( $class_name ) );
			$class_name = __NAMESPACE__ . '\\Conditions\\' . $class_name;

			if ( class_exists( $class_name ) ) {
				if ( $class_name::is_supported() ) {
					$this->_conditions[ $condition_name ] = $class_name::instance();
				}
			}
		}
	}

	/**
	 * @param string $condition_name
	 *
	 * @return Module_Base|Module_Base[]
	 */
	public function get_conditions( $condition_name = null ) {
		if ( $condition_name ) {
			if ( isset( $this->_conditions[ $condition_name ] ) ) {
				return $this->_conditions[ $condition_name ];
			}
			return null;
		}

		return $this->_conditions;
	}

	/**
	 * Set conditions.
	 *
	 * Sets the conditions property to all conditions comparison values
	 *
	 * @since 1.4.7
	 * @access protected
	 * @static
	 *
	 * @param mixed  $conditions  The conditions from the repeater field control
	 *
	 * @return void
	 */
	protected function set_conditions( $id, $conditions = [] ) {
		if ( ! $conditions ) {
			return;
		}

		foreach ( $conditions as $index => $condition ) {

			$key        = $condition['pp_condition_key'];
			$name       = null;

			if ( array_key_exists( 'pp_condition_' . $key . '_name', $condition ) ) {
				$name = $condition[ 'pp_condition_' . $key . '_name' ];
			}

			if ( 'woo_cart_total' === $key || 'woo_cart_subtotal' === $key || 'woo_product_price' === $key || 'woo_product_rating' === $key || 'woo_product_stock' === $key || 'woo_cart_items_count' === $key || 'woo_orders_placed' === $key ) {
				$operator = $condition['pp_condition_operator_advanced'];
			} else if ( 'woo_last_purchase' === $key ) {
				$operator = $condition['pp_condition_operator_date'];
			} else {
				$operator = $condition['pp_condition_operator'];
			}
			$value      = $condition[ 'pp_condition_' . $key . '_value' ];

			$_condition = $this->get_conditions( $key );

			if ( ! $_condition ) {
				continue;
			}

			$_condition->set_element_id( $id );

			$check = $_condition->check( $name, $operator, $value );

			$this->conditions[ $id ][ $key . '_' . $condition['_id'] ] = $check;
		}
	}

	/**
	 * Get Name
	 *
	 * Get the name of the module
	 *
	 * @since  1.4.7
	 * @return string
	 */
	public function get_name() {
		return 'display-conditions';
	}

	/**
	 * Add Actions
	 *
	 * @since 1.4.7
	 *
	 * @access protected
	 */
	public function add_actions() {
		$section_name = Extension_Display_Conditions::SECTION_NAME;

		// Activate controls for widgets
		add_action( 'elementor/element/common/' . $section_name . '/before_section_end', function( $element, $args ) {
			$this->add_controls( $element, $args );
		}, 10, 2 );

		// Activate controls for columns
		add_action( 'elementor/element/column/' . $section_name . '/before_section_end', function( $element, $args ) {
			$this->add_controls( $element, $args );
		}, 10, 2 );

		// Activate controls for sections
		add_action( 'elementor/element/section/' . $section_name . '/before_section_end', function( $element, $args ) {
			$this->add_controls( $element, $args );
		}, 10, 2 );

		// Activate controls for containers
		add_action( 'elementor/element/container/' . $section_name . '/before_section_end', function( $element, $args ) {
			$this->add_controls( $element, $args );
		}, 10, 2 );

		// Conditions for widgets
		add_filter( 'elementor/frontend/widget/should_render', array( $this, 'render_content' ), 10, 2 );
		add_action( 'elementor/frontend/widget/before_render', array( $this, 'before_render' ), 10, 1 );

		// Conditions for columns
		add_filter( 'elementor/frontend/column/should_render', array( $this, 'render_content' ), 10, 2 );
		add_action( 'elementor/frontend/column/before_render', array( $this, 'before_render' ), 10, 1 );

		// Conditions for sections
		add_filter( 'elementor/frontend/section/should_render', array( $this, 'render_content' ), 10, 2 );
		add_action( 'elementor/frontend/section/before_render', array( $this, 'before_render' ), 10, 1 );

		// Conditions for containers
		add_filter( 'elementor/frontend/container/should_render', array( $this, 'render_content' ), 10, 2 );
		add_action( 'elementor/frontend/container/before_render', array( $this, 'before_render' ), 10, 1 );

		// Keep elements with conditions out of Elementor's element cache
		add_filter( 'elementor/element/is_dynamic_content', array( $this, 'is_dynamic_content' ), 10, 2 );

		// Keep elements with conditions out of the plain-text copy Elementor saves to post_content
		add_action( 'elementor/db/before_save', [ $this, 'arm_plain_text_filter' ] );

		// Rewrite the plain-text copy of posts saved before the filter above existed
		add_action( 'admin_init', [ $this, 'schedule_plain_text_backfill' ] );
		add_action( self::PLAIN_TEXT_BACKFILL_HOOK, [ $this, 'backfill_plain_text' ] );
	}

	/**
	 * Start hiding gated elements from Elementor's plain-text pass.
	 *
	 * On every save Elementor renders each widget's plain content, hidden or
	 * not, and writes the result to post_content. WordPress builds the excerpt
	 * from that copy, so text behind a display condition reached anonymous
	 * visitors through the REST excerpt, the feeds and search. Elementor offers
	 * no filter on that output, and widgets such as Text Editor override
	 * render_plain_content(), so the element data Elementor reads for the pass
	 * is filtered instead: Elementor renders once, without the gated elements.
	 *
	 * 'elementor/db/before_save' fires right before Elementor\DB::save_plain_text().
	 * The meta filter only acts while dynamic tags are in the remove mode that
	 * save_plain_text() sets, and is taken off again as soon as the plain text
	 * reaches wp_insert_post(), so nothing else ever reads the stripped data and
	 * no other request pays for it.
	 *
	 * @since 3.2.0
	 */
	public function arm_plain_text_filter() {
		add_filter( 'get_post_metadata', [ $this, 'filter_plain_text_elements_data' ], 10, 3 );
		add_filter( 'wp_insert_post_data', [ $this, 'disarm_plain_text_filter' ], 1 );
	}

	/**
	 * Stop hiding gated elements once the plain text is about to be written.
	 *
	 * @since 3.2.0
	 *
	 * @param array $data Post data, returned unchanged.
	 *
	 * @return array
	 */
	public function disarm_plain_text_filter( $data ) {
		remove_filter( 'get_post_metadata', [ $this, 'filter_plain_text_elements_data' ], 10 );
		remove_filter( 'wp_insert_post_data', [ $this, 'disarm_plain_text_filter' ], 1 );

		return $data;
	}

	/**
	 * Serve Elementor data without gated elements to the plain-text pass.
	 *
	 * Gated elements are dropped whatever their conditions are: post_content is
	 * public and cannot depend on who reads it. Templates embedded in the post
	 * are read through the same meta, so their gated elements are dropped too.
	 *
	 * @since 3.2.0
	 *
	 * @param mixed  $value     Short-circuit value, null by default.
	 * @param int    $object_id Post ID.
	 * @param string $meta_key  Meta key.
	 *
	 * @return mixed
	 */
	public function filter_plain_text_elements_data( $value, $object_id, $meta_key ) {
		static $reading = false;

		if ( $reading || null !== $value || '_elementor_data' !== $meta_key || ! $this->is_saving_plain_text() ) {
			return $value;
		}

		$reading = true;
		$raw     = get_post_meta( $object_id, '_elementor_data', true );
		$reading = false;

		$elements = $this->get_public_elements( $raw );

		// get_metadata() returns the first item for a single value.
		return null === $elements ? $value : [ $elements ];
	}

	/**
	 * Whether Elementor is writing its plain-text copy of a document.
	 *
	 * Elementor\DB::save_plain_text() switches dynamic tags to remove mode for
	 * the duration of that write and nowhere else.
	 *
	 * @since 3.2.0
	 *
	 * @return bool
	 */
	private function is_saving_plain_text() {
		$dynamic_tags = \Elementor\Plugin::$instance->dynamic_tags;

		return $dynamic_tags && \Elementor\Core\DynamicTags\Manager::MODE_REMOVE === $dynamic_tags->get_parsing_mode();
	}

	/**
	 * Remove gated elements from stored Elementor data.
	 *
	 * @since 3.2.0
	 *
	 * @param mixed $raw The '_elementor_data' meta value: a JSON string or an array.
	 *
	 * @return array|null Elements without gated ones, or null when there were none.
	 */
	private function get_public_elements( $raw ) {
		// Skip the decode for the many documents that use no display conditions.
		if ( is_string( $raw ) ) {
			if ( false === strpos( $raw, '"pp_display_conditions_enable":"yes"' ) ) {
				return null;
			}

			$raw = json_decode( $raw, true );
		}

		if ( empty( $raw ) || ! is_array( $raw ) ) {
			return null;
		}

		$removed  = false;
		$elements = $this->remove_gated_elements( $raw, $removed );

		return $removed ? $elements : null;
	}

	/**
	 * Remove elements that have display conditions, with their children.
	 *
	 * @since 3.2.0
	 *
	 * @param array $elements Elements data.
	 * @param bool  $removed  Set to true when anything was removed.
	 *
	 * @return array
	 */
	private function remove_gated_elements( array $elements, &$removed ) {
		$kept = [];

		foreach ( $elements as $element ) {
			if ( ! is_array( $element ) ) {
				continue;
			}

			if ( ! empty( $element['settings']['pp_display_conditions_enable'] ) && 'yes' === $element['settings']['pp_display_conditions_enable'] ) {
				$removed = true;
				continue;
			}

			if ( ! empty( $element['elements'] ) && is_array( $element['elements'] ) ) {
				$element['elements'] = $this->remove_gated_elements( $element['elements'], $removed );
			}

			$kept[] = $element;
		}

		return $kept;
	}

	/**
	 * Queue the plain-text backfill until it has finished.
	 *
	 * The progress option is autoloaded, so once the backfill is done this check
	 * costs no query.
	 *
	 * @since 3.2.0
	 */
	public function schedule_plain_text_backfill() {
		if ( 'done' === get_option( self::PLAIN_TEXT_BACKFILL_OPTION ) || wp_next_scheduled( self::PLAIN_TEXT_BACKFILL_HOOK ) ) {
			return;
		}

		wp_schedule_single_event( time(), self::PLAIN_TEXT_BACKFILL_HOOK );
	}

	/**
	 * Rewrite post_content for posts saved before gated elements were stripped.
	 *
	 * Runs from WP-Cron, so no visitor or admin page waits on it. Rendering a
	 * post's plain text can take a second or more on a large page, so each run
	 * stops after PLAIN_TEXT_BACKFILL_TIME_LIMIT seconds and queues the next one.
	 * post_content is updated directly so the rewrite creates no revision, fires
	 * no save hooks and leaves the modified date alone.
	 *
	 * @since 3.2.0
	 */
	public function backfill_plain_text() {
		global $wpdb;

		$last_id = get_option( self::PLAIN_TEXT_BACKFILL_OPTION, 0 );

		if ( 'done' === $last_id ) {
			return;
		}

		$started = microtime( true );

		$dynamic_tags = \Elementor\Plugin::$instance->dynamic_tags;
		$parsing_mode = $dynamic_tags->get_parsing_mode();
		$dynamic_tags->set_parsing_mode( \Elementor\Core\DynamicTags\Manager::MODE_REMOVE );

		$finished = false;

		while ( true ) {
			$post_ids = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT p.ID FROM {$wpdb->posts} p
					INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID
					WHERE pm.meta_key = '_elementor_data'
					AND pm.meta_value LIKE %s
					AND p.post_type <> 'revision'
					AND p.ID > %d
					ORDER BY p.ID ASC
					LIMIT %d",
					'%' . $wpdb->esc_like( '"pp_display_conditions_enable":"yes"' ) . '%',
					(int) $last_id,
					self::PLAIN_TEXT_BACKFILL_BATCH
				)
			);

			foreach ( $post_ids as $post_id ) {
				$post_id  = (int) $post_id;
				$elements = $this->get_public_elements( get_post_meta( $post_id, '_elementor_data', true ) );

				if ( null !== $elements ) {
					$plain_text = \Elementor\Plugin::$instance->db->get_plain_text_from_data( $elements );

					$wpdb->update( $wpdb->posts, [ 'post_content' => $plain_text ], [ 'ID' => $post_id ] );
					clean_post_cache( $post_id );
				}

				$last_id = $post_id;

				if ( microtime( true ) - $started > self::PLAIN_TEXT_BACKFILL_TIME_LIMIT ) {
					break 2;
				}
			}

			if ( count( $post_ids ) < self::PLAIN_TEXT_BACKFILL_BATCH ) {
				$finished = true;
				break;
			}
		}

		$dynamic_tags->set_parsing_mode( $parsing_mode );

		update_option( self::PLAIN_TEXT_BACKFILL_OPTION, $finished ? 'done' : $last_id, true );

		if ( ! $finished ) {
			wp_schedule_single_event( time() + 30, self::PLAIN_TEXT_BACKFILL_HOOK );
		}
	}

	/**
	 * Flag an element that has display conditions as dynamic content.
	 *
	 * Elementor's element cache stores the rendered HTML of every element it
	 * considers static in the document's '_elementor_element_cache' meta and
	 * replays it on later requests. Containers, and widgets such as Heading,
	 * report themselves as static, so the show/hide decision made when the cache
	 * was primed was frozen into the template and reused for every post that
	 * template renders - a condition on a container evaluated once and never
	 * again, while a dynamic widget alongside it kept working.
	 *
	 * Marking the element dynamic makes Elementor render it through its
	 * '[elementor-element]' shortcode instead, which re-evaluates the conditions
	 * on every request. The filter is only consulted while the cache is being
	 * built, so this costs nothing when element caching is off.
	 *
	 * @since 3.1.0
	 *
	 * @param bool  $is_dynamic_content Whether the element output is dynamic.
	 * @param array $raw_data           Raw element data.
	 *
	 * @return bool
	 */
	public function is_dynamic_content( $is_dynamic_content, $raw_data ) {
		if ( $is_dynamic_content ) {
			return true;
		}

		if ( empty( $raw_data['settings']['pp_display_conditions_enable'] ) ) {
			return $is_dynamic_content;
		}

		return 'yes' === $raw_data['settings']['pp_display_conditions_enable'];
	}

	/**
	 * Render content based on conditions
	 *
	 * @since 2.7.2
	 *
	 * @param bool  $should_render return boolean value.
	 * @param array $element return controls.
	 *
	 * @return bool
	 */
	public function render_content( $should_render, $element ) {
		$settings = $element->get_settings();

		if ( ! empty( $settings['pp_display_conditions_enable'] ) && 'yes' === $settings['pp_display_conditions_enable'] ) {
			$id = $element->get_id();

			// Set the conditions
			$this->set_conditions( $id, $settings['pp_display_conditions'] );

			if ( ! $this->is_visible( $id, $settings['pp_display_conditions_relation'] ) ) { // Check the conditions
				if ( 'yes' === $settings['pp_display_conditions_output'] ) {
					$should_render = true;
				} else {
					$should_render = false;
				}
			}
		}

		return $should_render;
	}

	/**
	 * Render Display Conditions output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 2.8.3
	 * @access public
	 * @param object $element for current element.
	 */
	public function before_render( $element ) {
		$settings = $element->get_settings();

		if ( ! empty( $settings['pp_display_conditions_enable'] ) && 'yes' === $settings['pp_display_conditions_enable'] ) {

			// Set the conditions
			$this->set_conditions( $element->get_id(), $settings['pp_display_conditions'] );

			if ( ! $this->is_visible( $element->get_id(), $settings['pp_display_conditions_relation'] ) ) { // Check the conditions
				$element->add_render_attribute( '_wrapper', 'class', 'pp-visibility-hidden' );
			}
		}
	}

	/**
	 * Add Controls
	 *
	 * @since 1.4.7
	 *
	 * @access private
	 */
	public function add_controls( $element, $args ) {

		$element_type = $element->get_type();

		$element->add_control(
			'pp_display_conditions_enable',
			[
				'label'         => esc_html__( 'Display Conditions', 'powerpack' ),
				'type'          => Controls_Manager::SWITCHER,
				'default'       => '',
				'label_on'      => esc_html__( 'Yes', 'powerpack' ),
				'label_off'     => esc_html__( 'No', 'powerpack' ),
				'return_value'  => 'yes',
			]
		);

		$element->add_control(
			'pp_display_conditions_output',
			[
				'label'         => esc_html__( 'Output HTML', 'powerpack' ),
				'description'   => sprintf( esc_html__( 'If enabled, the HTML code will exist on the page but the %s will be hidden using CSS.', 'powerpack' ), $element_type ),
				'default'       => '',
				'type'          => Controls_Manager::SWITCHER,
				'label_on'      => esc_html__( 'Yes', 'powerpack' ),
				'label_off'     => esc_html__( 'No', 'powerpack' ),
				'return_value'  => 'yes',
				'condition'     => [
					'pp_display_conditions_enable' => 'yes',
				],
			]
		);

		$element->add_control(
			'pp_display_conditions_relation',
			[
				'label'         => esc_html__( 'Display on', 'powerpack' ),
				'type'          => Controls_Manager::SELECT,
				'default'       => 'all',
				'options'       => [
					'all' => esc_html__( 'All conditions met', 'powerpack' ),
					'any' => esc_html__( 'Any condition met', 'powerpack' ),
				],
				'condition'     => [
					'pp_display_conditions_enable' => 'yes',
				],
			]
		);

		$this->_conditions_repeater = new Repeater();

		$this->_conditions_repeater->add_control(
			'pp_condition_key',
			[
				'type'          => Controls_Manager::SELECT,
				'default'       => 'authentication',
				'label_block'   => true,
				'groups'        => $this->get_conditions_options(),
			]
		);

		$this->add_name_controls();

		$this->_conditions_repeater->add_control(
			'pp_condition_operator',
			[
				'type'          => Controls_Manager::SELECT,
				'default'       => 'is',
				'label_block'   => true,
				'options'       => [
					'is'        => esc_html__( 'Is', 'powerpack' ),
					'not'       => esc_html__( 'Is not', 'powerpack' ),
				],
				'condition'     => [
					'pp_condition_key!' => [
						'woo_cart_items_count',
						'woo_cart_total',
						'woo_cart_subtotal',
						'woo_product_price',
						'woo_product_rating',
						'woo_product_stock',
						'woo_orders_placed',
						'woo_last_purchase'
					],
				],
			]
		);

		$this->_conditions_repeater->add_control(
			'pp_condition_operator_advanced',
			[
				'type'          => Controls_Manager::SELECT,
				'default'       => '>',
				'label_block'   => true,
				'options'       => [
					'==' => esc_html__( 'Is equal to', 'powerpack' ),
					'!=' => esc_html__( 'Is not equal to', 'powerpack' ),
					'<'  => esc_html__( 'Is less than', 'powerpack' ),
					'>'  => esc_html__( 'Is greater than', 'powerpack' ),
					'<=' => esc_html__( 'Is less than equal to', 'powerpack' ),
					'>=' => esc_html__( 'Is greater than equal to', 'powerpack' ),
				],
				'condition'     => [
					'pp_condition_key' => [
						'woo_cart_items_count',
						'woo_cart_total',
						'woo_cart_subtotal',
						'woo_product_price',
						'woo_product_rating',
						'woo_product_stock',
						'woo_orders_placed'
					],
				],
			]
		);

		$this->_conditions_repeater->add_control(
			'pp_condition_operator_date',
			[
				'type'          => Controls_Manager::SELECT,
				'default'       => '<',
				'label_block'   => true,
				'options'       => [
					'==' => esc_html__( 'On', 'powerpack' ),
					'<'  => esc_html__( 'Before', 'powerpack' ),
					'>'  => esc_html__( 'After', 'powerpack' ),
					'<=' => esc_html__( 'On or Before', 'powerpack' ),
					'>=' => esc_html__( 'On or After', 'powerpack' ),
				],
				'condition'     => [
					'pp_condition_key' => 'woo_last_purchase',
				],
			]
		);

		$this->add_value_controls();

		$element->add_control(
			'pp_display_conditions',
			[
				'label'     => esc_html__( 'Conditions', 'powerpack' ),
				'type'      => Controls_Manager::REPEATER,
				'default'   => [
					[
						'pp_condition_key'                  => 'authentication',
						'pp_condition_operator'             => 'is',
						'pp_condition_authentication_value' => 'authenticated',
					],
				],
				'condition'     => [
					'pp_display_conditions_enable' => 'yes',
				],
				'fields'        => $this->_conditions_repeater->get_controls(),
				'title_field'   => 'Condition',
			]
		);
	}

	/**
	 * Add Value Controls
	 *
	 * Loops through conditions and adds the controls
	 * which select the value to check
	 *
	 * @since 1.4.13.4
	 *
	 * @access private
	 * @return void
	 */
	private function add_name_controls() {
		if ( ! $this->_conditions ) {
			return;
		}

		foreach ( $this->_conditions as $_condition ) {

			if ( false === $_condition->get_name_control() ) {
				continue;
			}

			$condition_name     = $_condition->get_name();
			$control_key        = 'pp_condition_' . $condition_name . '_name';
			$control_settings   = $_condition->get_name_control();

			// Show this only if the user select this specific condition
			$control_settings['condition'] = [
				'pp_condition_key' => $condition_name,
			];

			//
			$this->_conditions_repeater->add_control( $control_key, $control_settings );
		}
	}

	/**
	 * Add Value Controls
	 *
	 * Loops through conditions and adds the controls
	 * which select the value to check
	 *
	 * @since 1.4.13
	 *
	 * @access private
	 * @return void
	 */
	private function add_value_controls() {
		if ( ! $this->_conditions ) {
			return;
		}

		foreach ( $this->_conditions as $_condition ) {

			$condition_name     = $_condition->get_name();
			$control_key        = 'pp_condition_' . $condition_name . '_value';
			$control_settings   = $_condition->get_value_control();

			// Show this only if the user select this specific condition
			$control_settings['condition'] = [
				'pp_condition_key' => $condition_name,
			];

			//
			$this->_conditions_repeater->add_control( $control_key, $control_settings );
		}
	}

	/**
	 * Set the Conditions options array
	 *
	 * @since 1.4.13
	 *
	 * @access private
	 */
	private function get_conditions_options() {

		$groups = $this->get_groups();

		foreach ( $this->_conditions as $_condition ) {
			$groups[ $_condition->get_group() ]['options'][ $_condition->get_name() ] = $_condition->get_title();
		}

		return $groups;
	}

	/**
	 * Check conditions.
	 *
	 * Checks for all or any conditions and returns true or false
	 * depending on wether the content can be shown or not
	 *
	 * @since 1.4.7
	 * @access protected
	 * @static
	 *
	 * @param mixed  $relation  Required conditions relation
	 *
	 * @return bool
	 */
	protected function is_visible( $id, $relation ) {

		if ( ! array_key_exists( $id, $this->conditions ) ) {
			return;
		}

		if ( ! \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
			if ( 'any' === $relation ) {
				if ( ! in_array( true, $this->conditions[ $id ] ) ) {
					return false;
				}
			} else {
				if ( in_array( false, $this->conditions[ $id ] ) ) {
					return false;
				}
			}
		}

		return true;
	}
}
