<?php
/**
 * WPML translation support for the Progress Bar widget's labels repeater.
 *
 * @package PPE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * WPML integration for the Progress Bar widget.
 *
 * @since 2.11.0
 */
class WPML_PP_Progress_Bar extends WPML_Elementor_Module_With_Items {

	/**
	 * Retrieve the repeater control holding the translatable items.
	 *
	 * @since 2.11.0
	 * @access public
	 *
	 * @return string Repeater control name.
	 */
	public function get_items_field() {
		return 'labels';
	}

	/**
	 * Retrieve the repeater sub-fields exposed for translation.
	 *
	 * @since 2.11.0
	 * @access public
	 *
	 * @return array Translatable field names.
	 */
	public function get_fields() {
		return [
			'text',
		];
	}

	/**
	 * Retrieve the label shown for a field in the WPML translation editor.
	 *
	 * @since 2.11.0
	 * @access protected
	 *
	 * @param string $field Repeater sub-field name.
	 * @return string Field title, or an empty string for unknown fields.
	 */
	protected function get_title( $field ) {
		switch ( $field ) {
			case 'text':
				return esc_html__( 'Progress Bar - Label (Multiple)', 'powerpack' );
			default:
				return '';
		}
	}

	/**
	 * Retrieve the WPML editor type used for a field.
	 *
	 * @since 2.11.0
	 * @access protected
	 *
	 * @param string $field Repeater sub-field name.
	 * @return string WPML editor type, or an empty string for unknown fields.
	 */
	protected function get_editor_type( $field ) {
		switch ( $field ) {
			case 'text':
				return 'LINE';
			default:
				return '';
		}
	}
}
