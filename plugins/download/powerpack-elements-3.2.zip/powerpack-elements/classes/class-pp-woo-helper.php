<?php
/**
 * Pieces of the Products widget's product loop.
 *
 * @package PowerPack
 */

namespace PowerpackElements\Classes;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class PP_Woo_Helper.
 *
 * Called from the loop templates in modules/woocommerce/templates, which a
 * theme can override, so the method names stay as they are.
 */
class PP_Woo_Helper {

	/**
	 * Instance.
	 *
	 * @var PP_Woo_Helper
	 */
	private static $instance;

	/**
	 * Get the instance.
	 *
	 * @return PP_Woo_Helper
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Short Description.
	 *
	 * @since 1.3.3
	 */
	public function woo_shop_short_desc() {
		if ( has_excerpt() ) {
			echo '<div class="pp-woo-products-description">';
				echo wp_kses_post( get_the_excerpt() );
			echo '</div>';
		}
	}

	/**
	 * The current product's category names.
	 *
	 * Read from the terms rather than split out of a printed list, which broke
	 * apart any category with a comma in its name.
	 *
	 * @since 3.2.0
	 * @return string[]
	 */
	private function get_category_names() {
		$terms = get_the_terms( get_the_ID(), 'product_cat' );

		return $terms && ! is_wp_error( $terms ) ? wp_list_pluck( $terms, 'name' ) : [];
	}

	/**
	 * Parent Category.
	 *
	 * The product's first category.
	 *
	 * @since 1.1.0
	 */
	public function woo_shop_parent_category() {
		if ( ! apply_filters( 'pp_woo_shop_parent_category', true ) ) {
			return;
		}

		$names = $this->get_category_names();

		// Nothing to show means no element at all: an empty span would still take
		// up the spacing and typography set on the category style controls.
		if ( ! $names ) {
			return;
		}
		?>
		<span class="pp-woo-product-category"><?php echo esc_html( apply_filters( 'pp_woo_products_category', $names[0], $names[0] ) ); ?></span>
		<?php
	}

	/**
	 * Product Categories.
	 *
	 * @since 2.9.11
	 */
	public function woo_shop_product_categories() {
		$names = $this->get_category_names();

		// No categories means no element; see woo_shop_parent_category().
		if ( ! $names ) {
			return;
		}
		?>
		<span class="pp-woo-product-category"><?php echo esc_html( implode( ', ', $names ) ); ?></span>
		<?php
	}

	/**
	 * Product Flip Image.
	 *
	 * The first gallery image, shown on hover.
	 *
	 * @param string $image_size Size of image.
	 * @since 1.3.3
	 */
	public function woo_shop_product_flip_image( $image_size ) {
		global $product;

		$attachment_ids = $product->get_gallery_image_ids();

		if ( ! $attachment_ids ) {
			return;
		}

		// The swap image is decorative: the product name is already announced by
		// the primary image and the title, so an empty alt keeps screen readers
		// from reading the same product twice.
		$attr = [
			'class' => 'pp-show-on-hover',
			'alt'   => '',
		];

		// wp_get_attachment_image() already returns escaped markup. wp_kses_post()
		// is deliberately not used here: it would strip srcset, sizes and decoding.
		echo apply_filters( 'pp_woocommerce_product_flip_image', wp_get_attachment_image( reset( $attachment_ids ), $image_size, false, $attr ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
