<?php
namespace PowerpackElements\Classes;

use PowerpackElements\Classes\PP_Admin_Settings;
use PowerpackElements\Classes\PP_Helper;

/**
 * Handles logic for the site Header / Footer.
 *
 * @package PowerPack Elements
 * @since 1.4.15
 */

/**
 * Exit if accessed directly.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PP_Header_Footer
 */
final class PP_Header_Footer {
	/**
	 * Holds an array of posts.
	 *
	 * @var array $templates
	 * @since 1.4.15
	 */
	private static $templates = array();

	/**
	 * Instance of Elemenntor Frontend class.
	 *
	 * @var \Elementor\Frontend()
	 * @since 1.4.15
	 */
	private static $elementor_instance;

	/**
	 * Holds the post ID for header.
	 *
	 * @var int $header
	 * @since 1.4.15
	 */
	public static $header;

	/**
	 * Holds the post ID for footer.
	 *
	 * @var int $footer
	 * @since 1.4.15
	 */
	public static $footer;

	/**
	 * Site Builder template that supplied the header, which holds its
	 * behaviour settings. Differs from $header when the template points at
	 * a migrated page.
	 *
	 * @var int $header_template
	 * @since 3.2.0
	 */
	public static $header_template = 0;

	/**
	 * Initialize hooks.
	 *
	 * @since 1.4.15
	 * @return void
	 */
	public static function init() {

		if ( ! did_action( 'elementor/loaded' ) ) {
			return;
		}

		self::$elementor_instance = \Elementor\Plugin::instance();


		add_action( 'after_setup_theme', __CLASS__ . '::load' );
	}



	/**
	 * Add CSS classes to the body tag.
	 *
	 * Fired by 'body_class' filter.
	 *
	 * @since 1.4.15
	 *
	 * @param array $classes An array of body classes.
	 *
	 * @return array An array of body classes.
	 */
	public static function body_class( $classes ) {
		$classes[] = 'pp-elementor-header-footer';

		return $classes;
	}

	/**
	 * Get templates.
	 *
	 * Get all pages and Elementor templates.
	 *
	 * @since 1.4.15
	 */
	public static function get_templates() {
		if ( ! empty( self::$templates ) ) {
			return self::$templates;
		}

		$args = array(
			'post_type'              => 'page',
			'post_status'            => 'publish',
			'orderby'                => 'title',
			'order'                  => 'ASC',
			'posts_per_page'         => '-1',
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
		);

		$pages = get_posts( $args );

		$args['post_type'] = 'elementor_library';

		$args['tax_query'] = array(
			array(
				'taxonomy' => 'elementor_library_type',
				'field'    => 'slug',
				'terms'    => array(
					'section',
					'widget',
					'page',
					'header',
					'footer',
				),
			),
		);

		$templates = get_posts( $args );

		self::$templates = array(
			'pages'     => $pages,
			'templates' => $templates,
		);

		return self::$templates;
	}

	/**
	 * Get templates HTML.
	 *
	 * Get all pages and Elementor templates and build options for select field.
	 *
	 * @since 1.4.15
	 * @param string $selected Selected template for the field.
	 */
	public static function get_templates_html( $selected = '' ) {
		$templates = self::get_templates();

		$options = '<option value="">' . esc_html__( 'Default', 'powerpack' ) . '</option>';

		foreach ( $templates as $type => $data ) {
			if ( ! count( $data ) ) {
				continue;
			}

			$label = '';

			if ( 'pages' === $type ) {
				$label = esc_html__( 'Pages', 'powerpack' );
			}
			if ( 'templates' === $type ) {
				$label = esc_html__( 'Builder Templates', 'powerpack' );
			}

			$options .= '<optgroup label="' . $label . '">';

			foreach ( $data as $post ) {
				$options .= '<option value="' . $post->ID . '" ' . selected( $selected, $post->ID, false ) . '>' . $post->post_title . '</option>';
			}

			$options .= '</optgroup>';
		}

		return $options;
	}

	/**
	 * Get breakpoints list.
	 *
	 * Get all responsive breakpoint options for select field.
	 *
	 * @since 2.2.0
	 * @param string $selected Selected template for the field.
	 */
	public static function get_breakpoints( $selected = '' ) {
		$breakpoints = array(
			'all'               => __( 'Always', 'powerpack' ),
			'large'             => __( 'Desktop Only', 'powerpack' ),
			'large-medium'      => __( 'Desktop & Tablet', 'powerpack' ),
			'medium'            => __( 'Tablet Only', 'powerpack' ),
			'medium-responsive' => __( 'Tablet & Mobile', 'powerpack' ),
			'responsive'        => __( 'Mobile Only', 'powerpack' ),
		);

		$options = '<option value="">' . esc_html__( 'Default', 'powerpack' ) . '</option>';

		foreach ( $breakpoints as $breakpoint => $label ) {
			$options .= '<option value="' . $breakpoint . '" ' . selected( $selected, $breakpoint, false ) . '>' . $label . '</option>';
		}

		return $options;
	}

	/**
	 * Returns the slug for supported theme.
	 *
	 * @since 1.4.15
	 * @return mixed
	 */
	public static function get_theme_support_slug() {
		$slug = false;

		// Ahead of the named themes: a block theme's templates never call get_header().
		if ( function_exists( 'wp_is_block_theme' ) && wp_is_block_theme() ) {
			$slug = 'block-theme';
		} elseif ( defined( 'ASTRA_THEME_VERSION' ) ) {
			$slug = 'astra';
		} elseif ( defined( 'FL_THEME_VERSION' ) ) {
			$slug = 'bb-theme';
		} elseif ( function_exists( 'genesis' ) ) {
			$slug = 'genesis';
		} elseif ( defined( 'GENERATE_VERSION' ) ) {
			$slug = 'generatepress';
		} elseif ( defined( 'OCEANWP_THEME_VERSION' ) ) {
			$slug = 'oceanwp';
		} elseif ( defined( 'WPBF_VERSION' ) ) {
			$slug = 'pbf';
		} elseif ( function_exists( 'storefront_is_woocommerce_activated' ) ) {
			$slug = 'storefront';
		} else {
			$slug = 'universal-elementor';
		}

		return $slug;
	}

	/**
	 * Loads theme support if we have a supported theme.
	 *
	 * @since 1.4.15
	 * @return void
	 */
	public static function load() {
		/*
		 * Which template applies is only known once the main query has run,
		 * so here we only check that one could. A site still to migrate has
		 * no templates yet but will by the time 'wp' fires.
		 */
		$has_legacy = PP_Site_Builder_Migration::is_pending( 1 ) && ( get_option( 'pp_header_footer_template_header' ) || get_option( 'pp_header_footer_template_footer' ) );

		if ( ! $has_legacy && ! PP_Site_Builder::has_templates( [ 'header', 'footer' ] ) ) {
			return;
		}

		// Ahead of the theme support classes, which read $header and $footer on 'wp' at 10.
		add_action( 'wp', __CLASS__ . '::resolve', 5 );
		add_action( 'wp_enqueue_scripts', __CLASS__ . '::enqueue_scripts' );

		$slug = self::get_theme_support_slug();

		if ( $slug ) {
			require_once POWERPACK_ELEMENTS_PATH . "classes/theme-support/class-pp-theme-support-$slug.php";
		}
	}

	/**
	 * Pick the header and footer for the current request.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	public static function resolve() {
		self::$header_template = PP_Site_Builder::get_template_for( 'header' );
		self::$header          = PP_Site_Builder::get_content_id( self::$header_template );
		self::$footer          = PP_Site_Builder::get_content_id( PP_Site_Builder::get_template_for( 'footer' ) );

		if ( self::$header || self::$footer ) {
			add_filter( 'body_class', __CLASS__ . '::body_class' );
		}
	}

	/**
	 * Enqueue styles and scripts.
	 */
	public static function enqueue_scripts() {
		$suffix    = ( PP_Helper::is_script_debug() ) ? '' : '.min';
		$path_css  = ( PP_Helper::is_script_debug() ) ? 'assets/css/' : 'assets/css/min/';
		$path_js   = ( PP_Helper::is_script_debug() ) ? 'assets/js/' : 'assets/js/min/';
		$header_id = self::$header;
		$footer_id = self::$footer;

		if ( ! $header_id && ! $footer_id ) {
			return;
		}

		if ( class_exists( '\Elementor\Plugin' ) ) {
			$elementor = \Elementor\Plugin::instance();
			$elementor->frontend->enqueue_styles();
		}

		/* if ( class_exists( '\ElementorPro\Plugin' ) ) {
			$elementor_pro = \ElementorPro\Plugin::instance();
			$elementor_pro->enqueue_styles();
		} */

		if ( pp_header_enabled() ) {
			if ( class_exists( '\Elementor\Core\Files\CSS\Post' ) ) {
				$css_file = new \Elementor\Core\Files\CSS\Post( $header_id );
			} elseif ( class_exists( '\Elementor\Post_CSS_File' ) ) {
				$css_file = new \Elementor\Post_CSS_File( $header_id );
			}

			$css_file->enqueue();
		}

		if ( pp_footer_enabled() ) {
			if ( class_exists( '\Elementor\Core\Files\CSS\Post' ) ) {
				$css_file = new \Elementor\Core\Files\CSS\Post( $footer_id );
			} elseif ( class_exists( '\Elementor\Post_CSS_File' ) ) {
				$css_file = new \Elementor\Post_CSS_File( $footer_id );
			}

			$css_file->enqueue();
		}

		if ( $header_id && PP_Site_Builder::is_native( self::$header_template ) ) {
			$behaviour = PP_Site_Builder::get_behaviour( self::$header_template );

			wp_enqueue_style( 'pp-site-header', POWERPACK_ELEMENTS_URL . $path_css . 'site-header' . $suffix . '.css', [], POWERPACK_ELEMENTS_VER );

			// Without sticky or transparent the header never changes state, so nothing needs to watch the scroll.
			if ( $behaviour['sticky'] || $behaviour['transparent'] ) {
				wp_enqueue_script( 'pp-site-header', POWERPACK_ELEMENTS_URL . $path_js . 'site-header' . $suffix . '.js', [], POWERPACK_ELEMENTS_VER, true );
			}

			return;
		}

		// Headers migrated from the old settings keep the old behaviour script.
		wp_enqueue_script( 'jquery-throttle' );
		wp_enqueue_script( 'imagesloaded' );
		wp_enqueue_style( 'pp-header-layout-style', POWERPACK_ELEMENTS_URL . $path_css . 'header-layout' . $suffix . '.css', array(), POWERPACK_ELEMENTS_VER );
		wp_enqueue_script( 'pp-header-layout-script', POWERPACK_ELEMENTS_URL . $path_js . 'header-layout' . $suffix . '.js', array('jquery'), POWERPACK_ELEMENTS_VER, true );
	}

	/**
	 * Renders the header for the current page.
	 * Used by theme support classes.
	 *
	 * @param mixed $tag    HTML tag for header.
	 * @param mixed $id     Header ID.
	 * @since 1.4.15
	 * @return void
	 */
	public static function render_header( $tag = null, $id = '' ) {
		$tag = ! $tag ? 'header' : $tag;
		$id  = ! $id ? 'masthead' : $id;

		if ( PP_Site_Builder::is_native( self::$header_template ) ) {
			self::render_site_header( $tag, $id );
			return;
		}

		$header_id        = self::$header;
		$settings         = PP_Site_Builder::get_settings( self::$header_template );
		$is_fixed         = $settings['sticky'];
		$fixed_breakpoint = $settings['sticky_breakpoints'];
		$is_shrink        = $settings['shrink'];
		$is_overlay       = $settings['overlay'];
		$overlay_bg       = $settings['overlay_bg'];

		do_action( 'pp_header_footer_before_render_header', $header_id );

		// Print the styles if we are outside of the head tag.
		if ( did_action( 'wp_enqueue_scripts' ) && ! doing_filter( 'wp_enqueue_scripts' ) ) {
			wp_print_styles();
		}

		$data_sticky     = $is_fixed ? '1' : '0';
		$data_shrink     = $is_shrink ? '1' : '0';
		$data_overlay    = $is_overlay ? '1' : '0';
		$data_overlay_bg = $overlay_bg;
		$fixed_breakpoint = ( $fixed_breakpoint ) ? $fixed_breakpoint : 'large-medium';
		?>
		<<?php echo esc_html( $tag ); ?> <?php if ( $id) { echo 'id="' . esc_attr( $id ) . '"'; } ?> class="pp-elementor-header" itemscope="itemscope" itemtype="https://schema.org/WPHeader" data-type="header" data-header-id="<?php echo esc_attr( $header_id ); ?>" data-sticky="<?php echo esc_attr( $data_sticky ); ?>" data-shrink="<?php echo esc_attr( $data_shrink ); ?>" data-overlay="<?php echo esc_attr( $data_overlay ); ?>" data-overlay-bg="<?php echo esc_attr( $overlay_bg ); ?>" data-breakpoint="<?php echo esc_attr( $fixed_breakpoint ); ?>">
			<?php
			if ( 'publish' === get_post_status( $header_id ) ) {
				echo self::$elementor_instance->frontend->get_builder_content_for_display( $header_id ); //phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			?>
		</<?php echo esc_html( $tag ); ?>>
		<?php

		do_action( 'pp_header_footer_after_render_header', $header_id );
	}

	/**
	 * Renders a header built in the Site Builder.
	 *
	 * The data attributes hand the behaviour to site-header.js, which keeps
	 * data-pp-state current. The state styles set in the editor key off that
	 * attribute, so the header looks right before the script runs.
	 *
	 * @since 3.2.0
	 * @param string $tag HTML tag for the header.
	 * @param string $id  Element ID for the header.
	 * @return void
	 */
	private static function render_site_header( $tag, $id ) {
		$header_id = self::$header;
		$behaviour = PP_Site_Builder::get_behaviour( self::$header_template );

		$attributes = [
			'id'             => $id,
			'class'          => 'pp-site-header',
			'itemscope'      => 'itemscope',
			'itemtype'       => 'https://schema.org/WPHeader',
			'data-header-id' => $header_id,
			'data-pp-state'  => 'top',
		];

		if ( $behaviour['sticky'] ) {
			$attributes['data-pp-sticky-on'] = implode( ' ', $behaviour['sticky_on'] );
		}

		if ( $behaviour['hide_on_scroll'] ) {
			$attributes['data-pp-hide-on-scroll'] = '';
		}

		if ( $behaviour['transparent'] ) {
			$attributes['data-pp-transparent'] = '';
		}

		if ( $behaviour['sticky'] || $behaviour['transparent'] ) {
			$attributes['data-pp-offset']      = $behaviour['offset'];
			$attributes['data-pp-breakpoints'] = implode( ' ', self::get_device_breakpoints() );
		}

		do_action( 'pp_header_footer_before_render_header', $header_id );

		// Print the styles if we are outside of the head tag.
		if ( did_action( 'wp_enqueue_scripts' ) && ! doing_filter( 'wp_enqueue_scripts' ) ) {
			wp_print_styles();
		}

		/*
		 * Only where PowerPack prints the theme's whole header file, the one
		 * place 'pp_header' fires: a theme whose header file stays in place,
		 * or a block template, prints its own skip link already.
		 */
		if ( $behaviour['skip_link'] && doing_action( 'pp_header' ) ) {
			printf(
				'<a class="pp-skip-link" href="%1$s">%2$s</a>',
				esc_attr( $behaviour['skip_target'] ),
				esc_html__( 'Skip to content', 'powerpack' )
			);
		}

		echo '<' . tag_escape( $tag );

		foreach ( $attributes as $name => $value ) {
			echo ' ' . esc_attr( $name ) . ( '' === $value ? '' : '="' . esc_attr( $value ) . '"' );
		}

		echo '>';

		if ( 'publish' === get_post_status( $header_id ) ) {
			echo self::$elementor_instance->frontend->get_builder_content_for_display( $header_id ); //phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		echo '</' . tag_escape( $tag ) . '>';

		do_action( 'pp_header_footer_after_render_header', $header_id );
	}

	/**
	 * Widest mobile and tablet widths, in px, from Elementor's breakpoints.
	 *
	 * @since 3.2.0
	 * @return int[] Mobile max, tablet max.
	 */
	private static function get_device_breakpoints() {
		$mobile = 767;
		$tablet = 1024;

		if ( isset( self::$elementor_instance->breakpoints ) ) {
			$active = self::$elementor_instance->breakpoints->get_active_breakpoints();

			$mobile = isset( $active['mobile'] ) ? (int) $active['mobile']->get_value() : $mobile;
			$tablet = isset( $active['tablet'] ) ? (int) $active['tablet']->get_value() : $tablet;
		}

		return [ $mobile, $tablet ];
	}

	/**
	 * Renders the footer for the current page.
	 * Used by theme support classes.
	 *
	 * @param mixed $tag    HTML tag for footer.
	 * @since 1.4.15
	 * @return void
	 */
	public static function render_footer( $tag = null ) {
		$tag       = ! $tag ? 'footer' : $tag;
		$footer_id = self::$footer;

		// Print the styles if we are outside of the head tag.
		if ( did_action( 'wp_enqueue_scripts' ) && ! doing_filter( 'wp_enqueue_scripts' ) ) {
			wp_print_styles();
		}

		do_action( 'pp_header_footer_before_render_footer', $footer_id );
		?>
		<<?php echo esc_html( $tag ); ?> itemtype="https://schema.org/WPFooter" itemscope="itemscope" id="colophon" role="contentinfo">
			<?php
			if ( 'publish' === get_post_status( $footer_id ) ) {
				echo self::$elementor_instance->frontend->get_builder_content_for_display( $footer_id ); //phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			?>
		</<?php echo esc_html( $tag ); ?>>
		<?php

		do_action( 'pp_header_footer_after_render_footer', $footer_id );
	}

	/**
	 * Overrides the default editor content for headers
	 * and footers since those are edited in place.
	 *
	 * @param string $content   Post content.
	 * @since 1.4.15
	 * @return string
	 */
	public static function override_the_content( $content ) {
		return '<div style="padding: 200px 100px; text-align:center; opacity:0.5;">' . __( 'Content Area', 'powerpack' ) . '</div>';
	}
}

// Initialize the class.
PP_Header_Footer::init();
