<?php
/**
 * Header and footer support for block themes.
 *
 * A block theme never calls get_header() or get_footer(): its templates
 * place template parts, and the part in the header or footer area is the
 * site's header or footer. Each one is swapped for the Site Builder
 * template as core is about to render it, so the theme's own part never
 * renders and ours sits exactly where it stood.
 *
 * A page that leaves the block templates for a PHP one, such as Elementor's
 * Full Width, calls get_header() all the same, and with no header.php core
 * falls back to its long-deprecated stand-in. The universal support loaded
 * alongside answers that call as it would for any theme.
 *
 * @link https://powerpackelements.com/
 *
 * @package powerpack-elements
 * @subpackage header-footer
 * @since 3.2.0
 */

use PowerpackElements\Classes\PP_Header_Footer;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Support for block themes.
 *
 * @since 3.2.0
 */
final class PP_Header_Footer_Block_Theme {
	/**
	 * Areas already given a Site Builder template on this request.
	 *
	 * @since 3.2.0
	 * @var bool[]
	 */
	private static $rendered = [];

	/**
	 * Setup support for the theme.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	public static function init() {
		add_action( 'wp', __CLASS__ . '::setup_headers_and_footers' );
	}

	/**
	 * Swap the template parts only when a template applies to this request.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	public static function setup_headers_and_footers() {
		if ( ! empty( PP_Header_Footer::$header ) || ! empty( PP_Header_Footer::$footer ) ) {
			add_filter( 'pre_render_block', __CLASS__ . '::replace_template_part', 10, 2 );
		}
	}

	/**
	 * Render the Site Builder header or footer in place of the theme's part.
	 *
	 * A template with two parts in one area, such as a top bar above the
	 * header, gets the template once, at the first: both parts are the
	 * theme's header, and printing ours twice would repeat it.
	 *
	 * @since 3.2.0
	 * @param string|null $content Content to render instead of the block, or null.
	 * @param array       $block   The block being rendered.
	 * @return string|null
	 */
	public static function replace_template_part( $content, $block ) {
		if ( null !== $content || 'core/template-part' !== $block['blockName'] ) {
			return $content;
		}

		$area = self::get_area( $block['attrs'] );

		if ( 'header' === $area ) {
			$enabled = pp_header_enabled();
		} elseif ( 'footer' === $area ) {
			$enabled = pp_footer_enabled();
		} else {
			return $content;
		}

		if ( ! $enabled ) {
			return $content;
		}

		if ( ! empty( self::$rendered[ $area ] ) ) {
			return '';
		}

		self::$rendered[ $area ] = true;

		ob_start();

		if ( 'header' === $area ) {
			PP_Header_Footer::render_header();
		} else {
			PP_Header_Footer::render_footer();
		}

		return ob_get_clean();
	}

	/**
	 * The area of a template part block, as core works it out when rendering
	 * it: the saved part first, then the theme's file.
	 *
	 * @since 3.2.0
	 * @param array $attributes Template part block attributes.
	 * @return string Area, or '' when the part is not found.
	 */
	private static function get_area( $attributes ) {
		if ( empty( $attributes['slug'] ) ) {
			return '';
		}

		$theme = empty( $attributes['theme'] ) ? get_stylesheet() : $attributes['theme'];

		// Core renders nothing for a part from another theme, so neither do we.
		if ( get_stylesheet() !== $theme ) {
			return '';
		}

		$template_part = get_block_template( $theme . '//' . $attributes['slug'], 'wp_template_part' );

		return $template_part && ! empty( $template_part->area ) ? $template_part->area : '';
	}
}

PP_Header_Footer_Block_Theme::init();

require_once __DIR__ . '/class-pp-theme-support-universal-elementor.php';
