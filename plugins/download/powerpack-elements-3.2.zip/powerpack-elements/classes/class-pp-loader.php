<?php
/**
 * Loads the plugin's PHP files once its requirements are known to be met.
 *
 * @package PowerpackElements
 * @since 3.2.0
 */

namespace PowerpackElements\Classes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PP_Loader
 *
 * Most of these files call their class's init() as soon as they load, so loading a
 * file is what switches its feature on. pp_init() calls load() only after the
 * Elementor and PHP checks pass. Before this, the files loaded from the main plugin
 * file, so their hooks were registered on sites where the plugin had already
 * decided not to run.
 *
 * The order is the order the files have always loaded in. Several of them run code
 * on load (PP_Admin_Settings::init() migrates settings straight away), so do not
 * reorder the list without checking what each file needs from the files before it.
 *
 * The updater is not in this list. It loads from the main plugin file, so a site
 * with Elementor switched off still hears about PowerPack updates.
 *
 * @since 3.2.0
 */
class PP_Loader {

	/**
	 * Load every file the plugin needs. Safe to call more than once.
	 *
	 * Runs on plugins_loaded, from pp_init(), so every plugin has loaded and the
	 * WooCommerce check gives the right answer.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	public static function load() {
		// First, on its own: get_files() uses the checks it defines.
		require_once POWERPACK_ELEMENTS_PATH . 'includes/helper-functions.php';

		foreach ( self::get_files() as $file ) {
			require_once POWERPACK_ELEMENTS_PATH . $file;
		}
	}

	/**
	 * The files to load on this request, relative to the plugin directory.
	 *
	 * @since 3.2.0
	 * @return string[]
	 */
	private static function get_files() {
		$is_admin = is_admin();

		return array_values(
			array_filter(
				[
					'plugin.php',

					'classes/class-pp-config.php',

					// Settings screen.
					'classes/class-pp-settings-registry.php',
					'classes/class-pp-settings-rest-controller.php',
					'classes/class-pp-admin-settings.php',
					'classes/class-pp-login-register.php',

					// Site Builder.
					'classes/site-builder/class-pp-site-builder-rules.php',
					'classes/site-builder/class-pp-site-builder.php',
					'classes/site-builder/class-pp-site-builder-migration.php',
					'classes/site-builder/class-pp-site-builder-rest.php',
					'classes/site-builder/class-pp-site-builder-woo.php',
					'classes/site-builder/class-pp-site-builder-woo-render.php',
					'classes/site-builder/class-pp-site-builder-woo-preview.php',
					$is_admin ? 'classes/site-builder/class-pp-site-builder-admin.php' : '',

					'classes/class-pp-header-footer.php',
					'classes/class-pp-widgets-notice.php',
					'classes/class-pp-helper.php',
					'classes/class-pp-taxonomy-thumbnail.php',
					'classes/class-pp-posts-helper.php',
					'classes/class-pp-posts-query-builder.php',
					'modules/posts/traits/trait-posts-query-controls.php',
					'classes/class-pp-wpml.php',
					'classes/class-pp-attachment.php',
					'classes/class-pp-recaptcha.php',
					'classes/class-pp-google-places.php',
					'classes/class-pp-rollback.php',
					is_pp_woocommerce_active() ? 'classes/class-pp-woo-helper.php' : '',
					'classes/class-pp-templates-lib.php',

					// Adds the plugin's screens to the WordPress Command Palette. The
					// class checks that the palette is there before it registers anything.
					$is_admin ? 'classes/class-pp-command-palette.php' : '',
				]
			)
		);
	}
}
