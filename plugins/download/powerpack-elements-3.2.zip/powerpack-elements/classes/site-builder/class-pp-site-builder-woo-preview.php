<?php
namespace PowerpackElements\Classes;

/**
 * Real store data in the editor for WooCommerce Site Builder templates.
 *
 * A product template is edited on its own URL, where there is no product,
 * so every product widget would show a placeholder. Around each widget this
 * swaps the main query and $post for the template's preview product (or,
 * for an archive template, the Shop's products), and puts them back after.
 *
 * Covers native templates and the library templates migrated ones point at.
 * Anywhere else in the editor, a product widget with no product in context
 * gets the newest product instead, so it previews its real output rather
 * than nothing. Only ever in the editor and its preview: the live site
 * renders against the real request.
 *
 * @package PowerPack Elements
 * @since 3.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PP_Site_Builder_Woo_Preview
 */
final class PP_Site_Builder_Woo_Preview {

	/**
	 * Globals saved by each switch, newest last. Null for a widget that
	 * needed no switch, so every after-render has a before to match.
	 *
	 * @var array
	 * @since 3.2.0
	 */
	private static $stack = [];

	/**
	 * Template type per document ID, looked up once a request.
	 *
	 * @var array
	 * @since 3.2.0
	 */
	private static $types = [];

	/**
	 * Preview query per document, built on the first widget and rewound for
	 * the rest: Elementor fires its hook for every widget on the page.
	 *
	 * @var \WP_Query[]
	 * @since 3.2.0
	 */
	private static $queries = [];

	/**
	 * The newest product's query, for product widgets outside a store
	 * template. False until first needed.
	 *
	 * @var \WP_Query|null|false
	 * @since 3.2.0
	 */
	private static $sample = false;

	/**
	 * Initialize hooks.
	 *
	 * Both the generic Elementor hooks, which reach every widget including
	 * Elementor's own, and PowerPack's widget hooks, which also fire when the
	 * editor re-renders a single widget over AJAX.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	public static function init() {
		if ( ! did_action( 'elementor/loaded' ) ) {
			return;
		}

		add_action( 'elementor/frontend/widget/before_render', __CLASS__ . '::switch_query' );
		add_action( 'elementor/frontend/widget/after_render', __CLASS__ . '::restore_query' );
		add_action( 'pp_woo_builder_widget_before_render', __CLASS__ . '::switch_product_query' );
		add_action( 'pp_woo_builder_widget_after_render', __CLASS__ . '::restore_query' );
		add_action( 'elementor/documents/register_controls', __CLASS__ . '::register_linked_preview' );
		add_action( 'wp_enqueue_scripts', __CLASS__ . '::enqueue_product_scripts' );
		add_filter( 'body_class', __CLASS__ . '::body_class' );
	}

	/**
	 * Whether this request is the editor or its preview.
	 *
	 * @since 3.2.0
	 * @return bool
	 */
	private static function is_editor() {
		return PP_Helper::is_edit_mode() || PP_Helper::is_preview_mode();
	}

	/**
	 * Store template type a document edits: 'single_product',
	 * 'product_archive' or ''.
	 *
	 * @since 3.2.0
	 * @param int $document_id Document post ID.
	 * @return string
	 */
	public static function template_type( $document_id ) {
		$document_id = (int) $document_id;

		if ( isset( self::$types[ $document_id ] ) ) {
			return self::$types[ $document_id ];
		}

		$type = '';

		if ( PP_Site_Builder::POST_TYPE === get_post_type( $document_id ) ) {
			$type = get_post_meta( $document_id, PP_Site_Builder::META_TYPE, true );
		} else {
			// A library template a migrated template renders.
			$linked = get_posts( [
				'post_type'        => PP_Site_Builder::POST_TYPE,
				'post_status'      => 'any',
				'posts_per_page'   => 1,
				'fields'           => 'ids',
				'no_found_rows'    => true,
				'suppress_filters' => true,
				'meta_query'       => [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					[
						'key'   => PP_Site_Builder::META_SOURCE,
						'value' => $document_id,
					],
					[
						'key'     => PP_Site_Builder::META_TYPE,
						'value'   => [ 'single_product', 'product_archive' ],
						'compare' => 'IN',
					],
				],
			] );

			$type = $linked ? get_post_meta( $linked[0], PP_Site_Builder::META_TYPE, true ) : '';
		}

		self::$types[ $document_id ] = in_array( $type, [ 'single_product', 'product_archive' ], true ) ? $type : '';

		return self::$types[ $document_id ];
	}

	/**
	 * Whether a document is previewed by this class.
	 *
	 * @since 3.2.0
	 * @param int $document_id Document post ID.
	 * @return bool
	 */
	public static function covers( $document_id ) {
		return '' !== self::template_type( $document_id );
	}

	/**
	 * Whether the document being edited can show a product's or an
	 * archive's data, which decides whether those widgets are listed.
	 *
	 * Product widgets print nothing on an ordinary page, so the panel offers
	 * them only on product templates (PowerPack's, the library templates
	 * migrated ones point at, and Elementor Pro's) and on products themselves. With no document to ask, the answer is
	 * yes: hiding a widget by mistake is worse than listing one too many.
	 *
	 * @since 3.2.0
	 * @param string $type 'single_product' or 'product_archive'.
	 * @return bool
	 */
	public static function in_context( $type ) {
		$document = \Elementor\Plugin::$instance->documents->get_current();

		if ( ! $document ) {
			return true;
		}

		$id = (int) $document->get_main_id();

		if ( self::template_type( $id ) === $type ) {
			return true;
		}

		$elementor_pro = [
			'single_product'  => [ 'product', 'product-post' ],
			'product_archive' => [ 'product-archive' ],
		];

		if ( in_array( $document->get_name(), $elementor_pro[ $type ], true ) ) {
			return true;
		}

		return 'single_product' === $type && 'product' === get_post_type( $id );
	}

	/**
	 * The Preview section on a library template a migrated template renders.
	 *
	 * A native template has it from its own document class. A migrated one
	 * is edited as the library template it points at, which is Elementor's
	 * document, so the section is added to that. It replaces the old
	 * builder's Preview Settings, whose saved choice is still honoured: see
	 * preview_product_id().
	 *
	 * @since 3.2.0
	 * @param \Elementor\Core\Base\Document $document Document registering its controls.
	 * @return void
	 */
	public static function register_linked_preview( $document ) {
		$id = (int) $document->get_main_id();

		if ( ! $id || PP_Site_Builder::POST_TYPE === get_post_type( $id ) ) {
			return;
		}

		$type       = self::template_type( $id );
		$definition = $type ? PP_Site_Builder::get_type_definition( $type ) : null;
		$class      = $definition ? __NAMESPACE__ . '\\' . $definition['class'] : '';

		if ( $class && class_exists( $class ) ) {
			$class::register_preview_section( $document );
		}
	}

	/**
	 * The query to preview a document's widgets against, or null.
	 *
	 * @since 3.2.0
	 * @param \Elementor\Core\Base\Document $document Document being rendered.
	 * @return array|null WP_Query args.
	 */
	private static function preview_args( $document ) {
		$type     = self::template_type( $document->get_main_id() );
		$settings = $document->get_settings();

		if ( 'single_product' === $type ) {
			$product = self::preview_product_id( $settings );

			return $product ? [
				'post_type' => 'product',
				'p'         => $product,
			] : null;
		}

		if ( 'product_archive' === $type ) {
			$args = [
				'post_type'      => 'product',
				'post_status'    => 'publish',
				'posts_per_page' => (int) apply_filters( 'loop_shop_per_page', wc_get_default_products_per_row() * wc_get_default_product_rows_per_page() ),
			];

			/*
			 * A category goes in as its query var rather than a tax_query, so the
			 * preview is a category archive to WordPress: its term is the queried
			 * object, and the Archive Description widget has a description to show.
			 */
			if ( ! empty( $settings['pp_preview_term'] ) ) {
				$term     = get_term( (int) $settings['pp_preview_term'] );
				$taxonomy = $term && ! is_wp_error( $term ) ? get_taxonomy( $term->taxonomy ) : null;

				if ( $taxonomy && $taxonomy->query_var ) {
					unset( $args['post_type'] );
					$args[ $taxonomy->query_var ] = $term->slug;
				}
			}

			return $args;
		}

		return null;
	}

	/**
	 * The product a single product template previews with.
	 *
	 * The one picked in the template's settings, then the one the old
	 * builder's setting picked for a migrated template, then the newest.
	 *
	 * @since 3.2.0
	 * @param array $settings Document settings.
	 * @return int
	 */
	private static function preview_product_id( $settings ) {
		foreach ( [ 'pp_preview_product', 'pp_preview_id' ] as $key ) {
			if ( ! empty( $settings[ $key ] ) && 'product' === get_post_type( (int) $settings[ $key ] ) ) {
				return (int) $settings[ $key ];
			}
		}

		$newest = get_posts( [
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'no_found_rows'  => true,
		] );

		return $newest ? (int) $newest[0] : 0;
	}

	/**
	 * A document's preview query, or null when it needs none.
	 *
	 * @since 3.2.0
	 * @param \Elementor\Core\Base\Document $document Document being rendered.
	 * @return \WP_Query|null
	 */
	private static function preview_query( $document ) {
		$id = (int) $document->get_main_id();

		if ( ! array_key_exists( $id, self::$queries ) ) {
			$args                 = self::preview_args( $document );
			self::$queries[ $id ] = $args ? new \WP_Query( $args ) : null;
		}

		return self::$queries[ $id ];
	}

	/**
	 * Whether a widget shows one product's data, and so can preview with any.
	 *
	 * The store template widgets, and Add to Cart when it is set to the
	 * current product. Not the Products widget, which runs queries of its
	 * own that a swapped $post could change.
	 *
	 * @since 3.2.0
	 * @param \Elementor\Widget_Base $widget Widget about to render.
	 * @return bool
	 */
	private static function shows_one_product( $widget ) {
		if ( ! $widget instanceof \Elementor\Widget_Base ) {
			return false;
		}

		return in_array( 'powerpack-woocommerce-builder', $widget->get_categories(), true ) || 'pp-woo-add-to-cart' === $widget->get_name();
	}

	/**
	 * The newest product's query, or null when the store has none.
	 *
	 * @since 3.2.0
	 * @return \WP_Query|null
	 */
	private static function sample_query() {
		if ( false === self::$sample ) {
			$product = self::preview_product_id( [] );

			self::$sample = $product ? new \WP_Query( [
				'post_type' => 'product',
				'p'         => $product,
			] ) : null;
		}

		return self::$sample;
	}

	/**
	 * Swap in a product before a PowerPack product widget renders.
	 *
	 * The store template's own preview when there is one. Otherwise, on a
	 * document with no product of its own (a page, a library template, an
	 * Elementor Pro template with no preview set), the newest product.
	 *
	 * @since 3.2.0
	 * @param \Elementor\Widget_Base $widget Widget about to render.
	 * @return void
	 */
	public static function switch_product_query( $widget = null ) {
		$sample = 'product' !== get_post_type() && self::shows_one_product( $widget );

		self::switch_query( $sample );
	}

	/**
	 * Swap in the preview query before a widget renders.
	 *
	 * @since 3.2.0
	 * @param bool $sample Whether to fall back to the newest product.
	 * @return void
	 */
	public static function switch_query( $sample = false ) {
		$document = self::is_editor() ? \Elementor\Plugin::$instance->documents->get_current() : null;
		$query    = $document ? self::preview_query( $document ) : null;

		if ( ! $query && $document && true === $sample ) {
			$query = self::sample_query();
		}

		if ( ! $query ) {
			self::$stack[] = null;
			return;
		}

		global $wp_query, $post, $product;

		self::$stack[] = [ $wp_query, $post, $product ];

		$query->rewind_posts();
		$wp_query = $query; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited

		if ( 'product' === $wp_query->get( 'post_type' ) && $wp_query->get( 'p' ) && $wp_query->post ) {
			$post    = $wp_query->post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
			$product = wc_get_product( $post ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
			setup_postdata( $post );
		}
	}

	/**
	 * Put the real query back after a widget renders.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	public static function restore_query() {
		$saved = array_pop( self::$stack );

		if ( ! $saved ) {
			return;
		}

		global $wp_query, $post, $product;

		list( $wp_query, $post, $product ) = $saved; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited

		if ( $post ) {
			setup_postdata( $post );
		}
	}

	/**
	 * WooCommerce's product scripts in a product template's preview.
	 *
	 * WooCommerce only loads them on a real product page, and without them
	 * the gallery and tabs sit there unstyled and inert.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	public static function enqueue_product_scripts() {
		if ( ! PP_Helper::is_preview_mode() || 'single_product' !== self::template_type( get_queried_object_id() ) ) {
			return;
		}

		$features = [
			'zoom'                  => 'wc-product-gallery-zoom',
			'flexslider'            => 'wc-product-gallery-slider',
			'photoswipe-ui-default' => 'wc-product-gallery-lightbox',
		];

		foreach ( $features as $script => $feature ) {
			if ( current_theme_supports( $feature ) ) {
				wp_enqueue_script( $script );
			}
		}

		wp_enqueue_script( 'wc-single-product' );
		wp_enqueue_style( 'photoswipe' );
		wp_enqueue_style( 'photoswipe-default-skin' );
	}

	/**
	 * WooCommerce's body class in a store template's preview, which its
	 * stylesheet and the theme's WooCommerce styles hang off.
	 *
	 * @since 3.2.0
	 * @param array $classes Body classes.
	 * @return array
	 */
	public static function body_class( $classes ) {
		if ( PP_Helper::is_preview_mode() && self::covers( get_queried_object_id() ) ) {
			$classes[] = 'woocommerce';
		}

		return $classes;
	}
}

PP_Site_Builder_Woo_Preview::init();
