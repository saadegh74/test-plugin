<?php
namespace PowerpackElements\Classes;

/**
 * powerpack/v1/site-builder: the routes behind the Site Builder screen.
 *
 * The screen works in whole templates, with display rules already described
 * in words, so it never has to assemble a template from post fields, meta and
 * a separate label lookup the way the core posts endpoint would make it.
 *
 * @package PowerPack Elements
 * @since 3.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PP_Site_Builder_REST
 */
final class PP_Site_Builder_REST {

	/**
	 * REST namespace, shared with the settings routes.
	 *
	 * @since 3.2.0
	 */
	const REST_NAMESPACE = 'powerpack/v1';

	/**
	 * Option holding the notices this site has dismissed.
	 *
	 * @since 3.2.0
	 */
	const DISMISSED_OPTION = 'pp_site_builder_dismissed_notices';

	/**
	 * Highest priority the screen accepts.
	 *
	 * @since 3.2.0
	 */
	const MAX_PRIORITY = 9999;

	/**
	 * Initialize hooks.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', __CLASS__ . '::register_routes' );
	}

	/**
	 * Register the routes.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	public static function register_routes() {
		$permission = __CLASS__ . '::can_manage';
		$id_arg     = [
			'id' => [
				'type'     => 'integer',
				'required' => true,
			],
		];

		register_rest_route( self::REST_NAMESPACE, '/site-builder', [
			[
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => __CLASS__ . '::get_templates',
				'permission_callback' => $permission,
			],
			[
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => __CLASS__ . '::create_template',
				'permission_callback' => $permission,
				'args'                => [
					'title' => [
						'type'              => 'string',
						'default'           => '',
						'sanitize_callback' => 'sanitize_text_field',
					],
					'type'  => [
						'type'     => 'string',
						'required' => true,
						'enum'     => array_keys( PP_Site_Builder::get_types() ),
					],
					'rules' => [
						'type' => 'object',
					],
				],
			],
		] );

		register_rest_route( self::REST_NAMESPACE, '/site-builder/(?P<id>\d+)', [
			[
				'methods'             => \WP_REST_Server::EDITABLE,
				'callback'            => __CLASS__ . '::update_template',
				'permission_callback' => __CLASS__ . '::can_edit_template',
				'args'                => array_merge( $id_arg, [
					'title'    => [
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					],
					'rules'    => [
						'type' => 'object',
					],
					'priority' => [
						'type'    => 'integer',
						'minimum' => 0,
						'maximum' => self::MAX_PRIORITY,
					],
					'active'   => [
						'type' => 'boolean',
					],
				] ),
			],
			[
				'methods'             => \WP_REST_Server::DELETABLE,
				'callback'            => __CLASS__ . '::trash_template',
				'permission_callback' => __CLASS__ . '::can_delete_template',
				'args'                => $id_arg,
			],
		] );

		register_rest_route( self::REST_NAMESPACE, '/site-builder/(?P<id>\d+)/duplicate', [
			'methods'             => \WP_REST_Server::CREATABLE,
			'callback'            => __CLASS__ . '::duplicate_template',
			'permission_callback' => __CLASS__ . '::can_edit_template',
			'args'                => $id_arg,
		] );

		register_rest_route( self::REST_NAMESPACE, '/site-builder/(?P<id>\d+)/restore', [
			'methods'             => \WP_REST_Server::CREATABLE,
			'callback'            => __CLASS__ . '::restore_template',
			'permission_callback' => __CLASS__ . '::can_restore_template',
			'args'                => $id_arg,
		] );

		register_rest_route( self::REST_NAMESPACE, '/site-builder/rule-options', [
			'methods'             => \WP_REST_Server::READABLE,
			'callback'            => __CLASS__ . '::get_rule_options',
			'permission_callback' => $permission,
			'args'                => [
				'type' => [
					'type'    => 'string',
					'default' => 'header',
					'enum'    => array_keys( PP_Site_Builder::get_types() ),
				],
			],
		] );

		register_rest_route( self::REST_NAMESPACE, '/site-builder/search', [
			'methods'             => \WP_REST_Server::READABLE,
			'callback'            => __CLASS__ . '::search_items',
			'permission_callback' => $permission,
			'args'                => [
				'kind'    => [
					'type'     => 'string',
					'required' => true,
					'enum'     => [ 'post', 'term' ],
				],
				'subtype' => [
					'type'              => 'string',
					'required'          => true,
					'sanitize_callback' => 'sanitize_key',
				],
				'search'  => [
					'type'              => 'string',
					'default'           => '',
					'sanitize_callback' => 'sanitize_text_field',
				],
			],
		] );

		register_rest_route( self::REST_NAMESPACE, '/site-builder/notices/(?P<notice>migrated|migrated_woo|elementor_pro)', [
			'methods'             => \WP_REST_Server::DELETABLE,
			'callback'            => __CLASS__ . '::dismiss_notice',
			'permission_callback' => $permission,
		] );
	}

	/* ---------------------------------------------------------------------
	 * Permissions
	 * ------------------------------------------------------------------ */

	/**
	 * Whether the current user can work on templates at all.
	 *
	 * @since 3.2.0
	 * @return true|\WP_Error
	 */
	public static function can_manage() {
		$post_type = get_post_type_object( PP_Site_Builder::POST_TYPE );

		return $post_type && current_user_can( $post_type->cap->edit_posts ) ? true : self::forbidden();
	}

	/**
	 * Whether the current user can edit the template in the URL.
	 *
	 * @since 3.2.0
	 * @param \WP_REST_Request $request Request.
	 * @return true|\WP_Error
	 */
	public static function can_edit_template( $request ) {
		$post = self::get_template_post( $request['id'] );

		if ( is_wp_error( $post ) ) {
			return $post;
		}

		return current_user_can( 'edit_post', $post->ID ) ? true : self::forbidden();
	}

	/**
	 * Whether the current user can trash the template in the URL.
	 *
	 * @since 3.2.0
	 * @param \WP_REST_Request $request Request.
	 * @return true|\WP_Error
	 */
	public static function can_delete_template( $request ) {
		$post = self::get_template_post( $request['id'] );

		if ( is_wp_error( $post ) ) {
			return $post;
		}

		return current_user_can( 'delete_post', $post->ID ) ? true : self::forbidden();
	}

	/**
	 * Whether the current user can take the template in the URL out of the trash.
	 *
	 * Core asks the same of untrashing as of trashing.
	 *
	 * @since 3.2.0
	 * @param \WP_REST_Request $request Request.
	 * @return true|\WP_Error
	 */
	public static function can_restore_template( $request ) {
		$post = self::get_template_post( $request['id'], true );

		if ( is_wp_error( $post ) ) {
			return $post;
		}

		return current_user_can( 'delete_post', $post->ID ) ? true : self::forbidden();
	}

	/**
	 * The error for a refused request.
	 *
	 * @since 3.2.0
	 * @return \WP_Error
	 */
	private static function forbidden() {
		return new \WP_Error(
			'rest_forbidden',
			__( 'Sorry, you are not allowed to manage Site Builder templates.', 'powerpack' ),
			[ 'status' => rest_authorization_required_code() ]
		);
	}

	/**
	 * A template post by ID, or an error when it is not one.
	 *
	 * @since 3.2.0
	 * @param int  $id      Post ID.
	 * @param bool $trashed True for a template in the trash, the only kind that can be restored.
	 * @return \WP_Post|\WP_Error
	 */
	private static function get_template_post( $id, $trashed = false ) {
		$post = get_post( (int) $id );

		if ( ! $post || PP_Site_Builder::POST_TYPE !== $post->post_type || ( 'trash' === $post->post_status ) !== $trashed ) {
			return new \WP_Error( 'pp_site_builder_not_found', __( 'Template not found.', 'powerpack' ), [ 'status' => 404 ] );
		}

		return $post;
	}

	/* ---------------------------------------------------------------------
	 * Templates
	 * ------------------------------------------------------------------ */

	/**
	 * Every template, plus what the screen needs around them.
	 *
	 * @since 3.2.0
	 * @return \WP_REST_Response
	 */
	public static function get_templates() {
		$posts = get_posts( [
			'post_type'        => PP_Site_Builder::POST_TYPE,
			'post_status'      => [ 'publish', 'draft', 'pending', 'private', 'future' ],
			'posts_per_page'   => -1,
			'orderby'          => 'title',
			'order'            => 'ASC',
			'suppress_filters' => true,
		] );

		$types = [];

		foreach ( PP_Site_Builder::get_type_definitions() as $value => $definition ) {
			$types[] = [
				'value'       => $value,
				'label'       => $definition['label'],
				'plural'      => $definition['plural'],
				'group'       => $definition['group'],

				// A type added through the filter may come without one.
				'description' => isset( $definition['description'] ) ? $definition['description'] : '',

				// A type tied to one store page: the screen shows its page instead of a rules editor.
				'fixedRule'   => empty( $definition['fixed_rule'] ) ? null : $definition['fixed_rule'],
				'defaultRule' => empty( $definition['default_rule'] ) ? null : $definition['default_rule'],
			];
		}

		return rest_ensure_response( [
			'templates' => array_map( __CLASS__ . '::prepare_template', $posts ),
			'types'     => $types,
			'notices'   => self::get_notices( $posts ),
		] );
	}

	/**
	 * Create a template and hand back where to edit it.
	 *
	 * Without rules it shows nowhere until someone says where. Given rules, as
	 * the Add New dialog sends them, it starts inactive instead: going live at
	 * Entire site would swap the live header for a blank one the moment the
	 * editor opened. Publishing it in Elementor turns it on.
	 *
	 * A type that belongs on one store page, such as Cart, gets that page as
	 * its rule straight away, since there is no other choice to make, and
	 * starts inactive for the same reason a header starts with no rules.
	 *
	 * @since 3.2.0
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function create_template( $request ) {
		$type  = PP_Site_Builder::sanitize_type( $request['type'] );
		$types = PP_Site_Builder::get_types();
		$title = '' !== $request['title'] ? $request['title'] : $types[ $type ];

		$definition = PP_Site_Builder::get_type_definition( $type );
		$fixed      = empty( $definition['fixed_rule'] ) ? '' : $definition['fixed_rule'];
		$rules      = $fixed ? [ 'include' => [ $fixed ] ] : PP_Site_Builder_Rules::sanitize( null === $request['rules'] ? [] : $request['rules'] );

		if ( ! $fixed ) {
			$refused = self::refused_rules( $type, $rules );

			if ( $refused ) {
				return $refused;
			}
		}

		$id = wp_insert_post( [
			'post_type'   => PP_Site_Builder::POST_TYPE,
			'post_status' => $fixed || $rules['include'] ? 'draft' : 'publish',
			'post_title'  => wp_slash( $title ),
		], true );

		if ( is_wp_error( $id ) ) {
			return $id;
		}

		update_post_meta( $id, PP_Site_Builder::META_TYPE, $type );
		update_post_meta( $id, PP_Site_Builder::META_RULES, PP_Site_Builder_Rules::sanitize( $rules ) );
		update_post_meta( $id, '_elementor_template_type', PP_Site_Builder::get_document_type( $type ) );
		update_post_meta( $id, '_elementor_edit_mode', 'builder' );

		if ( defined( 'ELEMENTOR_VERSION' ) ) {
			update_post_meta( $id, '_elementor_version', ELEMENTOR_VERSION );
		}

		if ( in_array( $type, [ 'single_product', 'product_archive' ], true ) ) {
			self::enable_product_widgets();
		}

		PP_Site_Builder::rebuild_index();

		$response = rest_ensure_response( self::prepare_template( get_post( $id ) ) );
		$response->set_status( 201 );

		return $response;
	}

	/**
	 * Switch on the widgets a product template is built from.
	 *
	 * The old builder only listed them while it was enabled, so a site that
	 * never used it saved its widget list without them. Nobody turned them
	 * off, and a product template without them has nothing to build with. A
	 * site that switched every widget off is left alone.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	private static function enable_product_widgets() {
		$enabled = get_option( 'pp_elementor_modules' );
		$info    = PP_Config::get_widget_info();

		if ( ! is_array( $enabled ) || empty( $info['WooCommerce Builder Elements'] ) ) {
			return;
		}

		$missing = array_diff( wp_list_pluck( $info['WooCommerce Builder Elements'], 'name' ), $enabled );

		if ( $missing ) {
			update_option( 'pp_elementor_modules', array_values( array_merge( $enabled, $missing ) ) );
		}
	}

	/**
	 * Change a template's title, rules, priority or whether it is active.
	 *
	 * Inactive is a draft: the index only reads published templates, and the
	 * content stays where it is for switching back on.
	 *
	 * @since 3.2.0
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function update_template( $request ) {
		$id   = (int) $request['id'];
		$post = [];

		if ( null !== $request['rules'] ) {
			$refused = self::refused_rules( get_post_meta( $id, PP_Site_Builder::META_TYPE, true ), $request['rules'] );

			if ( $refused ) {
				return $refused;
			}
		}

		if ( null !== $request['title'] ) {
			$post['post_title'] = wp_slash( $request['title'] );
		}

		if ( null !== $request['active'] ) {
			$post['post_status'] = $request['active'] ? 'publish' : 'draft';
		}

		/*
		 * A rename keeps the modified date. It is the last tie-break between
		 * templates, and giving one a new name must not change which one shows.
		 */
		$is_rename = isset( $post['post_title'] ) && 1 === count( $post ) && null === $request['rules'] && null === $request['priority'];

		if ( $is_rename ) {
			add_filter( 'wp_insert_post_data', __CLASS__ . '::keep_modified_date', 10, 2 );
		}

		if ( $post ) {
			$result = wp_update_post( array_merge( [ 'ID' => $id ], $post ), true );

			if ( $is_rename ) {
				remove_filter( 'wp_insert_post_data', __CLASS__ . '::keep_modified_date', 10 );
			}

			if ( is_wp_error( $result ) ) {
				return $result;
			}
		}

		if ( null !== $request['rules'] ) {
			update_post_meta( $id, PP_Site_Builder::META_RULES, PP_Site_Builder_Rules::sanitize( $request['rules'] ) );
		}

		if ( null !== $request['priority'] ) {
			update_post_meta( $id, PP_Site_Builder::META_PRIORITY, (int) $request['priority'] );
		}

		PP_Site_Builder::rebuild_index();

		return rest_ensure_response( self::prepare_template( get_post( $id ) ) );
	}

	/**
	 * Put a post's stored modified date back on the data about to be saved.
	 *
	 * @since 3.2.0
	 * @param array $data    Post data about to be saved.
	 * @param array $postarr Post data as passed in.
	 * @return array
	 */
	public static function keep_modified_date( $data, $postarr ) {
		$existing = get_post( $postarr['ID'] );

		if ( $existing ) {
			$data['post_modified']     = $existing->post_modified;
			$data['post_modified_gmt'] = $existing->post_modified_gmt;
		}

		return $data;
	}

	/**
	 * The error for rules a template's type cannot take, or null when all fit.
	 *
	 * Checked before anything is written, so a refused change leaves the
	 * template as it was rather than half updated.
	 *
	 * @since 3.2.0
	 * @param string $type  Template type.
	 * @param mixed  $rules Rules as sent.
	 * @return \WP_Error|null
	 */
	private static function refused_rules( $type, $rules ) {
		$rules = PP_Site_Builder_Rules::sanitize( $rules );
		$wrong = [];

		foreach ( array_merge( $rules['include'], $rules['exclude'] ) as $rule ) {
			if ( ! PP_Site_Builder::rule_allowed( $type, $rule ) ) {
				$wrong[] = $rule;
			}
		}

		if ( ! $wrong ) {
			return null;
		}

		return new \WP_Error(
			'pp_site_builder_rule_not_allowed',
			/* translators: %s: list of display rules */
			sprintf( __( 'This type of template cannot use: %s', 'powerpack' ), implode( ', ', array_map( __NAMESPACE__ . '\PP_Site_Builder_Rules::describe', $wrong ) ) ),
			[
				'status' => 400,
				'rules'  => $wrong,
			]
		);
	}

	/**
	 * Move a template to the trash, from where WordPress can restore it.
	 *
	 * @since 3.2.0
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function trash_template( $request ) {
		$id = (int) $request['id'];

		/*
		 * The trash keeps the modified date, as Undo does: it is the last
		 * tie-break between templates, and trash then Undo must leave the
		 * site showing what it showed.
		 */
		add_filter( 'wp_insert_post_data', __CLASS__ . '::keep_modified_date', 10, 2 );
		$trashed = wp_trash_post( $id );
		remove_filter( 'wp_insert_post_data', __CLASS__ . '::keep_modified_date', 10 );

		if ( ! $trashed ) {
			return new \WP_Error( 'pp_site_builder_trash_failed', __( 'The template could not be moved to the trash.', 'powerpack' ), [ 'status' => 500 ] );
		}

		PP_Site_Builder::rebuild_index();

		return rest_ensure_response( [
			'trashed' => true,
			'id'      => $id,
		] );
	}

	/**
	 * Take a template out of the trash: the screen's Undo.
	 *
	 * It comes back as it went: active if it was, with its modified date.
	 * Core would bring it back as a draft.
	 *
	 * @since 3.2.0
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function restore_template( $request ) {
		$id = (int) $request['id'];

		add_filter( 'wp_untrash_post_status', 'wp_untrash_post_set_previous_status', 10, 3 );
		add_filter( 'wp_insert_post_data', __CLASS__ . '::keep_modified_date', 10, 2 );
		$restored = wp_untrash_post( $id );
		remove_filter( 'wp_insert_post_data', __CLASS__ . '::keep_modified_date', 10 );
		remove_filter( 'wp_untrash_post_status', 'wp_untrash_post_set_previous_status', 10 );

		if ( ! $restored ) {
			return new \WP_Error( 'pp_site_builder_restore_failed', __( 'The template could not be restored.', 'powerpack' ), [ 'status' => 500 ] );
		}

		PP_Site_Builder::rebuild_index();

		return rest_ensure_response( self::prepare_template( get_post( $id ) ) );
	}

	/**
	 * Copy a template, content and settings included.
	 *
	 * The copy starts inactive. Active, it would be the newest match for every
	 * page the original covers and would take them over at once.
	 *
	 * @since 3.2.0
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function duplicate_template( $request ) {
		$source = get_post( (int) $request['id'] );

		$id = wp_insert_post( [
			'post_type'   => PP_Site_Builder::POST_TYPE,
			'post_status' => 'draft',
			/* translators: %s: title of the template being copied */
			'post_title'  => sprintf( __( '%s (Copy)', 'powerpack' ), $source->post_title ),
		], true );

		if ( is_wp_error( $id ) ) {
			return $id;
		}

		$content_id = (int) get_post_meta( $source->ID, PP_Site_Builder::META_SOURCE, true );

		if ( $content_id ) {
			self::copy_migrated( $source->ID, $content_id, $id );
		} else {
			self::copy_meta( $source->ID, $id );
		}

		$response = rest_ensure_response( self::prepare_template( get_post( $id ) ) );
		$response->set_status( 201 );

		return $response;
	}

	/**
	 * Copy every meta value from one post to another.
	 *
	 * Per-post caches are rebuilt from the content, so they are not copied.
	 *
	 * @since 3.2.0
	 * @param int        $from Post to copy from.
	 * @param int        $to   Post to copy to.
	 * @param array|null $only Keys to copy; all of them when null.
	 * @return void
	 */
	private static function copy_meta( $from, $to, $only = null ) {
		$skip = [ '_edit_lock', '_edit_last', '_elementor_css', '_elementor_element_cache', '_elementor_page_assets', '_wp_old_slug' ];

		foreach ( get_post_meta( $from ) as $key => $values ) {
			if ( in_array( $key, $skip, true ) || ( null !== $only && ! in_array( $key, $only, true ) ) ) {
				continue;
			}

			foreach ( $values as $value ) {
				add_post_meta( $to, $key, wp_slash( maybe_unserialize( $value ) ) );
			}
		}
	}

	/**
	 * Copy a migrated template into a template of its own.
	 *
	 * A migrated template has no content: it points at the page the old
	 * settings assigned. Copying that pointer would leave two templates on one
	 * page, so editing the "copy" would change the original too. The copy
	 * takes the page's Elementor content instead and becomes an ordinary
	 * template, with the old sticky and overlay settings moved onto the
	 * header controls that replace them.
	 *
	 * @since 3.2.0
	 * @param int $template_id Migrated template.
	 * @param int $content_id  Page it renders.
	 * @param int $copy_id     New template.
	 * @return void
	 */
	private static function copy_migrated( $template_id, $content_id, $copy_id ) {
		self::copy_meta( $template_id, $copy_id, [ PP_Site_Builder::META_TYPE, PP_Site_Builder::META_RULES, PP_Site_Builder::META_PRIORITY ] );
		self::copy_meta( $content_id, $copy_id, [ '_elementor_data', '_elementor_edit_mode', '_elementor_version' ] );

		$type = get_post_meta( $template_id, PP_Site_Builder::META_TYPE, true );

		update_post_meta( $copy_id, '_elementor_template_type', PP_Site_Builder::get_document_type( $type ) );

		if ( 'header' !== $type ) {
			return;
		}

		$legacy  = PP_Site_Builder::get_settings( $template_id );
		$devices = [
			'all'               => [ 'desktop', 'tablet', 'mobile' ],
			'large'             => [ 'desktop' ],
			'large-medium'      => [ 'desktop', 'tablet' ],
			'medium'            => [ 'tablet' ],
			'medium-responsive' => [ 'tablet', 'mobile' ],
			'responsive'        => [ 'mobile' ],
		];

		// Shrink has no single equivalent: the Scrolled State styles do that job now.
		update_post_meta( $copy_id, '_elementor_page_settings', [
			'pp_sticky'      => $legacy['sticky'] ? 'yes' : '',
			'pp_sticky_on'   => $devices[ $legacy['sticky_breakpoints'] ],
			'pp_transparent' => $legacy['overlay'] ? 'yes' : '',
		] );
	}

	/**
	 * A template as the screen uses it.
	 *
	 * @since 3.2.0
	 * @param \WP_Post $post Template post.
	 * @return array
	 */
	public static function prepare_template( $post ) {
		$rules  = PP_Site_Builder_Rules::sanitize( get_post_meta( $post->ID, PP_Site_Builder::META_RULES, true ) );
		$source = (int) get_post_meta( $post->ID, PP_Site_Builder::META_SOURCE, true );
		$labels = [];

		foreach ( array_merge( $rules['include'], $rules['exclude'] ) as $rule ) {
			$labels[ $rule ] = PP_Site_Builder_Rules::describe( $rule );
		}

		$content_id = $source ? $source : $post->ID;

		return [
			'id'            => (int) $post->ID,
			// Saving can encode & and <, and the screen prints plain text, entities included.
			'title'         => wp_specialchars_decode( $post->post_title, ENT_QUOTES ),
			'type'          => get_post_meta( $post->ID, PP_Site_Builder::META_TYPE, true ),
			'active'        => 'publish' === $post->post_status,
			'rules'         => $rules,
			'labels'        => $labels,
			'priority'      => PP_Site_Builder::get_priority( $post->ID ),

			// A draft has no GMT dates until it is published, and inactive templates are drafts.
			'modified'      => mysql_to_rfc3339( '0000-00-00 00:00:00' === $post->post_modified_gmt ? get_gmt_from_date( $post->post_modified ) : $post->post_modified_gmt ),
			'editUrl'       => admin_url( 'post.php?post=' . $content_id . '&action=elementor' ),
			'migrated'      => (bool) $source,
			'sourceMissing' => $source && 'publish' !== get_post_status( $source ),
			'behaviour'     => 'header' === get_post_meta( $post->ID, PP_Site_Builder::META_TYPE, true ) ? self::describe_behaviour( $post->ID ) : [],
		];
	}

	/**
	 * A header's behaviour as short phrases for the template list.
	 *
	 * @since 3.2.0
	 * @param int $template_id Template post ID.
	 * @return string[]
	 */
	private static function describe_behaviour( $template_id ) {
		$phrases = [];

		if ( PP_Site_Builder::is_native( $template_id ) ) {
			$behaviour = PP_Site_Builder::get_behaviour( $template_id );
			$flags     = [
				'sticky'         => __( 'Sticky', 'powerpack' ),
				'hide_on_scroll' => __( 'Hides on scroll down', 'powerpack' ),
				'transparent'    => __( 'Transparent at top', 'powerpack' ),
			];
		} else {
			$behaviour = PP_Site_Builder::get_settings( $template_id );
			$flags     = [
				'sticky'  => __( 'Sticky', 'powerpack' ),
				'shrink'  => __( 'Shrinks on scroll', 'powerpack' ),
				'overlay' => __( 'Overlays the page', 'powerpack' ),
			];
		}

		foreach ( $flags as $key => $phrase ) {
			if ( ! empty( $behaviour[ $key ] ) ) {
				$phrases[] = $phrase;
			}
		}

		return $phrases;
	}

	/* ---------------------------------------------------------------------
	 * Rules
	 * ------------------------------------------------------------------ */

	/**
	 * The rules a template type can take, grouped as the picker shows them.
	 *
	 * An option with 'items' can also narrow to one post or term, picked by
	 * searching through search_items(). One with 'requiresItem' means nothing
	 * until an item is picked: "In Product categories" needs a category.
	 *
	 * @since 3.2.0
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response
	 */
	public static function get_rule_options( $request ) {
		$type = $request['type'];

		$option = function ( $value, $items = null, $subtype = null, $requires_item = false ) {
			$label = PP_Site_Builder_Rules::describe( $value );

			return [
				'value'        => $value,
				'label'        => $label,
				'items'        => $items,
				'subtype'      => $subtype,
				'requiresItem' => $requires_item,

				// What the item picker calls its choices: "Product categories", not "In Product categories".
				'itemsLabel'   => 'term' === $items && $subtype ? PP_Site_Builder_Rules::describe( 'archive/taxonomy/' . $subtype ) : $label,
			];
		};

		$general = [];

		foreach ( [ 'entire_site', 'front_page', 'blog', 'search', 'not_found' ] as $rule ) {
			$general[] = $option( $rule );
		}

		$singular = [ $option( 'singular' ) ];
		$archives = [ $option( 'archive' ) ];

		foreach ( self::get_post_types() as $post_type ) {
			$singular[] = $option( 'singular/' . $post_type->name, 'post', $post_type->name );

			if ( 'post' === $post_type->name || $post_type->has_archive ) {
				$archives[] = $option( 'archive/' . $post_type->name );
			}
		}

		$archives[] = $option( 'archive/author' );
		$archives[] = $option( 'archive/date' );

		$taxonomies = get_taxonomies( [
			'public'  => true,
			'show_ui' => true,
		], 'objects' );

		foreach ( $taxonomies as $taxonomy ) {
			if ( 'post_format' === $taxonomy->name ) {
				continue;
			}

			$singular[] = $option( 'singular_in/' . $taxonomy->name, 'term', $taxonomy->name, true );
			$archives[] = $option( 'archive/taxonomy/' . $taxonomy->name, 'term', $taxonomy->name );
		}

		$groups = [
			[
				'label'   => __( 'General', 'powerpack' ),
				'options' => $general,
			],
			[
				'label'   => __( 'Singular', 'powerpack' ),
				'options' => $singular,
			],
			[
				'label'   => __( 'Archives', 'powerpack' ),
				'options' => $archives,
			],
		];

		if ( PP_Site_Builder::has_woocommerce() ) {
			$store = [ $option( 'shop' ) ];

			foreach ( PP_Site_Builder_Woo::PAGES as $page ) {
				$store[] = $option( 'woo/' . $page );
			}

			$groups[] = [
				'label'   => __( 'WooCommerce', 'powerpack' ),
				'options' => $store,
			];
		}

		// An option that needs an item is allowed if any item would be; any ID shows that.
		foreach ( $groups as $index => $group ) {
			$groups[ $index ]['options'] = array_values( array_filter( $group['options'], function ( $item ) use ( $type ) {
				return PP_Site_Builder::rule_allowed( $type, $item['value'] . ( $item['requiresItem'] ? '/1' : '' ) );
			} ) );
		}

		return rest_ensure_response( [
			'groups' => array_values( array_filter( $groups, function ( $group ) {
				return (bool) $group['options'];
			} ) ),
		] );
	}
	/**
	 * Posts or terms matching a search, for narrowing a rule to one of them.
	 *
	 * @since 3.2.0
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function search_items( $request ) {
		$subtype = $request['subtype'];
		$items   = [];

		if ( 'post' === $request['kind'] ) {
			if ( ! array_key_exists( $subtype, self::get_post_types() ) ) {
				return new \WP_Error( 'pp_site_builder_bad_subtype', __( 'Unknown post type.', 'powerpack' ), [ 'status' => 400 ] );
			}

			$posts = get_posts( [
				'post_type'      => $subtype,
				'post_status'    => 'publish',
				's'              => $request['search'],
				'posts_per_page' => 20,
				'orderby'        => '' === $request['search'] ? 'title' : 'relevance',
				'order'          => 'ASC',
				'no_found_rows'  => true,
			] );

			foreach ( $posts as $post ) {
				$items[] = [
					'id'    => (int) $post->ID,
					'title' => '' !== $post->post_title ? $post->post_title : sprintf( '#%d', $post->ID ),
				];
			}
		} else {
			$taxonomy = get_taxonomy( $subtype );

			if ( ! $taxonomy || ! $taxonomy->public ) {
				return new \WP_Error( 'pp_site_builder_bad_subtype', __( 'Unknown taxonomy.', 'powerpack' ), [ 'status' => 400 ] );
			}

			$terms = get_terms( [
				'taxonomy'   => $subtype,
				'search'     => $request['search'],
				'number'     => 20,
				'hide_empty' => false,
			] );

			foreach ( is_wp_error( $terms ) ? [] : $terms as $term ) {
				$items[] = [
					'id'    => (int) $term->term_id,
					'title' => $term->name,
				];
			}
		}

		return rest_ensure_response( [ 'items' => $items ] );
	}

	/**
	 * Post types a rule can target, keyed by name.
	 *
	 * @since 3.2.0
	 * @return \WP_Post_Type[]
	 */
	private static function get_post_types() {
		$post_types = get_post_types( [ 'public' => true ], 'objects' );

		unset( $post_types['attachment'], $post_types['elementor_library'], $post_types['e-landing-page'], $post_types[ PP_Site_Builder::POST_TYPE ] );

		return $post_types;
	}

	/* ---------------------------------------------------------------------
	 * Notices
	 * ------------------------------------------------------------------ */

	/**
	 * Which notices the screen should show.
	 *
	 * @since 3.2.0
	 * @param \WP_Post[] $posts Every template.
	 * @return array
	 */
	private static function get_notices( $posts ) {
		$dismissed = (array) get_option( self::DISMISSED_OPTION, [] );
		$migrated  = [];

		foreach ( $posts as $post ) {
			if ( get_post_meta( $post->ID, PP_Site_Builder::META_SOURCE, true ) ) {
				$migrated[ get_post_meta( $post->ID, PP_Site_Builder::META_TYPE, true ) ] = true;
			}
		}

		// One notice per move, as they arrive in different releases: dismissing the first must not hide the second.
		$site  = isset( $migrated['header'] ) || isset( $migrated['footer'] );
		$store = isset( $migrated['single_product'] ) || isset( $migrated['product_archive'] );

		return [
			'migrated'     => $site && empty( $dismissed['migrated'] ),
			'migratedWoo'  => $store && empty( $dismissed['migrated_woo'] ),
			'elementorPro' => empty( $dismissed['elementor_pro'] ) ? self::elementor_pro_types() : [],
		];
	}

	/**
	 * Template types Elementor Pro's Theme Builder also has a template for.
	 *
	 * Read from the templates rather than from Elementor Pro's conditions
	 * API, which only answers for the request being served. Any template
	 * with conditions counts, even ones that cover only some pages, since
	 * PowerPack steps aside wherever both apply.
	 *
	 * @since 3.2.0
	 * @return string[] Template types, e.g. [ 'header', 'single_product' ].
	 */
	private static function elementor_pro_types() {
		if ( ! class_exists( '\ElementorPro\Plugin' ) || ! \ElementorPro\Plugin::instance()->modules_manager->get_modules( 'theme-builder' ) ) {
			return [];
		}

		// Elementor Pro's template type for each PowerPack type it competes with.
		$pro_types = [
			'header'          => 'header',
			'footer'          => 'footer',
			'single_product'  => 'product',
			'product_archive' => 'product-archive',
		];

		$types = [];

		foreach ( $pro_types as $type => $pro_type ) {
			if ( ! PP_Site_Builder::get_type_definition( $type ) ) {
				continue;
			}

			$ids = get_posts( [
				'post_type'        => 'elementor_library',
				'post_status'      => 'publish',
				'posts_per_page'   => 1,
				'fields'           => 'ids',
				'no_found_rows'    => true,
				'suppress_filters' => true,
				'meta_query'       => [
					[
						'key'   => '_elementor_template_type',
						'value' => $pro_type,
					],
					[
						'key'     => '_elementor_conditions',
						'value'   => 'a:0:{}',
						'compare' => '!=',
					],
				],
			] );

			if ( $ids ) {
				$types[] = $type;
			}
		}

		return $types;
	}

	/**
	 * Stop showing a notice on this site.
	 *
	 * @since 3.2.0
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response
	 */
	public static function dismiss_notice( $request ) {
		$dismissed = (array) get_option( self::DISMISSED_OPTION, [] );

		$dismissed[ $request['notice'] ] = true;

		update_option( self::DISMISSED_OPTION, $dismissed, false );

		return rest_ensure_response( [ 'dismissed' => $request['notice'] ] );
	}
}

PP_Site_Builder_REST::init();
