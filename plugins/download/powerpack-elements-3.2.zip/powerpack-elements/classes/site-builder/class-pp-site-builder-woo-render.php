<?php
namespace PowerpackElements\Classes;

/**
 * Renders the WooCommerce Site Builder templates on the store's pages.
 *
 * The page type is worked out once the main query has run, the template for
 * it resolved through the display rules, and only then are WooCommerce's
 * templates swapped, so a store page with no template is never touched.
 *
 * Markup matches what the old WooCommerce builder printed, so stylesheets
 * written for it keep working: the product sits in
 * #product-{id} > .pp-woo-template-builder, an archive in .pp-archive-product.
 *
 * @package PowerPack Elements
 * @since 3.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PP_Site_Builder_Woo_Render
 */
final class PP_Site_Builder_Woo_Render {

	/**
	 * Page layouts a store template can choose.
	 *
	 * theme: inside the theme's own page. full_width: the theme's header and
	 * footer around the template alone. canvas: the template alone.
	 *
	 * @since 3.2.0
	 */
	const LAYOUTS = [ 'theme', 'full_width', 'canvas' ];

	/**
	 * Store types that replace a page's content rather than a WooCommerce template.
	 *
	 * @since 3.2.0
	 */
	const PAGE_TYPES = [ 'cart', 'checkout', 'my_account', 'thankyou' ];

	/**
	 * Template type serving this request, or ''.
	 *
	 * @var string
	 * @since 3.2.0
	 */
	private static $type = '';

	/**
	 * Site Builder template serving this request.
	 *
	 * @var int
	 * @since 3.2.0
	 */
	private static $template = 0;

	/**
	 * Post whose Elementor content renders, which differs from the template
	 * for one migrated from the old builder.
	 *
	 * @var int
	 * @since 3.2.0
	 */
	private static $content = 0;

	/**
	 * Initialize hooks.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	public static function init() {
		if ( ! did_action( 'elementor/loaded' ) ) {
			return;
		}

		// After PP_Header_Footer, which resolves at 5; the two are independent.
		add_action( 'wp', __CLASS__ . '::resolve', 6 );
	}

	/**
	 * Find the template for this request, if it is a store page with one.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	public static function resolve() {
		if ( is_admin() || ! PP_Site_Builder::has_woocommerce() ) {
			return;
		}

		$type = self::request_type();

		if ( ! $type ) {
			return;
		}

		$template = PP_Site_Builder::get_template_for( $type );
		$content  = PP_Site_Builder::get_content_id( $template );

		if ( ! $content ) {
			return;
		}

		self::$type     = $type;
		self::$template = $template;
		self::$content  = $content;

		add_action( 'wp_enqueue_scripts', __CLASS__ . '::enqueue_styles' );
		add_filter( 'body_class', __CLASS__ . '::body_class' );

		if ( 'single_product' === $type ) {
			add_filter( 'wc_get_template_part', __CLASS__ . '::single_product_part', 99, 3 );
			add_action( 'pp_woocommerce_product_content', __CLASS__ . '::render_content', 5 );
			add_action( 'pp_woocommerce_product_content', __CLASS__ . '::product_structured_data', 10 );
		} elseif ( 'product_archive' === $type ) {
			add_action( 'pp_woocommerce_archive_product_content', __CLASS__ . '::render_content' );
		} elseif ( 'theme' === self::get_layout() ) {
			add_filter( 'the_content', __CLASS__ . '::replace_page_content', 999 );
		}

		if ( self::needs_page_template() ) {
			add_filter( 'template_include', __CLASS__ . '::template_include', 999 );
		}
	}

	/**
	 * Which store template type this request is for, or ''.
	 *
	 * The order received page is an endpoint of the checkout, so it is
	 * checked before the checkout. A product search lists in the archive.
	 *
	 * @since 3.2.0
	 * @return string
	 */
	public static function request_type() {
		if ( is_product() ) {
			return 'single_product';
		}

		if ( is_shop() || is_product_taxonomy() || ( is_search() && 'product' === get_query_var( 'post_type' ) ) ) {
			return 'product_archive';
		}

		if ( is_wc_endpoint_url( 'order-received' ) ) {
			return 'thankyou';
		}

		if ( is_cart() ) {
			return 'cart';
		}

		if ( is_checkout() ) {
			return 'checkout';
		}

		return is_account_page() ? 'my_account' : '';
	}

	/**
	 * Whether a template of this type is serving the request.
	 *
	 * @since 3.2.0
	 * @param string $type Template type.
	 * @return bool
	 */
	public static function handles( $type ) {
		return $type === self::$type && self::$content;
	}

	/**
	 * A template's page layout.
	 *
	 * A native template sets it in its Elementor document settings. One
	 * migrated from the old builder keeps the page template its source used,
	 * which is how the old builder chose a layout.
	 *
	 * @since 3.2.0
	 * @param int $template_id Template post ID. Defaults to the one serving this request.
	 * @return string One of LAYOUTS.
	 */
	public static function get_layout( $template_id = 0 ) {
		$template_id = $template_id ? $template_id : self::$template;

		if ( PP_Site_Builder::is_native( $template_id ) ) {
			$settings = get_post_meta( $template_id, '_elementor_page_settings', true );
			$layout   = is_array( $settings ) && ! empty( $settings['pp_page_layout'] ) ? $settings['pp_page_layout'] : 'theme';
		} else {
			$legacy = [
				'elementor_header_footer' => 'full_width',
				'elementor_canvas'        => 'canvas',
			];
			$slug   = get_page_template_slug( PP_Site_Builder::get_content_id( $template_id ) );
			$layout = isset( $legacy[ $slug ] ) ? $legacy[ $slug ] : 'theme';
		}

		return in_array( $layout, self::LAYOUTS, true ) ? $layout : 'theme';
	}

	/**
	 * Whether this request needs PowerPack's page template.
	 *
	 * Archives always do, as they did before. A product or store page only
	 * when its layout is not the theme's own, or the theme is a block theme,
	 * which never calls the WooCommerce template functions swapped above.
	 *
	 * @since 3.2.0
	 * @return bool
	 */
	private static function needs_page_template() {
		if ( 'product_archive' === self::$type ) {
			return true;
		}

		if ( 'single_product' === self::$type && self::is_block_theme() ) {
			return true;
		}

		return 'theme' !== self::get_layout();
	}

	/**
	 * Whether the active theme is a block theme.
	 *
	 * @since 3.2.0
	 * @return bool
	 */
	public static function is_block_theme() {
		return function_exists( 'wp_is_block_theme' ) && wp_is_block_theme();
	}

	/* ---------------------------------------------------------------------
	 * Output
	 * ------------------------------------------------------------------ */

	/**
	 * The template's styles in the head, before anything renders.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	public static function enqueue_styles() {
		$elementor = \Elementor\Plugin::instance();

		$elementor->frontend->enqueue_styles();

		if ( class_exists( '\Elementor\Core\Files\CSS\Post' ) ) {
			( new \Elementor\Core\Files\CSS\Post( self::$content ) )->enqueue();
		}
	}

	/**
	 * Mark the page as one a Site Builder template renders.
	 *
	 * @since 3.2.0
	 * @param array $classes Body classes.
	 * @return array
	 */
	public static function body_class( $classes ) {
		$classes[] = 'pp-site-builder-' . str_replace( '_', '-', self::$type );

		return $classes;
	}

	/**
	 * Swap WooCommerce's product content for the template's wrapper.
	 *
	 * @since 3.2.0
	 * @param string $template Template file.
	 * @param string $slug     Template part slug.
	 * @param string $name     Template part name.
	 * @return string
	 */
	public static function single_product_part( $template, $slug, $name ) {
		if ( 'content' === $slug && 'single-product' === $name ) {
			return POWERPACK_ELEMENTS_PATH . 'templates/woocommerce/single-product.php';
		}

		return $template;
	}

	/**
	 * Print the template's Elementor content.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	public static function render_content() {
		echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( self::$content ); //phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Keep the product's schema.org data, which WooCommerce prints from its
	 * own single product template.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	public static function product_structured_data() {
		if ( isset( WC()->structured_data ) ) {
			WC()->structured_data->generate_product_data();
		}
	}

	/**
	 * Put the template in place of a store page's own content.
	 *
	 * Only for the page itself in the main query: the cart and checkout pages
	 * call the_content for other things too, such as a widget's excerpt. A
	 * block theme's post content block runs outside the classic loop, so the
	 * loop check applies to classic themes only.
	 *
	 * @since 3.2.0
	 * @param string $content Page content.
	 * @return string
	 */
	public static function replace_page_content( $content ) {
		if ( ( ! self::is_block_theme() && ! in_the_loop() ) || ! is_main_query() || get_the_ID() !== get_queried_object_id() ) {
			return $content;
		}

		// The template's own widgets may call the_content; they must get the real thing.
		remove_filter( 'the_content', __CLASS__ . '::replace_page_content', 999 );

		ob_start();
		self::render_main();

		return ob_get_clean();
	}

	/**
	 * PowerPack's page template for this request.
	 *
	 * @since 3.2.0
	 * @param string $template Template file WordPress chose.
	 * @return string
	 */
	public static function template_include( $template ) {
		return POWERPACK_ELEMENTS_PATH . 'templates/site-builder/woo-page.php';
	}

	/**
	 * The template inside the wrapper the old builder used for its type.
	 *
	 * Called from the page template and from the content replacement.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	public static function render_main() {
		if ( 'single_product' === self::$type ) {
			while ( have_posts() ) {
				the_post();
				wc_get_template_part( 'content', 'single-product' );
			}

			return;
		}

		if ( 'product_archive' === self::$type ) {
			echo '<div class="pp-archive-product">';

			/**
			 * Print a Site Builder product archive. The old WooCommerce
			 * builder's hook, kept for code that adds to it.
			 *
			 * @since 2.1.0
			 */
			do_action( 'pp_woocommerce_archive_product_content' );

			echo '</div>';

			return;
		}

		echo '<div class="pp-woo-page pp-woo-page--' . esc_attr( str_replace( '_', '-', self::$type ) ) . '">';
		self::render_content();
		echo '</div>';
	}
}

PP_Site_Builder_Woo_Render::init();
