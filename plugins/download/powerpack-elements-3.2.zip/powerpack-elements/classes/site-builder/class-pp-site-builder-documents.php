<?php
namespace PowerpackElements\Classes;

use Elementor\Controls_Manager;
use Elementor\Core\Base\Document;
use Elementor\Group_Control_Box_Shadow;

/**
 * Elementor document types for Site Builder templates.
 *
 * Loaded from 'elementor/documents/register', once Elementor's base classes
 * exist.
 *
 * @package PowerPack Elements
 * @since 3.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PP_Site_Builder_Document
 *
 * @since 3.2.0
 */
abstract class PP_Site_Builder_Document extends Document {

	/**
	 * Document properties.
	 *
	 * @since 3.2.0
	 * @return array
	 */
	public static function get_properties() {
		$properties = parent::get_properties();

		$properties['cpt']                 = [ PP_Site_Builder::POST_TYPE ];
		$properties['support_kit']         = true;
		$properties['support_page_layout'] = false;
		$properties['show_in_finder']      = false;
		$properties['show_copy_and_share'] = true;

		return $properties;
	}

	/**
	 * What {{WRAPPER}} becomes in this document's settings CSS.
	 *
	 * The base document has none, which would leave a state rule such as
	 * '[data-pp-state~="scrolled"] {{WRAPPER}} img' reaching every image on
	 * the page. The template's own wrapper keeps it to the template, on the
	 * site and in the editor preview alike.
	 *
	 * @since 3.2.0
	 * @return string
	 */
	public function get_css_wrapper_selector() {
		return '.elementor-' . $this->get_main_id();
	}
}

/**
 * PP_Site_Builder_Header_Document
 *
 * @since 3.2.0
 */
class PP_Site_Builder_Header_Document extends PP_Site_Builder_Document {

	/**
	 * Document type.
	 *
	 * @since 3.2.0
	 * @return string
	 */
	public static function get_type() {
		return 'pp-header';
	}

	/**
	 * Document title.
	 *
	 * @since 3.2.0
	 * @return string
	 */
	public static function get_title() {
		return esc_html__( 'PowerPack Header', 'powerpack' );
	}

	/**
	 * Document plural title.
	 *
	 * @since 3.2.0
	 * @return string
	 */
	public static function get_plural_title() {
		return esc_html__( 'PowerPack Headers', 'powerpack' );
	}

	/**
	 * Header behaviour and state styles, first in the document's Settings tab.
	 *
	 * The state styles target the header's top-level elements while an
	 * ancestor carries the state: on the site that is the <header> the
	 * states script updates, in the editor it is the preview's body, which
	 * the editor script points at the state picked under Preview.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	protected function register_controls() {
		$scrolled = '[data-pp-state~="scrolled"] {{WRAPPER}}';

		/*
		 * Doubled class: beats the 0,3,0 an element's own background and
		 * padding use. The editor puts a .elementor-section-wrap between the
		 * wrapper and the top-level elements, which the site does not.
		 */
		$top_level = $scrolled . ' > .elementor-element.elementor-element, ' . $scrolled . ' > .elementor-section-wrap > .elementor-element.elementor-element';

		$this->start_controls_section( 'pp_header_behaviour', [
			'label' => esc_html__( 'Header Behaviour', 'powerpack' ),
			'tab'   => Controls_Manager::TAB_SETTINGS,
		] );

		$this->add_control( 'pp_preview_state', [
			'label'       => esc_html__( 'Preview', 'powerpack' ),
			'type'        => Controls_Manager::CHOOSE,
			'options'     => [
				'top'      => [
					'title' => esc_html__( 'Top of page', 'powerpack' ),
					'icon'  => 'eicon-v-align-top',
				],
				'scrolled' => [
					'title' => esc_html__( 'Scrolled', 'powerpack' ),
					'icon'  => 'eicon-v-align-middle',
				],
			],
			'default'     => 'top',
			'toggle'      => false,
			'render_type' => 'none',
			'description' => esc_html__( 'Shows the header as it looks at the top of the page or after scrolling. Scrolled styles below only apply in that state.', 'powerpack' ),
		] );

		$this->add_control( 'pp_sticky', [
			'label'     => esc_html__( 'Sticky', 'powerpack' ),
			'type'      => Controls_Manager::SWITCHER,
			'separator' => 'before',
		] );

		$this->add_control( 'pp_sticky_on', [
			'label'       => esc_html__( 'Sticky On', 'powerpack' ),
			'type'        => Controls_Manager::SELECT2,
			'multiple'    => true,
			'label_block' => true,
			'options'     => [
				'desktop' => esc_html__( 'Desktop', 'powerpack' ),
				'tablet'  => esc_html__( 'Tablet', 'powerpack' ),
				'mobile'  => esc_html__( 'Mobile', 'powerpack' ),
			],
			'default'     => [ 'desktop', 'tablet', 'mobile' ],
			'condition'   => [ 'pp_sticky' => 'yes' ],
		] );

		$this->add_control( 'pp_hide_on_scroll', [
			'label'       => esc_html__( 'Hide on Scroll Down', 'powerpack' ),
			'type'        => Controls_Manager::SWITCHER,
			'description' => esc_html__( 'Slides away while reading down the page and comes back on scroll up, or as soon as a link in it gets keyboard focus.', 'powerpack' ),
			'condition'   => [ 'pp_sticky' => 'yes' ],
		] );

		$this->add_control( 'pp_transparent', [
			'label'       => esc_html__( 'Transparent at Top', 'powerpack' ),
			'type'        => Controls_Manager::SWITCHER,
			'separator'   => 'before',
			'description' => esc_html__( 'Sits over the top of the page with no background, then takes its normal background once scrolled.', 'powerpack' ),
		] );

		$this->add_control( 'pp_transparent_color', [
			'label'     => esc_html__( 'Text Color at Top', 'powerpack' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				// Repeated attribute: outranks the 0,4,0 a widget's own text colour uses.
				'[data-pp-transparent][data-pp-state~="top"][data-pp-state~="top"] {{WRAPPER}} :is(.elementor-heading-title, .elementor-item, .elementor-button, .elementor-icon, a)' => 'color: {{VALUE}}; fill: {{VALUE}};',
			],
			'condition' => [ 'pp_transparent' => 'yes' ],
		] );

		$this->end_controls_section();

		$this->start_controls_section( 'pp_header_scrolled', [
			'label' => esc_html__( 'Scrolled State', 'powerpack' ),
			'tab'   => Controls_Manager::TAB_SETTINGS,
		] );

		$this->add_control( 'pp_scrolled_offset', [
			'label'       => esc_html__( 'Starts After', 'powerpack' ),
			'type'        => Controls_Manager::SLIDER,
			'size_units'  => [ 'px' ],
			'range'       => [
				'px' => [
					'min' => 0,
					'max' => 600,
				],
			],
			'default'     => [
				'unit' => 'px',
				'size' => 80,
			],
			'description' => esc_html__( 'How far the page scrolls before the header changes state.', 'powerpack' ),
		] );

		$this->add_control( 'pp_scrolled_background', [
			'label'     => esc_html__( 'Background Color', 'powerpack' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => [
				$top_level => 'background-color: {{VALUE}};',
			],
		] );

		$this->add_group_control( Group_Control_Box_Shadow::get_type(), [
			'name'     => 'pp_scrolled_shadow',
			'selector' => $scrolled,
		] );

		$this->add_responsive_control( 'pp_scrolled_padding', [
			'label'      => esc_html__( 'Vertical Padding', 'powerpack' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'px' ],
			'range'      => [
				'px' => [
					'min' => 0,
					'max' => 80,
				],
			],
			'selectors'  => [
				$top_level => 'padding-top: {{SIZE}}{{UNIT}}; padding-bottom: {{SIZE}}{{UNIT}};',
			],
		] );

		$this->add_responsive_control( 'pp_scrolled_image_height', [
			'label'       => esc_html__( 'Image Max Height', 'powerpack' ),
			'type'        => Controls_Manager::SLIDER,
			'size_units'  => [ 'px' ],
			'range'       => [
				'px' => [
					'min' => 16,
					'max' => 200,
				],
			],
			'description' => esc_html__( 'Shrinks the logo and any other images in the header.', 'powerpack' ),
			'selectors'   => [
				$scrolled . ' img' => 'max-height: {{SIZE}}{{UNIT}}; width: auto;',
			],
		] );

		$this->add_control( 'pp_state_transition', [
			'label'      => esc_html__( 'Transition Duration', 'powerpack' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => [ 'ms' ],
			'range'      => [
				'ms' => [
					'min'  => 0,
					'max'  => 1000,
					'step' => 50,
				],
			],
			'default'    => [
				'unit' => 'ms',
				'size' => 250,
			],
			'selectors'  => [
				'{{WRAPPER}}' => '--pp-header-transition: {{SIZE}}ms;',
			],
		] );

		$this->end_controls_section();

		$this->start_controls_section( 'pp_header_a11y', [
			'label' => esc_html__( 'Accessibility', 'powerpack' ),
			'tab'   => Controls_Manager::TAB_SETTINGS,
		] );

		$this->add_control( 'pp_skip_link', [
			'label'       => esc_html__( 'Skip to Content Link', 'powerpack' ),
			'type'        => Controls_Manager::SWITCHER,
			'default'     => 'yes',
			'description' => esc_html__( 'Lets keyboard users jump past the header. Added when PowerPack replaces your theme’s whole header; themes that keep their own header file keep their own link.', 'powerpack' ),
		] );

		$this->add_control( 'pp_skip_target', [
			'label'       => esc_html__( 'Skip Link Target', 'powerpack' ),
			'type'        => Controls_Manager::TEXT,
			'default'     => '#content',
			'placeholder' => '#content',
			'description' => esc_html__( 'The ID of the element your main content starts in.', 'powerpack' ),
			'condition'   => [ 'pp_skip_link' => 'yes' ],
		] );

		$this->end_controls_section();

		// After ours, so the header settings open first rather than below every other plugin's.
		parent::register_controls();
	}
}

/**
 * PP_Site_Builder_Footer_Document
 *
 * @since 3.2.0
 */
class PP_Site_Builder_Footer_Document extends PP_Site_Builder_Document {

	/**
	 * Document type.
	 *
	 * @since 3.2.0
	 * @return string
	 */
	public static function get_type() {
		return 'pp-footer';
	}

	/**
	 * Document title.
	 *
	 * @since 3.2.0
	 * @return string
	 */
	public static function get_title() {
		return esc_html__( 'PowerPack Footer', 'powerpack' );
	}

	/**
	 * Document plural title.
	 *
	 * @since 3.2.0
	 * @return string
	 */
	public static function get_plural_title() {
		return esc_html__( 'PowerPack Footers', 'powerpack' );
	}
}
