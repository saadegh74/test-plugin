<?php
namespace PowerpackElements\Classes;

/**
 * Site Builder columns on the template list screen, and the way back to the
 * Site Builder screen from everywhere else a template can be reached.
 *
 * Templates are managed on the Site Builder screen, so leaving the editor,
 * WordPress's template list and its edit screen all lead there instead,
 * opened on the template concerned. The list is kept for the trash, which
 * the Site Builder screen links to.
 *
 * @package PowerPack Elements
 * @since 3.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PP_Site_Builder_Admin
 */
final class PP_Site_Builder_Admin {

	/**
	 * Initialize hooks.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	public static function init() {
		$post_type = PP_Site_Builder::POST_TYPE;

		add_filter( "manage_{$post_type}_posts_columns", __CLASS__ . '::columns' );
		add_action( "manage_{$post_type}_posts_custom_column", __CLASS__ . '::render_column', 10, 2 );
		add_filter( 'post_row_actions', __CLASS__ . '::row_actions', 20, 2 );

		add_filter( 'elementor/document/urls/exit_to_dashboard', __CLASS__ . '::exit_url', 10, 2 );
		add_filter( 'elementor/document/urls/all_post_type', __CLASS__ . '::all_templates_url', 10, 2 );
		add_action( 'load-edit.php', __CLASS__ . '::redirect_screen' );
		add_action( 'load-post.php', __CLASS__ . '::redirect_screen' );
		add_action( 'load-post-new.php', __CLASS__ . '::redirect_screen' );
	}

	/**
	 * The Site Builder screen, opened on a view, or '' when white label has
	 * taken the screen out of the menu.
	 *
	 * The view is read by the screen once: a template type, 'new' for the Add
	 * New dialog, or 'template-{id}' for one template.
	 *
	 * @since 3.2.0
	 * @param string $view View to open on.
	 * @return string
	 */
	public static function screen_url( $view = '' ) {
		if ( ! PP_Admin_Settings::is_page_available( 'site_builder' ) ) {
			return '';
		}

		$url = PP_Admin_Settings::get_page_url( 'header_footer' );

		return $view ? $url . '/' . $view : $url;
	}

	/**
	 * Elementor's Exit, with "Exit to: This Post", goes back to the template
	 * on the Site Builder screen, where its display rules are set.
	 *
	 * Also for the page or library template a migrated template renders,
	 * which is what its Edit with Elementor opens.
	 *
	 * @since 3.2.0
	 * @param string                        $url      Exit URL.
	 * @param \Elementor\Core\Base\Document $document Document being edited.
	 * @return string
	 */
	public static function exit_url( $url, $document ) {
		$template = PP_Site_Builder::get_template_by_content( $document->get_main_id() );
		$screen   = $template ? self::screen_url( 'template-' . $template ) : '';

		return $screen ? $screen : $url;
	}

	/**
	 * Elementor's Exit with "Exit to: All Posts", for a template: the Site
	 * Builder screen, opened on that template's type.
	 *
	 * @since 3.2.0
	 * @param string                        $url      All posts URL.
	 * @param \Elementor\Core\Base\Document $document Document being edited.
	 * @return string
	 */
	public static function all_templates_url( $url, $document ) {
		$template = PP_Site_Builder::get_template_by_content( $document->get_main_id() );
		$screen   = $template ? self::screen_url( (string) get_post_meta( $template, PP_Site_Builder::META_TYPE, true ) ) : '';

		return $screen ? $screen : $url;
	}

	/**
	 * Where a request for WordPress's own template screens should go instead,
	 * or '' to let it through.
	 *
	 * The list goes to the Site Builder screen, Add New to its dialog, and a
	 * template's edit screen, which has nothing to edit, to that template.
	 * The trash list stays, as does every other action post.php handles.
	 *
	 * @since 3.2.0
	 * @param string $screen 'edit.php', 'post.php' or 'post-new.php'.
	 * @param array  $query  The request's query vars.
	 * @return string
	 */
	public static function redirect_target( $screen, $query ) {
		$post_type = isset( $query['post_type'] ) ? sanitize_key( $query['post_type'] ) : '';
		$action    = isset( $query['action'] ) ? sanitize_key( $query['action'] ) : '';
		$post_id   = isset( $query['post'] ) ? absint( $query['post'] ) : 0;

		if ( 'edit.php' === $screen && PP_Site_Builder::POST_TYPE === $post_type ) {
			return isset( $query['post_status'] ) && 'trash' === $query['post_status'] ? '' : self::screen_url();
		}

		if ( 'post-new.php' === $screen && PP_Site_Builder::POST_TYPE === $post_type ) {
			return self::screen_url( 'new' );
		}

		if ( 'post.php' === $screen && 'edit' === $action && $post_id && PP_Site_Builder::POST_TYPE === get_post_type( $post_id ) ) {
			return self::screen_url( 'template-' . $post_id );
		}

		return '';
	}

	/**
	 * Send a request for WordPress's own template screens to the Site Builder.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	public static function redirect_screen() {
		global $pagenow;

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read only, to choose where to send a GET request.
		$target = 'GET' === $_SERVER['REQUEST_METHOD'] ? self::redirect_target( $pagenow, wp_unslash( $_GET ) ) : '';

		if ( $target ) {
			wp_safe_redirect( $target );
			exit;
		}
	}

	/**
	 * Add the Site Builder columns after the title.
	 *
	 * @since 3.2.0
	 * @param array $columns Columns.
	 * @return array
	 */
	public static function columns( $columns ) {
		$added = [
			'pp_type'     => __( 'Type', 'powerpack' ),
			'pp_rules'    => __( 'Display on', 'powerpack' ),
			'pp_priority' => __( 'Priority', 'powerpack' ),
		];

		$position = array_search( 'title', array_keys( $columns ), true );
		$position = false === $position ? count( $columns ) : $position + 1;

		return array_slice( $columns, 0, $position, true ) + $added + array_slice( $columns, $position, null, true );
	}

	/**
	 * Render a Site Builder column.
	 *
	 * @since 3.2.0
	 * @param string $column  Column key.
	 * @param int    $post_id Post ID.
	 * @return void
	 */
	public static function render_column( $column, $post_id ) {
		switch ( $column ) {
			case 'pp_type':
				$types = PP_Site_Builder::get_types();
				$type  = get_post_meta( $post_id, PP_Site_Builder::META_TYPE, true );

				echo esc_html( isset( $types[ $type ] ) ? $types[ $type ] : __( 'None', 'powerpack' ) );
				break;

			case 'pp_rules':
				$rules = PP_Site_Builder_Rules::sanitize( get_post_meta( $post_id, PP_Site_Builder::META_RULES, true ) );

				if ( ! $rules['include'] ) {
					echo '<em>' . esc_html__( 'Not shown anywhere', 'powerpack' ) . '</em>';
					break;
				}

				echo esc_html( implode( ', ', array_map( __NAMESPACE__ . '\PP_Site_Builder_Rules::describe', $rules['include'] ) ) );

				if ( $rules['exclude'] ) {
					echo '<br><span class="description">';
					/* translators: %s: list of excluded locations */
					echo esc_html( sprintf( __( 'Except: %s', 'powerpack' ), implode( ', ', array_map( __NAMESPACE__ . '\PP_Site_Builder_Rules::describe', $rules['exclude'] ) ) ) );
					echo '</span>';
				}
				break;

			case 'pp_priority':
				echo esc_html( PP_Site_Builder::get_priority( $post_id ) );
				break;
		}
	}

	/**
	 * Point a migrated template's edit link at the page it renders.
	 *
	 * Elementor's own "Edit with Elementor" action would open the template
	 * post, which has no content of its own.
	 *
	 * @since 3.2.0
	 * @param array    $actions Row actions.
	 * @param \WP_Post $post    Post.
	 * @return array
	 */
	public static function row_actions( $actions, $post ) {
		if ( PP_Site_Builder::POST_TYPE !== $post->post_type ) {
			return $actions;
		}

		$source = (int) get_post_meta( $post->ID, PP_Site_Builder::META_SOURCE, true );

		if ( ! $source ) {
			return $actions;
		}

		unset( $actions['edit_with_elementor'] );

		if ( current_user_can( 'edit_post', $source ) ) {
			$actions['pp_edit_source'] = sprintf(
				'<a href="%s">%s</a>',
				esc_url( admin_url( 'post.php?post=' . $source . '&action=elementor' ) ),
				esc_html__( 'Edit with Elementor', 'powerpack' )
			);
		}

		return $actions;
	}
}

PP_Site_Builder_Admin::init();
