<?php
namespace PowerpackElements\Classes;

/**
 * WooCommerce in the Site Builder: the store's own display rules.
 *
 *   shop                                The Shop page.
 *   woo/cart | woo/checkout             The cart and checkout pages.
 *   woo/account                         Any My Account page or endpoint.
 *   woo/thankyou                        The order received page.
 *
 * They reach the rules engine through its filters, so the engine itself
 * knows nothing about WooCommerce. The matching below reads only the request
 * context, and is tested without WordPress like the engine's own rules.
 *
 * Hooked whether or not WooCommerce turns out to be active, because it loads
 * after this plugin: the context simply never names a store page without it.
 *
 * @package PowerPack Elements
 * @since 3.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PP_Site_Builder_Woo
 */
final class PP_Site_Builder_Woo {

	/**
	 * Store pages a woo/ rule can name.
	 *
	 * @since 3.2.0
	 */
	const PAGES = [ 'cart', 'checkout', 'account', 'thankyou' ];

	/**
	 * Initialize hooks.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	public static function init() {
		add_filter( 'pp_site_builder/context', __CLASS__ . '::add_context' );
		add_filter( 'pp_site_builder/rule_matches', __CLASS__ . '::rule_matches', 10, 3 );
		add_filter( 'pp_site_builder/rule_specificity', __CLASS__ . '::rule_specificity', 10, 2 );
		add_filter( 'pp_site_builder/describe_rule', __CLASS__ . '::describe_rule', 10, 2 );
	}

	/**
	 * Add the store page being served to the request context.
	 *
	 * The order received page is an endpoint of the checkout, so it is
	 * checked first: otherwise a Checkout template would replace it.
	 *
	 * @since 3.2.0
	 * @param array $context Request context.
	 * @return array
	 */
	public static function add_context( $context ) {
		$context['shop'] = false;
		$context['woo']  = '';

		if ( ! function_exists( 'is_shop' ) ) {
			return $context;
		}

		$context['shop'] = is_shop();

		if ( is_wc_endpoint_url( 'order-received' ) ) {
			$context['woo'] = 'thankyou';
		} elseif ( is_cart() ) {
			$context['woo'] = 'cart';
		} elseif ( is_checkout() ) {
			$context['woo'] = 'checkout';
		} elseif ( is_account_page() ) {
			$context['woo'] = 'account';
		}

		return $context;
	}

	/**
	 * Match the store rules.
	 *
	 * @since 3.2.0
	 * @param bool   $matches Whether another handler already matched it.
	 * @param string $rule    Rule path.
	 * @param array  $context Request context.
	 * @return bool
	 */
	public static function rule_matches( $matches, $rule, $context ) {
		if ( 'shop' === $rule ) {
			return ! empty( $context['shop'] );
		}

		$page = self::woo_page( $rule );

		if ( $page ) {
			return isset( $context['woo'] ) && $page === $context['woo'];
		}

		return $matches;
	}

	/**
	 * Store rules name one page each, as narrow as a front page rule.
	 *
	 * @since 3.2.0
	 * @param int    $specificity Specificity so far.
	 * @param string $rule        Rule path.
	 * @return int
	 */
	public static function rule_specificity( $specificity, $rule ) {
		return 'shop' === $rule || self::woo_page( $rule ) ? 30 : $specificity;
	}

	/**
	 * Store rules as words.
	 *
	 * @since 3.2.0
	 * @param string $label Description so far.
	 * @param string $rule  Rule path.
	 * @return string
	 */
	public static function describe_rule( $label, $rule ) {
		$labels = [
			'shop'         => __( 'Shop page', 'powerpack' ),
			'woo/cart'     => __( 'Cart page', 'powerpack' ),
			'woo/checkout' => __( 'Checkout page', 'powerpack' ),
			'woo/account'  => __( 'My Account pages', 'powerpack' ),
			'woo/thankyou' => __( 'Order received page', 'powerpack' ),
		];

		return isset( $labels[ $rule ] ) ? $labels[ $rule ] : $label;
	}

	/**
	 * The store page a woo/ rule names, or ''.
	 *
	 * @since 3.2.0
	 * @param string $rule Rule path.
	 * @return string
	 */
	private static function woo_page( $rule ) {
		$parts = explode( '/', $rule );

		return 2 === count( $parts ) && 'woo' === $parts[0] && in_array( $parts[1], self::PAGES, true ) ? $parts[1] : '';
	}
}

PP_Site_Builder_Woo::init();
