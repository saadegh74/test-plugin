<?php
namespace PowerpackElements\Classes;

/**
 * Site Builder: header, footer and content block templates with display rules.
 *
 * Templates are posts of their own type. Which template a request gets is
 * decided from an index of every published template, kept in one autoloaded
 * option so the front end never queries for them.
 *
 * @package PowerPack Elements
 * @since 3.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PP_Site_Builder
 */
final class PP_Site_Builder {

	const POST_TYPE     = 'pp_template';
	const META_TYPE     = '_pp_template_type';
	const META_RULES    = '_pp_display_rules';
	const META_PRIORITY = '_pp_template_priority';
	const META_SETTINGS = '_pp_template_settings';
	const META_SOURCE   = '_pp_template_source';
	const INDEX_OPTION  = 'pp_site_builder_index';

	/**
	 * Priority a template has until someone sets one.
	 *
	 * @since 3.2.0
	 */
	const DEFAULT_PRIORITY = 10;

	/**
	 * Template resolved for each type on this request.
	 *
	 * @var array
	 * @since 3.2.0
	 */
	private static $resolved = [];

	/**
	 * Whether an index rebuild is queued for shutdown.
	 *
	 * @var bool
	 * @since 3.2.0
	 */
	private static $rebuild_queued = false;

	/**
	 * Initialize hooks.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	public static function init() {
		if ( ! did_action( 'elementor/loaded' ) ) {
			return;
		}

		require_once __DIR__ . '/class-pp-site-builder-rest-controller.php';

		add_action( 'init', __CLASS__ . '::register_post_type' );
		add_action( 'init', __CLASS__ . '::register_meta' );
		add_action( 'elementor/documents/register', __CLASS__ . '::register_documents' );
		add_action( 'elementor/editor/after_enqueue_scripts', __CLASS__ . '::enqueue_editor_script' );
		add_action( 'elementor/preview/enqueue_styles', __CLASS__ . '::enqueue_preview_styles' );
		add_action( 'template_redirect', __CLASS__ . '::protect_single' );
		add_filter( 'template_include', __CLASS__ . '::template_include', 20 );

		add_action( 'save_post_' . self::POST_TYPE, __CLASS__ . '::queue_rebuild' );
		add_action( 'deleted_post', __CLASS__ . '::maybe_queue_rebuild' );
		add_action( 'trashed_post', __CLASS__ . '::maybe_queue_rebuild' );
		add_action( 'untrashed_post', __CLASS__ . '::maybe_queue_rebuild' );

		foreach ( [ 'added_post_meta', 'updated_post_meta', 'deleted_post_meta' ] as $hook ) {
			add_action( $hook, __CLASS__ . '::maybe_queue_rebuild_for_meta', 10, 3 );
		}
	}

	/**
	 * Template types and their labels.
	 *
	 * @since 3.2.0
	 * @return array
	 */
	public static function get_types() {
		return wp_list_pluck( self::get_type_definitions(), 'label' );
	}

	/**
	 * Every template type and what it needs.
	 *
	 * - label, plural: names on screen.
	 * - description: one line on what the template replaces, shown while a
	 *   type has no templates yet.
	 * - document, class: the Elementor document type and its class.
	 * - location: the Elementor Pro Theme Builder location it competes with,
	 *   so PowerPack steps aside where Elementor Pro already supplies one.
	 * - rules: which display rules it takes. 'all' for anywhere on the site;
	 *   'product' and 'product_archive' for the shop's own pages.
	 * - fixed_rule: for a template that belongs on one store page, the only
	 *   rule it takes, set for it when it is created.
	 * - default_rule: the rule the Add New dialog suggests for a new template.
	 * - group: 'site' or 'woocommerce', for sorting types on screen.
	 *
	 * The WooCommerce types exist only while WooCommerce is active.
	 *
	 * @since 3.2.0
	 * @return array Map of type slug to definition.
	 */
	public static function get_type_definitions() {
		$types = [
			'header' => [
				'label'        => __( 'Header', 'powerpack' ),
				'plural'       => __( 'Headers', 'powerpack' ),
				'description'  => __( 'Replaces your theme’s header on the pages you choose.', 'powerpack' ),
				'document'     => 'pp-header',
				'class'        => 'PP_Site_Builder_Header_Document',
				'location'     => 'header',
				'rules'        => 'all',
				'group'        => 'site',
				'default_rule' => 'entire_site',
			],
			'footer' => [
				'label'        => __( 'Footer', 'powerpack' ),
				'plural'       => __( 'Footers', 'powerpack' ),
				'description'  => __( 'Replaces your theme’s footer on the pages you choose.', 'powerpack' ),
				'document'     => 'pp-footer',
				'class'        => 'PP_Site_Builder_Footer_Document',
				'location'     => 'footer',
				'rules'        => 'all',
				'group'        => 'site',
				'default_rule' => 'entire_site',
			],
		];

		if ( self::has_woocommerce() ) {
			$woo = [
				'single_product'  => [
					'label'        => __( 'Single Product', 'powerpack' ),
					'plural'       => __( 'Single Products', 'powerpack' ),
					'description'  => __( 'Lays out product pages, for every product or only some categories.', 'powerpack' ),
					'document'     => 'pp-single-product',
					'class'        => 'PP_Site_Builder_Single_Product_Document',
					'location'     => 'single',
					'rules'        => 'product',
					'default_rule' => 'singular/product',
				],
				'product_archive' => [
					'label'        => __( 'Product Archive', 'powerpack' ),
					'plural'       => __( 'Product Archives', 'powerpack' ),
					'description'  => __( 'Lays out the shop page and product category and tag archives.', 'powerpack' ),
					'document'     => 'pp-product-archive',
					'class'        => 'PP_Site_Builder_Product_Archive_Document',
					'location'     => 'archive',
					'rules'        => 'product_archive',
					'default_rule' => 'archive/product',
				],
				'cart'            => [
					'label'       => __( 'Cart', 'powerpack' ),
					'plural'      => __( 'Cart', 'powerpack' ),
					'document'    => 'pp-cart',
					'class'       => 'PP_Site_Builder_Cart_Document',
					'fixed_rule'  => 'woo/cart',
					'description' => __( 'Replaces the layout of the cart page.', 'powerpack' ),
				],
				'checkout'        => [
					'label'       => __( 'Checkout', 'powerpack' ),
					'plural'      => __( 'Checkout', 'powerpack' ),
					'document'    => 'pp-checkout',
					'class'       => 'PP_Site_Builder_Checkout_Document',
					'fixed_rule'  => 'woo/checkout',
					'description' => __( 'Replaces the layout of the checkout page.', 'powerpack' ),
				],
				'my_account'      => [
					'label'       => __( 'My Account', 'powerpack' ),
					'plural'      => __( 'My Account', 'powerpack' ),
					'document'    => 'pp-my-account',
					'class'       => 'PP_Site_Builder_My_Account_Document',
					'fixed_rule'  => 'woo/account',
					'description' => __( 'Replaces the layout of the customer account page.', 'powerpack' ),
				],
			];

			/*
			 * No Thank You type yet: there are no order widgets to build one
			 * from. Its document class, and the request detection that keeps
			 * a Checkout template off the order received page, stay for when
			 * there are.
			 */

			foreach ( $woo as $key => $definition ) {
				$types[ $key ] = $definition + [
					'group'    => 'woocommerce',
					'location' => '',
					'rules'    => 'all',
				];
			}
		}

		/**
		 * Filter the Site Builder template types.
		 *
		 * @since 3.2.0
		 * @param array $types Map of type slug to definition; see get_type_definitions().
		 */
		return apply_filters( 'pp_site_builder/types', $types );
	}

	/**
	 * One type's definition, or null.
	 *
	 * @since 3.2.0
	 * @param string $type Template type.
	 * @return array|null
	 */
	public static function get_type_definition( $type ) {
		$types = self::get_type_definitions();

		return isset( $types[ $type ] ) ? $types[ $type ] : null;
	}

	/**
	 * Whether WooCommerce is active, which brings the store template types.
	 *
	 * @since 3.2.0
	 * @return bool
	 */
	public static function has_woocommerce() {
		return class_exists( '\WooCommerce' );
	}

	/**
	 * Whether a template type takes a display rule.
	 *
	 * A product template on a blog post would never show, and a Cart template
	 * anywhere but the cart would replace a page with a cart. Checked when
	 * rules are saved, not only hidden in the picker.
	 *
	 * @since 3.2.0
	 * @param string $type Template type.
	 * @param string $rule Rule path.
	 * @return bool
	 */
	public static function rule_allowed( $type, $rule ) {
		$definition = self::get_type_definition( $type );

		if ( ! $definition ) {
			return false;
		}

		if ( ! empty( $definition['fixed_rule'] ) ) {
			return $rule === $definition['fixed_rule'];
		}

		$taxonomies = implode( '|', array_map( 'preg_quote', self::get_product_taxonomies() ) );

		switch ( $definition['rules'] ) {
			case 'product':
				return (bool) preg_match( '#^singular/product(/\d+)?$#', $rule )
					|| ( $taxonomies && preg_match( '#^singular_in/(' . $taxonomies . ')/\d+$#', $rule ) );

			case 'product_archive':
				return in_array( $rule, [ 'shop', 'archive/product' ], true )
					|| ( $taxonomies && preg_match( '#^archive/taxonomy/(' . $taxonomies . ')(/\d+)?$#', $rule ) );
		}

		return true;
	}

	/**
	 * Public taxonomies products can be filed under.
	 *
	 * @since 3.2.0
	 * @return string[]
	 */
	public static function get_product_taxonomies() {
		if ( ! self::has_woocommerce() ) {
			return [];
		}

		$names = [];

		foreach ( get_object_taxonomies( 'product', 'objects' ) as $taxonomy ) {
			if ( $taxonomy->public ) {
				$names[] = $taxonomy->name;
			}
		}

		return $names;
	}

	/**
	 * Register the template post type.
	 *
	 * Publicly queryable so Elementor can load the editor preview, but
	 * protect_single() keeps the single view to people who can edit it.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	public static function register_post_type() {
		register_post_type( self::POST_TYPE, [
			'labels'                => [
				'name'          => __( 'Site Builder Templates', 'powerpack' ),
				'singular_name' => __( 'Site Builder Template', 'powerpack' ),
				'add_new_item'  => __( 'Add New Template', 'powerpack' ),
				'edit_item'     => __( 'Edit Template', 'powerpack' ),
				'search_items'  => __( 'Search Templates', 'powerpack' ),
				'not_found'     => __( 'No templates found.', 'powerpack' ),
			],
			'public'                => false,
			'publicly_queryable'    => true,
			'exclude_from_search'   => true,
			'show_ui'               => true,
			'show_in_menu'          => false,
			'show_in_nav_menus'     => false,
			'show_in_admin_bar'     => false,
			'show_in_rest'          => true,
			'rest_controller_class' => __NAMESPACE__ . '\PP_Site_Builder_REST_Controller',
			'rewrite'               => false,
			'hierarchical'          => false,
			'capability_type'       => 'page',
			'capabilities'          => self::capabilities(),
			'map_meta_cap'          => true,
			'supports'              => [ 'title', 'author', 'revisions', 'elementor', 'custom-fields' ],
		] );
	}

	/**
	 * Primitive capabilities for templates.
	 *
	 * A header or footer changes every page the way a theme does, so working
	 * on templates takes the theme capability rather than the page ones an
	 * editor has. The meta capabilities (edit_post and so on) still map onto
	 * these through map_meta_cap.
	 *
	 * @since 3.2.0
	 * @return array
	 */
	private static function capabilities() {
		$primitive = [
			'edit_posts',
			'edit_others_posts',
			'edit_private_posts',
			'edit_published_posts',
			'publish_posts',
			'read_private_posts',
			'delete_posts',
			'delete_others_posts',
			'delete_private_posts',
			'delete_published_posts',
			'create_posts',
		];

		return array_fill_keys( $primitive, 'edit_theme_options' );
	}

	/**
	 * Register template meta, exposed over REST for the Site Builder screen.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	public static function register_meta() {
		$auth = function ( $allowed, $meta_key, $post_id ) {
			return current_user_can( 'edit_post', $post_id );
		};

		$rule_list = [
			'type'  => 'array',
			'items' => [ 'type' => 'string' ],
		];

		$meta = [
			self::META_TYPE     => [
				'type'              => 'string',
				'default'           => '',
				'sanitize_callback' => __CLASS__ . '::sanitize_type',
				'show_in_rest'      => [
					'schema' => [ 'enum' => array_merge( [ '' ], array_keys( self::get_types() ) ) ],
				],
			],
			self::META_RULES    => [
				'type'              => 'object',
				'default'           => PP_Site_Builder_Rules::sanitize( [] ),
				'sanitize_callback' => __NAMESPACE__ . '\PP_Site_Builder_Rules::sanitize',
				'show_in_rest'      => [
					'schema' => [
						'type'                 => 'object',
						'additionalProperties' => false,
						'properties'           => [
							'include' => $rule_list,
							'exclude' => $rule_list,
						],
					],
				],
			],
			self::META_PRIORITY => [
				'type'              => 'integer',
				'default'           => self::DEFAULT_PRIORITY,
				'sanitize_callback' => 'absint',
				'show_in_rest'      => true,
			],
			self::META_SETTINGS => [
				'type'              => 'object',
				'default'           => self::default_settings(),
				'sanitize_callback' => __CLASS__ . '::sanitize_settings',
				'show_in_rest'      => [
					'schema' => [
						'type'                 => 'object',
						'additionalProperties' => false,
						'properties'           => [
							'sticky'             => [ 'type' => 'boolean' ],
							'sticky_breakpoints' => [ 'type' => 'string' ],
							'shrink'             => [ 'type' => 'boolean' ],
							'overlay'            => [ 'type' => 'boolean' ],
							'overlay_bg'         => [ 'type' => 'string' ],
						],
					],
				],
			],
			self::META_SOURCE   => [
				'type'              => 'integer',
				'default'           => 0,
				'sanitize_callback' => 'absint',
				'show_in_rest'      => true,
			],
		];

		foreach ( $meta as $key => $args ) {
			register_post_meta( self::POST_TYPE, $key, array_merge( $args, [
				'single'        => true,
				'auth_callback' => $auth,
			] ) );
		}
	}

	/**
	 * Register the Elementor document type for each template type.
	 *
	 * @since 3.2.0
	 * @param \Elementor\Core\Documents_Manager $documents_manager Documents manager.
	 * @return void
	 */
	public static function register_documents( $documents_manager ) {
		require_once __DIR__ . '/class-pp-site-builder-documents.php';

		if ( self::has_woocommerce() ) {
			require_once __DIR__ . '/class-pp-site-builder-woo-documents.php';
		}

		foreach ( self::get_type_definitions() as $definition ) {
			$class = __NAMESPACE__ . '\\' . $definition['class'];

			if ( class_exists( $class ) ) {
				$documents_manager->register_document_type( $definition['document'], $class );
			}
		}
	}

	/**
	 * Elementor document type for a template type.
	 *
	 * @since 3.2.0
	 * @param string $type Template type.
	 * @return string
	 */
	public static function get_document_type( $type ) {
		$definition = self::get_type_definition( $type );

		return $definition ? $definition['document'] : '';
	}

	/**
	 * The script that mirrors the header's Preview state into the editor.
	 *
	 * Loaded for every document since the editor can switch to a header
	 * without reloading; it does nothing unless one is open.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	public static function enqueue_editor_script() {
		$debug = PP_Helper::is_script_debug();

		wp_enqueue_script(
			'pp-site-builder-editor',
			POWERPACK_ELEMENTS_URL . ( $debug ? 'assets/js/site-builder-editor.js' : 'assets/js/min/site-builder-editor.min.js' ),
			[ 'jquery', 'elementor-editor' ],
			POWERPACK_ELEMENTS_VER,
			true
		);
	}

	/**
	 * The header stylesheet inside a header's editor preview, for the
	 * transparent-at-top rules and the checkerboard behind them.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	public static function enqueue_preview_styles() {
		$document = \Elementor\Plugin::$instance->documents->get( \Elementor\Plugin::$instance->preview->get_post_id() );

		if ( ! $document || 'pp-header' !== $document->get_name() ) {
			return;
		}

		$debug = PP_Helper::is_script_debug();

		wp_enqueue_style(
			'pp-site-header',
			POWERPACK_ELEMENTS_URL . ( $debug ? 'assets/css/site-header.css' : 'assets/css/min/site-header.min.css' ),
			[],
			POWERPACK_ELEMENTS_VER
		);
	}

	/**
	 * Keep template URLs from being browsed by anyone who cannot edit them.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	public static function protect_single() {
		if ( is_singular( self::POST_TYPE ) && ! current_user_can( 'edit_post', get_queried_object_id() ) ) {
			global $wp_query;

			$wp_query->set_404();
			status_header( 404 );
			nocache_headers();
		}
	}

	/**
	 * Render a template on its own, without the theme around it, so the
	 * editor preview shows only what is being built.
	 *
	 * @since 3.2.0
	 * @param string $template Template file.
	 * @return string
	 */
	public static function template_include( $template ) {
		if ( ! is_singular( self::POST_TYPE ) || ! defined( 'ELEMENTOR_PATH' ) ) {
			return $template;
		}

		$canvas = ELEMENTOR_PATH . 'modules/page-templates/templates/canvas.php';

		return file_exists( $canvas ) ? $canvas : $template;
	}

	/* ---------------------------------------------------------------------
	 * Index
	 * ------------------------------------------------------------------ */

	/**
	 * Queue an index rebuild for the end of the request.
	 *
	 * Saving a template fires save_post and several meta writes, and REST
	 * writes meta after save_post. Rebuilding once at shutdown sees them all.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	public static function queue_rebuild() {
		if ( self::$rebuild_queued ) {
			return;
		}

		self::$rebuild_queued = true;
		add_action( 'shutdown', __CLASS__ . '::rebuild_index' );
	}

	/**
	 * Queue a rebuild when a template post changes state.
	 *
	 * @since 3.2.0
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public static function maybe_queue_rebuild( $post_id ) {
		if ( self::POST_TYPE === get_post_type( $post_id ) ) {
			self::queue_rebuild();
		}
	}

	/**
	 * Queue a rebuild when template meta changes.
	 *
	 * @since 3.2.0
	 * @param int|array $meta_ids  Meta ID(s).
	 * @param int       $object_id Post ID.
	 * @param string    $meta_key  Meta key.
	 * @return void
	 */
	public static function maybe_queue_rebuild_for_meta( $meta_ids, $object_id, $meta_key ) {
		if ( in_array( $meta_key, [ self::META_TYPE, self::META_RULES, self::META_PRIORITY ], true ) ) {
			self::maybe_queue_rebuild( $object_id );
		}
	}

	/**
	 * Rebuild the index of published templates.
	 *
	 * @since 3.2.0
	 * @return array The new index.
	 */
	public static function rebuild_index() {
		// A rebuild already queued for shutdown would only repeat this one.
		self::$rebuild_queued = false;
		remove_action( 'shutdown', __CLASS__ . '::rebuild_index' );

		$ids = get_posts( [
			'post_type'        => self::POST_TYPE,
			'post_status'      => 'publish',
			'posts_per_page'   => -1,
			'fields'           => 'ids',
			'no_found_rows'    => true,
			'suppress_filters' => true,
		] );

		$types = self::get_types();
		$index = [];

		foreach ( $ids as $id ) {
			$type = get_post_meta( $id, self::META_TYPE, true );

			if ( ! isset( $types[ $type ] ) ) {
				continue;
			}

			$index[ $type ][] = [
				'id'       => (int) $id,
				'rules'    => PP_Site_Builder_Rules::sanitize( get_post_meta( $id, self::META_RULES, true ) ),
				'priority' => self::get_priority( $id ),
				'modified' => (int) get_post_modified_time( 'U', true, $id ),
			];
		}

		update_option( self::INDEX_OPTION, $index, true );

		return $index;
	}

	/**
	 * The index, rebuilt if it has never been written.
	 *
	 * @since 3.2.0
	 * @return array Map of type to index entries.
	 */
	public static function get_index() {
		$index = get_option( self::INDEX_OPTION, null );

		return is_array( $index ) ? $index : self::rebuild_index();
	}

	/**
	 * Whether any published template of the given types exists.
	 *
	 * @since 3.2.0
	 * @param array $types Template types.
	 * @return bool
	 */
	public static function has_templates( $types ) {
		$index = self::get_index();

		foreach ( $types as $type ) {
			if ( ! empty( $index[ $type ] ) ) {
				return true;
			}
		}

		return false;
	}

	/* ---------------------------------------------------------------------
	 * Resolution
	 * ------------------------------------------------------------------ */

	/**
	 * The template that applies to the current request.
	 *
	 * @since 3.2.0
	 * @param string $type Template type.
	 * @return int Template post ID, or 0.
	 */
	public static function get_template_for( $type ) {
		if ( array_key_exists( $type, self::$resolved ) ) {
			return self::$resolved[ $type ];
		}

		// The rules read the main query, which is not ready before 'wp'.
		if ( ! did_action( 'wp' ) ) {
			return 0;
		}

		$id    = 0;
		$index = self::get_index();

		// A template being previewed or edited gets no header or footer around it.
		if ( ! empty( $index[ $type ] ) && ! is_singular( self::POST_TYPE ) ) {
			$id = PP_Site_Builder_Rules::resolve( $index[ $type ], PP_Site_Builder_Rules::current_context() );

			if ( $id && self::defers_to_elementor_pro( $type ) ) {
				$id = 0;
			}
		}

		/**
		 * Filter the template resolved for the current request.
		 *
		 * @since 3.2.0
		 * @param int    $id   Template post ID, or 0 for none.
		 * @param string $type Template type.
		 */
		self::$resolved[ $type ] = (int) apply_filters( 'pp_site_builder/template', $id, $type );

		return self::$resolved[ $type ];
	}

	/**
	 * Forget what was resolved, for code that switches the main query.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	public static function reset() {
		self::$resolved = [];
	}

	/**
	 * Whether Elementor Pro's Theme Builder already supplies this location.
	 *
	 * Two headers on one page is never what anyone wants, and a site that set
	 * up Elementor Pro conditions chose those deliberately.
	 *
	 * @since 3.2.0
	 * @param string $type Template type.
	 * @return bool
	 */
	private static function defers_to_elementor_pro( $type ) {
		$defer = false;

		$definition = self::get_type_definition( $type );

		// Cart, Checkout and the rest have no Theme Builder location to compete for.
		if ( ! empty( $definition['location'] ) && class_exists( '\ElementorPro\Plugin' ) ) {
			$module = \ElementorPro\Plugin::instance()->modules_manager->get_modules( 'theme-builder' );

			if ( $module && method_exists( $module, 'get_conditions_manager' ) ) {
				$defer = ! empty( $module->get_conditions_manager()->get_documents_for_location( $definition['location'] ) );
			}
		}

		/**
		 * Filter whether PowerPack steps aside for Elementor Pro's Theme Builder.
		 *
		 * @since 3.2.0
		 * @param bool   $defer Whether Elementor Pro has a template for this location.
		 * @param string $type  Template type.
		 */
		return (bool) apply_filters( 'pp_site_builder/defer_to_elementor_pro', $defer, $type );
	}

	/* ---------------------------------------------------------------------
	 * Template data
	 * ------------------------------------------------------------------ */

	/**
	 * The post whose Elementor content renders for a template.
	 *
	 * A template migrated from the old Header Footer settings points at the
	 * page or library template that was assigned there, so existing content
	 * keeps rendering and keeps being edited where it always was.
	 *
	 * @since 3.2.0
	 * @param int $template_id Template post ID.
	 * @return int Content post ID, or 0 when the source is gone.
	 */
	public static function get_content_id( $template_id ) {
		if ( ! $template_id ) {
			return 0;
		}

		$source = (int) get_post_meta( $template_id, self::META_SOURCE, true );

		if ( ! $source ) {
			return (int) $template_id;
		}

		return 'publish' === get_post_status( $source ) ? $source : 0;
	}

	/**
	 * The template a post is the content of, the reverse of get_content_id().
	 *
	 * A template itself, or the template a migrated one renders through: that
	 * one is edited as the page or library template it points at.
	 *
	 * @since 3.2.0
	 * @param int $post_id Post being edited.
	 * @return int Template ID, or 0 when the post is neither.
	 */
	public static function get_template_by_content( $post_id ) {
		$post_id = (int) $post_id;

		if ( ! $post_id ) {
			return 0;
		}

		if ( self::POST_TYPE === get_post_type( $post_id ) ) {
			return $post_id;
		}

		$ids = get_posts( [
			'post_type'        => self::POST_TYPE,
			'post_status'      => 'any',
			'posts_per_page'   => 1,
			'fields'           => 'ids',
			'no_found_rows'    => true,
			'suppress_filters' => true,
			'meta_key'         => self::META_SOURCE, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'meta_value'       => $post_id, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
		] );

		return $ids ? (int) $ids[0] : 0;
	}

	/**
	 * A template's priority.
	 *
	 * @since 3.2.0
	 * @param int $template_id Template post ID.
	 * @return int
	 */
	public static function get_priority( $template_id ) {
		$priority = get_post_meta( $template_id, self::META_PRIORITY, true );

		return '' === $priority ? self::DEFAULT_PRIORITY : (int) $priority;
	}

	/**
	 * Header behaviour defaults.
	 *
	 * @since 3.2.0
	 * @return array
	 */
	public static function default_settings() {
		return [
			'sticky'             => false,
			'sticky_breakpoints' => 'large-medium',
			'shrink'             => false,
			'overlay'            => false,
			'overlay_bg'         => 'default',
		];
	}

	/**
	 * A template's header behaviour settings.
	 *
	 * @since 3.2.0
	 * @param int $template_id Template post ID.
	 * @return array
	 */
	public static function get_settings( $template_id ) {
		$settings = $template_id ? get_post_meta( $template_id, self::META_SETTINGS, true ) : [];

		return self::sanitize_settings( $settings );
	}

	/**
	 * Whether a template is built here rather than pointing at a migrated page.
	 *
	 * Native headers take their behaviour from the Elementor document's
	 * settings and use the states script. Migrated ones keep the old
	 * site-wide settings and script, so an upgrade changes nothing visible.
	 *
	 * @since 3.2.0
	 * @param int $template_id Template post ID.
	 * @return bool
	 */
	public static function is_native( $template_id ) {
		return $template_id && ! get_post_meta( $template_id, self::META_SOURCE, true );
	}

	/**
	 * A native header's behaviour, from its Elementor document settings.
	 *
	 * Elementor stores only what was changed from a control's default, so the
	 * defaults here mirror the controls'.
	 *
	 * @since 3.2.0
	 * @param int $template_id Template post ID.
	 * @return array
	 */
	public static function get_behaviour( $template_id ) {
		$settings = get_post_meta( $template_id, '_elementor_page_settings', true );
		$settings = is_array( $settings ) ? $settings : [];

		$on = function ( $key, $default = '' ) use ( $settings ) {
			return 'yes' === ( isset( $settings[ $key ] ) ? $settings[ $key ] : $default );
		};

		$devices = [ 'desktop', 'tablet', 'mobile' ];
		$sticky  = isset( $settings['pp_sticky_on'] ) ? array_values( array_intersect( $devices, (array) $settings['pp_sticky_on'] ) ) : $devices;

		$offset = isset( $settings['pp_scrolled_offset']['size'] ) && '' !== $settings['pp_scrolled_offset']['size'] ? (int) $settings['pp_scrolled_offset']['size'] : 80;

		// An ID reference only; anything else would be a selector or a URL.
		$target = isset( $settings['pp_skip_target'] ) ? trim( $settings['pp_skip_target'] ) : '#content';
		$target = preg_match( '/^#[A-Za-z][\w\-:.]*$/', $target ) ? $target : '#content';

		return [
			'sticky'         => $on( 'pp_sticky' ) && $sticky,
			'sticky_on'      => $sticky,
			'hide_on_scroll' => $on( 'pp_sticky' ) && $on( 'pp_hide_on_scroll' ),
			'transparent'    => $on( 'pp_transparent' ),
			'offset'         => max( 0, $offset ),
			'skip_link'      => $on( 'pp_skip_link', 'yes' ),
			'skip_target'    => $target,
		];
	}

	/**
	 * Normalise header behaviour settings.
	 *
	 * @since 3.2.0
	 * @param mixed $settings Raw settings.
	 * @return array
	 */
	public static function sanitize_settings( $settings ) {
		$defaults = self::default_settings();
		$settings = is_array( $settings ) ? array_intersect_key( $settings, $defaults ) : [];
		$settings = array_merge( $defaults, $settings );

		foreach ( [ 'sticky', 'shrink', 'overlay' ] as $key ) {
			$settings[ $key ] = (bool) $settings[ $key ];
		}

		$breakpoints = [ 'all', 'large', 'large-medium', 'medium', 'medium-responsive', 'responsive' ];

		if ( ! in_array( $settings['sticky_breakpoints'], $breakpoints, true ) ) {
			$settings['sticky_breakpoints'] = $defaults['sticky_breakpoints'];
		}

		if ( ! in_array( $settings['overlay_bg'], [ 'default', 'transparent' ], true ) ) {
			$settings['overlay_bg'] = $defaults['overlay_bg'];
		}

		return $settings;
	}

	/**
	 * Keep a template type to the registered ones.
	 *
	 * @since 3.2.0
	 * @param mixed $type Raw type.
	 * @return string
	 */
	public static function sanitize_type( $type ) {
		$type = is_string( $type ) ? $type : '';

		return array_key_exists( $type, self::get_types() ) ? $type : '';
	}
}

PP_Site_Builder::init();
