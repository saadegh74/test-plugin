<?php
namespace PowerpackElements\Classes;

/**
 * Display rules for Site Builder templates.
 *
 * A rule is a slash path, most general segment first:
 *
 *   entire_site
 *   front_page | blog | search | not_found
 *   singular | singular/{post_type} | singular/{post_type}/{post_id}
 *   singular_in/{taxonomy}/{term_id}
 *   archive | archive/{post_type} | archive/author | archive/date
 *   archive/taxonomy/{taxonomy} | archive/taxonomy/{taxonomy}/{term_id}
 *
 * Other rule types plug in through the pp_site_builder/rule_matches,
 * pp_site_builder/rule_specificity and pp_site_builder/context filters.
 *
 * Matching runs against a plain context array rather than the WordPress
 * conditionals, so everything below current_context() is testable without an
 * install.
 *
 * @package PowerPack Elements
 * @since 3.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PP_Site_Builder_Rules
 */
final class PP_Site_Builder_Rules {

	/**
	 * Score given to a rule set that does not match.
	 *
	 * @since 3.2.0
	 */
	const NO_MATCH = -1;

	/**
	 * Normalise a stored rule set to include/exclude lists of valid paths.
	 *
	 * @since 3.2.0
	 * @param mixed $rules Raw rules, as stored or as sent by the client.
	 * @return array
	 */
	public static function sanitize( $rules ) {
		$clean = [
			'include' => [],
			'exclude' => [],
		];

		if ( ! is_array( $rules ) ) {
			return $clean;
		}

		foreach ( array_keys( $clean ) as $group ) {
			if ( empty( $rules[ $group ] ) || ! is_array( $rules[ $group ] ) ) {
				continue;
			}

			foreach ( $rules[ $group ] as $rule ) {
				$rule = is_string( $rule ) ? strtolower( trim( $rule ) ) : '';

				if ( preg_match( '#^[a-z0-9_\-]+(/[a-z0-9_\-]+){0,3}$#', $rule ) && ! in_array( $rule, $clean[ $group ], true ) ) {
					$clean[ $group ][] = $rule;
				}
			}
		}

		return $clean;
	}

	/**
	 * Score a rule set against a request.
	 *
	 * Any matching exclusion rejects the set outright. Otherwise the score is
	 * the specificity of the most specific matching inclusion, so a template
	 * for the front page beats one for the entire site without either needing
	 * a priority.
	 *
	 * @since 3.2.0
	 * @param array $rules   Rule set.
	 * @param array $context Request context from current_context().
	 * @return int Specificity, or NO_MATCH.
	 */
	public static function score( $rules, $context ) {
		$rules = self::sanitize( $rules );

		foreach ( $rules['exclude'] as $rule ) {
			if ( self::rule_matches( $rule, $context ) ) {
				return self::NO_MATCH;
			}
		}

		$score = self::NO_MATCH;

		foreach ( $rules['include'] as $rule ) {
			if ( self::rule_matches( $rule, $context ) ) {
				$score = max( $score, self::specificity( $rule ) );
			}
		}

		return $score;
	}

	/**
	 * Whether a rule set applies to a request.
	 *
	 * @since 3.2.0
	 * @param array $rules   Rule set.
	 * @param array $context Request context.
	 * @return bool
	 */
	public static function matches( $rules, $context ) {
		return self::NO_MATCH !== self::score( $rules, $context );
	}

	/**
	 * Pick the template that wins a request.
	 *
	 * Order: priority, then rule specificity, then the most recently modified
	 * template, then the highest ID so the result never depends on index order.
	 *
	 * @since 3.2.0
	 * @param array $candidates Index entries with id, rules, priority, modified.
	 * @param array $context    Request context.
	 * @return int Winning template ID, or 0.
	 */
	public static function resolve( $candidates, $context ) {
		$best = null;

		foreach ( (array) $candidates as $candidate ) {
			$score = self::score( $candidate['rules'], $context );

			if ( self::NO_MATCH === $score ) {
				continue;
			}

			$rank = [ (int) $candidate['priority'], $score, (int) $candidate['modified'], (int) $candidate['id'] ];

			if ( null === $best || $rank > $best ) {
				$best = $rank;
			}
		}

		return $best ? $best[3] : 0;
	}

	/**
	 * How narrowly a rule targets requests. Higher is narrower.
	 *
	 * @since 3.2.0
	 * @param string $rule Rule path.
	 * @return int
	 */
	public static function specificity( $rule ) {
		$parts = explode( '/', $rule );

		switch ( $parts[0] ) {
			case 'entire_site':
				return 0;
			case 'front_page':
			case 'blog':
				return 30;
			case 'search':
			case 'not_found':
				return 20;

			// Narrower than every post of a type, wider than one post.
			case 'singular_in':
				return 25;

			case 'singular':
			case 'archive':
				// Steps of ten leave room for rules that fall between two of these.
				return 10 * count( $parts );
		}

		/**
		 * Specificity of a rule the built-in types do not know.
		 *
		 * @since 3.2.0
		 * @param int    $specificity Default 10, the same as a bare singular or archive.
		 * @param string $rule        Rule path.
		 */
		return (int) apply_filters( 'pp_site_builder/rule_specificity', 10, $rule );
	}

	/**
	 * Whether a single rule matches a request.
	 *
	 * @since 3.2.0
	 * @param string $rule    Rule path.
	 * @param array  $context Request context.
	 * @return bool
	 */
	public static function rule_matches( $rule, $context ) {
		$parts = explode( '/', $rule );

		switch ( $parts[0] ) {
			case 'entire_site':
				return true;

			case 'front_page':
			case 'blog':
			case 'search':
			case 'not_found':
				return ! empty( $context[ $parts[0] ] );

			case 'singular':
				return self::singular_matches( $parts, $context );

			case 'singular_in':
				return self::singular_in_matches( $parts, $context );

			case 'archive':
				return self::archive_matches( $parts, $context );
		}

		/**
		 * Match a rule the built-in types do not know.
		 *
		 * @since 3.2.0
		 * @param bool   $matches Whether the rule matches. Default false.
		 * @param string $rule    Rule path.
		 * @param array  $context Request context.
		 */
		return (bool) apply_filters( 'pp_site_builder/rule_matches', false, $rule, $context );
	}

	/**
	 * Match singular/{post_type}/{post_id}.
	 *
	 * @since 3.2.0
	 * @param array $parts   Rule segments.
	 * @param array $context Request context.
	 * @return bool
	 */
	private static function singular_matches( $parts, $context ) {
		if ( empty( $context['singular'] ) ) {
			return false;
		}

		$singular = $context['singular'];

		if ( ! isset( $parts[1] ) ) {
			return true;
		}

		if ( $parts[1] !== $singular['post_type'] ) {
			return false;
		}

		return ! isset( $parts[2] ) || (int) $parts[2] === (int) $singular['id'];
	}

	/**
	 * Match singular_in/{taxonomy}/{term_id}: a single post in that term.
	 *
	 * The context lists each term's ancestors too, so "in Clothing" also
	 * reaches a product filed only under Clothing › Shirts.
	 *
	 * @since 3.2.0
	 * @param array $parts   Rule segments.
	 * @param array $context Request context.
	 * @return bool
	 */
	private static function singular_in_matches( $parts, $context ) {
		if ( empty( $context['singular'] ) || ! isset( $parts[2] ) ) {
			return false;
		}

		$terms = isset( $context['singular']['terms'][ $parts[1] ] ) ? $context['singular']['terms'][ $parts[1] ] : [];

		return in_array( (int) $parts[2], array_map( 'intval', $terms ), true );
	}

	/**
	 * Match archive rules.
	 *
	 * archive/{post_type} also covers that post type's taxonomy archives, so a
	 * Shop rule reaches product categories too.
	 *
	 * @since 3.2.0
	 * @param array $parts   Rule segments.
	 * @param array $context Request context.
	 * @return bool
	 */
	private static function archive_matches( $parts, $context ) {
		if ( empty( $context['archive'] ) ) {
			return false;
		}

		$archive = $context['archive'];

		if ( ! isset( $parts[1] ) ) {
			return true;
		}

		if ( 'author' === $parts[1] || 'date' === $parts[1] ) {
			return $parts[1] === $archive['kind'];
		}

		if ( 'taxonomy' === $parts[1] ) {
			if ( 'taxonomy' !== $archive['kind'] ) {
				return false;
			}

			if ( ! isset( $parts[2] ) ) {
				return true;
			}

			if ( $parts[2] !== $archive['taxonomy'] ) {
				return false;
			}

			return ! isset( $parts[3] ) || (int) $parts[3] === (int) $archive['term_id'];
		}

		return ! empty( $archive['post_type'] ) && $parts[1] === $archive['post_type'];
	}

	/**
	 * Describe the current request for matching.
	 *
	 * Only meaningful once the main query has run, i.e. from 'wp' onwards.
	 *
	 * @since 3.2.0
	 * @return array
	 */
	public static function current_context() {
		$context = [
			'front_page' => is_front_page(),
			'blog'       => is_home(),
			'search'     => is_search(),
			'not_found'  => is_404(),
			'singular'   => null,
			'archive'    => null,
		];

		$object = get_queried_object();

		if ( is_singular() && $object instanceof \WP_Post ) {
			$context['singular'] = [
				'post_type' => $object->post_type,
				'id'        => (int) $object->ID,
				'terms'     => self::post_terms( $object ),
			];
		} elseif ( is_archive() || is_home() ) {
			$context['archive'] = self::archive_context( $object );
		}

		/**
		 * Filter the request context used to match display rules.
		 *
		 * @since 3.2.0
		 * @param array $context Request context.
		 */
		return apply_filters( 'pp_site_builder/context', $context );
	}

	/**
	 * A post's term IDs per taxonomy, each with its ancestors.
	 *
	 * The main query has already primed the term cache, so this reads memory.
	 *
	 * @since 3.2.0
	 * @param \WP_Post $post Post.
	 * @return array Map of taxonomy to term IDs.
	 */
	private static function post_terms( $post ) {
		$terms = [];

		foreach ( get_object_taxonomies( $post->post_type ) as $taxonomy ) {
			$assigned = get_the_terms( $post, $taxonomy );

			if ( ! $assigned || is_wp_error( $assigned ) ) {
				continue;
			}

			$ids = [];

			foreach ( $assigned as $term ) {
				$ids[] = (int) $term->term_id;
				$ids   = array_merge( $ids, array_map( 'intval', get_ancestors( $term->term_id, $taxonomy, 'taxonomy' ) ) );
			}

			$terms[ $taxonomy ] = array_values( array_unique( $ids ) );
		}

		return $terms;
	}

	/**
	 * Describe the current archive.
	 *
	 * @since 3.2.0
	 * @param mixed $object Queried object.
	 * @return array
	 */
	private static function archive_context( $object ) {
		$archive = [
			'kind'      => 'post_type',
			'post_type' => '',
			'taxonomy'  => '',
			'term_id'   => 0,
		];

		if ( is_author() ) {
			$archive['kind'] = 'author';
		} elseif ( is_date() ) {
			$archive['kind'] = 'date';
		} elseif ( ( is_category() || is_tag() || is_tax() ) && $object instanceof \WP_Term ) {
			$taxonomy = get_taxonomy( $object->taxonomy );

			$archive['kind']     = 'taxonomy';
			$archive['taxonomy'] = $object->taxonomy;
			$archive['term_id']  = (int) $object->term_id;

			// A taxonomy shared by several post types belongs to none of their archives.
			if ( $taxonomy && 1 === count( $taxonomy->object_type ) ) {
				$archive['post_type'] = reset( $taxonomy->object_type );
			}
		} elseif ( is_post_type_archive() ) {
			$post_type            = get_query_var( 'post_type' );
			$archive['post_type'] = is_array( $post_type ) ? reset( $post_type ) : $post_type;
		} elseif ( is_home() ) {
			$archive['post_type'] = 'post';
		}

		return $archive;
	}

	/**
	 * A rule path as words.
	 *
	 * Reads post type, taxonomy, post and term names, so it needs WordPress.
	 *
	 * @since 3.2.0
	 * @param string $rule Rule path.
	 * @return string
	 */
	public static function describe( $rule ) {
		$parts = explode( '/', $rule );

		$fixed = [
			'entire_site' => __( 'Entire site', 'powerpack' ),
			'front_page'  => __( 'Front page', 'powerpack' ),
			'blog'        => __( 'Blog page', 'powerpack' ),
			'search'      => __( 'Search results', 'powerpack' ),
			'not_found'   => __( '404 page', 'powerpack' ),
		];

		if ( isset( $fixed[ $rule ] ) ) {
			return $fixed[ $rule ];
		}

		if ( 'singular' === $parts[0] ) {
			if ( ! isset( $parts[1] ) ) {
				return __( 'All singular', 'powerpack' );
			}

			$label = self::post_type_label( $parts[1] );

			return isset( $parts[2] ) ? $label . ' › ' . get_the_title( (int) $parts[2] ) : $label;
		}

		// Without a term, the option the picker lists: "In Product categories".
		if ( 'singular_in' === $parts[0] && isset( $parts[1] ) ) {
			/* translators: %s: taxonomy, or taxonomy and term, e.g. "Product categories › Shoes" */
			return sprintf( __( 'In %s', 'powerpack' ), self::term_label( $parts[1], isset( $parts[2] ) ? $parts[2] : null ) );
		}

		if ( 'archive' === $parts[0] ) {
			if ( ! isset( $parts[1] ) ) {
				return __( 'All archives', 'powerpack' );
			}

			if ( 'author' === $parts[1] ) {
				return __( 'Author archives', 'powerpack' );
			}

			if ( 'date' === $parts[1] ) {
				return __( 'Date archives', 'powerpack' );
			}

			if ( 'taxonomy' === $parts[1] && isset( $parts[2] ) ) {
				return self::term_label( $parts[2], isset( $parts[3] ) ? $parts[3] : null );
			}

			/* translators: %s: post type name */
			return sprintf( __( '%s archive', 'powerpack' ), self::post_type_label( $parts[1] ) );
		}

		/**
		 * Describe a rule the built-in types do not know.
		 *
		 * @since 3.2.0
		 * @param string $label Description. Default the rule path itself.
		 * @param string $rule  Rule path.
		 */
		return (string) apply_filters( 'pp_site_builder/describe_rule', $rule, $rule );
	}

	/**
	 * A taxonomy's plural label, then a term in it when one is named.
	 *
	 * @since 3.2.0
	 * @param string   $taxonomy Taxonomy.
	 * @param int|null $term_id  Term ID.
	 * @return string
	 */
	private static function term_label( $taxonomy, $term_id = null ) {
		$object = get_taxonomy( $taxonomy );
		$label  = $object ? $object->labels->name : $taxonomy;

		if ( null !== $term_id ) {
			$term   = get_term( (int) $term_id, $taxonomy );
			$label .= ' › ' . ( $term && ! is_wp_error( $term ) ? $term->name : '#' . (int) $term_id );
		}

		return $label;
	}

	/**
	 * A post type's plural label, or its slug when it is not registered.
	 *
	 * @since 3.2.0
	 * @param string $post_type Post type.
	 * @return string
	 */
	private static function post_type_label( $post_type ) {
		$object = get_post_type_object( $post_type );

		return $object ? $object->labels->name : $post_type;
	}
}
