<?php
namespace PowerpackElements\Classes;

use Elementor\Controls_Manager;

/**
 * Elementor document types for the WooCommerce Site Builder templates.
 *
 * Loaded from 'elementor/documents/register' when WooCommerce is active. Each
 * document takes its type and names from PP_Site_Builder::get_type_definitions(),
 * so a class here only says which template type it edits.
 *
 * @package PowerPack Elements
 * @since 3.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PP_Site_Builder_Woo_Document
 *
 * @since 3.2.0
 */
abstract class PP_Site_Builder_Woo_Document extends PP_Site_Builder_Document {

	/**
	 * Template type this document edits.
	 *
	 * @since 3.2.0
	 */
	const TEMPLATE_TYPE = '';

	/**
	 * Document type.
	 *
	 * @since 3.2.0
	 * @return string
	 */
	public static function get_type() {
		return PP_Site_Builder::get_document_type( static::TEMPLATE_TYPE );
	}

	/**
	 * Document title.
	 *
	 * @since 3.2.0
	 * @return string
	 */
	public static function get_title() {
		return static::name( 'label' );
	}

	/**
	 * Document plural title.
	 *
	 * @since 3.2.0
	 * @return string
	 */
	public static function get_plural_title() {
		return static::name( 'plural' );
	}

	/**
	 * Page layout, and what the editor previews the template with.
	 *
	 * Registered ahead of the document's own settings so they open first.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	protected function register_controls() {
		$this->start_controls_section( 'pp_store_layout', [
			'label' => esc_html__( 'Layout', 'powerpack' ),
			'tab'   => Controls_Manager::TAB_SETTINGS,
		] );

		$this->add_control( 'pp_page_layout', [
			'label'       => esc_html__( 'Page Layout', 'powerpack' ),
			'type'        => Controls_Manager::SELECT,
			'default'     => 'theme',
			'options'     => [
				'theme'      => esc_html__( 'Theme', 'powerpack' ),
				'full_width' => esc_html__( 'Full width', 'powerpack' ),
				'canvas'     => esc_html__( 'Canvas', 'powerpack' ),
			],
			'description' => esc_html__( 'Theme keeps the theme\'s own page around the template. Full width keeps only its header and footer. Canvas shows the template alone.', 'powerpack' ),
		] );

		$this->end_controls_section();

		static::register_preview_section( $this );

		parent::register_controls();
	}

	/**
	 * Add the Preview section to a document.
	 *
	 * Public for the library templates migrated templates point at, which
	 * are edited as Elementor's own documents: see
	 * PP_Site_Builder_Woo_Preview::register_linked_preview().
	 *
	 * @since 3.2.0
	 * @param \Elementor\Core\Base\Document $document Document to add it to.
	 * @return void
	 */
	public static function register_preview_section( $document ) {
		$preview = static::preview_control();

		if ( ! $preview ) {
			return;
		}

		$document->start_controls_section( 'pp_store_preview', [
			'label' => esc_html__( 'Preview', 'powerpack' ),
			'tab'   => Controls_Manager::TAB_SETTINGS,
		] );

		$document->add_control( $preview['name'], $preview['control'] );

		$document->add_control( 'pp_store_apply_preview', [
			'type'        => Controls_Manager::BUTTON,
			'text'        => esc_html__( 'Apply & Preview', 'powerpack' ),
			'label_block' => true,
			'show_label'  => false,
			'separator'   => 'none',
			'event'       => 'ppWooBuilder:ApplyPreview',
		] );

		$document->end_controls_section();
	}

	/**
	 * The control that picks what the editor previews, or null for none.
	 *
	 * @since 3.2.0
	 * @return array|null Control name and arguments.
	 */
	protected static function preview_control() {
		return null;
	}

	/**
	 * A name from the type definition, as Elementor shows it.
	 *
	 * @since 3.2.0
	 * @param string $key 'label' or 'plural'.
	 * @return string
	 */
	protected static function name( $key ) {
		$definition = PP_Site_Builder::get_type_definition( static::TEMPLATE_TYPE );

		/* translators: %s: template type, e.g. "Single Product" */
		return $definition ? esc_html( sprintf( __( 'PowerPack %s', 'powerpack' ), $definition[ $key ] ) ) : '';
	}
}

/**
 * PP_Site_Builder_Single_Product_Document
 *
 * @since 3.2.0
 */
class PP_Site_Builder_Single_Product_Document extends PP_Site_Builder_Woo_Document {
	const TEMPLATE_TYPE = 'single_product';

	/**
	 * Pick the product the editor shows.
	 *
	 * @since 3.2.0
	 * @return array
	 */
	protected static function preview_control() {
		return [
			'name'    => 'pp_preview_product',
			'control' => [
				'label'       => esc_html__( 'Preview With', 'powerpack' ),
				'type'        => 'pp-query',
				'label_block' => true,
				'multiple'    => false,
				'query_type'  => 'posts',
				'object_type' => 'product',
				'description' => esc_html__( 'Shows this product while you edit. With none picked, the newest product is used.', 'powerpack' ),
			],
		];
	}
}

/**
 * PP_Site_Builder_Product_Archive_Document
 *
 * @since 3.2.0
 */
class PP_Site_Builder_Product_Archive_Document extends PP_Site_Builder_Woo_Document {
	const TEMPLATE_TYPE = 'product_archive';

	/**
	 * Pick the archive the editor shows.
	 *
	 * @since 3.2.0
	 * @return array
	 */
	protected static function preview_control() {
		return [
			'name'    => 'pp_preview_term',
			'control' => [
				'label'       => esc_html__( 'Preview As', 'powerpack' ),
				'type'        => 'pp-query',
				'label_block' => true,
				'multiple'    => false,
				'query_type'  => 'terms',
				'object_type' => 'product_cat',
				'placeholder' => esc_html__( 'Shop page', 'powerpack' ),
				'description' => esc_html__( 'Shows the products of this category while you edit. With none picked, the Shop page is shown.', 'powerpack' ),
			],
		];
	}
}

/**
 * PP_Site_Builder_Cart_Document
 *
 * @since 3.2.0
 */
class PP_Site_Builder_Cart_Document extends PP_Site_Builder_Woo_Document {
	const TEMPLATE_TYPE = 'cart';
}

/**
 * PP_Site_Builder_Checkout_Document
 *
 * @since 3.2.0
 */
class PP_Site_Builder_Checkout_Document extends PP_Site_Builder_Woo_Document {
	const TEMPLATE_TYPE = 'checkout';
}

/**
 * PP_Site_Builder_My_Account_Document
 *
 * @since 3.2.0
 */
class PP_Site_Builder_My_Account_Document extends PP_Site_Builder_Woo_Document {
	const TEMPLATE_TYPE = 'my_account';
}

/**
 * PP_Site_Builder_Thankyou_Document
 *
 * @since 3.2.0
 */
class PP_Site_Builder_Thankyou_Document extends PP_Site_Builder_Woo_Document {
	const TEMPLATE_TYPE = 'thankyou';
}
