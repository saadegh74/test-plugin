<?php
namespace PowerpackElements\Classes;

/**
 * Moves the old Header Footer and WooCommerce builder settings into Site
 * Builder templates, one numbered step at a time.
 *
 *   1  Headers and footers, each set to Entire site.
 *   2  WooCommerce: the single product and archive templates.
 *
 * Each migrated template points at the page or library template the old
 * settings assigned, so the site looks the same and the content is still
 * edited where it always was. The old options are left in place, so going
 * back to an earlier PowerPack version still works.
 *
 * @package PowerPack Elements
 * @since 3.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PP_Site_Builder_Migration
 */
final class PP_Site_Builder_Migration {

	/**
	 * Option holding the migration version this site has run.
	 *
	 * @since 3.2.0
	 */
	const VERSION_OPTION = 'pp_site_builder_migration';

	/**
	 * Current migration version.
	 *
	 * @since 3.2.0
	 */
	const VERSION = 2;

	/**
	 * Initialize hooks.
	 *
	 * Runs after the post type registers on 'init'.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	public static function init() {
		if ( ! did_action( 'elementor/loaded' ) ) {
			return;
		}

		add_action( 'init', __CLASS__ . '::maybe_migrate', 20 );
	}

	/**
	 * Whether this site has yet to run a migration step.
	 *
	 * @since 3.2.0
	 * @param int|null $step Step number; any step when null.
	 * @return bool
	 */
	public static function is_pending( $step = null ) {
		return (int) get_option( self::VERSION_OPTION, 0 ) < ( null === $step ? self::VERSION : (int) $step );
	}

	/**
	 * Migrate once per site.
	 *
	 * @since 3.2.0
	 * @return void
	 */
	public static function maybe_migrate() {
		if ( ! self::is_pending() ) {
			return;
		}

		// Two requests arriving together would otherwise both create templates.
		if ( get_transient( 'pp_site_builder_migrating' ) ) {
			return;
		}

		set_transient( 'pp_site_builder_migrating', 1, MINUTE_IN_SECONDS );

		$version = (int) get_option( self::VERSION_OPTION, 0 );

		if ( $version < 1 ) {
			self::migrate_legacy();
			$version = 1;
		}

		/*
		 * The store template types exist only while WooCommerce is active. A
		 * site with old store templates and WooCommerce switched off waits
		 * until it is back on, rather than being marked done with nothing
		 * migrated and losing those templates when the old builder goes.
		 */
		if ( 2 > $version && ( PP_Site_Builder::has_woocommerce() || ! self::has_legacy_woo() ) ) {
			self::migrate_woo();
			$version = 2;
		}

		update_option( self::VERSION_OPTION, $version );
		delete_transient( 'pp_site_builder_migrating' );
	}

	/**
	 * Create a template for each header and footer the old settings assign.
	 *
	 * Safe to run twice: a source that already has a template is skipped.
	 *
	 * @since 3.2.0
	 * @return array Map of type to created template ID.
	 */
	public static function migrate_legacy() {
		$created = [];

		foreach ( [ 'header', 'footer' ] as $type ) {
			$source = (int) get_option( 'pp_header_footer_template_' . $type );

			if ( ! $source || 'publish' !== get_post_status( $source ) || self::find_existing( $type, $source ) ) {
				continue;
			}

			$id = wp_insert_post( [
				'post_type'   => PP_Site_Builder::POST_TYPE,
				'post_status' => 'publish',
				'post_title'  => get_post_field( 'post_title', $source ),
			], true );

			if ( is_wp_error( $id ) ) {
				continue;
			}

			update_post_meta( $id, PP_Site_Builder::META_TYPE, $type );
			update_post_meta( $id, PP_Site_Builder::META_SOURCE, $source );
			update_post_meta( $id, PP_Site_Builder::META_RULES, [
				'include' => [ 'entire_site' ],
				'exclude' => [],
			] );

			if ( 'header' === $type ) {
				update_post_meta( $id, PP_Site_Builder::META_SETTINGS, self::legacy_header_settings() );
			}

			$created[ $type ] = $id;
		}

		if ( $created ) {
			PP_Site_Builder::rebuild_index();
		}

		return $created;
	}

	/**
	 * A template already created for this source.
	 *
	 * @since 3.2.0
	 * @param string $type   Template type.
	 * @param int    $source Source post ID.
	 * @return int Template ID, or 0.
	 */
	private static function find_existing( $type, $source ) {
		$ids = get_posts( [
			'post_type'        => PP_Site_Builder::POST_TYPE,
			'post_status'      => 'any',
			'posts_per_page'   => 1,
			'fields'           => 'ids',
			'no_found_rows'    => true,
			'suppress_filters' => true,
			'meta_query'       => [
				[
					'key'   => PP_Site_Builder::META_SOURCE,
					'value' => $source,
				],
				[
					'key'   => PP_Site_Builder::META_TYPE,
					'value' => $type,
				],
			],
		] );

		return $ids ? (int) $ids[0] : 0;
	}

	/**
	 * Whether the old WooCommerce builder has anything to migrate.
	 *
	 * @since 3.2.0
	 * @return bool
	 */
	public static function has_legacy_woo() {
		return get_option( 'pp_woo_template_single_product' ) || get_option( 'pp_woo_template_product_archive' );
	}

	/**
	 * Create Site Builder templates for the old WooCommerce builder.
	 *
	 * The single product and archive templates cover all products and every
	 * product archive, as before. With the old builder switched off the
	 * templates arrive inactive, so nothing starts showing by itself.
	 *
	 * Per-category layouts are not carried over. The old builder read them
	 * from term meta another plugin writes, with no setting of its own to
	 * choose one, so they belong to that plugin rather than to PowerPack.
	 *
	 * Safe to run twice: a source that already has a template of the type is
	 * skipped.
	 *
	 * @since 3.2.0
	 * @return array Map of template ID to the type it was created as.
	 */
	public static function migrate_woo() {
		$active  = (bool) get_option( 'pp_woo_builder_enable' );
		$created = [];

		$general = [
			'single_product'  => [ (int) get_option( 'pp_woo_template_single_product' ), 'singular/product' ],
			'product_archive' => [ (int) get_option( 'pp_woo_template_product_archive' ), 'archive/product' ],
		];

		foreach ( $general as $type => list( $source, $rule ) ) {
			$id = self::create_linked( $type, $source, [ $rule ], PP_Site_Builder::DEFAULT_PRIORITY, $active );

			if ( $id ) {
				$created[ $id ] = $type;
			}
		}

		if ( $created ) {
			PP_Site_Builder::rebuild_index();
		}

		return $created;
	}

	/**
	 * A template that renders an existing page or library template.
	 *
	 * @since 3.2.0
	 * @param string $type     Template type.
	 * @param int    $source   Post to render.
	 * @param array  $rules    Include rules.
	 * @param int    $priority Priority.
	 * @param bool   $active   Whether it starts published.
	 * @return int New template ID, or 0 when skipped.
	 */
	private static function create_linked( $type, $source, $rules, $priority, $active ) {
		if ( ! $source || 'publish' !== get_post_status( $source ) || self::find_existing( $type, $source ) ) {
			return 0;
		}

		$id = wp_insert_post( [
			'post_type'   => PP_Site_Builder::POST_TYPE,
			'post_status' => $active ? 'publish' : 'draft',
			'post_title'  => get_post_field( 'post_title', $source ),
		], true );

		if ( is_wp_error( $id ) ) {
			return 0;
		}

		update_post_meta( $id, PP_Site_Builder::META_TYPE, $type );
		update_post_meta( $id, PP_Site_Builder::META_SOURCE, $source );
		update_post_meta( $id, PP_Site_Builder::META_RULES, [
			'include' => $rules,
			'exclude' => [],
		] );

		if ( PP_Site_Builder::DEFAULT_PRIORITY !== $priority ) {
			update_post_meta( $id, PP_Site_Builder::META_PRIORITY, $priority );
		}

		return $id;
	}

	/**
	 * The old site-wide header behaviour, as template settings.
	 *
	 * @since 3.2.0
	 * @return array
	 */
	private static function legacy_header_settings() {
		return PP_Site_Builder::sanitize_settings( [
			'sticky'             => (bool) get_option( 'pp_header_footer_fixed_header' ),
			'sticky_breakpoints' => get_option( 'pp_header_footer_fixed_header_breakpoints', 'large-medium' ),
			'shrink'             => (bool) get_option( 'pp_header_footer_shrink_header' ),
			'overlay'            => (bool) get_option( 'pp_header_footer_overlay_header' ),
			'overlay_bg'         => get_option( 'pp_header_footer_overlay_header_bg', 'default' ),
		] );
	}
}

PP_Site_Builder_Migration::init();
