<?php
namespace PowerpackElements\Classes;

/**
 * REST controller for Site Builder templates.
 *
 * The post type is publicly queryable for Elementor's preview, which would
 * otherwise let anyone read published templates and their display rules over
 * REST. Reading needs the same capability as editing.
 *
 * @package PowerPack Elements
 * @since 3.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PP_Site_Builder_REST_Controller
 */
class PP_Site_Builder_REST_Controller extends \WP_REST_Posts_Controller {

	/**
	 * Only people who can edit templates may list them.
	 *
	 * @since 3.2.0
	 * @param \WP_REST_Request $request Request.
	 * @return true|\WP_Error
	 */
	public function get_items_permissions_check( $request ) {
		return $this->can_read() ? parent::get_items_permissions_check( $request ) : $this->forbidden();
	}

	/**
	 * Only people who can edit templates may read one.
	 *
	 * @since 3.2.0
	 * @param \WP_REST_Request $request Request.
	 * @return true|\WP_Error
	 */
	public function get_item_permissions_check( $request ) {
		return $this->can_read() ? parent::get_item_permissions_check( $request ) : $this->forbidden();
	}

	/**
	 * Whether the current user can edit templates.
	 *
	 * @since 3.2.0
	 * @return bool
	 */
	private function can_read() {
		return current_user_can( get_post_type_object( $this->post_type )->cap->edit_posts );
	}

	/**
	 * The error for a user who cannot read templates.
	 *
	 * @since 3.2.0
	 * @return \WP_Error
	 */
	private function forbidden() {
		return new \WP_Error(
			'rest_forbidden',
			__( 'Sorry, you are not allowed to view templates.', 'powerpack' ),
			[ 'status' => rest_authorization_required_code() ]
		);
	}
}
