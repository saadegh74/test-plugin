<?php
/**
 * A product page rendered by a Single Product template.
 *
 * Stands in for WooCommerce's content-single-product.php part; see
 * PP_Site_Builder_Woo_Render::single_product_part(). WooCommerce's notices,
 * password form and #product-{id} wrapper stay, since themes and WooCommerce's
 * own scripts hang off them, with the template's content inside.
 *
 * @package PowerPack Elements
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * WooCommerce's hook before a single product; prints its notices.
 */
do_action( 'woocommerce_before_single_product' );

if ( post_password_required() ) {
	echo get_the_password_form(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core markup.
	return;
}

global $post;
?>

<div id="product-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="pp-woo-template-builder">
		<?php
		/**
		 * Prints a Single Product template's content inside the product wrapper.
		 *
		 * @hooked PP_Site_Builder_Woo_Render::render_content - 5
		 * @hooked PP_Site_Builder_Woo_Render::product_structured_data - 10
		 *
		 * @since 2.1.0
		 * @param WP_Post $post The product.
		 */
		do_action( 'pp_woocommerce_product_content', $post );
		?>
	</div>
</div><!-- #product-<?php the_ID(); ?> -->

<?php do_action( 'woocommerce_after_single_product' ); ?>
