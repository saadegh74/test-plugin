<?php
/**
 * A store page rendered from a Site Builder template.
 *
 * Used for every product archive, and for a product or store page whose
 * layout is Full width or Canvas, or on a block theme. The classic theme
 * branches match the old WooCommerce builder's archive templates.
 *
 * @package PowerPack Elements
 * @since 3.2.0
 */

use PowerpackElements\Classes\PP_Site_Builder_Woo_Render as Render;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$pp_layout = Render::get_layout();

/*
 * Canvas, and any layout on a block theme, print the document themselves:
 * the first has no theme around it at all, and a block theme has no
 * header.php or footer.php to call.
 */
if ( 'canvas' === $pp_layout || Render::is_block_theme() ) {
	if ( 'canvas' === $pp_layout ) {
		\Elementor\Plugin::$instance->frontend->add_body_class( 'elementor-template-canvas' );
	}
	?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<?php if ( ! current_theme_supports( 'title-tag' ) ) : ?>
		<title><?php echo esc_html( wp_get_document_title() ); ?></title>
	<?php endif; ?>
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
	<?php
	wp_body_open();

	if ( 'canvas' === $pp_layout ) {
		do_action( 'elementor/page_templates/canvas/before_content' );
		Render::render_main();
		do_action( 'elementor/page_templates/canvas/after_content' );
	} else {
		echo '<div class="wp-site-blocks">';
		block_template_part( 'header' );
		echo '<main class="pp-site-builder-main">';
		Render::render_main();
		echo '</main>';
		block_template_part( 'footer' );
		echo '</div>';
	}

	wp_footer();
	?>
</body>
</html>
	<?php
	return;
}

if ( 'full_width' === $pp_layout ) {
	\Elementor\Plugin::$instance->frontend->add_body_class( 'elementor-template-full-width' );
}

get_header( 'shop' );

if ( 'full_width' === $pp_layout ) {
	do_action( 'elementor/page_templates/header-footer/before_content' );
}

Render::render_main();

if ( 'full_width' === $pp_layout ) {
	do_action( 'elementor/page_templates/header-footer/after_content' );
}

get_footer( 'shop' );
