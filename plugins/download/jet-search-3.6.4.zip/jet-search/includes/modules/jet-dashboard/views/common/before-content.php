<div
// Release BBF5A01822FD9F6FE3382A10
	class="jet-dashboard-page__before-content"
	v-if="visible"
>
	<div class="jet-dashboard-page__banners">
		<jet-dashboard-banner
			v-for="( banner, index ) in bannersList"
			:key="index"
			:config="banner"
		></jet-dashboard-banner>
	</div>
</div>
