<?php

namespace NinjaTablesPro\App\Modules\DataTables;

use NinjaTablesPro\App\Modules\DataTables\Handlers\DTFrontendEditHandler;

class DataTablesModule
{
    public function register()
    {
        (new DTFrontendEditHandler())->register();
    }

    public static function isDataTablesTable($tableId)
    {
        $settings = ninja_table_get_table_settings($tableId, 'public');
        return isset($settings['library']) && $settings['library'] === 'datatables';
    }
}
