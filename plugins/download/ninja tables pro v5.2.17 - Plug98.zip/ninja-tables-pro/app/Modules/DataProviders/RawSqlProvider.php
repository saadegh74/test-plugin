<?php

namespace NinjaTablesPro\App\Modules\DataProviders;

use NinjaTables\Framework\Support\Arr;
use NinjaTables\App\App;

class RawSqlProvider
{
    public $provider = 'raw_sql';

    public function boot()
    {
        add_filter('ninja_tables_get_table_raw_sql', array($this, 'getTableSettings'), 10, 1);
        add_filter('ninja_tables_get_table_data_raw_sql', array($this, 'getTableData'), 10, 4);
        add_filter('ninja_tables_fetching_table_rows_raw_sql', array($this, 'data'), 10, 5);
        add_action('wp_ajax_ninja_tables_save_raw_sql_table', array($this, 'createTable'));
        add_action('wp_ajax_ninja_table_raw_sql_update_sql', array($this, 'updateSQL'));
        add_filter('ninja_table_activated_features', function ($features) {
            $features['raw_sql_query'] = true;

            return $features;
        });

        add_action('wp_ajax_ninja_table_raw_sql_remote_connection_details', array($this, 'getRemoteSQLDetails'));

        add_filter('ninja_table_sql_permission', array($this, 'hasSQLPermission'), 10, 1);
    }

    /**
     * Placeholder sent to the browser instead of the stored DB password.
     * Submitting it back (or an empty value) keeps the stored password.
     */
    const PASSWORD_MASK = '********';

    /**
     * Resolve a request table_id to an existing ninja-table post or fail the request.
     */
    private function requireTableId()
    {
        $tableId = absint(Arr::get($_REQUEST, 'table_id'));
        if (!$tableId || get_post_type($tableId) !== 'ninja-table') {
            wp_send_json_error([
                'message' => array('Invalid table.')
            ], 404);
            wp_die();
        }

        return $tableId;
    }

    /**
     * Remote connections opened during this request, keyed by table ID.
     */
    private $remoteConnections = [];

    public function getDb($tableId = false, $connectionDetails = false)
    {
        if ($connectionDetails) {
            return $this->getRemoteDB($connectionDetails);
        }
        if ($tableId) {
            $connectionType = get_post_meta($tableId, '_ninja_tables_sql_connection_type', true);
            if ($connectionType == 'external') {
                if (!array_key_exists($tableId, $this->remoteConnections)) {
                    $connection = get_post_meta($tableId, '_ninja_tables_sql_connection_details', true);
                    $this->remoteConnections[$tableId] = $this->getRemoteDB($connection);
                }

                return $this->remoteConnections[$tableId];
            }
        }
        global $wpdb;

        return $wpdb;
    }

    /**
     * Run a stored SELECT for rendering; returns [] on connection or query failure.
     */
    private function runQuery($tableId, $sql, $output = OBJECT)
    {
        $db = $this->getDb($tableId);
        if (!$db) {
            return array();
        }
        $sql = $this->parseTableSQL($sql, $tableId, $db);

        $db->last_error = '';
        $db->suppress_errors(true);
        $results = $db->get_results($sql, $output);
        $db->suppress_errors(false);

        if ($db->last_error || !is_array($results)) {
            return array();
        }

        return $results;
    }

    public function createTable()
    {
        if (!current_user_can(ninja_table_admin_role())) {
            return;
        }
        ninjaTablesValidateNonce();

        $hasPermission = apply_filters('ninja_table_sql_permission', '');
        if ($hasPermission != 'yes') {
            wp_send_json_error([
                'message' => 'Sorry, You do not have permission to do this'
            ], 423);
        }

        $sql = wp_unslash((Arr::get($_REQUEST, 'sql', '')));


        $connectionType = sanitize_text_field(Arr::get($_REQUEST, 'connection_type', 'local'));

        $connection_details = [];

        if ($connectionType == 'external') {
            $connection_details = $this->sanitizeConnectionDetails(Arr::get($_REQUEST, 'connection_details', []));
            $this->validateRemoteConnection($connection_details);
            $this->validateSql($sql, false, $connection_details);
        } else {
            // Validate the SQL and see if we have any data or not
            $this->validateSql($sql);
        }

        // Validate Title
        $messages = array();
        if (empty(Arr::get($_REQUEST, 'post_title'))) {
            $messages[] = __('The title field is required.', 'ninja-tables-pro');
            wp_send_json_error(array('message' => $messages), 422);
            wp_die();
        }

        // Create The Table now
        $tableId = $this->saveTable();

        do_action('ninja_tables/update_table_settings', $tableId, [
            'request_data' => App::make('request')->all()
        ]);

        update_post_meta($tableId, '_ninja_table_raw_sql_query', $sql);
        update_post_meta($tableId, '_ninja_tables_data_provider', $this->provider);
        update_post_meta($tableId, '_ninja_tables_sql_connection_type', $connectionType);

        if ($connectionType == 'external') {
            update_post_meta($tableId, '_ninja_tables_sql_connection_details', $connection_details);
        }


        $this->createColumns($tableId, $sql);


        wp_send_json_success(
            array('table_id' => $tableId)
        );
    }

    public function updateSQL()
    {
        if (!current_user_can(ninja_table_admin_role())) {
            return;
        }

        ninjaTablesValidateNonce();

        $hasPermission = apply_filters('ninja_table_sql_permission', '');
        if ($hasPermission != 'yes') {
            wp_send_json_error([
                'message' => 'Sorry, You do not have permission to do this'
            ], 423);
        }

        $tableId = $this->requireTableId();

        $connectionDetails = false;
        if (isset($_REQUEST['connection_details'])) {
            $connectionDetails = $this->sanitizeConnectionDetails(Arr::get($_REQUEST, 'connection_details'));

            // The UI never receives the real password; a masked/empty value means "unchanged".
            $password = $connectionDetails['db_userpassword'];
            if ($password === '' || $password === self::PASSWORD_MASK) {
                $stored = get_post_meta($tableId, '_ninja_tables_sql_connection_details', true);
                $connectionDetails['db_userpassword'] = (string)Arr::get((array)$stored, 'db_userpassword', '');
            }

            $this->validateRemoteConnection($connectionDetails);
        }

        $sql = wp_unslash(Arr::get($_REQUEST, 'sql', ''));
        // Validate against the submitted connection (if any) before persisting it,
        // so a failing SQL does not leave the table pointing at new credentials.
        $this->validateSql($sql, $tableId, $connectionDetails);

        if ($connectionDetails) {
            update_post_meta($tableId, '_ninja_tables_sql_connection_details', $connectionDetails);
        }

        update_post_meta($tableId, '_ninja_table_raw_sql_query', $sql);

        $this->updateTableColumn($tableId, $sql);

        wp_send_json_success(array(
            'message' => 'SQL successfully updated'
        ), 200);
    }

    private function sanitizeConnectionDetails($details)
    {
        $details = is_array($details) ? wp_unslash($details) : [];

        // The password is only ever handed to mysqli, never rendered, so it must
        // not go through wp_kses (which would mangle characters like & < > ").
        return [
            'db_name'         => sanitize_text_field(Arr::get($details, 'db_name', '')),
            'db_username'     => sanitize_text_field(Arr::get($details, 'db_username', '')),
            'db_userpassword' => (string)Arr::get($details, 'db_userpassword', ''),
            'db_host'         => sanitize_text_field(Arr::get($details, 'db_host', '')),
            'db_host_port'    => absint(Arr::get($details, 'db_host_port', 3306)) ?: 3306,
        ];
    }

    private function validateRemoteConnection($connection)
    {
        $connect = $this->getRemoteDB($connection);
        if (!$connect) {
            wp_send_json_error(array(
                'message' => array('Provided SQL Connection details is not valid'),
                'error'   => $this->lastConnectionError
            ), 423);
            wp_die();
        }

        return $connect;
    }

    /**
     * Last remote-connection failure message, for the admin error response.
     */
    private $lastConnectionError = '';

    private function getRemoteDB($connection)
    {
        $this->lastConnectionError = '';

        if (!is_array($connection) || empty($connection['db_host'])) {
            $this->lastConnectionError = 'Connection details are missing.';
            return false;
        }

        $port   = absint(Arr::get($connection, 'db_host_port')) ?: 3306;
        $dbHost = $connection['db_host'] . ':' . $port;

        // Connect without bailing: wpdb::__construct() would otherwise wp_die()/dead_db()
        // on failure, and with WP_DEBUG_DISPLAY off it silently returns a dead handle.
        $db = new RemoteWpdb(
            Arr::get($connection, 'db_username', ''),
            Arr::get($connection, 'db_userpassword', ''),
            Arr::get($connection, 'db_name', ''),
            $dbHost
        );

        if (!$db->dbh) {
            $this->lastConnectionError = $db->connectError ?: 'Could not connect to the database server.';
            return false;
        }

        // A fresh wpdb has no prefix; assume the WordPress default so {prefix} keeps working.
        $prefix = apply_filters('ninja_table_raw_sql_remote_prefix', 'wp_', $connection);
        $db->set_prefix($prefix);

        return $db;
    }

    public function validateSql($sql, $tableId = false, $connectionDetails = false)
    {
        $normalized = $this->normalizeSqlForChecks($sql);

        // SQL must start with SELECT (after stripping comments)
        if (!preg_match('/^\(*\s*select\b/', $normalized)) {
            wp_send_json_error(array(
                'message' => array('SQL is not valid'),
                'error'   => 'Only SELECT queries are allowed.'
            ), 423);
        }

        if ($this->hasDisallowedKeyword($normalized)) {
            wp_send_json_error(array(
                'message' => array('SQL is not valid'),
                'error'   => 'The SQL contains disallowed keywords. Only SELECT queries are permitted.'
            ), 423);
        }

        // Resolve the executing connection first so {prefix} expands against it,
        // not against the local DB (creation) or the previously stored remote (update).
        $db = $this->getDb($tableId, $connectionDetails);
        if (!$db) {
            wp_send_json_error(array(
                'message' => array('Provided SQL Connection details is not valid'),
                'error'   => $this->lastConnectionError
            ), 423);
        }

        $sql = $this->parseTableSQL($sql, $tableId, $db);

        // Errors are only printed when WP_DEBUG_DISPLAY is on, so read last_error
        // instead of buffering output.
        $db->last_error = '';
        $db->suppress_errors(true);
        $results = $db->get_results($sql);
        $db->suppress_errors(false);

        if ($db->last_error) {
            wp_send_json_error(array(
                'message' => array('SQL is not valid'),
                'error'   => esc_html($db->last_error)
            ), 423);
            wp_die();
        }

        if (!$results) {
            wp_send_json_error(array(
                'message' => array('SQL is valid but returned no rows, so columns cannot be detected.'),
                'error'   => 'The query returned an empty result set.'
            ), 423);
            wp_die();
        }

        return true;
    }

    /**
     * Lower-case the SQL and remove string literals, quoted identifiers, comments
     * and repeated whitespace so keyword checks see only real SQL tokens.
     */
    private function normalizeSqlForChecks($sql)
    {
        $sql = strtolower($sql);
        // 'literals', "literals" and `identifiers` (with escaped quotes) can never carry a statement.
        $sql = preg_replace("/'(?:[^'\\\\]|\\\\.|'')*'|\"(?:[^\"\\\\]|\\\\.|\"\")*\"|`[^`]*`/s", ' ', $sql);
        $sql = preg_replace('~/\*.*?\*/|--[^\n]*|#[^\n]*~s', ' ', $sql);
        $sql = preg_replace('/\s+/', ' ', $sql);

        return trim($sql);
    }

    /**
     * Whole-word match so `last_update` or `created_at` pass while `DELETE\nFROM`
     * or `DELETE/**\/FROM` are caught. REPLACE() the string function is allowed;
     * REPLACE INTO is not.
     */
    private function hasDisallowedKeyword($normalized)
    {
        $statements = 'delete|update|insert|drop|truncate|alter|create|grant|revoke|rename|call|handler|lock|unlock|set';
        if (preg_match('/\b(?:' . $statements . ')\b/', $normalized)) {
            return true;
        }
        if (preg_match('/\breplace\b(?!\s*\()/', $normalized)) {
            return true;
        }

        return (bool)preg_match('/\bload_file\b|\binto\s+(?:outfile|dumpfile)\b|\bload\s+data\b/', $normalized);
    }

    public function createColumns($tableId, $sql)
    {
        // We have to create the columns and additional settings now
        $db     = $this->getDb($tableId);
        $sql    = $this->parseTableSQL($sql, $tableId, $db);
        $row    = $db ? $db->get_row($sql) : null;
        $fields = array();
        foreach ((array)$row as $row_key => $row_value) {
            $fields[] = $row_key;
        }

        $columns = array();

        foreach ($fields as $key => $column) {
            $columns[] = array(
                'name'                => $column,
                'key'                 => $column,
                'breakpoints'         => null,
                'data_type'           => 'text',
                'dateFormat'          => null,
                'header_html_content' => null,
                'enable_html_content' => false,
                'contentAlign'        => null,
                'textAlign'           => null,
                'original_name'       => $column,
                'original_key'        => $column
            );
        }

        $tableSettings = ninja_table_get_table_settings($tableId, 'admin');
        update_post_meta($tableId, '_ninja_table_settings', $tableSettings);
        update_post_meta($tableId, '_ninja_table_columns', $columns);
    }

    public function updateTableColumn($tableId, $sql)
    {
        // We have to create the columns and additional settings now
        $db  = $this->getDb($tableId);
        if (!$db) {
            return;
        }
        $sql = $this->parseTableSQL($sql, $tableId, $db);
        $row = $db->get_row($sql);
        if (!$row) {
            if (!class_exists('\PHPSQLParser\PHPSQLParser')) {
                require_once NINJAPROPLUGIN_PATH . '/app/Library/load.php';
            }
            $parser = new \PHPSQLParser\PHPSQLParser($sql, true);
            $parsed = $parser->parsed;
            if (isset($parsed['WHERE'])) {
                unset($parsed['WHERE']);
            }
            $creator = new \PHPSQLParser\PHPSQLCreator();
            $sql     = $creator->create($parsed);
            $row     = $db->get_row($sql);
        }

        $columns = array();
        foreach ((array)$row as $row_key => $row_value) {
            $columns[] = $row_key;
        }

        $existingColumns     = get_post_meta($tableId, '_ninja_table_columns', true);
        $exisitingColumnKeys = array();
        if (is_array($existingColumns)) {
            foreach ($existingColumns as $column) {
                // Columns created in the normal editor carry only `key`; only
                // raw-sql columns also carry `original_key`. Fall back so an
                // editor-built table does not warn on every SQL save.
                $columnKey = Arr::get($column, 'original_key', Arr::get($column, 'key'));
                if ($columnKey !== null) {
                    $exisitingColumnKeys[$columnKey] = $column;
                }
            }
        }
        $formattedColumns = array();
        foreach ($columns as $key => $column) {
            if (isset($exisitingColumnKeys[$column])) {
                $exisitingColumnKeys[$column]['original_key']  = $column;
                $exisitingColumnKeys[$column]['key']           = $column;
                $exisitingColumnKeys[$column]['original_name'] = $column;
                $formattedColumns[]                            = $exisitingColumnKeys[$column];
            } else {
                $formattedColumns[$key] = array(
                    'name'                => $column,
                    'key'                 => $column,
                    'breakpoints'         => null,
                    'data_type'           => 'text',
                    'dateFormat'          => null,
                    'header_html_content' => null,
                    'enable_html_content' => false,
                    'contentAlign'        => null,
                    'textAlign'           => null,
                    'original_name'       => $column,
                    'original_key'        => $column
                );
            }
        }
        update_post_meta($tableId, '_ninja_table_columns', $formattedColumns);
    }

    public function getTableSettings($table)
    {
        $connectionType = get_post_meta($table->ID, '_ninja_tables_sql_connection_type', true);
        if (!$connectionType) {
            $connectionType = 'local';
        }
        $table->isEditable                 = false;
        $table->dataSourceType             = get_post_meta($table->ID, '_ninja_tables_data_provider', true);
        $table->isEditableMessage          = ' to edit your SQL query please click here';
        $table->isExportable               = true;
        $table->isImportable               = false;
        $table->isSortable                 = false;
        $table->hasCacheFeature            = false;
        $table->isCreatedSortable          = false;
        $table->hasExternalCachingInterval = false;
        $table->sql                        = get_post_meta($table->ID, '_ninja_table_raw_sql_query', true);
        $table->connection_type            = $connectionType;

        return $table;
    }

    /**
     * @param \wpdb|false|null $db The connection that will run the query; resolved
     *                              from $tableID when omitted. {prefix} must come from
     *                              the same connection that executes the SQL.
     */
    private function parseTableSQL($sql, $tableID = false, $db = null)
    {
        if ($db === null) {
            $db = $this->getDb($tableID);
        }
        $prefix          = ($db && property_exists($db, 'prefix')) ? $db->prefix : '';
        $sqlPlaceHolders = apply_filters('ninja_table_raw_sql_placeholders', array(
            '{current_user_id}'   => get_current_user_id(),
            '{current_date}'      => date('Y-m-d'),
            '{prefix}'            => $prefix,
            '{current_date_time}' => date('Y-m-d H:i:s'),
        ), $tableID);
        $parsedSQL       = str_replace(array_keys($sqlPlaceHolders), array_values($sqlPlaceHolders), $sql);

        $parsedSQL = apply_filters('ninja_parse_placeholder', $parsedSQL);

        return apply_filters('ninja_table_raw_sql_parsed', $parsedSQL, $sql, $tableID);
    }

    public function getTableData($data, $tableId, $perPage, $offset)
    {
        $newData = array();
        $sql     = get_post_meta($tableId, '_ninja_table_raw_sql_query', true);
        $results = $this->runQuery($tableId, $sql);

        $totalData = count($results);

        $responseData = array_slice($results, $offset, $perPage);

        foreach ($responseData as $key => $value) {
            $newData[] = array(
                'id'       => $key + 1,
                'values'   => $value,
                'position' => $key + 1,
            );
        }

        return array(
            $newData,
            $totalData
        );
    }

    public function data($data, $tableId, $defaultSorting, $limitEntries = false, $skip = false)
    {
        $sql          = get_post_meta($tableId, '_ninja_table_raw_sql_query', true);
        $limitEntries = intval($limitEntries);
        $skip         = intval($skip);

        $results = $this->runQuery($tableId, $sql, ARRAY_A);

        if ($limitEntries || $skip) {
            $results = array_slice($results, $skip, $limitEntries);
        }

        return $results ? $results : $data;
    }

    protected function saveTable($postId = null)
    {
        $attributes = array(
            'post_title'   => sanitize_text_field($this->get($_REQUEST, 'post_title')),
            'post_content' => wp_kses_post($this->get($_REQUEST, 'post_content')),
            'post_type'    => 'ninja-table',
            'post_status'  => 'publish'
        );

        if (!$postId) {
            $postId = wp_insert_post($attributes);
        } else {
            $attributes['ID'] = $postId;
            wp_update_post($attributes);
        }

        return $postId;
    }

    protected function get($array, $key, $default = false)
    {
        if (isset($array[$key])) {
            return $array[$key];
        }

        return $default;
    }

    public function returnFalse()
    {
        return false;
    }

    public function hasSQLPermission($status = false)
    {
        if ($status == 'yes') {
            return $status; // Already admin so further check required
        }

        $permission = get_option('_ninja_tables_sql_permission');

        if ($permission == 'yes') {
            return 'yes';
        }

        if (current_user_can('manage_options')) {
            return 'yes';
        }

        return 'no';
    }


    public function getRemoteSQLDetails()
    {
        if (!current_user_can(ninja_table_admin_role())) {
            return;
        }

        ninjaTablesValidateNonce();

        $hasPermission = apply_filters('ninja_table_sql_permission', '');
        if ($hasPermission != 'yes') {
            wp_send_json_error([
                'message' => 'Sorry, You do not have permission to do this'
            ], 423);
        }

        $tableId = $this->requireTableId();

        $connectionDetails = get_post_meta($tableId, '_ninja_tables_sql_connection_details', true);
        if (is_array($connectionDetails) && Arr::get($connectionDetails, 'db_userpassword') !== '') {
            $connectionDetails['db_userpassword'] = self::PASSWORD_MASK;
        }

        wp_send_json_success(array(
            'connection_details' => $connectionDetails
        ));
    }
}
