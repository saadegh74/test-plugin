<?php

namespace NinjaTablesPro\App\Modules\DataProviders;

/**
 * wpdb that never wp_die()s / dead_db()s when the remote server is unreachable,
 * so a bad connection can be reported back to the admin as a normal error.
 */
class RemoteWpdb extends \wpdb
{
    public $connectError = '';

    public function __construct($dbuser, $dbpassword, $dbname, $dbhost)
    {
        $this->dbuser     = $dbuser;
        $this->dbpassword = $dbpassword;
        $this->dbname     = $dbname;
        $this->dbhost     = $dbhost;

        $this->suppress_errors(true);
        $this->db_connect(false);
        $this->suppress_errors(false);

        if (!$this->dbh) {
            $this->connectError = mysqli_connect_error() ?: 'Could not connect to the database server.';
        }
    }

    // Core reconnects on a dropped handle and bails with dead_db(); never bail here.
    public function check_connection($allow_bail = true)
    {
        return parent::check_connection(false);
    }
}
