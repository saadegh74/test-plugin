<?php

namespace NinjaTablesPro\App\Modules\GoogleSheetSync;

defined('ABSPATH') || exit;

use NinjaTables\Framework\Support\Arr;

class GoogleSheetSyncProvider
{
    public function boot()
    {
        add_action('ninja_tables_gsheet_sync', [SyncService::class, 'handleCronSync']);
        add_action('ninja_tables_gsheet_cleanup_tmp', [SyncService::class, 'cleanupTempFiles']);
        add_action('before_delete_post', [$this, 'onBeforeDeletePost']);

        // Schedule daily temp file cleanup if not already scheduled
        if (!wp_next_scheduled('ninja_tables_gsheet_cleanup_tmp')) {
            wp_schedule_event(time(), 'daily', 'ninja_tables_gsheet_cleanup_tmp');
        }

        add_filter('ninja_table_activated_features', function ($features) {
            $features['google_sheet_dt'] = true;

            return $features;
        });

        add_filter('ninja_tables_get_table_google-csv', [$this, 'maybeSetDTTableSettings']);

        // Visitor-triggered auto-sync: every DataTables render passes through
        // this filter, so it is the lifecycle point where an overdue enabled
        // table gets its background sync scheduled. maybeScheduleSync() is a
        // no-op unless the table has an enabled sync config that is past due,
        // so attaching to all renders is cheap.
        add_filter('ninja_table_rendering_table_vars', [$this, 'maybeScheduleAutoSync'], 10, 2);
    }

    /**
     * @param array $tableVars
     * @param int   $tableId
     *
     * @return array the table vars, untouched
     */
    public function maybeScheduleAutoSync($tableVars, $tableId)
    {
        SyncService::maybeScheduleSync((int) $tableId);

        return $tableVars;
    }

    public function maybeSetDTTableSettings($table)
    {
        $settings = ninja_table_get_table_settings($table->ID, 'public');

        if (Arr::get($settings, 'library') !== 'datatables') {
            return $table;
        }

        $syncConfig = get_post_meta($table->ID, '_ninja_gsheet_sync_config', true);

        if (!is_array($syncConfig) || empty($syncConfig['enabled'])) {
            return $table;
        }

        $table->isEditable     = false;
        $table->dataSourceType = 'google-csv';
        $table->remoteURL      = get_post_meta($table->ID, '_ninja_tables_data_provider_url', true);

        return $table;
    }

    public function onBeforeDeletePost($postId)
    {
        $post = get_post($postId);

        if (!$post || $post->post_type !== 'ninja-table') {
            return;
        }

        $syncConfig = get_post_meta($postId, '_ninja_gsheet_sync_config', true);

        if (!is_array($syncConfig)) {
            return;
        }

        wp_clear_scheduled_hook('ninja_tables_gsheet_sync', [$postId]);
        delete_transient('_ninja_gsheet_sync_lock_' . $postId);

        // Clean up any active chunked sync job + temp file
        $state = SyncService::getSyncState($postId);
        $token = Arr::get($state, 'active_token', '');
        if ($token) {
            $job = get_transient(SyncService::JOB_PREFIX . $token);
            if ($job && !empty($job['file_path']) && file_exists($job['file_path'])) {
                wp_delete_file($job['file_path']);
            }
            delete_transient(SyncService::JOB_PREFIX . $token);
        }
    }
}
