<?php

namespace NinjaTablesPro\App\Http\Controllers;

use NinjaTables\App\Models\NinjaTableItem as TableItem;
use NinjaTables\Framework\Request\Request;
use NinjaTablesPro\App\Models\NinjaTableItem;
use NinjaTablesPro\App\Traits\SortableTrait;
use NinjaTablesPro\App\Modules\DataTables\Handlers\SortableHandler;

class SortableController extends Controller
{
    use SortableTrait;

    public function init(Request $request)
    {
        global $wpdb;

        $tableId        = intval($request->getSafe('table_id'));
        $dataSourceType = ninja_table_get_data_provider($tableId);
        $tableSettings  = ninja_table_get_table_settings($tableId, 'admin');

        // Dispatch to DataTables handler if using DataTables rendering engine
        $library = isset($tableSettings['library']) ? $tableSettings['library'] : 'footable';
        if ($library === 'datatables') {
            SortableHandler::init($tableId, $tableSettings, $_REQUEST);

            return;
        }

        $tableName = $wpdb->prefix . static::$tableName;

        static::migrateDatabaseIfNeeded($tableName);

        // The post meta table would have a flag that the data of
        // the table is migrated to use for the manual sorting.
        $dataMigrated = ninjaTablesDataMigratedForManualSort($tableId);

        if (!$dataMigrated) {
            $orderBy = ($tableSettings['default_sorting'] === 'old_first') ? 'ASC' : 'DESC';

            // Initialize the `position` value of the data to allow manual sort.
            $wpdb->query("SET @p=0");

            $wpdb->query($wpdb->prepare(
                "UPDATE {$tableName} SET position = @p := (@p+1) WHERE table_id = %d ORDER BY created_at {$orderBy}",
                $tableId
            ));

            // Update the post meta table that the data of this
            // table is migrated to use for manual sorting.
            $postMetaKey = '_ninja_tables_data_migrated_for_manual_sort';
            update_post_meta($tableId, $postMetaKey, true);
        } else {
            static::recheckItemPositions($tableId);
        }

        // Finally update the table's sorting settings.
        $tableSettings['sorting_type'] = 'manual_sort';
        update_post_meta($tableId, '_ninja_table_settings', $tableSettings);

        if (!isset($_REQUEST['noData'])) {
            $perPage     = isset($_REQUEST['per_page']) ? intval($_REQUEST['per_page']) : 10;
            $currentPage = isset($_REQUEST['page']) ? intval($_REQUEST['page']) : 1;
            $skip        = $perPage * ($currentPage - 1);
            $search      = $request->getSafe('search', 'sanitize_text_field', '');
            $data        = TableItem::getItems($tableId, $perPage, $currentPage, $skip, $search, $dataSourceType);

            wp_send_json($data, 200);
        }
    }

    public function store(Request $request)
    {
        global $wpdb;

        $id             = $request->getSafe('id', 'intval');
        $tableId        = $request->getSafe('table_id', 'intval');
        $newPosition    = $request->getSafe('newPosition', 'intval');
        $dataSourceType = ninja_table_get_data_provider($tableId);

        // Dispatch to DataTables handler if using DataTables rendering engine
        $tableSettings = ninja_table_get_table_settings($tableId, 'admin');
        $library       = isset($tableSettings['library']) ? $tableSettings['library'] : 'footable';
        if ($library === 'datatables') {
            $result = SortableHandler::store($tableId, $id, $newPosition, $_REQUEST);

            if (!$result['success']) {
                return $this->json(['message' => $result['message']], 400);
            }

            unset($result['success']);

            return $this->json($result, 200);
        }

        $tableName   = $wpdb->prefix . static::$tableName;
        $oldPosition = (int) NinjaTableItem::where('table_id', $tableId)->where('id', $id)->first()->position;

        // A drop on the slot the row already occupies has nothing to move: skip
        // every position write — not even a transient position=0 — and the
        // cache clear, and fall straight through to the response. This keeps a
        // no-op from exposing an intermediate state to concurrent readers or
        // reorders.
        if ($newPosition !== $oldPosition) {
            // If the new position is less than the old one, shift each row
            // between them down by one; otherwise pull them up by one.
            if ($newPosition < $oldPosition) {
                $query = "UPDATE {$tableName}
                          SET position = position + 1
                          WHERE table_id = %d
                          AND position BETWEEN %d AND %d
                          ORDER BY position DESC";

                $bindings = array($tableId, $newPosition, $oldPosition);
            } else {
                $query = "UPDATE {$tableName}
                          SET position = position - 1
                          WHERE table_id = %d
                          AND position BETWEEN %d AND %d
                          ORDER BY position ASC";

                $bindings = array($tableId, $oldPosition, $newPosition);
            }

            // Wrap the three-step reorder (park the target at 0, shift the range,
            // write the target's new position) in a transaction so a concurrent
            // request never observes the row parked at 0 mid-shift. The framework
            // connection wraps the same global $wpdb the raw batch UPDATE uses,
            // so the transaction spans the ORM writes and the raw query alike.
            (new NinjaTableItem)->getConnection()->transaction(function () use ($wpdb, $tableId, $id, $query, $bindings, $newPosition) {
                NinjaTableItem::where('table_id', $tableId)->where('id', $id)->update(['position' => 0]);
                $wpdb->query($wpdb->prepare($query, $bindings));
                NinjaTableItem::where('table_id', $tableId)->where('id', $id)->update(['position' => $newPosition]);
            });

            ninjaTablesClearTableDataCache($tableId);
        }
        // Now return the data.

        $perPage     = isset($_REQUEST['per_page']) ? intval($_REQUEST['per_page']) : 10;
        $currentPage = isset($_REQUEST['page']) ? intval($_REQUEST['page']) : 1;
        $skip        = $perPage * ($currentPage - 1);
        $search      = $request->getSafe('search', 'sanitize_text_field', '');
        $data        = TableItem::getItems($tableId, $perPage, $currentPage, $skip, $search, $dataSourceType);

        return $this->json($data, 200);
    }
}
