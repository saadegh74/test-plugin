<?php

namespace NinjaTablesPro\App\Http\Controllers;

use NinjaTables\Framework\Request\Request;
use NinjaTables\Framework\Support\Arr;
use NinjaTablesPro\App\Services\PluginManager\FluentLicensing;
use NinjaTablesPro\App\Services\PluginManager\RenewRedirect;

/**
 * The three endpoints the license screen (in the free plugin) talks to.
 *
 * Everything the UI shows is resolved here rather than in JavaScript: dates
 * are formatted in the site's timezone and locale, and the raw license key
 * must never reach the browser.
 */
class LicenseController extends Controller
{
    public function getStatus()
    {
        $licenseManager = FluentLicensing::getInstance();

        // true = remote check; fine here, this is an admin-only screen.
        $data = $licenseManager->getStatus(true);

        if (is_wp_error($data)) {
            return [
                'status'  => 'invalid',
                'message' => $data->get_error_message(),
            ];
        }

        return $this->formatLicenseData($data, $licenseManager);
    }

    public function saveLicense(Request $request)
    {
        $licenseKey = sanitize_text_field($request->get('license_key'));

        $licenseManager = FluentLicensing::getInstance();

        $response = $licenseManager->activate($licenseKey);

        if (is_wp_error($response)) {
            return $this->sendError([
                'message' => $response->get_error_message(),
            ], 422);
        }

        return [
            'license_data' => $this->formatLicenseData($licenseManager->getStatus(), $licenseManager),
            'message'      => __('Your license key has been successfully updated', 'ninja-tables-pro'),
        ];
    }

    public function deactivateLicense()
    {
        $licenseManager = FluentLicensing::getInstance();

        $response = $licenseManager->deactivate();

        $message = __('Your license key has been successfully deactivated', 'ninja-tables-pro');

        if (is_wp_error($response)) {
            $message = sprintf(
            /* translators: %s: the error the store returned. */
                __('Deactivated on this site, but the store could not be reached (%s). The activation may still count against your license — remove it from your account if it does.', 'ninja-tables-pro'),
                $response->get_error_message()
            );
        }

        return [
            'license_data' => $this->formatLicenseData($licenseManager->getStatus(), $licenseManager),
            'message'      => $message,
        ];
    }

    /**
     * Build an allowlisted browser payload. Anything not named here — the raw
     * key, the activation hash, whatever the store adds to the response next —
     * cannot reach the screen. Fields are only ever added, never renamed: an
     * old free screen reads `status` and `expires`, and both must keep coming
     * back. §12.3 of the SDK README.
     *
     * @param array $data
     * @param FluentLicensing $licenseManager
     * @return array
     */
    protected function formatLicenseData($data, FluentLicensing $licenseManager)
    {
        $licenseKey = (string)Arr::get($data, 'license_key', '');
        $activationHash = (string)Arr::get($data, 'activation_hash', '');

        // A store-supplied URL that echoes a credential back is dropped, not shown.
        $safeUrl = function ($value) use ($licenseKey, $activationHash) {
            $value = (string)$value;

            foreach ([$licenseKey, $activationHash] as $credential) {
                if ($credential !== '' && strpos($value, $credential) !== false) {
                    return '';
                }
            }

            return esc_url_raw($value);
        };

        $status = Arr::get($data, 'status', 'unregistered');
        $expires = (string)Arr::get($data, 'expires', '');
        $isLifetime = strtolower($expires) === 'lifetime';

        $expiresHuman = '';
        $daysRemaining = null;

        if (!$isLifetime && $expires && $expiresAt = strtotime($expires)) {
            $expiresHuman = wp_date(get_option('date_format'), $expiresAt);
            $daysRemaining = (int)floor(($expiresAt - time()) / DAY_IN_SECONDS);
        }

        $inGracePeriod = $licenseManager->isWithinGracePeriod($data);

        $lastCheckedHuman = '';

        if ($lastChecked = Arr::get($data, 'last_checked')) {
            if ($lastCheckedAt = strtotime($lastChecked)) {
                $lastCheckedHuman = sprintf(
                /* translators: %s: human readable time difference, e.g. "2 mins" */
                    __('%s ago', 'ninja-tables-pro'),
                    human_time_diff($lastCheckedAt)
                );
            }
        }

        $safe = [
            'status'                => sanitize_text_field($status),
            'expires'               => sanitize_text_field($expires),
            'expires_human'         => $expiresHuman,
            'is_lifetime'           => $isLifetime,
            'is_expired'            => !$isLifetime && $daysRemaining !== null && $daysRemaining < 0 && !$inGracePeriod,
            'days_remaining'        => $daysRemaining,
            'in_grace_period'       => $inGracePeriod,
            'grace_period_days'     => $inGracePeriod ? (int)Arr::get($data, 'grace_period_days', 0) : null,
            'last_checked_human'    => $lastCheckedHuman,
            'variation_id'          => sanitize_text_field(Arr::get($data, 'variation_id', '')),
            'variation_title'       => sanitize_text_field(Arr::get($data, 'variation_title', '')),
            'product_title'         => sanitize_text_field(
                Arr::get($data, 'product_title') ?: $licenseManager->getConfig('plugin_title')
            ),
            'subscription_status'   => sanitize_text_field(Arr::get($data, 'subscription_status', '')),
            'customer_name'         => sanitize_text_field(Arr::get($data, 'customer_name', '')),
            'customer_email_masked' => sanitize_text_field(Arr::get($data, 'customer_email_masked', '')),
            'error_type'            => sanitize_text_field(Arr::get($data, 'error_type', '')),
            'error_message'         => sanitize_text_field(Arr::get($data, 'error_message', '')),
            'manage_url'            => $safeUrl(Arr::get($data, 'manage_url', '')),
            'purchase_url'          => $safeUrl($licenseManager->getConfig('purchase_url')),
            'account_url'           => $safeUrl($licenseManager->getConfig('account_url')),
            'support_url'           => $safeUrl($licenseManager->getConfig('support_url')),
            'license_key_masked'    => $licenseManager->getMaskedLicenseKey(),
        ];

        // Always the same-site redirector — store-built renew URLs carry the raw key.
        if (in_array($status, ['expired', 'valid'], true)) {
            $safe['renew_url'] = RenewRedirect::url();
        }

        return array_filter($safe, function ($value) {
            return $value !== '' && $value !== null;
        });
    }
}
