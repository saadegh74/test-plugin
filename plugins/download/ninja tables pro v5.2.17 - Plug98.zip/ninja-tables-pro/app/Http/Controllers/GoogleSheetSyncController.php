<?php

namespace NinjaTablesPro\App\Http\Controllers;

defined('ABSPATH') || exit;

use NinjaTables\App\Modules\DataTables\Database\DynamicTableManager;
use NinjaTables\Framework\Http\Request\Request;
use NinjaTables\Framework\Support\Arr;
use NinjaTablesPro\App\Modules\GoogleSheetSync\SyncService;

class GoogleSheetSyncController extends Controller
{
    public function fetchHeaders(Request $request)
    {
        $url = sanitize_text_field(Arr::get($request->all(), 'url', ''));
        $url = $this->normalizeGoogleSheetCsvUrl($url);

        if (!$url || !filter_var($url, FILTER_VALIDATE_URL) || strpos($url, 'https://') !== 0) {
            return $this->sendError([
                'data' => ['message' => __('Please provide a valid HTTPS URL.', 'ninja-tables-pro')]
            ], 422);
        }

        $response = wp_safe_remote_get($url, [
            'timeout'             => 30,
            'limit_response_size' => 65536, // 64 KB — only need the header row
        ]);

        if (is_wp_error($response)) {
            return $this->sendError([
                'data' => ['message' => $response->get_error_message()]
            ], 422);
        }

        $code = wp_remote_retrieve_response_code($response);

        if ($code !== 200) {
            return $this->sendError([
                'data' => ['message' => sprintf(
                    __('URL returned HTTP %d. Please check the URL.', 'ninja-tables-pro'),
                    $code
                )]
            ], 422);
        }

        $body = wp_remote_retrieve_body($response);

        if (empty($body)) {
            return $this->sendError([
                'data' => ['message' => __('The URL returned empty content.', 'ninja-tables-pro')]
            ], 422);
        }

        // Strip UTF-8 BOM if present (common in Google Sheets CSV exports)
        if (substr($body, 0, 3) === "\xEF\xBB\xBF") {
            $body = substr($body, 3);
        }

        $stream = fopen('php://temp', 'r+');
        fwrite($stream, $body);
        rewind($stream);
        $header = fgetcsv($stream);
        fclose($stream);

        if (!is_array($header) || empty($header)) {
            return $this->sendError([
                'data' => ['message' => __('Unable to read CSV headers from the URL.', 'ninja-tables-pro')]
            ], 422);
        }

        $headers = [];
        foreach ($header as $h) {
            $h = sanitize_text_field(trim($h));
            if ($h !== '') {
                $headers[] = $h;
            }
        }

        return $this->json(['headers' => $headers], 200);
    }

    public function createTable(Request $request)
    {
        $title        = sanitize_text_field(Arr::get($request->all(), 'title', ''));
        $url          = sanitize_text_field(Arr::get($request->all(), 'url', ''));
        $url          = $this->normalizeGoogleSheetCsvUrl($url);
        $selectedCols = (array) Arr::get($request->all(), 'columns', []);
        $syncInterval = max(60, intval(Arr::get($request->all(), 'sync_interval', 3600)));

        if (!$title) {
            $title = __('Google Sheet Table', 'ninja-tables-pro');
        }

        if (!$url || !filter_var($url, FILTER_VALIDATE_URL) || strpos($url, 'https://') !== 0) {
            return $this->sendError([
                'data' => ['message' => __('Please provide a valid HTTPS URL.', 'ninja-tables-pro')]
            ], 422);
        }

        if (empty($selectedCols)) {
            return $this->sendError([
                'data' => ['message' => __('Please select at least one column.', 'ninja-tables-pro')]
            ], 422);
        }

        $columns = $this->buildColumnDefinitions($selectedCols);

        $reservedKeys = DynamicTableManager::getReservedKeys($columns);
        if ($reservedKeys) {
            return $this->sendError([
                'data' => ['message' => sprintf(
                    __('Column "%s" conflicts with a reserved system column.', 'ninja-tables-pro'),
                    implode('", "', $reservedKeys)
                )]
            ], 400);
        }

        $tableId = wp_insert_post([
            'post_title'   => $title,
            'post_content' => '',
            'post_type'    => 'ninja-table',
            'post_status'  => 'publish',
        ]);

        if (is_wp_error($tableId)) {
            return $this->sendError([
                'data' => ['message' => __('Failed to create table.', 'ninja-tables-pro')]
            ], 500);
        }

        $tableSettings                = ninja_table_get_table_settings($tableId, 'admin');
        $tableSettings['library']     = 'datatables';
        $tableSettings['render_type'] = 'ajax_table';
        update_post_meta($tableId, '_ninja_table_settings', $tableSettings);

        update_post_meta($tableId, '_ninja_table_columns', $columns);
        update_post_meta($tableId, '_ninja_tables_data_provider', 'google-csv');
        update_post_meta($tableId, '_ninja_tables_data_provider_url', esc_url_raw($url));
        update_post_meta($tableId, '_ninja_gsheet_sync_config', [
            'sync_interval' => $syncInterval,
            'enabled'       => true,
        ]);

        // Arm the recurring interval up front so auto-sync runs on schedule even
        // if this table is never rendered (done before the initial sync starts,
        // while no job is active).
        SyncService::scheduleNextSync($tableId, true);

        $tableManager = new DynamicTableManager($tableId);
        $tableManager->createTable();
        $tableManager->syncColumns($columns);

        // Init chunked sync — returns token for frontend to drive chunk processing
        $initResult = SyncService::initChunkedSync($tableId);

        return $this->json([
            'message'     => __('Table created.', 'ninja-tables-pro'),
            'tableId'     => $tableId,
            'sync'        => $initResult,
        ], 200);
    }

    public function updateSettings(Request $request, $id)
    {
        $tableId      = intval($id);
        $post         = get_post($tableId);

        if (!$post || $post->post_type !== 'ninja-table') {
            return $this->sendError([
                'data' => ['message' => __('Table not found.', 'ninja-tables-pro')]
            ], 404);
        }

        if (ninja_table_get_data_provider($tableId) !== 'google-csv') {
            return $this->sendError([
                'data' => ['message' => __('This table is not a Google Sheet sync table.', 'ninja-tables-pro')]
            ], 400);
        }

        $url          = sanitize_text_field(Arr::get($request->all(), 'url', ''));
        $url          = $this->normalizeGoogleSheetCsvUrl($url);
        $syncInterval = intval(Arr::get($request->all(), 'sync_interval', 0));
        $selectedCols = (array) Arr::get($request->all(), 'columns', []);

        if ($url) {
            if (!filter_var($url, FILTER_VALIDATE_URL) || strpos($url, 'https://') !== 0) {
                return $this->sendError([
                    'data' => ['message' => __('Please provide a valid HTTPS URL.', 'ninja-tables-pro')]
                ], 422);
            }
            update_post_meta($tableId, '_ninja_tables_data_provider_url', esc_url_raw($url));
        }

        if (!empty($selectedCols)) {
            $columns    = $this->buildColumnDefinitions($selectedCols);
            $oldColumns = get_post_meta($tableId, '_ninja_table_columns', true);

            // Preserve existing column settings
            if (is_array($oldColumns)) {
                foreach ($columns as $key => $newColumn) {
                    foreach ($oldColumns as $oldColumn) {
                        if (Arr::get($oldColumn, 'original_name') === $newColumn['original_name']) {
                            $columns[$key] = $oldColumn;
                            break;
                        }
                    }
                }
                $columns = array_values($columns);
            }

            $reservedKeys = DynamicTableManager::getReservedKeys($columns);
            if ($reservedKeys) {
                return $this->sendError([
                    'data' => ['message' => sprintf(
                        __('Column "%s" conflicts with a reserved system column.', 'ninja-tables-pro'),
                        implode('", "', $reservedKeys)
                    )]
                ], 400);
            }

            update_post_meta($tableId, '_ninja_table_columns', $columns);

            $tableManager = new DynamicTableManager($tableId);
            if ($tableManager->tableExists()) {
                $tableManager->syncColumns($columns);
            }

            SyncService::updateSyncState($tableId, ['last_hash' => '']);
        }

        $config = get_post_meta($tableId, '_ninja_gsheet_sync_config', true);
        if (!is_array($config)) {
            $config = ['sync_interval' => 3600, 'enabled' => true];
        }

        if ($syncInterval > 0) {
            $config['sync_interval'] = max(60, $syncInterval);
        }

        update_post_meta($tableId, '_ninja_gsheet_sync_config', $config);

        // Reconcile the schedule to the (possibly new) interval, or clear it if
        // sync was disabled.
        SyncService::scheduleNextSync($tableId, true);

        return $this->json([
            'message' => __('Settings updated.', 'ninja-tables-pro'),
        ], 200);
    }

    public function triggerSync(Request $request, $id)
    {
        $tableId = intval($id);
        $post    = get_post($tableId);

        if (!$post || $post->post_type !== 'ninja-table') {
            return $this->sendError([
                'data' => ['message' => __('Table not found.', 'ninja-tables-pro')]
            ], 404);
        }

        if (ninja_table_get_data_provider($tableId) !== 'google-csv') {
            return $this->sendError([
                'data' => ['message' => __('This table is not a Google Sheet sync table.', 'ninja-tables-pro')]
            ], 400);
        }

        $result = SyncService::initChunkedSync($tableId);

        return $this->json([
            'message' => __('Sync initialized.', 'ninja-tables-pro'),
            'data'    => $result,
        ], Arr::get($result, 'status') === 'error' ? 500 : 200);
    }

    public function processChunk(Request $request, $id)
    {
        $tableId = intval($id);
        $token   = sanitize_text_field(Arr::get($request->all(), 'token', ''));

        if (!$token) {
            return $this->sendError([
                'data' => ['message' => __('Sync token is missing.', 'ninja-tables-pro')]
            ], 422);
        }

        $chunkSize = max(1000, min(20000, intval(Arr::get($request->all(), 'chunk_size', 20000))));
        $result    = SyncService::processChunk($token, $chunkSize, $tableId);

        return $this->json($result, Arr::get($result, 'status') === 'error' ? 500 : 200);
    }

    public function getSyncStatus(Request $request, $id)
    {
        $tableId = intval($id);
        $post    = get_post($tableId);

        if (!$post || $post->post_type !== 'ninja-table') {
            return $this->sendError([
                'data' => ['message' => __('Table not found.', 'ninja-tables-pro')]
            ], 404);
        }

        if (ninja_table_get_data_provider($tableId) !== 'google-csv') {
            return $this->sendError([
                'data' => ['message' => __('This table is not a Google Sheet sync table.', 'ninja-tables-pro')]
            ], 400);
        }

        $state  = SyncService::getSyncState($tableId);
        $config = get_post_meta($tableId, '_ninja_gsheet_sync_config', true);
        $url    = get_post_meta($tableId, '_ninja_tables_data_provider_url', true);

        // Surface any resumable job so the editor can pick up an in-progress sync
        // on its own — e.g. right after the table is created, the first sync runs
        // and loads data without the user clicking "Sync".
        $activeJob = SyncService::getActiveJob($tableId);

        return $this->json([
            'url'        => $url,
            'config'     => is_array($config) ? $config : [],
            'state'      => $state,
            'active_job' => is_array($activeJob) ? [
                'token'          => Arr::get($activeJob, 'token', ''),
                'processed_rows' => (int) Arr::get($activeJob, 'processed_rows', 0),
                'total_rows'     => (int) Arr::get($activeJob, 'total_rows', 0),
            ] : null,
        ], 200);
    }

    private function buildColumnDefinitions(array $selectedCols): array
    {
        $fields  = array_map('sanitize_text_field', $selectedCols);
        $headers = ninja_table_format_header($fields);

        $columns = [];
        foreach ($headers as $key => $column) {
            $columns[] = [
                'name'                => $column,
                'key'                 => $key,
                'breakpoints'         => null,
                'data_type'           => 'text',
                'dateFormat'          => null,
                'header_html_content' => null,
                'enable_html_content' => false,
                'contentAlign'        => null,
                'textAlign'           => null,
                'original_name'       => $column,
            ];
        }

        return $columns;
    }

    /**
     * Normalize a Google Sheets published URL to CSV format.
     *
     * Accepts:
     *   .../pubhtml?gid=123&single=true  →  .../pub?gid=123&single=true&output=csv
     *   .../pubhtml                       →  .../pub?output=csv
     *   .../pub?gid=123&single=true       →  .../pub?gid=123&single=true&output=csv
     *   .../pub?output=csv                →  unchanged
     *
     * Non-Google-Sheets URLs are returned as-is.
     */
    private function normalizeGoogleSheetCsvUrl(string $url): string
    {
        if (strpos($url, 'docs.google.com/spreadsheets/') === false) {
            return $url;
        }

        // Already has output=csv — nothing to do
        if (preg_match('/[?&]output=csv/', $url)) {
            return $url;
        }

        // Replace /pubhtml with /pub
        $url = preg_replace('#/pubhtml(\?|$)#', '/pub$1', $url);

        // Append output=csv
        $url .= (strpos($url, '?') !== false) ? '&output=csv' : '?output=csv';

        return $url;
    }
}
