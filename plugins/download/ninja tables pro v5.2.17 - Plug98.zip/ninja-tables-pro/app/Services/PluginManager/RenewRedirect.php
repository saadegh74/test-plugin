<?php

namespace NinjaTablesPro\App\Services\PluginManager;

/**
 * Browser-safe renewal link: redirects to the credential-free account page,
 * never getRenewUrl() — its query string carries the raw key, and a redirect's
 * Location target is browser-visible. Swap the target here once the store
 * supports an opaque renewal token.
 */
class RenewRedirect
{
    const ACTION = 'ninja_tables_pro_renew';

    public static function register()
    {
        add_action('admin_post_' . self::ACTION, [__CLASS__, 'redirect']);
    }

    /** The URL responses may safely expose to the browser. */
    public static function url()
    {
        return wp_nonce_url(
            admin_url('admin-post.php?action=' . self::ACTION),
            self::ACTION
        );
    }

    public static function redirect()
    {
        check_admin_referer(self::ACTION);

        // Same gate as LicensePolicy: this resolves a paid credential.
        if (!current_user_can('manage_options') || (is_multisite() && !is_super_admin())) {
            wp_die(esc_html__('Sorry, you are not allowed to do that.', 'ninja-tables-pro'), 403);
        }

        $licenseManager = FluentLicensing::getInstance();

        $target = $licenseManager->getConfig('account_url')
            ?: $licenseManager->getConfig('purchase_url')
            ?: $licenseManager->getConfig('store_url');

        // wp_redirect, not wp_safe_redirect: the target is the external store.
        wp_redirect($target); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect
        exit;
    }
}
