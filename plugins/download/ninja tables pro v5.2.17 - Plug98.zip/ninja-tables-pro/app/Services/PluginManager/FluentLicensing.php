<?php

namespace NinjaTablesPro\App\Services\PluginManager;

defined('ABSPATH') or die;

class FluentLicensing
{
    private static $instance;

    private $config = [];

    public $settingsKey = '';

    /**
     * Informational fields the licensing API may return, mapped to the keys we
     * persist them under. They are stored with the license so the UI (and the
     * in-app notices) can show plan, seat and customer details without waiting
     * for a remote round trip.
     */
    private $metaFields = [
        'product_title'         => 'product_title',
        'subscription_status'   => 'subscription_status',
        'customer_name'         => 'customer_name',
        'customer_email_masked' => 'customer_email_masked',
        'manage_url'            => 'manage_url',
        'grace_period_days'     => 'grace_period_days',
    ];

    public function register($config = [])
    {
        if (self::$instance) {
            return self::$instance;
        }

        if (empty($config['basename']) || empty($config['version']) || empty($config['api_url'])) {
            throw new \Exception('Invalid configuration provided for FluentLicensing. Please provide basename, version, and api_url.');
        }

        $this->config = $config;
        $baseName = $this->arrGet($config, 'basename', plugin_basename(__FILE__));

        $slug = $this->arrGet($config, 'slug', $this->arrGet(explode('/', $baseName), 0));
        $this->config['slug'] = (string)$slug;

        $this->settingsKey = $this->arrGet($config, 'settings_key', '__' . $this->config['slug'] . '_sl_info');

        if (empty($config['store_url'])) {
            $this->config['store_url'] = $this->config['api_url'];
        }

        if (empty($config['purchase_url'])) {
            $this->config['purchase_url'] = $this->config['store_url'];
        }

        $config = $this->config;

        if (empty($config['license_key']) && empty($config['license_key_callback'])) {
            $config['license_key_callback'] = function () {
                return $this->getCurrentLicenseKey();
            };
        }

        // Resolve the site identity once so checks and updates cannot disagree.
        if (empty($config['site_url'])) {
            $config['site_url'] = $this->siteUrl();
        }

        if (!class_exists('\\' . __NAMESPACE__ . '\PluginUpdater')) {
            require_once __DIR__ . '/PluginUpdater.php';
        }

        new PluginUpdater($config);

        self::$instance = $this;

        return self::$instance;
    }

    /**
     * Local array read. Deliberately not the framework's Arr helper: this file
     * boots from ninja-tables-pro.php even when the free plugin is inactive, and
     * the framework would not be loaded to resolve it.
     *
     * @param mixed $array
     * @param string|int $key
     * @param mixed $default
     * @return mixed
     */
    private function arrGet($array, $key, $default = null)
    {
        if (!is_array($array) || !array_key_exists($key, $array) || $array[$key] === null) {
            return $default;
        }

        return $array[$key];
    }

    public function getConfig($key)
    {
        return $this->arrGet($this->config, $key, '');
    }

    /**
     * @return self
     * @throws \Exception
     */
    public static function getInstance()
    {
        if (!self::$instance) {
            throw new \Exception('Licensing is not registered. Please call register() method first.');
        }

        return self::$instance;
    }

    public function activate($licenseKey = '')
    {
        if (!$licenseKey) {
            return new \WP_Error('license_key_missing', __('License key is required for activation.', 'ninja-tables-pro'));
        }

        $response = $this->apiRequest('activate_license', [
            'license_key'      => $licenseKey,
            'platform_version' => get_bloginfo('version'),
            'server_version'   => PHP_VERSION,
        ]);

        if (is_wp_error($response)) {
            return $response;
        }

        // The store reports failures as HTTP 200 too, so persist nothing unless
        // this is a documented successful activation.
        $status = (string)$this->arrGet($response, 'status', '');

        if (empty($response['success']) || empty($response['activation_hash']) || !in_array($status, ['valid', 'expired'], true)) {
            return new \WP_Error(
                (string)$this->arrGet($response, 'error_type') ?: 'activation_failed',
                (string)$this->arrGet($response, 'message') ?: __('License activation failed. Please verify your license key.', 'ninja-tables-pro'),
                $response
            );
        }

        $saveData = [
            'license_key'     => $licenseKey,
            'status'          => $status,
            'variation_id'    => $this->arrGet($response, 'variation_id', ''),
            'variation_title' => $this->arrGet($response, 'variation_title', ''),
            'expires'         => $this->arrGet($response, 'expiration_date', ''),
            'activation_hash' => $this->arrGet($response, 'activation_hash', ''),
            'last_checked'    => gmdate('Y-m-d H:i:s'),
        ];

        $saveData = $this->mergeRemoteMeta($saveData, $response, true);

        $this->writeOption($this->settingsKey, $saveData);
        $this->syncLegacyOptions($saveData);

        return $saveData;
    }

    public function deactivate()
    {
        $deactivated = $this->apiRequest('deactivate_license', [
            'license_key' => $this->getCurrentLicenseKey(),
        ]);

        // The local record goes either way. A site owner who asked to deactivate
        // must not be left holding the license because the store was unreachable;
        // the caller reports the failed round trip so the seat can be freed from
        // the account page.
        $this->deleteOption($this->settingsKey);
        $this->clearLegacyOptions();

        return $deactivated;
    }

    public function getStatus($remoteFetch = false)
    {
        $currentLicense = $this->readOption($this->settingsKey, []);

        if (!$currentLicense || !is_array($currentLicense) || empty($currentLicense['license_key'])) {
            $currentLicense = $this->migrateLegacyLicense();

            if (!$currentLicense) {
                return [
                    'license_key'     => '',
                    'status'          => 'unregistered',
                    'variation_id'    => '',
                    'variation_title' => '',
                    'expires'         => '',
                    'activation_hash' => '',
                ];
            }
        }

        if (!$remoteFetch) {
            return $currentLicense;
        }

        $remoteStatus = $this->apiRequest('check_license', [
            'license_key'      => $this->arrGet($currentLicense, 'license_key', ''),
            'activation_hash'  => $this->arrGet($currentLicense, 'activation_hash', ''),
            'item_id'          => $this->getConfig('item_id'),
            'site_url'         => $this->siteUrl(),
            'platform_version' => get_bloginfo('version'),
            'server_version'   => PHP_VERSION,
        ]);

        if (is_wp_error($remoteStatus)) {
            return $remoteStatus;
        }

        $status = $this->arrGet($remoteStatus, 'status', 'unregistered');
        $errorType = $this->arrGet($remoteStatus, 'error_type', '');

        if (!empty($currentLicense['status'])) {
            $currentLicense['status'] = $status;

            if (!empty($remoteStatus['expiration_date'])) {
                $currentLicense['expires'] = sanitize_text_field($remoteStatus['expiration_date']);
            }

            if (!empty($remoteStatus['variation_id'])) {
                $currentLicense['variation_id'] = sanitize_text_field($remoteStatus['variation_id']);
            }

            if (!empty($remoteStatus['variation_title'])) {
                $currentLicense['variation_title'] = sanitize_text_field($remoteStatus['variation_title']);
            }

            // Drop meta the store no longer reports (a lifetime upgrade has no
            // subscription, a downgraded plan has a smaller seat count) so the
            // UI never shows a value the license does not carry anymore.
            $currentLicense = $this->mergeRemoteMeta($currentLicense, $remoteStatus, true);

            $currentLicense['last_checked'] = gmdate('Y-m-d H:i:s');

            $this->writeOption($this->settingsKey, $currentLicense);
            $this->syncLegacyOptions($currentLicense);
        } else {
            $currentLicense['status'] = 'error';
        }

        $currentLicense['renew_url'] = $this->arrGet($remoteStatus, 'renew_url', '');
        $currentLicense['is_expired'] = $this->arrGet($remoteStatus, 'is_expired', false);

        if ($errorType) {
            $currentLicense['error_type'] = $errorType;
            $currentLicense['error_message'] = $this->arrGet($remoteStatus, 'message', '');
        }

        return $currentLicense;
    }

    public function getCurrentLicenseKey()
    {
        return $this->arrGet($this->getStatus(), 'license_key', '');
    }

    /**
     * One-time copy of the old EDD license into the structured option this
     * system reads, done on the first status read. The next remote check
     * backfills the expiry, the plan meta and the activation hash.
     *
     * Unlike the upstream SDK the legacy options are kept, not deleted: free's
     * AdminMenuHandler reads _ninjatables_pro_license_status directly, and a
     * rollback to the EDD updater needs the key. Deactivation clears both
     * (LegacyAjaxHandler::clearLegacyCredentials), so nothing can resurrect a
     * key the site owner removed.
     *
     * @return array|null the seeded license, or null when there is nothing to migrate
     */
    private function migrateLegacyLicense()
    {
        // 5.2.15 stored per-site even on multisite; adopt that record first.
        if ($this->usesNetworkStorage()) {
            $perSite = get_option($this->settingsKey);

            if (is_array($perSite) && !empty($perSite['license_key'])) {
                $this->writeOption($this->settingsKey, $perSite);
                $this->syncLegacyOptions($perSite);
                delete_option($this->settingsKey);

                return $perSite;
            }
        }

        $legacyKey = $this->readOption('_ninjatables_pro_license_key');

        if (!$legacyKey || !is_string($legacyKey)) {
            return null;
        }

        $license = [
            'license_key'     => trim($legacyKey),
            'status'          => $this->readOption('_ninjatables_pro_license_status') ?: 'valid',
            'variation_id'    => '',
            'variation_title' => '',
            'expires'         => '',
            'activation_hash' => '',
        ];

        $this->writeOption($this->settingsKey, $license);
        $this->syncLegacyOptions($license);

        return $license;
    }

    /**
     * Copy the informational fields from an API response onto the license data.
     *
     * @param array $licenseData
     * @param array $response
     * @param bool $pruneMissing when true, locally stored meta that the response
     *                           does not carry is removed instead of kept stale.
     * @return array
     */
    private function mergeRemoteMeta($licenseData, $response, $pruneMissing = false)
    {
        foreach ($this->metaFields as $remoteKey => $localKey) {
            $value = $this->arrGet($response, $remoteKey);

            if ($value === null || $value === '') {
                if ($pruneMissing) {
                    unset($licenseData[$localKey]);
                }
                continue;
            }

            if ($localKey === 'manage_url') {
                $licenseData[$localKey] = esc_url_raw($value);
                continue;
            }

            $licenseData[$localKey] = sanitize_text_field($value);
        }

        return $licenseData;
    }

    /**
     * The license key never leaves the server in full, but showing the head and
     * tail lets a site owner tell which of their keys is on this site.
     *
     * @return string
     */
    public function getMaskedLicenseKey()
    {
        $licenseKey = $this->getCurrentLicenseKey();

        if (!$licenseKey) {
            return '';
        }

        $length = strlen($licenseKey);

        if ($length <= 8) {
            return str_repeat('•', $length);
        }

        return substr($licenseKey, 0, 4) . str_repeat('•', min($length - 8, 20)) . substr($licenseKey, -4);
    }

    public function getLicenseMessages()
    {
        $licenseDetails = $this->getStatus();

        if (is_wp_error($licenseDetails) || !is_array($licenseDetails)) {
            return false;
        }

        $status = $this->arrGet($licenseDetails, 'status', 'unregistered');

        // A record only becomes 'expired' after a successful remote check, and nothing
        // schedules one. A lapsed license on a site that cannot reach the API would
        // otherwise stay 'valid' — and silent — forever. An empty expiry means
        // lifetime (or a migrated legacy key), so it is left alone.
        if ($status === 'expired' || ($status === 'valid' && $this->hasLapsed($licenseDetails))) {
            return [
                'message'         => $this->getExpireMessage($licenseDetails),
                'type'            => 'in_app',
                'license_details' => $licenseDetails,
            ];
        }

        if ($status === 'disabled') {
            return [
                'message'         => sprintf(
                /* translators: 1: plugin name, 2: link to the license screen. */
                    __('The license for %1$s has been disabled. Please contact support for assistance. %2$s', 'ninja-tables-pro'),
                    $this->getConfig('plugin_title'),
                    $this->licenseScreenLink(__('Manage License', 'ninja-tables-pro'))
                ),
                'type'            => 'global',
                'license_details' => $licenseDetails,
            ];
        }

        if ($status !== 'valid') {
            // A stored key that has not been confirmed needs verifying, not activating.
            // Migrated EDD licenses land here with a key already saved.
            if ($this->arrGet($licenseDetails, 'license_key')) {
                $message = sprintf(
                /* translators: 1: plugin name, 2: link to the license screen. */
                    __('The %1$s license needs to be verified. %2$s', 'ninja-tables-pro'),
                    $this->getConfig('plugin_title'),
                    $this->licenseScreenLink(__('Click here to verify', 'ninja-tables-pro'))
                );
            } else {
                $message = sprintf(
                /* translators: 1: plugin name, 2: link to the license screen. */
                    __('The %1$s license needs to be activated. %2$s', 'ninja-tables-pro'),
                    $this->getConfig('plugin_title'),
                    $this->licenseScreenLink(__('Click here to activate', 'ninja-tables-pro'))
                );
            }

            return [
                'message'         => $message,
                'type'            => 'global',
                'license_details' => $licenseDetails,
            ];
        }

        return false;
    }

    /**
     * Whether a license carries an expiry date that has already passed and is
     * not covered by its grace period.
     *
     * @param array $licenseData
     * @return bool
     */
    private function hasLapsed($licenseData)
    {
        $expiresAt = $this->expiryTimestamp($licenseData);

        return $expiresAt && $expiresAt < time() && !$this->isWithinGracePeriod($licenseData);
    }

    /**
     * Whether a lapsed license is still covered by its store-granted grace period.
     *
     * Single source of truth for the license screen and the notices, so the two
     * can never disagree about whether a license has actually expired.
     *
     * @param array $licenseData
     * @return bool
     */
    public function isWithinGracePeriod($licenseData)
    {
        if ($this->arrGet($licenseData, 'status') !== 'valid') {
            return false;
        }

        $expiresAt = $this->expiryTimestamp($licenseData);

        if (!$expiresAt || $expiresAt >= time()) {
            return false;
        }

        // Grace is a store entitlement; never invent it locally.
        $graceDays = (int)$this->arrGet($licenseData, 'grace_period_days', 0);

        return $graceDays > 0 && ($expiresAt + ($graceDays * DAY_IN_SECONDS)) > time();
    }

    /**
     * @param array $licenseData
     * @return int|false
     */
    private function expiryTimestamp($licenseData)
    {
        $expires = trim((string)$this->arrGet($licenseData, 'expires', ''));

        if (!$expires || strtolower($expires) === 'lifetime') {
            return false;
        }

        return strtotime($expires);
    }

    /**
     * @param string $text Already translated.
     * @return string
     */
    private function licenseScreenLink($text)
    {
        return '<a href="' . esc_url($this->getConfig('activate_url')) . '">' . esc_html($text) . '</a>';
    }

    /**
     * Returns unwrapped text. The caller owns the markup its channel needs.
     *
     * @param array $licenseData
     * @return string
     */
    private function getExpireMessage($licenseData)
    {
        // The license screen, never getRenewUrl() — that query string carries the raw key.
        $link = '<a href="' . esc_url($this->getConfig('activate_url')) . '"><b>'
            . esc_html__('Click Here to Renew Your License', 'ninja-tables-pro') . '</b></a>';

        $expiresAt = $this->expiryTimestamp($licenseData);

        // A migrated legacy license stores no expiry date. Saying nothing beats
        // asserting it expired in 1970.
        if (!$expiresAt) {
            return sprintf(
            /* translators: 1: plugin name, 2: renewal link. */
                __('Your %1$s license has expired. %2$s', 'ninja-tables-pro'),
                $this->getConfig('plugin_title'),
                $link
            );
        }

        return sprintf(
        /* translators: 1: plugin name, 2: expiry date, 3: renewal link. */
            __('Your %1$s license expired on %2$s. %3$s', 'ninja-tables-pro'),
            $this->getConfig('plugin_title'),
            '<b>' . wp_date('d M Y', $expiresAt) . '</b>',
            $link
        );
    }

    private function apiRequest($action, $data = [])
    {
        $fullUrl = add_query_arg(['fluent-cart' => $action], $this->config['api_url']);

        $defaults = [
            'item_id'         => $this->config['item_id'],
            'current_version' => $this->config['version'],
            'site_url'        => $this->siteUrl(),
        ];

        $payload = wp_parse_args($data, $defaults);

        $response = wp_remote_post($fullUrl, [
            'timeout' => 15,
            'body'    => $payload,
        ]);

        if (is_wp_error($response)) {
            return $response;
        }

        $responseCode = wp_remote_retrieve_response_code($response);

        if (200 !== $responseCode) {
            $errorData = wp_remote_retrieve_body($response);
            $message = 'API request failed with status code: ' . $responseCode;
            if (!empty($errorData)) {
                $decodedData = json_decode($errorData, true);
                if ($decodedData) {
                    $errorData = $decodedData;
                }

                if (!empty($errorData['message'])) {
                    $message = (string)$errorData['message'];
                }
            }
            return new \WP_Error('api_error', $message, $errorData);
        }

        $responseData = json_decode(wp_remote_retrieve_body($response), true);

        if ($responseData) {
            return $responseData;
        }

        return new \WP_Error('api_error', 'API request returned an empty or not JSON response.', []);
    }

    public function getRenewUrl()
    {
        $licenseKey = $this->getCurrentLicenseKey();

        if (empty($licenseKey)) {
            return $this->getConfig('purchase_url');
        }

        return add_query_arg([
            'license_key' => $licenseKey,
            'fluent-cart' => 'renew_license',
        ], $this->getConfig('store_url'));
    }

    /**
     * Backfill the pre-SDK options from a license record.
     *
     * free's AdminMenuHandler reads _ninjatables_pro_license_status for its
     * submenu and _ninjatables_pro_license_key for its integrity check, and both
     * shipped free versions still do. Every path that writes the license record
     * calls this, so the two can never drift apart — leaving it to the caller
     * means the next caller forgets.
     *
     * Takes the record rather than re-reading it: getStatus() is one of the
     * callers, and re-entering it here would recurse through the migration.
     *
     * @param array $license
     */
    public function syncLegacyOptions($license)
    {
        $status = isset($license['status']) ? $license['status'] : '';

        if ($status) {
            $this->writeOption('_ninjatables_pro_license_status', $status);

            // free reads the per-site option before the network one.
            if (is_multisite() && get_option('_ninjatables_pro_license_status') !== $status) {
                update_option('_ninjatables_pro_license_status', $status);
            }
        }

        if (!empty($license['license_key'])) {
            $this->writeOption('_ninjatables_pro_license_key', $license['license_key']);
        }
    }

    /**
     * Drop every credential-bearing legacy copy, but keep the status option
     * itself alive — free treats a missing one as "activate your license", and
     * an owner who just deactivated should see the deactivated state instead.
     */
    public function clearLegacyOptions()
    {
        $this->deleteOption('_ninjatables_pro_license_key');
        $this->writeOption('_ninjatables_pro_license_status', 'deactivated');

        if (is_multisite()) {
            // Per-site copies left by 5.2.15, which free would read first.
            delete_option('_ninjatables_pro_license_key');
            update_option('_ninjatables_pro_license_status', 'deactivated');
        }
    }

    /**
     * Read and write the license from the same tenancy scope on every request:
     * network options on multisite, per-site otherwise. Mirrors where the old
     * EDD updater kept it, and where free's AdminMenuHandler looks for it.
     *
     * @param string $key
     * @param mixed $default
     * @return mixed
     */
    public function readOption($key, $default = false)
    {
        if ($this->usesNetworkStorage()) {
            return get_network_option(get_main_network_id(), $key, $default);
        }

        return get_option($key, $default);
    }

    public function writeOption($key, $value)
    {
        if ($this->usesNetworkStorage()) {
            return update_network_option(get_main_network_id(), $key, $value);
        }

        return update_option($key, $value, false);
    }

    public function deleteOption($key)
    {
        if ($this->usesNetworkStorage()) {
            return delete_network_option(get_main_network_id(), $key);
        }

        return delete_option($key);
    }

    public function usesNetworkStorage()
    {
        return !empty($this->config['network_wide']) && is_multisite();
    }

    public function siteUrl()
    {
        return $this->usesNetworkStorage() ? network_site_url() : home_url();
    }
}
