<?php

/**
 * Licensing + updates boot (FluentCart SDK, replaces app/Library/updater).
 *
 * Runs on every request — cron and WP-CLI update plugins too. Included from
 * ninja-tables-pro.php at file scope, same as the old updater include.
 */

if (!defined('ABSPATH')) {
    exit;
}

use NinjaTablesPro\App\Services\PluginManager\FluentLicensing;
use NinjaTablesPro\App\Services\PluginManager\LegacyAjaxHandler;
use NinjaTablesPro\App\Services\PluginManager\PluginInstaller;
use NinjaTablesPro\App\Services\PluginManager\RenewRedirect;

$licenseManager = (new FluentLicensing())->register([
    'version'           => NINJAPROPLUGIN_VERSION,
    'basename'          => plugin_basename(NINJAPRO_PLUGIN_FILE),
    'api_url'           => 'https://fluentapi.wpmanageninja.com/',
    'item_id'           => 7560865, // FluentCart product ID (old EDD download ID was 273)
    'plugin_title'      => 'Ninja Tables Pro',
    'settings_key'      => '__ninjatables_pro_license',
    'network_wide'      => true, // The EDD updater kept it network-wide; free still reads it there.
    'store_url'         => 'https://wpmanageninja.com/',
    'purchase_url'      => 'https://wpmanageninja.com/downloads/ninja-tables-pro-add-on/',
    'account_url'       => 'https://wpmanageninja.com/account/',
    'support_url'       => 'https://wpmanageninja.com/account/support-tickets/',
    'activate_url'      => admin_url('admin.php?page=ninja_tables#/tools/licensing'),
    'show_check_update' => true,
    // Secure by default (matches fluent-community-pro). Release ordering, SDK
    // README §7: sign each 7560865 release on the store BEFORE shipping it.
    'verify_updates'    => !(defined('NINJA_TABLES_PRO_SKIP_UPDATE_VERIFY') && NINJA_TABLES_PRO_SKIP_UPDATE_VERIFY),
]);

// Mirror into the old options on every admin request — free reads
// _ninjatables_pro_license_status directly (AdminMenuHandler's submenu and its
// integrity check), and it must never fall out of sync or the site is told to
// activate a license it already has. Not on admin_init: wp-admin/admin.php
// builds the menu at line 163 and only fires admin_init at line 180, so the
// first request after a migration would render a stale status.
if (is_admin()) {
    LegacyAjaxHandler::mirrorLegacyOptions();
}

// Old free versions talk to the three wp_ajax_ license actions — keep them answering.
(new LegacyAjaxHandler($licenseManager))->register();

RenewRedirect::register();

// Offer the required Ninja Tables core release straight from wordpress.org while
// the WP.org update-check API is still in its post-release cool-down window
// (see PluginInstaller for details).
(new PluginInstaller())->registerCoreUpdater();

// Resolved inside the hooks, not here: getLicenseMessages() translates, and
// __() before init triggers WP 6.7's just-in-time textdomain warning.
if (is_admin()) {
    add_action('admin_notices', function () use ($licenseManager) {
        if (!current_user_can('manage_options')) {
            return;
        }

        $licenseMessage = $licenseManager->getLicenseMessages();

        if (!$licenseMessage) {
            return;
        }

        printf(
            '<div class="%1$s"><p>%2$s</p></div>',
            esc_attr('notice notice-error'),
            wp_kses_post($licenseMessage['message'])
        );
    });

    // In-app bar only when expired ('in_app'), matching the old checker;
    // free's App.vue needs exactly this object shape.
    add_filter('ninja_dashboard_notices', function ($notices) use ($licenseManager) {
        if (!current_user_can('manage_options')) {
            return $notices;
        }

        $licenseMessage = $licenseManager->getLicenseMessages();

        if (!$licenseMessage || $licenseMessage['type'] !== 'in_app') {
            return $notices;
        }

        $notices['license_expire'] = [
            'type'     => 'error',
            'message'  => $licenseMessage['message'],
            'closable' => false,
        ];

        return $notices;
    });
}
