<?php

namespace NinjaTablesPro\App\Services\PluginManager;

/**
 * Back-compat: old free versions' license screen talks to these three wp_ajax_
 * actions with the old EDD response shapes. Delete once pre-SDK free versions
 * are ancient history.
 */
class LegacyAjaxHandler
{
    /** @var FluentLicensing */
    private $licenseManager;

    public function __construct(FluentLicensing $licenseManager)
    {
        $this->licenseManager = $licenseManager;
    }

    public function register()
    {
        add_action('wp_ajax__ninjatables_pro_license_activate_license', [$this, 'activateLicense']);
        add_action('wp_ajax__ninjatables_pro_license_deactivate_license', [$this, 'deactivateLicense']);
        add_action('wp_ajax__ninjatables_pro_license_get_license_info', [$this, 'getLicenseInfo']);
    }

    /** Entry point for callers outside the licensing record's own write paths. */
    public static function mirrorLegacyOptions()
    {
        $licensing = FluentLicensing::getInstance();
        $licensing->syncLegacyOptions($licensing->getStatus());
    }

    /** @deprecated FluentLicensing::deactivate() clears these itself. */
    public static function clearLegacyCredentials()
    {
        FluentLicensing::getInstance()->clearLegacyOptions();
    }

    private function guard()
    {
        check_ajax_referer('ninja_table_admin_nonce', 'ninja_table_admin_nonce');

        if (!function_exists('ninja_table_admin_role') || !current_user_can(ninja_table_admin_role())) {
            wp_send_json_error([
                'message' => 'Sorry, you do not have permission to manage licenses.',
            ], 403);
        }

        if (is_multisite() && !is_super_admin()) {
            wp_send_json_error([
                'message' => 'Only network admin can manage the license in multisite.',
            ], 403);
        }
    }

    public function activateLicense()
    {
        $this->guard();

        $licenseKey = isset($_POST['_ninjatables_pro_license_key'])
            ? sanitize_text_field(wp_unslash($_POST['_ninjatables_pro_license_key']))
            : '';

        if (!$licenseKey) {
            wp_send_json_error([
                'message'       => 'Please Provide a license key',
                'human_message' => 'Please Provide a license key',
                'is_error'      => true,
            ], 423);
        }

        $response = $this->licenseManager->activate($licenseKey);

        if (is_wp_error($response)) {
            wp_send_json_error([
                'message'       => $response->get_error_message(),
                'human_message' => $response->get_error_message(),
                'is_error'      => true,
            ], 423);
        }

        wp_send_json_success([
            'message'  => 'Congratulation! Ninja Tables Pro is successfully activated',
            'response' => $response,
        ], 200);
    }

    public function deactivateLicense()
    {
        $this->guard();

        $response = $this->licenseManager->deactivate();

        $message = 'License deactivated';

        if (is_wp_error($response)) {
            $message = 'License deactivated on this site, but the store could not be reached: '
                . $response->get_error_message();
            $response = [];
        }

        wp_send_json_success([
            'message'      => $message,
            'license_data' => $response,
        ], 200);
    }

    public function getLicenseInfo()
    {
        $this->guard();

        $data = $this->licenseManager->getStatus(true);

        if (is_wp_error($data)) {
            wp_send_json_error([
                'message' => $data->get_error_message(),
            ], 423);
        }

        self::mirrorLegacyOptions();

        $status   = !empty($data['status']) ? $data['status'] : 'unregistered';
        $expires  = !empty($data['expires']) ? $data['expires'] : '';
        $renewUrl = RenewRedirect::url(); // never the key-bearing store URL

        // Same fields the old handler sent; the old screen renders these verbatim.
        $expiredDate = '';
        $expireDate  = '';
        $renewHtml   = '';

        if ($status === 'expired' && $expires && $expires !== 'lifetime') {
            $expiredDate = date('d M Y', strtotime($expires));
            $renewHtml   = '<p>Your license has been expired at <b>' . $expiredDate . '</b></p>'
                . '<p><a target="_blank" href="' . esc_url($renewUrl) . '">click here to renew your license</a></p>';
        } elseif ($status === 'valid' && $expires && $expires !== 'lifetime') {
            $expireDate   = date('d M Y', strtotime($expires));
            $intervalDays = intval((strtotime($expires) - time()) / DAY_IN_SECONDS);
            if ($intervalDays < 30) {
                $renewHtml = '<p>Your license will be expired in ' . $intervalDays . ' days</p>'
                    . '<p>Please <a target="_blank" href="' . esc_url($renewUrl) . '">click here to renew your license</a></p>';
            }
        }

        wp_send_json_success([
            'status'      => $status,
            'expiredDate' => $expiredDate,
            'expireDate'  => $expireDate,
            'renewUrl'    => $renewUrl,
            'renewHtml'   => $renewHtml,
        ], 200);
    }
}
