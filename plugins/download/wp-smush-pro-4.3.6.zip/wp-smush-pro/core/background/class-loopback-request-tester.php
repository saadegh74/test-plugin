<?php

namespace Smush\Core\Background;

class Loopback_Request_Tester extends Async_Request {
	private static $id = 'wp_smush_background_request_tester';

	public function __construct() {
		parent::__construct( self::$id );
	}

	protected function handle( $instance_id ) {
		Background_Pre_Flight_Controller::get_instance()->set_loopback_healthy();
	}

	public function test() {
		$this->dispatch( self::$id );
	}
}
