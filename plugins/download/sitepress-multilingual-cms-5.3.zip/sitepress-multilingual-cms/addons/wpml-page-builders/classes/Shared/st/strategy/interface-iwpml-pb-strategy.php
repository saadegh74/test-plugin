<?php

interface IWPML_PB_Strategy {

	public function register_strings( $post );

	public function register_strings_in_content( $post_id, $content, ?WPML\PB\Shortcode\StringCleanUp $stringCleanUp = null );

	public function set_factory( $factory );

	public function get_package_key( $page_id );
	public function get_package_kind();
	public function get_update_post( $package_data );
	public function get_content_updater();
	public function get_package_strings( $package_data );
	public function remove_string( $string_data );
	public function migrate_location( $post_id, $post_content );
}
