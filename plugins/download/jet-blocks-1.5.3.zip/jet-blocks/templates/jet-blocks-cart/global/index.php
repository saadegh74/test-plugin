<?php
/**
 * Main cart template
 */

$show_quantity_controls = (
	isset( $settings['show_quantity_controls'] )
	&& 'yes' === $settings['show_quantity_controls']
);

$widget_settings = [
	'triggerType'  => $settings['trigger_type'],
	'openMiniCartOnAdd'  => $settings['open_minicart_on_add'],
	'closeOnClickOutside'  => $settings['close_on_click_outside'],
	'showCartList'  => $settings['show_cart_list'],
	'showQuantityControls' => $show_quantity_controls ? 'yes' : 'no',
	'quantityNonce' => wp_create_nonce(
		'jet-blocks-cart-quantity'
	),
];

$classes = [
    'jet-blocks-cart',
    'jet-blocks-cart--' . $settings['layout_type'] . '-layout',
];

if ( 'slide-out' === $settings['layout_type'] ) {

	$slide_out_position = ! empty( $settings['slide_out_position'] )
		? $settings['slide_out_position']
		: 'right';

	$classes[] = 'jet-blocks-cart--slide-out-position-' . $slide_out_position;
}

if ( $show_quantity_controls ) {
	$classes[] = 'jet-blocks-cart--quantity-controls';
}

// Check if the cart should be hidden when empty
if (
	'yes' === $settings['hide_cart_when_empty']
	&& class_exists('WooCommerce')
	&& WC()->cart
	&& WC()->cart->is_empty()
) {
	$classes[] = 'jet-blocks-cart--empty';
}
$class_string = implode( ' ', $classes );

?>
<div
	class="<?php echo esc_attr( $class_string ); ?>"
	data-settings="<?php echo esc_attr( wp_json_encode( $widget_settings ) ); // phpcs:ignore ?>"
>

	<div class="jet-blocks-cart__heading">
		<?php include $this->__get_global_template( 'cart-link' ); ?>
	</div>

	<?php if ( 'yes' === $settings['show_cart_list'] ) {
		include $this->__get_global_template( 'cart-list' );
	} ?>

	<?php if ( 'slide-out' === $settings['layout_type'] && 'yes' === $settings['show_overlay_color'] ) { ?>
		<div class="jet-blocks-cart__overlay"></div>
	<?php } ?>
</div>