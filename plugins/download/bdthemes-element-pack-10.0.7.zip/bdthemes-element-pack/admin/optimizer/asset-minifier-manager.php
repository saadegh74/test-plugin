<?php

namespace ElementPack\Admin\AssetMinifier;

if ( !defined('ABSPATH') ) {
    exit;
} // Exit if accessed directly

if ( !class_exists('MatthiasMullie\Minify\Minify') ) {
    require_once 'autoload.php';
}

use ElementPack\Admin\ModuleService;
use MatthiasMullie\Minify;

class Asset_Minifier {

    public function getWidgetIds() {

        return ModuleService::get_widget_settings(function ($settings) {
            $active_widgets     = $settings['settings_fields']['element_pack_active_modules'];
            $elementor_extend   = $settings['settings_fields']['element_pack_elementor_extend'];
            $third_party_widget = $settings['settings_fields']['element_pack_third_party_widget'];

            /**
             * Core Widget
             */
            $options        = get_option('element_pack_active_modules', []);
            $active_widgets = array_reduce($active_widgets, function ($results, $item) use ($options) {
                if(element_pack_is_widget_enabled($item['name'], $options)){
                    $results[] = $item['name'];
                }
                return $results;
            }, []);


            /**
             * Extension
             */
            $options        = get_option('element_pack_elementor_extend', []);
            $elementor_extend = array_reduce($elementor_extend, function ($results, $item) use ($options) {
                if(element_pack_is_extend_enabled($item['name'], $options)){
                    $results[] = $item['name'];
                };
                return $results;
            }, []);


            /**
             * Third Party Widget
             */
            $options        = get_option('element_pack_third_party_widget', []);
            $third_party_widget = array_reduce($third_party_widget, function ($results, $item) use ($options) {
                if(element_pack_is_third_party_enabled($item['name'], $options)){
                    if ( isset($item['plugin_path']) ) {
                        if(ModuleService::is_plugin_active($item['plugin_path'])){
                            $results[] = $item['name'];
                        }
                    }
                };
                return $results;
            }, []);


            return array_merge_recursive($active_widgets, $elementor_extend, $third_party_widget);

        });
    }

    public function getAssets() {
        $widgets = $this->getWidgetIds();

        $scripts   = [];

        foreach ( $widgets as $widget ) {
            // Companion-plugin modules keep their built assets in their own plugin dir.
            $external = ModuleService::get_external_module($widget);
            $root     = $external ? $external['dir'] : BDTEP_PATH;

            $jsPath  = $root . 'assets/js/modules/ep-' . $widget . '.min.js';
            $cssPath = $root . 'assets/css/ep-' . $widget . '.css';

            $script = [];
            if ( file_exists($jsPath) ) {
                $script['js'] = $jsPath;
            }

            if ( file_exists($cssPath) ) {
                $script['css'] = $cssPath;
            }

            if ( $script ) {
                $scripts[] = $script;
            }

        }

        return $scripts;
    }

    protected function getJsPaths() {
        return array_reduce($this->getAssets(), function ($results, $item) {
            if ( isset($item['js']) ) {
                $results[] = $item['js'];
            }
            return $results;
        }, []);
    }

    public function getCssPaths() {
        return array_reduce($this->getAssets(), function ($results, $item) {
            if ( isset($item['css']) ) {
                $results[] = $item['css'];
            }
            return $results;
        }, []);
    }

    public function minifyJs() {
        $scripts = array_merge([
            // global js path goes there
            BDTEP_ASSETS_PATH . 'js/common/helper.min.js'
        ], $this->getJsPaths());

        $scripts  = apply_filters('elementpack/optimization/assets/scripts', $scripts);
        $minifier = new Minify\JS();

        foreach ( $scripts as $item ) {
            $minifier->add($item);
        }

        $uploads_dir = trailingslashit(wp_upload_dir()['basedir']) . 'element-pack/minified/js';
        $minifiedPath = "$uploads_dir" . "/ep-scripts.js";

        return $this->writeBundle($minifier, $minifiedPath);
    }

    public function minifyCss() {
        $styles = array_merge($this->getCssPaths(), [
            // global js path goes there
            BDTEP_ASSETS_PATH . 'css/ep-font.css'
        ]);

        $styles   = apply_filters('elementpack/optimization/assets/styles', $styles);
        $minifier = new Minify\CSS();

        foreach ( $styles as $item ) {
            $minifier->add($item);
        }

        $uploads_dir = trailingslashit(wp_upload_dir()['basedir']) . 'element-pack/minified/css';
        $minifiedPath = "$uploads_dir" . "/ep-styles.css";

        return $this->writeBundle($minifier, $minifiedPath);
    }

    /**
     * Minify into $path without ever exposing a partial file.
     *
     * Minify::minify($path) opens the target with fopen('w'), which empties it
     * before writing, so a request served mid-rebuild got a truncated bundle. The
     * content is built for the final path (CSS url() rewriting depends on it),
     * written to a temp file in the same directory, then renamed over the target,
     * which is atomic on the same filesystem.
     *
     * @param Minify\Minify $minifier
     * @param string        $path
     * @return bool Whether the file was written. Failures (unwritable uploads, a full
     *              disk) are reported rather than thrown, so a rebuild can never
     *              fatal the request that triggered it.
     */
    private function writeBundle($minifier, $path) {
        try {
            $content = $minifier->execute($path);
        } catch (\Exception $e) {
            return false;
        }

        if (!wp_mkdir_p(dirname($path))) {
            return false;
        }

        $tmp = $path . '.' . uniqid('', true) . '.tmp';

        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Atomic temp-file write; WP_Filesystem has no rename-over.
        if (false === @file_put_contents($tmp, $content, LOCK_EX)) {
            @unlink($tmp);
            return false;
        }

        // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename -- Atomic replace of the served bundle.
        if (!@rename($tmp, $path)) {
            @unlink($tmp);
            return false;
        }

        return true;
    }

}