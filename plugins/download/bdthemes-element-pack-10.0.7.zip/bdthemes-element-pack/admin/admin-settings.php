<?php

namespace ElementPack\Admin;

use ElementPack\Base\Element_Pack_Base;
use ElementPack\Biggopties;

/**
 * Element Pack admin bootstrap (React dashboard shell).
 *
 * Registers the top-level WP menu, license admin-post handlers, white-label
 * menu icon CSS, and setup-wizard settings AJAX via ElementPack_Settings_API.
 * All dashboard UI lives in the React SPA (build/admin).
 */

require_once BDTEP_ADMIN_PATH . 'class-rollback-version.php';
require_once BDTEP_ADMIN_PATH . 'permission-manager/class-permission-manager.php';
require_once BDTEP_ADMIN_PATH . 'permission-manager/element-pack-role-filters.php';

class ElementPack_Admin_Settings {

	public $license_title;

	const PAGE_ID = 'element_pack_options';

	public $responseObj;
	public $licenseMessage;
	public $showMessage = false;

	public $rollback_version;

	private $is_activated = false;

	public function __construct() {
		new ElementPack_Settings_API();

		$license_key   = self::get_license_key();
		$license_email = self::get_license_email();

		Element_Pack_Base::add_on_delete(
			function () {
				update_option( 'element_pack_license_email', '' );
				update_option( 'element_pack_license_key', '' );
				update_option( Element_Pack_Base::get_lic_key_param( 'element_pack_license_key' ), '' );
			}
		);

		$ep_3rdparty_option = get_option( 'element_pack_third_party_widget' );
		$el_use_mini_cart     = get_option( 'elementor_use_mini_cart_template' );

		if ( false !== $el_use_mini_cart && false !== $ep_3rdparty_option && $ep_3rdparty_option ) {
			if ( 'yes' === $el_use_mini_cart && isset( $ep_3rdparty_option['wc-mini-cart'] ) && 'off' !== trim( $ep_3rdparty_option['wc-mini-cart'] ) ) {
				add_action( 'admin_notices', [ $this, 'el_use_mini_cart' ], 10, 3 );
			}
		}

		if ( Element_Pack_Base::check_wp_plugin( $license_key, $license_email, $error, $responseObj, BDTEP__FILE__ ) ) {
			add_action( 'admin_post_element_pack_deactivate_license', [ $this, 'action_deactivate_license' ] );
			$this->is_activated = true;
		} else {
			if ( $error ) {
				$this->licenseMessage = $error;
				$this->license_activate_error_warning();
			}

			$this->license_activate_warning();
			update_option( Element_Pack_Base::get_lic_key_param( 'element_pack_license_key' ), '' );
			add_action( 'admin_post_element_pack_activate_license', [ $this, 'action_activate_license' ] );
		}

		$license_info    = Element_Pack_Base::get_register_info();
		$this->license_title = ( isset( $license_info->license_title ) && ! empty( $license_info->license_title ) )
			? $license_info->license_title
			: 'None';
		$this->license_wl_process();

		if ( ! defined( 'BDTEP_HIDE' ) || ! BDTEP_HIDE || false === self::license_wl_status() ) {
			add_action( 'admin_menu', [ $this, 'admin_menu' ], 201 );
			add_action( 'admin_menu', [ $this, 'admin_license_menu' ], 220 );
		}

		Element_Pack_Base::add_on_delete(
			function () {
				delete_option( 'element_pack_activation_source' );
			}
		);

		add_action( 'admin_head', [ $this, 'inject_white_label_icon_css' ] );

		$this->rollback_version   = new ElementPack_Rollback_Version();
	}

	public function inject_white_label_icon_css() {
		$white_label_enabled = get_option( 'ep_white_label_enabled', false );
		$white_label_icon    = get_option( 'ep_white_label_icon', '' );

		if ( ! $white_label_enabled || empty( $white_label_icon ) ) {
			return;
		}

		echo '<style type="text/css">';
		echo '#toplevel_page_element_pack_options .wp-menu-image {';
		echo 'background-image: url(' . esc_url( $white_label_icon ) . ') !important;';
		echo 'background-size: 20px 20px !important;';
		echo 'background-repeat: no-repeat !important;';
		echo 'background-position: center !important;';
		echo '}';
		echo '#toplevel_page_element_pack_options .wp-menu-image:before,#toplevel_page_element_pack_options .wp-menu-image img{display:none!important;}';
		echo '</style>';
	}

	public function admin_menu() {
		add_menu_page(
			BDTEP_TITLE . ' ' . esc_html__( 'Dashboard', 'bdthemes-element-pack' ),
			BDTEP_TITLE,
			'manage_options',
			self::PAGE_ID,
			[ $this, 'plugin_page' ],
			$this->element_pack_icon(),
			3
		);
	}

	public function admin_license_menu() {
		$this->maybe_add_license_renew_submenu();
	}

	private function maybe_add_license_renew_submenu( $license_info = null ) {
		if ( defined( 'BDTEP_LO' ) && self::license_wl_status() ) {
			return;
		}

		if ( null === $license_info ) {
			$license_info = Element_Pack_Base::get_register_info();
		}

		if ( empty( $license_info->expire_date ) ) {
			return;
		}

		if ( 'no expiry' === strtolower( $license_info->expire_date ) ) {
			return;
		}

		$days_left = ( strtotime( $license_info->expire_date ) - time() ) / DAY_IN_SECONDS;

		if ( $days_left > 7 ) {
			return;
		}

		add_submenu_page(
			self::PAGE_ID,
			BDTEP_TITLE,
			esc_html__( '🔔 Pro Renew Now', 'bdthemes-element-pack' ),
			'manage_options',
			self::PAGE_ID . '_license_renew',
			[ $this, 'plugin_page' ]
		);
	}
	public function element_pack_icon() {
			return 'data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz4NCjwhLS0gR2VuZXJhdG9yOiBBZG9iZSBJbGx1c3RyYXRvciAyMy4wLjIsIFNWRyBFeHBvcnQgUGx1Zy1JbiAuIFNWRyBWZXJzaW9uOiA2LjAwIEJ1aWxkIDApICAtLT4NCjxzdmcgdmVyc2lvbj0iMS4xIiBpZD0iTGF5ZXJfMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgeD0iMHB4IiB5PSIwcHgiDQoJIHdpZHRoPSIyMzAuN3B4IiBoZWlnaHQ9IjI1NC44MXB4IiB2aWV3Qm94PSIwIDAgMjMwLjcgMjU0LjgxIiBzdHlsZT0iZW5hYmxlLWJhY2tncm91bmQ6bmV3IDAgMCAyMzAuNyAyNTQuODE7Ig0KCSB4bWw6c3BhY2U9InByZXNlcnZlIj4NCjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+DQoJLnN0MHtmaWxsOiNGRkZGRkY7fQ0KPC9zdHlsZT4NCjxwYXRoIGNsYXNzPSJzdDAiIGQ9Ik02MS4wOSwyMjkuMThIMjguOTVjLTMuMTcsMC01Ljc1LTIuNTctNS43NS01Ljc1bDAtMTkyLjA3YzAtMy4xNywyLjU3LTUuNzUsNS43NS01Ljc1aDMyLjE0DQoJYzMuMTcsMCw1Ljc1LDIuNTcsNS43NSw1Ljc1djE5Mi4wN0M2Ni44MywyMjYuNjEsNjQuMjYsMjI5LjE4LDYxLjA5LDIyOS4xOHoiLz4NCjxwYXRoIGNsYXNzPSJzdDAiIGQ9Ik0yMDcuNSwzMS4zN3YzMi4xNGMwLDMuMTctMi41Nyw1Ljc1LTUuNzUsNS43NUg5MC4wNGMtMy4xNywwLTUuNzUtMi41Ny01Ljc1LTUuNzVWMzEuMzcNCgljMC0zLjE3LDIuNTctNS43NSw1Ljc1LTUuNzVoMTExLjcyQzIwNC45MywyNS42MiwyMDcuNSwyOC4yLDIwNy41LDMxLjM3eiIvPg0KPHBhdGggY2xhc3M9InN0MCIgZD0iTTIwNy41LDExMS4zM3YzMi4xNGMwLDMuMTctMi41Nyw1Ljc1LTUuNzUsNS43NUg5MC4wNGMtMy4xNywwLTUuNzUtMi41Ny01Ljc1LTUuNzV2LTMyLjE0DQoJYzAtMy4xNywyLjU3LTUuNzUsNS43NS01Ljc1aDExMS43MkMyMDQuOTMsMTA1LjU5LDIwNy41LDEwOC4xNiwyMDcuNSwxMTEuMzN6Ii8+DQo8cGF0aCBjbGFzcz0ic3QwIiBkPSJNMjA3LjUsMTkxLjN2MzIuMTRjMCwzLjE3LTIuNTcsNS43NS01Ljc1LDUuNzVIOTAuMDRjLTMuMTcsMC01Ljc1LTIuNTctNS43NS01Ljc1VjE5MS4zDQoJYzAtMy4xNywyLjU3LTUuNzUsNS43NS01Ljc1aDExMS43MkMyMDQuOTMsMTg1LjU1LDIwNy41LDE4OC4xMywyMDcuNSwxOTEuM3oiLz4NCjxwYXRoIGNsYXNzPSJzdDAiIGQ9Ik0xNjkuNjIsMjUuNjJoMzIuMTRjMy4xNywwLDUuNzUsMi41Nyw1Ljc1LDUuNzV2MTEyLjFjMCwzLjE3LTIuNTcsNS43NS01Ljc1LDUuNzVoLTMyLjE0DQoJYy0zLjE3LDAtNS43NS0yLjU3LTUuNzUtNS43NVYzMS4zN0MxNjMuODcsMjguMiwxNjYuNDQsMjUuNjIsMTY5LjYyLDI1LjYyeiIvPg0KPC9zdmc+DQo=';
		}

	public function plugin_page() {
		if ( Admin_Cutover::is_default() ) {
			React_App::render_root();
			return;
		}

		React_App::render_build_missing_notice();
	}

	public static function get_license_key() {
		$license_key = get_option( Element_Pack_Base::get_lic_key_param( 'element_pack_license_key' ) );

		if ( empty( $license_key ) ) {
			$license_key = get_option( 'element_pack_license_key' );

			if ( ! empty( $license_key ) ) {
				self::set_license_key( $license_key );
				update_option( 'element_pack_license_key', '' );
			}
		}

		return trim( (string) $license_key );
	}

	public static function get_license_email() {
		return trim( get_option( 'element_pack_license_email', get_bloginfo( 'admin_email' ) ) );
	}

	public static function set_license_key( $license_key ) {
		return update_option( Element_Pack_Base::get_lic_key_param( 'element_pack_license_key' ), $license_key );
	}

	public static function set_license_email( $license_email ) {
		return update_option( 'element_pack_license_email', $license_email );
	}

	public function action_activate_license() {
		check_admin_referer( 'el-license' );

		$license_key   = ! empty( $_POST['element_pack_license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['element_pack_license_key'] ) ) : '';
		$license_email = ! empty( $_POST['element_pack_license_email'] ) ? wp_unslash( $_POST['element_pack_license_email'] ) : '';

		update_option( Element_Pack_Base::get_lic_key_param( 'element_pack_license_key' ), $license_key );
		update_option( 'element_pack_license_email', sanitize_email( $license_email ) );

		wp_safe_redirect( Admin_Cutover::app_url( '/license' ) );
		exit;
	}

	public function action_deactivate_license() {
		check_admin_referer( 'el-license' );

		if ( Element_Pack_Base::remove_license_key( BDTEP__FILE__, $message ) ) {
			update_option( Element_Pack_Base::get_lic_key_param( 'element_pack_license_key' ), '' );
			delete_option( 'element_pack_activation_source' );
		}

		wp_safe_redirect( Admin_Cutover::app_url( '/license' ) );
		exit;
	}

	public function license_activate_error_warning() {
		Biggopties::add_biggopti(
			[
				'id'               => 'license-error',
				'type'             => 'error',
				'category'         => 'critical',
				'dismissible'      => true,
				'dismissible-time' => 43200,
				'title'            => esc_html__( 'Oops! Element Pack is not activated.', 'bdthemes-element-pack' ),
				'message'          => $this->licenseMessage,
			]
		);
	}

	public function license_activate_warning() {
		Biggopties::add_biggopti(
			[
				'id'             => 'license-issue',
				'type'           => 'error',
				'category'       => 'critical',
				'dismissible'    => false,
				'dismissible-time' => HOUR_IN_SECONDS * 72,
				'html_message'   => $this->license_active_message(),
			]
		);
	}

	public function license_active_message() {
		$plugin_icon  = BDTEP_ASSETS_URL . 'images/logo.svg';
		$plugin_title = __( 'Element Pack Pro', 'bdthemes-element-pack' );
		$plugin_msg   = __( 'Thank you for purchase Element Pack. Please activate your license to get feature updates, premium support. Don\'t have Element Pack license? Purchase and download your license copy from here.', 'bdthemes-element-pack' );
		$license_url  = esc_url( Admin_Cutover::app_url( '/license' ) );

		ob_start();
		?>
		<div class="bdt-license-biggopti-global element_pack_pro">
			<div class="bdt-license-biggopti-logo">
				<img src="<?php echo esc_url( $plugin_icon ); ?>" alt="">
			</div>
			<div class="bdt-license-biggopti-content">
				<h3><?php echo esc_html( $plugin_title ); ?></h3>
				<p><?php echo esc_html( $plugin_msg ); ?></p>
				<div class="bdt-license-biggopti-button-wrap">
					<a href="<?php echo esc_url( $license_url ); ?>" class="bdt-button bdt-button-allow">
						<?php esc_html_e( 'Activate License', 'bdthemes-element-pack' ); ?>
					</a>
					<a href="https://elementpack.pro/" target="_blank" class="bdt-button bdt-button-skip">
						<?php esc_html_e( 'Get License', 'bdthemes-element-pack' ); ?>
					</a>
				</div>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	public function el_use_mini_cart() {
		Biggopties::add_biggopti(
			[
				'id'               => 'ep-el-use-mini-cart',
				'type'             => 'warning',
				'category'         => 'critical',
				'dismissible'      => true,
				'dismissible-time' => MONTH_IN_SECONDS / 2,
				'title'            => esc_html__( 'Oops, Possibilities to get errors', 'bdthemes-element-pack' ),
				'message'          => __( 'We can see you activated the <strong>Mini-Cart</strong> of Elementor Pro and also Element Pack Pro. We will recommend you to choose one of them, otherwise you will get conflict. Thank you.', 'bdthemes-element-pack' ),
			]
		);
	}

	public function license_wl_process() {
		$license_info = Element_Pack_Base::get_register_info();

		if ( empty( $license_info ) || empty( $license_info->license_title ) ) {
			update_option( 'element_pack_license_title_status', false );
			return false;
		}

		if ( ! empty( $license_info->other_param ) ) {
			if ( is_array( $license_info->other_param ) && in_array( 'WL', $license_info->other_param, true ) ) {
				update_option( 'element_pack_license_title_status', true );
				return true;
			}

			if ( is_string( $license_info->other_param ) && false !== strpos( $license_info->other_param, 'WL' ) ) {
				update_option( 'element_pack_license_title_status', true );
				return true;
			}
		}

		$license_title  = strtolower( $license_info->license_title );
		$allowed_hashes = array_values( self::get_white_label_allowed_license_types() );

		foreach ( preg_split( '/\s+/', $license_title ) as $word ) {
			$word = trim( $word );

			if ( '' === $word ) {
				continue;
			}

			if ( in_array( hash( 'sha256', $word ), $allowed_hashes, true ) ) {
				update_option( 'element_pack_license_title_status', true );
				return true;
			}
		}

		update_option( 'element_pack_license_title_status', false );
		return false;
	}

	public static function license_wl_status() {
		return (bool) get_option( 'element_pack_license_title_status' );
	}

	public static function is_white_label_license() {
		$license_info = Element_Pack_Base::get_register_info();

		if ( empty( $license_info ) || ! is_object( $license_info ) || empty( $license_info->license_title ) || empty( $license_info->is_valid ) ) {
			return false;
		}

		if ( ! empty( $license_info->other_param ) ) {
			if ( is_array( $license_info->other_param ) && in_array( 'WL', $license_info->other_param, true ) ) {
				return true;
			}

			if ( is_string( $license_info->other_param ) && false !== strpos( $license_info->other_param, 'WL' ) ) {
				return true;
			}
		}

		$license_title  = sanitize_text_field( strtolower( $license_info->license_title ) );
		$allowed_hashes = array_values( self::get_white_label_allowed_license_types() );

		foreach ( preg_split( '/\s+/', $license_title, -1, PREG_SPLIT_NO_EMPTY ) as $word ) {
			$word = trim( $word );

			if ( '' === $word || strlen( $word ) > 50 ) {
				continue;
			}

			if ( in_array( hash( 'sha256', $word ), $allowed_hashes, true ) ) {
				return true;
			}
		}

		return false;
	}

	public static function get_white_label_allowed_license_types() {
		return [
			'agency'    => 'c4b2af4722ee54e317672875b2d8cf49aa884bf5820ec6091114fea5ec6560e4',
			'extended'  => '4d7120eb6c796b04273577476eb2e20c34c51d7fa1025ec19c3414448abc241e',
			'developer' => '88fa0d759f845b47c044c2cd44e29082cf6fea665c30c146374ec7c8f3d699e3',
		];
	}
}

$GLOBALS['element_pack_admin_settings'] = new ElementPack_Admin_Settings();