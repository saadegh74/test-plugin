<?php

namespace ElementPack\Admin;

if (!defined('ABSPATH')) {
	exit;
} // Exit if accessed directly

if (!function_exists('is_plugin_active')) {
	include_once(ABSPATH . 'wp-admin/includes/plugin.php');
}

class ModuleService {

	/**
	 * Per-request memo of the fully built settings array.
	 *
	 * @var array|null
	 */
	private static $settings_cache = null;

	public static function get_widget_settings($callable) {

		// The settings array below is large (~300 widgets, hundreds of esc_html__()
		// calls, plus get_plugins()/is_plugin_active() lookups). On admin/editor
		// requests several callers build it, and the Manager builds it on every
		// front-end load. Memoize it per-request so it is constructed at most once;
		// plugin/option state cannot change within a single request, so reusing the
		// built array across callers is safe. Each caller still runs its own $callable.
		if ( self::$settings_cache !== null ) {
			return $callable( self::$settings_cache );
		}

		$settings_fields = [
			'element_pack_active_modules'   => [
				[
					'name'         => 'accordion',
					'label'        => esc_html__('Accordion', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'free',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/accordion/',
					'video_url'    => 'https://youtu.be/DP3XNV1FEk0',
				],
				[
					'name'         => 'advanced-button',
					'label'        => esc_html__('Advanced Button', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/advanced-button/',
					'video_url'    => 'https://youtu.be/Lq_st2IWZiE',
				],
				[
					'name'         => 'advanced-calculator',
					'label'        => esc_html__('Advanced Calculator', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/advanced-calculator/',
					'video_url'    => 'https://youtu.be/vw28HW6duXE',
				],
				[
					'name'         => 'advanced-counter',
					'label'        => esc_html__('Advanced Counter', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/advanced-counter/',
					'video_url'    => 'https://youtu.be/Ydok6ImEQvE',
				],
				[
					'name'         => 'advanced-divider',
					'label'        => esc_html__('Advanced Divider', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/advanced-divider/',
					'video_url'    => 'https://youtu.be/HbtNHQJm3m0',
				],
				[
					'name'         => 'advanced-gmap',
					'label'        => esc_html__('Advanced Google Map', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/advanced-google-map/',
					'video_url'    => 'https://youtu.be/qaZ-hv6UPDY',
				],
				[
					'name'         => 'advanced-heading',
					'label'        => esc_html__('Advanced Heading', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/advanced-heading/',
					'video_url'    => 'https://youtu.be/E1jYInKYTR0',
				],
				[
					'name'         => 'advanced-icon-box',
					'label'        => esc_html__('Advanced Icon Box', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/advanced-icon-box/',
					'video_url'    => 'https://youtu.be/IU4s5Cc6CUA',
				],
				[
					'name'         => 'advanced-image-gallery',
					'label'        => esc_html__('Advanced Image Gallery', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'pro',
					'content_type' => 'custom gallery',
					'demo_url'     => 'https://elementpack.pro/demo/element/advanced-image-gallery/',
					'video_url'    => 'https://youtu.be/se7BovYbDok',
				],
				[
					'name'         => 'advanced-progress-bar',
					'label'        => esc_html__('Advanced Progress Bar', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/advanced-progress-bar/',
					'video_url'    => 'https://youtu.be/7hnmMdd2-Yo',
				],
				[
					'name'         => 'animated-card',
					'label'        => esc_html__('Animated Card', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/animated-card/',
					'video_url'    => 'https://youtu.be/gfXpQ-dTr9g',
				],
				[
					'name'         => 'animated-heading',
					'label'        => esc_html__('Animated Heading', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/animated-heading/',
					'video_url'    => 'https://youtu.be/xypAmQodUYA',
				],
				[
					'name'         => 'animated-link',
					'label'        => esc_html__('Animated Link', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/animated-link/',
					'video_url'    => 'https://youtu.be/qs0gEVh0x7w',
				],
				[
					'name'         => 'audio-player',
					'label'        => esc_html__('Audio Player', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/audio-player/',
					'video_url'    => 'https://youtu.be/VHAEO1xLVxU',
				],
				[
					'name'         => 'barcode',
					'label'        => esc_html__('Barcode', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/barcode',
					'video_url'    => 'https://youtu.be/PWxNP2zLqDg',
				],
				[
					'name'         => 'brand-grid',
					'label'        => esc_html__('Brand Grid', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/brand-grid',
					'video_url'    => 'https://youtu.be/a_wJL950Kz4',
				],
				[
					'name'         => 'brand-carousel',
					'label'        => esc_html__('Brand Carousel', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/brand-carousel',
					'video_url'    => 'https://youtu.be/LdCxFzpYuO0',
				],
				[
					'name'         => 'breadcrumbs',
					'label'        => esc_html__('Breadcrumbs', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/breadcrumbs',
					'video_url'    => 'https://youtu.be/32yrjPHq-AA',
				],
				[
					'name'         => 'business-hours',
					'label'        => esc_html__('Business Hours', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/business-hours',
					'video_url'    => 'https://youtu.be/1QfZ-os75rQ',
				],
				[
					'name'         => 'dual-button',
					'label'        => esc_html__('Dual Button', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/dual-button/',
					'video_url'    => 'https://youtu.be/7hWWqHEr6s8',
				],
				[
					'name'         => 'chart',
					'label'        => esc_html__('Chart', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/charts',
					'video_url'    => 'https://youtu.be/-1WVTzTyti0',

				],
				[
					'name'         => 'calendly',
					'label'        => esc_html__('Calendly', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'free',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/calendly/',
					'video_url'    => 'https://youtu.be/nl4zC46SrhY',
				],
				[
					'name'         => 'changelog',
					'label'        => esc_html__('Changelog', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/changelog',
					'video_url'    => 'https://youtu.be/835Fsi2jGRI',

				],
				[
					'name'         => 'circle-menu',
					'label'        => esc_html__('Circle Menu', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/circle-menu/',
					'video_url'    => 'https://www.youtube.com/watch?v=rfW22T-U7Ag',

				],
				[
					'name'         => 'comparison-list',
					'label'        => esc_html__('Comparison List', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom new',
					'demo_url'     => 'https://elementpack.pro/demo/element/comparison-list/',
					'video_url'    => 'https://youtu.be/7XvSgvbJM74',
				],
				[
					'name'         => 'circle-info',
					'label'        => esc_html__('Circle Info', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/circle-info/',
					'video_url'    => 'https://youtu.be/PIQ6BJtNpNU',

				],
				[
					'name'         => 'content-switcher',
					'label'        => esc_html__('Content Switcher', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'custom new',
					'demo_url'     => 'https://elementpack.pro/demo/element/content-switcher/',
					'video_url'    => 'https://youtu.be/4NjUGf9EY0U',
				],
				[
					'name'         => 'cookie-consent',
					'label'        => esc_html__('Cookie Consent', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'free',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/cookie-consent/',
					'video_url'    => 'https://youtu.be/BR4t5ngDzqM',

				],
				[
					'name'         => 'countdown',
					'label'        => esc_html__('Countdown', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'free',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/countdown',
					'video_url'    => 'https://youtu.be/oxqHEDyzvIM',

				],
				[
					'name'         => 'contact-form',
					'label'        => esc_html__('Simple Contact Form', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'free',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/simple-contact-form/',
					'video_url'    => 'https://youtu.be/faIeyW7LOJ8',

				],
				[
					'name'         => 'comment',
					'label'        => esc_html__('Comment', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/comment/',
					'video_url'    => 'https://youtu.be/csvMTyUx7Hs',
				],
				[
					'name'         => 'custom-gallery',
					'label'        => esc_html__('Custom Gallery', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'free',
					'content_type' => 'custom gallery',
					'demo_url'     => 'https://elementpack.pro/demo/element/custom-gallery/',
					'video_url'    => 'https://youtu.be/2fAF8Rt7FbQ',

				],
				[
					'name'         => 'custom-carousel',
					'label'        => esc_html__('Custom Carousel', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'pro',
					'content_type' => 'custom carousel',
					'demo_url'     => 'https://elementpack.pro/demo/element/custom-carousel/',
					'video_url'    => 'https://youtu.be/TMwdfYDmTQo',

				],
				[
					'name'         => 'creative-button',
					'label'        => esc_html__('Creative Button', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/creative-button/',
					'video_url'    => 'https://youtu.be/6f2t-79MfnU',
				],
				[
					'name'         => 'coupon-code',
					'label'        => esc_html__('Coupon Code', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/coupon-code/',
					'video_url'    => 'https://youtu.be/xru1Xu3ISZ0',

				],

				[
					'name'         => 'document-viewer',
					'label'        => esc_html__('Document Viewer', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/document-viewer',
					'video_url'    => 'https://www.youtube.com/watch?v=8Ar9NQe93vg',

				],

				[
					'name'         => 'device-slider',
					'label'        => esc_html__('Device Slider', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'pro',
					'content_type' => 'custom slider',
					'demo_url'     => 'https://elementpack.pro/demo/element/device-slider/',
					'video_url'    => 'https://youtu.be/GACXtqun5Og',

				],
				[
					'name'         => 'dynamic-grid',
					'label'        => esc_html__('Dynamic Grid', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/dynamic-grid/',
					'video_url'    => 'https://youtu.be/-BdpQ2lttSo?si=vpEHqHl_pTzQxhyY',

				],
				[
					'name'         => 'dynamic-carousel',
					'label'        => esc_html__('Dynamic Carousel', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/dynamic-carousel/',
					'video_url'    => 'https://youtu.be/uc08OzVbq_g?si=3vCt8T4zeFSw4oiU',

				],
				[
					'name'         => 'facebook-feed',
					'label'        => esc_html__('Facebook Feed', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/facebook-feed/',
					'video_url'    => 'https://youtu.be/iNUl6q2yRDU',

				],
				[
					'name'         => 'facebook-feed-carousel',
					'label'        => esc_html__('Facebook Feed Carousel', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/facebook-feed-carousel/',
					'video_url'    => 'https://youtu.be/wMumsINLfUA',

				],
				[
					'name'         => 'fancy-list',
					'label'        => esc_html__('Fancy List', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/fancy-list/',
					'video_url'    => 'https://youtu.be/t1_5uys8bto',

				],
				[
					'name'         => 'fancy-icons',
					'label'        => esc_html__('Fancy Icons', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/fancy-icons/',
					'video_url'    => 'https://youtu.be/Y4NoiuW2yBM',

				],
				[
					'name'         => 'fancy-slider',
					'label'        => esc_html__('Fancy Slider', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/fancy-slider/',
					'video_url'    => 'https://youtu.be/UGBnjbp90eA',

				],
				[
					'name'         => 'fancy-tabs',
					'label'        => esc_html__('Fancy Tabs', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/fancy-tabs/',
					'video_url'    => 'https://youtu.be/wBTRSjofce4',

				],
				[
					'name'         => 'flip-box',
					'label'        => esc_html__('Flip Box', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/flip-box/',
					'video_url'    => 'https://youtu.be/FLmKzk9KbQg',

				],
				[
					'name'         => 'floating-knowledgebase',
					'label'        => esc_html__('Floating Knowledgebase', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'post new',
					'demo_url'     => 'https://elementpack.pro/demo/element/floating-knowledgebase/',
					'video_url'    => 'https://youtu.be/02xNh5syhZ0',

				],
				[
					'name'         => 'featured-box',
					'label'        => esc_html__('Featured Box', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/featured-box/',
					'video_url'    => 'https://youtu.be/Qe4yYXajhQg',

				],
				[
					'name'         => 'google-reviews',
					'label'        => esc_html__('Google Reviews', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'slider',
					'demo_url'     => 'https://elementpack.pro/demo/element/google-reviews/',
					'video_url'    => 'https://youtu.be/pp0mQpyKqfs',

				],
				[
					'name'         => 'helpdesk',
					'label'        => esc_html__('Help Desk', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/help-desk/',
					'video_url'    => 'https://youtu.be/bO__skhy4yk',

				],
				[
					'name'         => 'hover-box',
					'label'        => esc_html__('Hover Box', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/hover-box/',
					'video_url'    => 'https://youtu.be/lWdF9-SV-2I',

				],
				[
					'name'         => 'hover-video',
					'label'        => esc_html__('Hover Video', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/hover-video/',
					'video_url'    => 'https://youtu.be/RgoWlIm5KOo',

				],
				[
					'name'         => 'horizontal-scroller',
					'label'        => esc_html__('Horizontal Scroller', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/horizontal-scroller/',
					'video_url'    => 'https://youtu.be/x6vpXQt6__k',

				],
				[
					'name'         => 'icon-mobile-menu',
					'label'        => esc_html__('Icon Mobile Menu', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'menu',
					'demo_url'     => 'https://elementpack.pro/demo/element/icon-mobile-menu/',
					'video_url'    => 'https://youtu.be/lJxkFDzrDeY',
				],
				[
					'name'         => 'iconnav',
					'label'        => esc_html__('Icon Nav', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/icon-nav/',
					'video_url'    => 'https://youtu.be/Q4YY8pf--ig',
				],
				[
					'name'         => 'iframe',
					'label'        => esc_html__('Iframe', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/iframe/',
					'video_url'    => 'https://youtu.be/wQPgsmrxZHM',
				],
				[
					'name'         => 'instagram',
					'label'        => esc_html__('Instagram', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'others carousel',
					'demo_url'     => 'https://elementpack.pro/demo/element/instagram-feed/',
					'video_url'    => 'https://youtu.be/uj9WpuFIZb8',
				],
				[
					'name'         => 'image-compare',
					'label'        => esc_html__('Image Compare', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'free',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/image-compare/',
					'video_url'    => 'https://youtu.be/-Kwjlg0Fwk0',
				],
				[
					'name'         => 'image-expand',
					'label'        => esc_html__('Image Expand', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/image-expand/',
					'video_url'    => 'https://youtu.be/gNg7vpypycY',
				],
				[
					'name'         => 'image-stack',
					'label'        => esc_html__('Image Stack', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/image-stack/',
					'video_url'    => 'https://youtu.be/maLIlug2RwM',
				],
				[
					'name'         => 'image-magnifier',
					'label'        => esc_html__('Image Magnifier', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'free',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/image-magnifier/',
					'video_url'    => 'https://youtu.be/GSy3pLihNPY',
				],
				[
					'name'         => 'interactive-card',
					'label'        => esc_html__('Interactive Card', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/interactive-card/',
					'video_url'    => 'https://youtu.be/r8IXJUD3PA4',
				],
				[
					'name'         => 'interactive-tabs',
					'label'        => esc_html__('Interactive Tabs', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/interactive-tabs/',
					'video_url'    => 'https://youtu.be/O3VFyW0G6_Q',
				],
				[
					'name'         => 'lightbox',
					'label'        => esc_html__('Lightbox', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'free',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/lightbox/',
					'video_url'    => 'https://youtu.be/1iKQD4HfZG4',
				],
				[
					'name'         => 'lottie-image',
					'label'        => esc_html__('Lottie Image', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/lottie-image/',
					'video_url'    => 'https://youtu.be/CbODBtLTxWc',
				],
				[
					'name'         => 'lottie-icon-box',
					'label'        => esc_html__('Lottie Icon Box', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/lottie-icon-box/',
					'video_url'    => 'https://youtu.be/1jKFSglW6qE',
				],
				[
					'name'         => 'logo-grid',
					'label'        => esc_html__('Logo Grid', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/logo-grid/',
					'video_url'    => 'https://youtu.be/Go1YE3O23J4',
				],
				[
					'name'         => 'logo-carousel',
					'label'        => esc_html__('Logo Carousel', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/logo-carousel/',
					'video_url'    => 'https://youtu.be/xe_SA0ZgAvA',
				],
				[
					'name'         => 'mega-menu',
					'label'        => esc_html__('Mega Menu', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/mega-menu/',
					'video_url'    => 'https://youtu.be/ZOBLWIZvGLs',
				],
				[
					'name'         => 'marquee',
					'label'        => esc_html__('Marquee', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/marquee/',
					'video_url'    => 'https://youtu.be/3Dnxt9V0mzc',
				],
				[
					'name'         => 'modal',
					'label'        => esc_html__('Modal', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/modal/',
					'video_url'    => 'https://youtu.be/XcK7a-nN3FM',
				],
				[
					'name'         => 'mailchimp',
					'label'        => esc_html__('Mailchimp', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/mailchimp/',
					'video_url'    => 'https://youtu.be/hClaXvxvkXM',
				],
				[
					'name'         => 'marker',
					'label'        => esc_html__('Marker', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/marker/',
					'video_url'    => 'https://youtu.be/1iKQD4HfZG4',
				],
				[
					'name'         => 'navbar',
					'label'        => esc_html__('Navbar', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'free',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/navbar/',
					'video_url'    => 'https://youtu.be/ZXdDAi9tCxE',
				],
				[
					'name'         => 'notification',
					'label'        => esc_html__('Notification', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/notification',
					'video_url'    => 'https://youtu.be/eI4UG1NYAYk',
				],
				[
					'name'         => 'offcanvas',
					'label'        => esc_html__('Offcanvas', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/offcanvas/',
					'video_url'    => 'https://youtu.be/CrrlirVfmQE',
				],
				[
					'name'         => 'open-street-map',
					'label'        => esc_html__('Open Street Map', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'free',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/open-street-map',
					'video_url'    => 'https://youtu.be/DCQ5g7yleyk',
				],
				[
					'name'         => 'price-list',
					'label'        => esc_html__('Price List', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'free',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/price-list/',
					'video_url'    => 'https://youtu.be/QsXkIYwfXt4',
				],
				[
					'name'         => 'price-table',
					'label'        => esc_html__('Price Table', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/price-table/',
					'video_url'    => 'https://youtu.be/D8_inzgdvyg',
				],
				[
					'name'         => 'product-grid',
					'label'        => esc_html__('Product Grid', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/product-grid',
					'video_url'    => 'https://youtu.be/-UJhU-ak5_k',
				],
				[
					'name'         => 'product-carousel',
					'label'        => esc_html__('Product Carousel', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'carousel',
					'demo_url'     => 'https://elementpack.pro/demo/element/product-carousel',
					'video_url'    => 'https://youtu.be/ZFpkJIctXic',
				],
				[
					'name'         => 'panel-slider',
					'label'        => esc_html__('Panel Slider', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'free',
					'content_type' => 'custom slider',
					'demo_url'     => 'https://elementpack.pro/demo/element/panel-slider/',
					'video_url'    => 'https://youtu.be/_piVTeJd0g4',
				],
				[
					'name'         => 'progress-pie',
					'label'        => esc_html__('Progress Pie', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'free',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/progress-pie/',
					'video_url'    => 'https://youtu.be/yi0IMsyP43I',
				],
				[
					'name'         => 'profile-card',
					'label'        => esc_html__('Profile Card', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'post',
					'demo_url'     => 'https://elementpack.pro/demo/element/profile-card/',
					'video_url'    => 'https://youtu.be/Slnx_mxDBqo',
				],
				[
					'name'         => 'protected-content',
					'label'        => esc_html__('Protected Content', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/protected-content/',
					'video_url'    => 'https://youtu.be/jcLWace-JpE',

				],
				[
					'name'         => 'qrcode',
					'label'        => esc_html__('QR Code', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/qr-code/',
					'video_url'    => 'https://youtu.be/3ofLAjpnmO8',
				],
				[
					'name'         => 'reading-progress',
					'label'        => esc_html__('Reading Progress', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/reading-progress/',
					'video_url'    => 'https://youtu.be/cODL1E2f9FI',
				],
				[
					'name'         => 'reading-timer',
					'label'        => esc_html__('Reading Timer', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'others new',
					'demo_url'     => 'https://elementpack.pro/demo/element/reading-timer/',
					'video_url'    => 'https://youtu.be/7lRyOmR6yqo?si=iuO-Ax-6wNmkmSuM',
				],
				[
					'name'         => 'remote-arrows',
					'label'        => esc_html__('Remote Arrows', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/remote-arrows/',
					'video_url'    => 'https://youtu.be/w0CEROpvjjA',
				],
				[
					'name'         => 'remote-fraction',
					'label'        => esc_html__('Remote Fraction', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/remote-fraction/',
					'video_url'    => 'https://youtu.be/UfmwcTjX7L8',
				],
				[
					'name'         => 'remote-pagination',
					'label'        => esc_html__('Remote Pagination', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/remote-pagination/',
					'video_url'    => 'https://youtu.be/eZWSkb7HeUA',
				],
				[
					'name'         => 'remote-thumbs',
					'label'        => esc_html__('Remote Thumbs', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/remote-thumbs/',
					'video_url'    => 'https://youtu.be/PKKnqB0vhzE',
				],
				[
					'name'         => 'review-card',
					'label'        => esc_html__('Review Card', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/review-card/',
					'video_url'    => 'https://youtu.be/xFtjeR1qgSE',
				],
				[
					'name'         => 'review-card-grid',
					'label'        => esc_html__('Review Card Grid', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/review-card-grid/',
					'video_url'    => 'https://youtu.be/hIKLXU9Rh-8',
				],
				[
					'name'         => 'review-card-carousel',
					'label'        => esc_html__('Review Card Carousel', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'custom carousel',
					'demo_url'     => 'https://elementpack.pro/demo/element/review-card-carousel/',
					'video_url'    => 'https://youtu.be/7kMyajVai6E',
				],
				[
					'name'         => 'slider',
					'label'        => esc_html__('Slider', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'free',
					'content_type' => 'custom slider',
					'demo_url'     => 'https://elementpack.pro/demo/element/layer-slider/',
					'video_url'    => 'https://youtu.be/SI4K4zuNOoE',
				],
				[
					'name'         => 'slideshow',
					'label'        => esc_html__('Slideshow', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/slideshow/',
					'video_url'    => 'https://youtu.be/BrrKmDfJ5ZI',
				],
				[
					'name'        => 'scrollnav',
					'label'       => esc_html__('Scrollnav', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'on',
					'widget_type' => 'free',
					'content_type' => 'others',
					'demo_url'    => 'https://elementpack.pro/demo/element/scrollnav/',
					'video_url'   => 'https://youtu.be/P3DfE53_w5I',
				],
				[
					'name'         => 'search',
					'label'        => esc_html__('Search', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'free',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/search/',
					'video_url'    => 'https://youtu.be/H3F1LHc97Gk',
				],
				[
					'name'         => 'scroll-button',
					'label'        => esc_html__('Scroll Button', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'free',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/scroll-button/',
					'video_url'    => 'https://youtu.be/y8LJCO3tQqk',
				],
				[
					'name'         => 'scroll-image',
					'label'        => esc_html__('Scroll Image', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/scroll-image',
					'video_url'    => 'https://youtu.be/UpmtN1GsJkQ',
				],
				[
					'name'         => 'source-code',
					'label'        => esc_html__('Source Code', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/source-code',
					'video_url'    => 'https://youtu.be/vnqpD9aAmzg',
				],
				[
					'name'         => 'stacker',
					'label'        => esc_html__('Stacker', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom new',
					'demo_url'     => 'https://elementpack.pro/demo/element/stacker',
					'video_url'    => 'https://youtu.be/fZSTyJc5W7E?si=GkkUhdv9aXPTlVxS',
				],
				[
					'name'         => 'static-carousel',
					'label'        => esc_html__('Static Carousel', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'custom carousel',
					'demo_url'     => 'https://elementpack.pro/demo/element/static-carousel',
					'video_url'    => 'https://youtu.be/8A2a8ws6364',
				],
				[
					'name'         => 'static-grid-tab',
					'label'        => esc_html__('Static Grid Tab', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/static-grid-tab',
					'video_url'    => 'https://www.youtube.com/watch?v=HIvQX9eLWU8',
				],
				[
					'name'         => 'social-share',
					'label'        => esc_html__('Social Share', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'free',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/social-share/',
					'video_url'    => 'https://youtu.be/3OPYfeVfcb8',
				],
				[
					'name'         => 'social-proof',
					'label'        => esc_html__('Social Proof', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/social-proof/',
					'video_url'    => 'https://youtu.be/jpIX4VHzSxA',
				],
				[
					'name'         => 'step-flow',
					'label'        => esc_html__('Step Flow', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/step-flow/',
					'video_url'    => 'https://youtu.be/YNjbt-5GO4k',
				],
				[
					'name'         => 'sub-menu',
					'label'        => esc_html__('Sub Menu', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/sub-menu/',
					'video_url'    => 'https://youtu.be/YuwB964kQMw',
				],
				[
					'name'         => 'switcher',
					'label'        => esc_html__('Switcher', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/switcher/',
					'video_url'    => 'https://youtu.be/BIEFRxDF1UE',
				],
				[
					'name'         => 'svg-blob',
					'label'        => esc_html__('SVG Blob', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/svg-blob/',
					'video_url'    => 'https://youtu.be/sgyUOC7TXPA',
				],
				[
					'name'         => 'svg-image',
					'label'        => esc_html__('SVG Image', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/svg-image/',
					'video_url'    => 'https://youtu.be/XRbjpcp5dJ0',

				],
				[
					'name'         => 'svg-maps',
					'label'        => esc_html__('SVG Maps', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/svg-maps/',
					'video_url'    => 'https://youtu.be/LZMtIMqBTZY?si=JvfHuTJWFWPXE5mc',
				],
				[
					'name'         => 'tabs',
					'label'        => esc_html__('Tabs', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'pro',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/tabs/',
					'video_url'    => 'https://youtu.be/1BmS_8VpBF4',
				],
				[
					'name'         => 'table',
					'label'        => esc_html__('Table', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/table/',
					'video_url'    => 'https://youtu.be/dviKkEPsg04',
				],
				[
					'name'         => 'table-of-content',
					'label'        => esc_html__('Table Of Content', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'post',
					'demo_url'     => 'https://elementpack.pro/demo/element/table-of-content-test-post/',
					'video_url'    => 'https://youtu.be/DbPrqUD8cOY',
				],
				[
					'name'         => 'time-zone',
					'label'        => esc_html__('Time Zone', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/time-zone/',
					'video_url'    => 'https://youtu.be/WOMIk_FVRz4',
				],
				[
					'name'         => 'total-count',
					'label'        => esc_html__('Total Count', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/total-count/',
					'video_url'    => 'https://youtu.be/1KgG9vTrY8I',
				],
				[
					'name'         => 'trailer-box',
					'label'        => esc_html__('Trailer Box', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'free',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/trailer-box/',
					'video_url'    => 'https://youtu.be/3AR5RlBAAYg',
				],
				[
					'name'         => 'toggle',
					'label'        => esc_html__('Read More Toggle', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'free',
					'content_type' => 'custom',
					'demo_url'     => 'https://elementpack.pro/demo/element/toggle/',
					'video_url'    => 'https://youtu.be/7_jk_NvbKls',
				],
				[
					'name'         => 'twitter-carousel',
					'label'        => esc_html__('Twitter Carousel', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'others carousel',
					'demo_url'     => 'https://elementpack.pro/demo/element/twitter-carousel/',
					'video_url'    => 'https://youtu.be/eeyR1YtUFZw',
				],
				[
					'name'         => 'twitter-grid',
					'label'        => esc_html__('Twitter Grid', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/twitter-grid/',
					'video_url'    => 'https://youtu.be/cYqDPiDpsEY',
				],
				[
					'name'         => 'twitter-slider',
					'label'        => esc_html__('Twitter Slider', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'others slider',
					'demo_url'     => 'https://elementpack.pro/demo/element/twitter-slider',
					'video_url'    => 'https://youtu.be/Bd3I7ipqMms',
				],
				[
					'name'         => 'threesixty-product-viewer',
					'label'        => esc_html__('360 Product Viewer', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/360-product-viewer/',
					'video_url'    => 'https://youtu.be/60Q4sK-FzLI',
				],
				[
					'name'         => 'user-login',
					'label'        => esc_html__('User Login', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/user-login/',
					'video_url'    => 'https://youtu.be/JLdKfv_-R6c',
				],
				[
					'name'         => 'user-register',
					'label'        => esc_html__('User Register', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'on',
					'widget_type'  => 'free',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/user-register/',
					'video_url'    => 'https://youtu.be/hTjZ1meIXSY',
				],
				[
					'name'         => 'vertical-menu',
					'label'        => esc_html__('Vertical Menu', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/vertical-menu/',
					'video_url'    => 'https://youtu.be/ezZBOistuF4',
				],
				[
					'name'         => 'video-gallery',
					'label'        => esc_html__('Video Gallery', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'custom gallery',
					'demo_url'     => 'https://elementpack.pro/demo/element/video-gallery/',
					'video_url'    => 'https://youtu.be/wbkou6p7l3s',
				],
				[
					'name'         => 'video-player',
					'label'        => esc_html__('Video Player', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/video-player/',
					'video_url'    => 'https://youtu.be/ksy2uZ5Hg3M',
				],
				[
					'name'         => 'weather',
					'label'        => esc_html__('Weather', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'others',
					'demo_url'     => 'https://elementpack.pro/demo/element/weather/',
					'video_url'    => 'https://youtu.be/Vjyl4AAAufg',
				],
				[
					'name'         => 'webhook-form',
					'label'        => esc_html__('Webhook Form', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'others new',
					'demo_url'     => 'https://elementpack.pro/demo/element/webhook-form/',
					'video_url'    => 'https://youtu.be/l6h9xFh723A?si=4RICL4bZap5i9fQo',
				],
			],

			'element_pack_elementor_extend' => [
				[
					'name'        => 'adblock-detector',
					'label'       => esc_html__('AdBlock Detector', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'pro',
					'demo_url'    => 'https://elementpack.pro/demo/element/adblock-detector',
					'video_url'   => 'https://youtu.be/DGmEHqIM4XA',
				],
				[
					'name'        => 'animated-gradient-background',
					'label'       => esc_html__('Animated Gradient BG', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'free',
					'demo_url'    => 'https://elementpack.pro/demo/element/animated-gradient-background/',
					'video_url'   => 'https://youtu.be/Hdq06W-2KDw',
				],
				[
					'name'        => 'backdrop-filter',
					'label'       => esc_html__('Backdrop Filter', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'free',
					'demo_url'    => 'https://elementpack.pro/demo/element/backdrop-filter',
					'video_url'   => 'https://youtu.be/XuS3D-czTJc',
				],

				[
					'name'        => 'background-expand',
					'label'       => esc_html__('Background Expand', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'pro',
					'demo_url'    => 'https://elementpack.pro/demo/element/background-expand',
					'video_url'   => 'https://youtu.be/VJ5ZnhLgLMs',
				],
				[
					'name'        => 'background-overlay',
					'label'       => esc_html__('Background Overlay', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'free',
					'demo_url'    => 'https://elementpack.pro/demo/element/background-overlay/',
					'video_url'   => 'https://youtu.be/Px7PMsFK3Jg',
				],
				[
					'name'        => 'background-parallax',
					'label'       => esc_html__('BG Parallax Effects', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'on',
					'widget_type' => 'pro',
					'demo_url'    => 'https://elementpack.pro/demo/element/parallax-background/',
					'video_url'   => 'https://youtu.be/UI3xKt2IlCQ',
				],
				[
					'name'        => 'confetti-effects',
					'label'       => esc_html__('Confetti Effects', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'pro',
					'demo_url'    => 'https://elementpack.pro/demo/element/confetti-effects',
					'video_url'   => 'https://youtu.be/NcKHFeeUXqg',
				],
				[
					'name'        => 'cursor-effects',
					'label'       => esc_html__('Cursor Effects', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'free',
					'demo_url'    => 'https://elementpack.pro/demo/element/cursor-effects/',
					'video_url'   => 'https://youtu.be/Pnev5lPByEc',
				],
				[
					'name'        => 'custom-js',
					'label'       => esc_html__('Custom CSS / JS', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'pro',
					'demo_url'    => 'https://elementpack.pro/demo/element/custom-js/',
					'video_url'   => 'https://youtu.be/e-_qQl6dBbE?t=312',
				],
				[
					'name'        => 'equal-height',
					'label'       => esc_html__('Widget Equal Height', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'free',
					'demo_url'    => 'https://elementpack.pro/demo/element/widget-equal-height/',
					'video_url'   => 'https://youtu.be/h19c3FOxYlc',
				],
				[
					'name'        => 'floating-effects',
					'label'       => esc_html__('Floating Effects', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'free',
					'demo_url'    => 'https://elementpack.pro/demo/element/floating-effects',
					'video_url'   => 'https://youtu.be/hVFqjc9b3dE',
				],
				[
					'name'         => 'global-badge',
					'label'        => esc_html__( 'Global Badge', 'bdthemes-element-pack' ),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'new',
					'demo_url'     => 'https://elementpack.pro/demo/element/global-badge/',
					'video_url'    => '',
				],
				[
					'name'        => 'hash-link',
					'label'       => esc_html__('Hash Link', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'pro',
					'demo_url'    => 'https://elementpack.pro/demo/element/hash-link/',
					'video_url'   => '',
				],
				[
					'name'        => 'grid-line',
					'label'       => esc_html__('Grid Line', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'free',
					'demo_url'    => 'https://elementpack.pro/demo/element/grid-line',
					'video_url'   => 'https://youtu.be/SzC8En2Xl9c',
				],
				[
					'name'        => 'content-protector',
					'label'       => esc_html__('Content Protector', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'pro',
					'demo_url'    => 'https://elementpack.pro/demo/element/content-protector',
					'video_url'   => 'https://youtu.be/ZN-8fnhWeI0?si=6WBFa6YYrXxYYLdF',
				],
				[
					'name'         => 'image-hover-effects',
					'label'        => esc_html__('Image Hover Effects', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'free',
					'content_type' => 'update',
					'demo_url'     => 'https://elementpack.pro/demo/element/image-hover-effects/',
					'video_url'    => '',
				],
				[
					'name'         => 'background-image-parallax',
					'label'        => esc_html__('Background Image Parallax', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'new',
					'demo_url'     => 'https://elementpack.pro/demo/element/background-image-parallax/',
					'video_url'    => 'https://youtu.be/6vTAGdCy1wY',
				],
				[
					'name'         => 'image-masking',
					'label'        => esc_html__('Image Masking', 'bdthemes-element-pack'),
					'type'         => 'checkbox',
					'default'      => 'off',
					'widget_type'  => 'pro',
					'content_type' => 'new',
					'demo_url'     => 'https://elementpack.pro/demo/element/image-masking/',
					'video_url'    => 'https://youtu.be/5aJvWL3Xn-0?si=iUiGH11iiofMPJvb',
				],
				[
					'name'        => 'image-parallax',
					'label'       => esc_html__('Section Image Parallax', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'on',
					'widget_type' => 'pro',
					'demo_url'    => 'https://elementpack.pro/demo/element/parallax-section/',
					'video_url'   => 'https://youtu.be/nMzk55831MY',
				],
				[
					'name'        => 'notation',
					'label'       => esc_html__('Notation', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'pro',
					'demo_url'    => 'https://elementpack.pro/demo/element/notation',
					'video_url'   => 'https://youtu.be/DTz91mthFGE',
				],
				[
					'name'        => 'parallax-effects',
					'label'       => esc_html__('Parallax/Scrolling Effects', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'on',
					'widget_type' => 'pro',
					'demo_url'    => 'https://elementpack.pro/demo/element/element-parallax',
					'video_url'   => 'https://youtu.be/Aw9TnT_L1g8',
				],
				[
					'name'        => 'particles',
					'label'       => esc_html__('Section Particles', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'on',
					'widget_type' => 'pro',
					'demo_url'    => 'https://elementpack.pro/demo/element/section-particles/',
					'video_url'   => 'https://youtu.be/8mylXgB2bYg',
				],
				[
					'name'        => 'reveal-effects',
					'label'       => esc_html__('Reveal Effects', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'pro',
					'demo_url'    => 'https://elementpack.pro/demo/element/reveal-effects/',
					'video_url'   => 'https://youtu.be/A4tMF9Bl8ok?si=cDjicQQci7njUFyI',
				],
				[
					'name'        => 'ripple-effects',
					'label'       => esc_html__('Ripple Effects', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'pro',
					'demo_url'    => 'https://elementpack.pro/demo/element/ripple-effects/',
					'video_url'   => '',
				],
				[
					'name'        => 'scroll-box',
					'label'       => esc_html__('Scroll Box', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'pro',
					'demo_url'    => 'https://elementpack.pro/demo/element/scroll-box/',
					'video_url'   => 'https://youtu.be/Wj_4NS0lSd8',
				],
				[
					'name'        => 'scroll-fill-effect',
					'label'       => esc_html__('Scroll Fill Effect', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'pro',
					'demo_url'    => 'https://elementpack.pro/demo/element/scroll-fill-effect/',
					'video_url'   => '',
				],
				[
					'name'        => 'section-sticky',
					'label'       => esc_html__('Sticky', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'on',
					'widget_type' => 'pro',
					'content_type' => 'update',
					'demo_url'    => 'https://elementpack.pro/demo/sticky-section/',
					'video_url'   => 'https://youtu.be/Vk0EoQSX0K8',
				],
				[
					'name'        => 'shape-builder',
					'label'       => esc_html__('Shape Builder', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'pro',
					'content_type' => 'new',
					'demo_url'    => 'https://elementpack.pro/demo/element/shape-builder',
					'video_url'   => '',
				],
				[
					'name'        => 'sound-effects',
					'label'       => esc_html__('Sound Effects', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'pro',
					'demo_url'    => 'https://elementpack.pro/demo/element/sound-effects',
					'video_url'   => 'https://youtu.be/L1Sy1ZDfp3A',
				],
				[
					'name'        => 'shape-divider',
					'label'       => esc_html__('Shape Divider', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'on',
					'widget_type' => 'pro',
					'content_type' => 'new',
					'demo_url'    => 'https://elementpack.pro/demo/element/shape-divider',
					'video_url'   => 'https://youtu.be/Onlgq2ND5EM?si=AceE8KxbPD46vlbS',
				],
				[
					'name'        => 'threed-text',
					'label'       => esc_html__('3D Text', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'free',
					'demo_url'    => 'https://elementpack.pro/demo/element/3d-text/',
					'video_url'   => 'https://youtu.be/lhqgA4EyYKc',
				],
				[
					'name'        => 'tile-scroll',
					'label'       => esc_html__('Tile Scroll', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'pro',
					'demo_url'    => 'https://elementpack.pro/demo/element/tile-scroll/',
					'video_url'   => 'https://youtu.be/rH4h03C4FE0',
				],
				[
					'name'        => 'text-gradient-background',
					'label'       => esc_html__('Text Gradient Background', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'pro',
					'content_type' => 'new',
					'demo_url'    => 'https://elementpack.pro/demo/element/text-gradient-background/',
					'video_url'   => 'https://youtu.be/J1DNE_Jx4Rs?si=l8Q5Y0ddMl9YzqEh',
				],
				[
					'name'        => 'realistic-image-shadow',
					'label'       => esc_html__('Realistic Image Shadow', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'pro',
					'demo_url'    => 'https://elementpack.pro/demo/element/realistic-image-shadow/',
					'video_url'   => 'https://youtu.be/oVXwG-38g2Y',
				],
				[
					'name'        => 'tooltip',
					'label'       => esc_html__('Widget Tooltip', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'free',
					'demo_url'    => 'https://elementpack.pro/demo/element/widget-tooltip/',
					'video_url'   => 'https://youtu.be/LJgF8wt7urw',
				],
				[
					'name'        => 'transform-effects',
					'label'       => esc_html__('Transform Effects', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'free',
					'demo_url'    => 'https://elementpack.pro/demo/element/transform-example/',
					'video_url'   => 'https://youtu.be/Djc6bP7CF18',
				],
				[
					'name'        => 'visibility-controls',
					'label'       => esc_html__('Visibility Controls', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'pro',
					'content_type' => 'update',
					'demo_url'    => 'https://elementpack.pro/demo/element/visibility-controls/',
					'video_url'   => 'https://youtu.be/E18TikPHBq4',
				],
				[
					'name'        => 'wrapper-link',
					'label'       => esc_html__('Wrapper Link', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'free',
					'demo_url'    => 'https://elementpack.pro/demo/element/wrapper-link',
					'video_url'   => 'https://youtu.be/ZVgGDY_FM1U',
				],
			],
			'element_pack_api_settings'     => [
				[
					'name'              => 'google_map_key',
					'label'             => esc_html__('Google Map API Key', 'bdthemes-element-pack'),
					'desc'              => __('Go to <a href="https://developers.google.com/maps/documentation/javascript/get-api-key" target="_blank">https://developers.google.com</a> and <a href="https://console.cloud.google.com/google/maps-apis/overview">generate the API key</a> and insert here. This API key needs for show Advanced Google Map widget correctly. API Key also works for Google Review widget so you must enabled Places API too.', 'bdthemes-element-pack'),
					'placeholder'       => '------------- -------------------------',
					'type'              => 'text',
					'sanitize_callback' => 'sanitize_text_field',
					'video_url'         => 'https://youtu.be/cssyofmylFA',
				],
				[
					'name'              => 'disqus_user_name',
					'label'             => esc_html__('Disqus User Name', 'bdthemes-element-pack'),
					'desc'              => __('Go to <a href="https://help.disqus.com/customer/portal/articles/1255134-updating-your-disqus-settings#account" target="_blank">https://help.disqus.com/</a> for know how to get user name of your disqus account.', 'bdthemes-element-pack'),
					'placeholder'       => esc_attr__( 'for example: bdthemes', 'bdthemes-element-pack' ),
					'type'              => 'text',
					'sanitize_callback' => 'sanitize_text_field'
				],

				[
					'name'              => 'open_street_map_access_token',
					'label'             => esc_html__('MapBox Access Token (for Open Street Map)', 'bdthemes-element-pack'),
					'desc'              => __('<a href="https://www.mapbox.com/account/access-tokens" target="_blank">Click Here</a> to get access token. This Access Token needs for show Open Street Map widget correctly.', 'bdthemes-element-pack'),
					'placeholder'       => '------------- -------------------------',
					'type'              => 'text',
					'sanitize_callback' => 'sanitize_text_field'
				],

				[
					'name'  => 'social_login_group_start',
					'label' => esc_html__('Social Login Access', 'bdthemes-element-pack'),
					'desc'  => __('Fill in the fields below to enable social login in the User Login widget.', 'bdthemes-element-pack'),
					'type'  => 'start_group',
				],

				[
					'name'              => 'facebook_app_id',
					'label'             => esc_html__('Facebook APP ID', 'bdthemes-element-pack'),
					'desc'              => __('Go to <a href="https://developers.facebook.com/docs/apps/register#create-app" target="_blank">https://developers.facebook.com</a> for create your facebook APP ID.', 'bdthemes-element-pack'),
					'placeholder'       => '---------------',
					'type'              => 'text',
					'sanitize_callback' => 'sanitize_text_field'
				],
				[
					'name'              => 'facebook_app_secret',
					'label'             => esc_html__('Facebook APP Secret', 'bdthemes-element-pack'),
					'desc'              => __('Go to your Google <a href="https://developers.facebook.com/docs/apps/register#create-app" target="_blank">developer</a>', 'bdthemes-element-pack'),
					'placeholder'       => '---------------',
					'type'              => 'text',
					'sanitize_callback' => 'sanitize_text_field'
				],
				[
					'name'              => 'google_client_id',
					'label'             => esc_html__('Google Client ID', 'bdthemes-element-pack'),
					'desc'              => __('Go to your Google <a href="https://console.developers.google.com/" target="_blank">developer</a> > Account.', 'bdthemes-element-pack'),
					'placeholder'       => '---------------',
					'type'              => 'text',
					'sanitize_callback' => 'sanitize_text_field'
				],

				[
					'name' => 'social_login_group_end',
					'type' => 'end_group',
				],


				//                [
				//                    'name'              => 'instagram_access_token',
				//                    'label'             => esc_html__( 'Instagram Access Token', 'bdthemes-element-pack' ),
				//                    'desc'              => __( 'Go to <a href="https://instagram.pixelunion.net/" target="_blank">This Link</a> and Generate the access token then copy and paste here.', 'bdthemes-element-pack' ),
				//                    'placeholder'       => '---------------',
				//                    'type'              => 'text',
				//                    'sanitize_callback' => 'sanitize_text_field'
				//                ],
				[
					'name'      => 'instagram_group_start',
					'label'     => esc_html__('Instagram Access', 'bdthemes-element-pack'),
					'desc'      => __('Go to <a href="https://developers.facebook.com/docs/instagram-basic-display-api/getting-started" target="_blank">https://developers.facebook.com/docs/instagram-basic-display-api/getting-started</a> for create your Consumer key and Access Token.', 'bdthemes-element-pack'),
					'type'      => 'start_group',
					'video_url' => 'https://youtu.be/IrQVteaaAow',
				],

				[
					'name'              => 'instagram_app_id',
					'label'             => esc_html__('Instagram App ID', 'bdthemes-element-pack'),
					'placeholder'       => '---------------',
					'type'              => 'text',
					'sanitize_callback' => 'sanitize_text_field'
				],
				[
					'name'              => 'instagram_app_secret',
					'label'             => esc_html__('Instagram App Secret', 'bdthemes-element-pack'),
					'placeholder'       => '---------------',
					'type'              => 'text',
					'sanitize_callback' => 'sanitize_text_field'
				],

				[
					'name'              => 'instagram_access_token',
					'label'             => esc_html__('Instagram Access Token', 'bdthemes-element-pack'),
					'desc'              => __('Go to <a href="https://developers.facebook.com/docs/instagram-basic-display-api/getting-started" target="_blank">This Link</a> and Generate the access token then copy and paste here.', 'bdthemes-element-pack'),
					'placeholder'       => '---------------',
					'type'              => 'text',
					'sanitize_callback' => 'sanitize_text_field'
				],

				[
					'name' => 'instagram_group_end',
					'type' => 'end_group',
				],

				[
					'name'      => 'twitter_group_start',
					'label'     => esc_html__('Twitter Access', 'bdthemes-element-pack'),
					'desc'      => __('Go to <a href="https://developer.twitter.com/en" target="_blank">https://developer.twitter.com/en</a> for create your Consumer key and Access Token.', 'bdthemes-element-pack'),
					'type'      => 'start_group',
					'video_url' => 'https://youtu.be/IrQVteaaAow',
				],

				[
					'name'              => 'twitter_name',
					'label'             => esc_html__('User Name', 'bdthemes-element-pack'),
					'placeholder'       => 'for example: bdthemescom',
					'type'              => 'text',
					'sanitize_callback' => 'sanitize_text_field'
				],
				[
					'name'              => 'twitter_consumer_key',
					'label'             => esc_html__('Consumer Key', 'bdthemes-element-pack'),
					'placeholder'       => '',
					'type'              => 'text',
					'sanitize_callback' => 'sanitize_text_field'
				],
				[
					'name'              => 'twitter_consumer_secret',
					'label'             => esc_html__('Consumer Secret', 'bdthemes-element-pack'),
					'placeholder'       => '',
					'type'              => 'text',
					'sanitize_callback' => 'sanitize_text_field'
				],
				[
					'name'              => 'twitter_access_token',
					'label'             => esc_html__('Access Token', 'bdthemes-element-pack'),
					'placeholder'       => '',
					'type'              => 'text',
					'sanitize_callback' => 'sanitize_text_field'
				],
				[
					'name'              => 'twitter_access_token_secret',
					'label'             => esc_html__('Access Token Secret', 'bdthemes-element-pack'),
					'placeholder'       => '',
					'type'              => 'text',
					'sanitize_callback' => 'sanitize_text_field'
				],
				[
					'name' => 'twitter_group_end',
					'type' => 'end_group',
				],

				[
					'name'  => 'recaptcha_group_start',
					'label' => esc_html__('reCAPTCHA Access', 'bdthemes-element-pack'),
					'desc'  => __('Go to your Google <a href="https://www.google.com/recaptcha/" target="_blank">reCAPTCHA</a> > Account > Generate Keys (reCAPTCHA V2 > Invisible) and Copy and Paste here.', 'bdthemes-element-pack'),
					'type'  => 'start_group',
				],

				[
					'name'              => 'recaptcha_site_key',
					'label'             => esc_html__('Site key', 'bdthemes-element-pack'),
					'placeholder'       => '',
					'type'              => 'text',
					'sanitize_callback' => 'sanitize_text_field'
				],
				[
					'name'              => 'recaptcha_secret_key',
					'label'             => esc_html__('Secret key', 'bdthemes-element-pack'),
					'placeholder'       => '',
					'type'              => 'text',
					'sanitize_callback' => 'sanitize_text_field'
				],

				[
					'name' => 'recaptcha_group_end',
					'type' => 'end_group',
				],

				[
					'name'  => 'google_sheets_group_start',
					'label' => esc_html__('Google Sheets Access', 'bdthemes-element-pack'),
					'desc'  => __('Configure Google Sheets API settings for webhook form integration. <a class="bdt-text-warning" href="https://bdthemes.com/knowledge-base/element-pack-pro-google-sheet-integration/" target="_blank">Documentation</a>', 'bdthemes-element-pack'),
					'type'  => 'start_group',
				],

				[
					'name'              => 'google_sheets_client_id',
					'label'             => esc_html__('Client ID', 'bdthemes-element-pack'),
					'placeholder'       => '123456789-example.apps.googleusercontent.com',
					'type'              => 'text',
					'sanitize_callback' => 'sanitize_text_field'
				],

				[
					'name'              => 'google_sheets_client_secret',
					'label'             => esc_html__('Client Secret', 'bdthemes-element-pack'),
					'placeholder'       => '1234567890',
					'type'              => 'text',
					'sanitize_callback' => 'sanitize_text_field'
				],

				[
					'name' => 'google_sheets_group_end',
					'type' => 'end_group',
				],

				[
					'name'  => 'mailchimp_group_start',
					'label' => esc_html__('Mailchimp Access', 'bdthemes-element-pack'),
					'desc'  => __('Go to your Mailchimp > Website > Domains > Extras > API Keys (<a href="http://prntscr.com/xqo78x" target="_blank">http://prntscr.com/xqo78x</a>) then create a key and paste here. You will get the audience ID here: <a href="http://prntscr.com/xqnt5z" target="_blank">http://prntscr.com/xqnt5z</a>', 'bdthemes-element-pack'),
					'type'  => 'start_group',
				],


				[
					'name'              => 'mailchimp_api_key',
					'label'             => esc_html__('Mailchimp API Key', 'bdthemes-element-pack'),
					'placeholder'       => '',
					'type'              => 'text',
					'sanitize_callback' => 'sanitize_text_field'
				],
				[
					'name'              => 'mailchimp_list_id',
					'label'             => esc_html__('Audience ID', 'bdthemes-element-pack'),
					'placeholder'       => '',
					'type'              => 'text',
					'sanitize_callback' => 'sanitize_text_field'
				],

				[
					'name' => 'mailchimp_group_end',
					'type' => 'end_group',
				],

				[
					'name'  => 'yelp_social_group_start',
					'label' => esc_html__('Yelp Access', 'bdthemes-element-pack'),
					'desc'  => __('Go to your <a href="https://www.yelp.com/developers/v3/manage_app" target="_blank">Yelp Developer Account</a> to get access client ID and Key. This credential need for Social Proof widget.', 'bdthemes-element-pack'),
					'type'  => 'start_group',
				],

				[
					'name'              => 'yelp_client_id',
					'label'             => esc_html__('Yelp Client ID', 'bdthemes-element-pack'),
					'placeholder'       => '',
					'type'              => 'text',
					'sanitize_callback' => 'sanitize_text_field'
				],
				[
					'name'              => 'yelp_api_key',
					'label'             => esc_html__('Yelp API Key', 'bdthemes-element-pack'),
					'placeholder'       => '',
					'type'              => 'text',
					'sanitize_callback' => 'sanitize_text_field'
				],

				[
					'name' => 'yelp_social_group_end',
					'type' => 'end_group',
				],

				[
					'name'  => 'weather_group_start',
					'label' => esc_html__('Weather API Access', 'bdthemes-element-pack'),
					'desc'  => __('Please choose your Weather provider, both provider has the free and paid package.', 'bdthemes-element-pack'),
					'type'  => 'start_group',
				],
				[
					'name'              => 'weatherstack_api_key',
					'label'             => esc_html__('WeatherStack Key', 'bdthemes-element-pack'),
					'desc'              => __('Go to <a href="https://weatherstack.com/quickstart" target="_blank">https://weatherstack.com/quickstart</a> > Copy Key and Paste here.', 'bdthemes-element-pack'),
					'placeholder'       => '',
					'type'              => 'text',
					'sanitize_callback' => 'sanitize_text_field'
				],

				[
					'name'              => 'open_weather_api_key',
					'label'             => esc_html__('Open Weather Map Key', 'bdthemes-element-pack'),
					'desc'              => __('Go to <a href="https://home.openweathermap.org/api_keys" target="_blank">https://home.openweathermap.org/api_keys</a> > Copy Key and Paste here. This api key also works for <strong>Air Pollution Widget</strong>', 'bdthemes-element-pack'),
					'placeholder'       => '',
					'type'              => 'text',
					'sanitize_callback' => 'sanitize_text_field'
				],
				[
					'name' => 'weather_group_end',
					'type' => 'end_group',
				],
				

				[
					'name'  => 'contact_form_group_start',
					'label' => esc_html__('Simple Contact Form ', 'bdthemes-element-pack'),
					'desc'  => __('Set your simple contact form settings from here.', 'bdthemes-element-pack'),
					'type'  => 'start_group',
				],

				[
					'name'              => 'contact_form_email',
					'label'             => esc_html__('Contact Form Email', 'bdthemes-element-pack'),
					'desc'              => __('You can set alternative email for simple contact form', 'bdthemes-element-pack'),
					'placeholder'       => 'example@email.com',
					'type'              => 'text',
					'sanitize_callback' => 'sanitize_text_field'
				],
				[
					'name'              => 'contact_form_spam_email',
					'label'             => esc_html__('Spam Email List', 'bdthemes-element-pack'),
					'desc'              => __('add spam email here for block spamming from your contact form. multiple email separated by comma (,).', 'bdthemes-element-pack'),
					'placeholder'       => 'example@email.com, example2@email.com',
					'type'              => 'textarea',
					'sanitize_callback' => 'sanitize_text_field'
				],

				[
					'name' => 'contact_form_group_end',
					'type' => 'end_group',
				],

				[
					'name'  => 'fb_social_group_start',
					'label' => esc_html__('Facebook Social Access', 'bdthemes-element-pack'),
					'desc'  => __('Go to your <a href="https://developers.facebook.com/apps/" target="_blank">Facebook Developer Account</a> to get access Page ID and Access Token. This credential need for Social Feeds widget.', 'bdthemes-element-pack'),
					'type'  => 'start_group',
				],
				[
					'name'              => 'fb_page_id',
					'label'             => esc_html__('Facebook Page ID', 'bdthemes-element-pack'),
					'placeholder'       => '',
					'type'              => 'text',
					'sanitize_callback' => 'sanitize_text_field'
				],
				[
					'name'              => 'fb_access_token',
					'label'             => esc_html__('Facebook Access Token', 'bdthemes-element-pack'),
					'placeholder'       => '',
					'type'              => 'text',
					'sanitize_callback' => 'sanitize_text_field'
				],
				[
					'name' => 'fb_social_group_end',
					'type' => 'end_group',
				],

			],
			'element_pack_other_settings'   => [

				[
					'name'        => 'asset-manager',
					'label'       => esc_html__('Asset Manager', 'bdthemes-element-pack'),
					'tooltip'  => __('Joins the CSS and JS of the widgets each page uses into combined files, so a page loads only what it renders, in fewer files.', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'free',
					'demo_url'    => 'https://bdthemes.com/knowledge-base/asset-manager/',
					'video_url'   => 'https://youtu.be/nytQFZv_CSs',
				],

				[
					'name'        => 'mega-menu',
					'label'       => esc_html__('Mega Menu', 'bdthemes-element-pack'),
					'tooltip'  => __('The Mega Menu by Element Pack Pro allows the users to create organized and oversized menus with full custom layouts having images, columns, sliders, icons, forms, buttons, and lots of links. This is one of the most demanding feature and now it is in your hands.', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'pro',
					'demo_url'    => 'https://bdthemes.com/knowledge-base/mega-menu-widget/',
					'video_url'   => 'https://youtu.be/ZOBLWIZvGLs',
				],

				[
					'name'        => 'dynamic-content',
					'label'       => esc_html__('Dynamic Content', 'bdthemes-element-pack'),
					'tooltip'  => __('The Dynamic Content feature allows users to automatically populate Elementor widgets with real-time data from WordPress.', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'pro',
					'content_type' => 'new',
					'demo_url'    => 'https://elementpack.pro/demo/element/dynamic-content/',
					'video_url'   => 'https://youtu.be/JEqXbIETdDE',

				],

				[
					'name'        => 'smooth-scroller',
					'label'       => esc_html__('Smooth Scroller', 'bdthemes-element-pack'),
					'tooltip'  => __('Turn on this switcher to enable the Smooth Scroller Features, The Smooth Scroller feature enhances user experience by providing seamless, visually pleasing content navigation through animated transitions.', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'pro',
					'content_type' => 'new',
					'demo_url'    => '',
					'video_url'   => 'https://youtu.be/cQnu1LUlFL8?si=5xYIZu_XlWqZOWG8',
				],
				
				[
					'name'        => 'live-copy',
					'label'       => esc_html__('Live Copy Paste', 'bdthemes-element-pack'),
					'tooltip'  => __('Live copy is a copy feature that allow you to copy and paste content from one domain to another. For example you can copy demo content directly from our demo website.', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'free',
					'demo_url'    => 'https://bdthemes.com/knowledge-base/live-copy-paste/live-copy-alternative/',
					'video_url'   => 'https://youtu.be/jOdWVw2TCmo',
				],
				
				[
					'name'        => 'essential-shortcodes',
					'label'       => esc_html__('Essential Shortcodes', 'bdthemes-element-pack'),
					'tooltip'  => __('If you need element pack essential shortcodes feature so you can do that from here. it\'s included some basic content feature that not possible by element pack.', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'pro',
					'demo_url'    => 'https://bdthemes.com/knowledge-base/element-pack-essential-shortcodes/',
					'video_url'   => 'https://youtu.be/fUMoYNa_WLY',
				],
				
				[
					'name'        => 'template-library',
					'label'       => esc_html__('Template Library (in Editor)', 'bdthemes-element-pack'),
					'tooltip'  => __('If you need to show element pack template library in your editor so please enable this option. It\'s amazing feature for elementor.', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'on',
					'widget_type' => 'free',
					'demo_url'    => '',
					'video_url'   => 'https://youtu.be/Z6XNSPSxtJw?si=XEuoQCotMQy2vJA2',
				],

				[
					'name'        => 'context-menu',
					'label'       => esc_html__('Context Menu', 'bdthemes-element-pack'),
					'tooltip'  => __('Turn on this switcher to enable the Context Menu inside "Site Settings" of Elementor Editor Page to use the right-click menu.', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'pro',
					'demo_url'    => 'https://bdthemes.com/knowledge-base/context-menu/',
					'video_url'   => 'https://youtu.be/LptQctJ22S0',
				],

				[
					'name'        => 'duplicator',
					'label'       => esc_html__('Duplicator', 'bdthemes-element-pack'),
					'tooltip'  => __('Just hit the button below to enable the duplicator. It can duplicate anything like posts,pages and elementor templates. A masterclass duplication with just one click.', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'off',
					'widget_type' => 'free',
					'demo_url'    => 'https://bdthemes.com/knowledge-base/duplicator-feature/',
                    'video_url'   => 'https://youtu.be/bCkCPzyPouE?si=S6zgjdrNDgGi-y7u',
				],

				[
					'name'        => 'svg-support',
					'label'       => esc_html__('SVG Support', 'bdthemes-element-pack'),
					'tooltip'  => __('Turn on this option to enable SVG support in your widgets & Upload Media Library.', 'bdthemes-element-pack'),
					'type'        => 'checkbox',
					'default'     => 'on',
					'widget_type' => 'free',
					'content_type' => 'new',
					'demo_url'    => '',
					'video_url'   => '',
				],
				
				[
					'name'      => 'swatches_group_start',
					'tooltip'  => __('Replace dropdowns with color swatches, image swatches or text/button swatches', 'bdthemes-element-pack'),
					'type'      => 'start_group',
					'video_url' => '',
					'content_type' => 'new'
				],
                [
                    'name'         => 'variation-swatches',
                    'label'        => esc_html__('Variation Swatches', 'bdthemes-element-pack'),
                    'tooltip'      => __('Replace dropdowns with color swatches, image swatches or text/button swatches', 'bdthemes-element-pack'),
                    'type'         => 'checkbox',
                    'default'      => "off",
                    'widget_type'  => 'pro',
                    'plugin_name'  => 'woocommerce',
                    'plugin_path'  => 'woocommerce/woocommerce.php',
                    'content_type' => 'woocommerce product',
                    'demo_url'     => 'https://elementpack.pro/demo/element/variation-swatches/',
                    'video_url'    => 'https://www.youtube.com/watch?v=qIl2mvS7mgk',
                    'ep_parent_switcher'       => true,
                ],
                [
					'name'              => 'ep_variation_swatches_shape',
					'label'             => esc_html__('Shape', 'bdthemes-element-pack'),
					'type'              => 'select',
                    'default'           => 'round',
                    'options'           => [
                        'round' => esc_html__('Default', 'bdthemes-element-pack'),
                        'square' => esc_html__('Square', 'bdthemes-element-pack'),
                        'rounded' => esc_html__('Rounded', 'bdthemes-element-pack'),
                    ],
				],

                [
					'name'              => 'ep_variation_swatches_tooltip',
					'label'             => esc_html__('Tooltip', 'bdthemes-element-pack'),
					'type'              => 'select',
                    'default'           => 'yes',
                    'options'           => [
                        'yes' => esc_html__('Default', 'bdthemes-element-pack'),
                        'no' => esc_html__('No', 'bdthemes-element-pack'),
                    ],
				],

                [
					'name'              => 'ep_variation_swatches_size',
					'label'             => esc_html__('Size', 'bdthemes-element-pack'),
					'type'              => 'number',
                    'default'           => '26',
				],

                [
					'name' => 'swatches_group_end',
					'type' => 'end_group',
				]
			]
		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'        => 'acf-accordion',
			'label'       => esc_html__('ACF Accordion', 'bdthemes-element-pack'),
			'type'        => 'checkbox',
			'default'     => 'off',
			'plugin_name' => 'advanced-custom-fields-pro',
			'plugin_path' => 'advanced-custom-fields-pro/acf.php',
			'paid'        => 'https://www.advancedcustomfields.com/pro/',
			'widget_type' => 'pro',
			'content_type' => 'acf new',
			'demo_url'    => 'https://elementpack.pro/demo/element/acf-accordion',
			'video_url'   => '',
		];
		
		$settings_fields['element_pack_third_party_widget'][] = [
			'name'        => 'acf-gallery',
			'label'       => esc_html__('ACF Gallery', 'bdthemes-element-pack'),
			'type'        => 'checkbox',
			'default'     => 'off',
			'plugin_name' => 'advanced-custom-fields-pro',
			'plugin_path' => 'advanced-custom-fields-pro/acf.php',
			'paid'        => 'https://www.advancedcustomfields.com/pro/',
			'widget_type' => 'pro',
			'content_type' => 'acf new',
			'demo_url'    => 'https://elementpack.pro/demo/element/acf-gallery',
			'video_url'   => 'https://youtu.be/U53H31MCiy4?si=OYOXb2ht-8_4a3G1',
		];
		
		$settings_fields['element_pack_third_party_widget'][] = [
			'name'        => 'acf-slider',
			'label'       => esc_html__('ACF Slider', 'bdthemes-element-pack'),
			'type'        => 'checkbox',
			'default'     => 'off',
			'plugin_name' => 'advanced-custom-fields-pro',
			'plugin_path' => 'advanced-custom-fields-pro/acf.php',
			'paid'        => 'https://www.advancedcustomfields.com/pro/',
			'widget_type' => 'pro',
			'content_type' => 'acf new',
			'demo_url'    => 'https://elementpack.pro/demo/element/acf-slider',
			'video_url'   => 'https://youtu.be/PE411IBFw0I',
		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'        => 'acf-tabs',
			'label'       => esc_html__('ACF Tabs', 'bdthemes-element-pack'),
			'type'        => 'checkbox',
			'default'     => 'off',
			'plugin_name' => 'advanced-custom-fields-pro',
			'plugin_path' => 'advanced-custom-fields-pro/acf.php',
			'paid'        => 'https://www.advancedcustomfields.com/pro/',
			'widget_type' => 'pro',
			'content_type' => 'acf new',
			'demo_url'    => 'https://elementpack.pro/demo/element/acf-tabs',
			'video_url'   => '',
		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'        => 'acf-list',
			'label'       => esc_html__('ACF List', 'bdthemes-element-pack'),
			'type'        => 'checkbox',
			'default'     => 'off',
			'plugin_name' => 'advanced-custom-fields-pro',
			'plugin_path' => 'advanced-custom-fields-pro/acf.php',
			'paid'        => 'https://www.advancedcustomfields.com/pro/',
			'widget_type' => 'pro',
			'content_type' => 'acf new',
			'demo_url'    => 'https://elementpack.pro/demo/element/acf-list',
			'video_url'   => '',
		];







		$settings_fields['element_pack_third_party_widget'][] = [
			'name'        => 'contact-form-7',
			'label'       => esc_html__('Contact Form 7', 'bdthemes-element-pack'),
			'type'        => 'checkbox',
			'default'     => 'on',
			'plugin_name' => 'contact-form-7',
			'plugin_path' => 'contact-form-7/wp-contact-form-7.php',
			'widget_type' => 'free',
			'demo_url'    => 'https://elementpack.pro/demo/element/contact-form-7/',
			'video_url'   => 'https://youtu.be/oWepfrLrAN4',

		];










		// The Easy Digital Downloads entry used to live here, but f0b38367
		// ("edd & bbpress widgets deleted") removed modules/easy-digital-downloads/
		// and the EDD widgets now ship from the Element Pack Addon as the
		// edd-* modules. Its bbPress sibling was dropped in that commit; this
		// registration was missed, leaving a checkbox for a module that could
		// never load.

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'        => 'events-calendar-grid',
			'label'       => esc_html__('Events Calendar Grid', 'bdthemes-element-pack'),
			'type'        => 'checkbox',
			'default'     => 'off',
			'plugin_name' => 'the-events-calendar',
			'plugin_path' => 'the-events-calendar/the-events-calendar.php',
			'widget_type' => 'free',
			'demo_url'    => 'https://elementpack.pro/demo/element/events-calendar-grid/',
			'video_url'   => 'https://youtu.be/QeqrcDx1Vus',
		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'        => 'events-calendar-carousel',
			'label'       => esc_html__('Events Calendar Carousel', 'bdthemes-element-pack'),
			'type'        => 'checkbox',
			'default'     => 'off',
			'plugin_name' => 'the-events-calendar',
			'plugin_path' => 'the-events-calendar/the-events-calendar.php',
			'widget_type' => 'pro',
			'demo_url'    => 'https://elementpack.pro/demo/element/events-calendar-carousel/',
			'video_url'   => 'https://youtu.be/_ZPPBmKmGGg',
		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'        => 'events-calendar-list',
			'label'       => esc_html__('Events Calendar List', 'bdthemes-element-pack'),
			'type'        => 'checkbox',
			'default'     => 'off',
			'plugin_name' => 'the-events-calendar',
			'plugin_path' => 'the-events-calendar/the-events-calendar.php',
			'widget_type' => 'pro',
			'demo_url'    => 'https://elementpack.pro/demo/element/events-calendar-list/',
			'video_url'   => '',
		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'        => 'fooevents-calendar',
			'label'       => esc_html__('FooEvents Calendar', 'bdthemes-element-pack'),
			'type'        => 'checkbox',
			'default'     => 'off',
			'plugin_name' => 'fooevents-calendar',
			'plugin_path' => 'fooevents-calendar/fooevents-calendar.php',
			'widget_type' => 'pro',
			'content_type' => 'others new',
			'demo_url'    => 'https://elementpack.pro/demo/element/fooevents-calendar/',
			'video_url'   => '',
		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'         => 'fooevents-calendar-events',
			'label'        => esc_html__( 'FooEvents Calendar Events', 'bdthemes-element-pack' ),
			'type'         => 'checkbox',
			'default'      => 'off',
			'plugin_name'  => 'fooevents-calendar',
			'plugin_path'  => 'fooevents-calendar/fooevents-calendar.php',
			'widget_type'  => 'pro',
			'content_type' => 'others new',
			'demo_url'     => 'https://elementpack.pro/demo/element/fooevents-calendar-events/',
			'video_url'    => '',
		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'         => 'fooevents-calendar-carousel',
			'label'        => esc_html__( 'FooEvents Calendar Carousel', 'bdthemes-element-pack' ),
			'type'         => 'checkbox',
			'default'      => 'off',
			'plugin_name'  => 'fooevents-calendar',
			'plugin_path'  => 'fooevents-calendar/fooevents-calendar.php',
			'widget_type'  => 'pro',
			'content_type' => 'others new',
			'demo_url'     => 'https://elementpack.pro/demo/element/fooevents-calendar-carousel/',
			'video_url'    => '',
		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'         => 'faq',
			'label'        => esc_html__('FAQ', 'bdthemes-element-pack'),
			'type'         => 'checkbox',
			'default'      => 'off',
			'plugin_name'  => 'bdthemes-faq',
			'plugin_path'  => 'bdthemes-faq/bdthemes-faq.php',
			'paid'         => 'https://bdthemes.com/secure/plugins/bdthemes-faq.zip?key=849686abd67b099b7cdbc7cfeff49ed8',
			'widget_type'  => 'pro',
			'content_type' => 'post',
			'demo_url'     => 'https://elementpack.pro/demo/element/faq/',
			'video_url'    => 'https://youtu.be/jGGdCuSjesY',
		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'         => 'fluent-forms',
			'label'        => esc_html__('Fluent Forms', 'bdthemes-element-pack'),
			'type'         => 'checkbox',
			'default'      => 'off',
			'plugin_name'  => 'fluentform',
			'plugin_path'  => 'fluentform/fluentform.php',
			'widget_type'  => 'free',
			'content_type' => 'forms',
			'demo_url'     => 'https://elementpack.pro/demo/element/fluent-forms/',
			'video_url'    => 'https://youtu.be/BWPuKe4PfQ4',

		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'         => 'formidable-forms',
			'label'        => esc_html__('Formidable Forms', 'bdthemes-element-pack'),
			'type'         => 'checkbox',
			'default'      => 'off',
			'plugin_name'  => 'formidable',
			'plugin_path'  => 'formidable/formidable.php',
			'widget_type'  => 'free',
			'content_type' => 'forms',
			'demo_url'     => 'https://elementpack.pro/demo/element/formidable-forms/',
			'video_url'    => 'https://youtu.be/ZQzcED7S-XI',
		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'         => 'forminator-forms',
			'label'        => esc_html__('Forminator Forms', 'bdthemes-element-pack'),
			'type'         => 'checkbox',
			'default'      => 'off',
			'plugin_name'  => 'forminator',
			'plugin_path'  => 'forminator/forminator.php',
			'widget_type'  => 'free',
			'content_type' => 'forms',
			'demo_url'     => 'https://elementpack.pro/demo/element/forminator-forms/',
			'video_url'    => 'https://youtu.be/DdBvY0dnGsk',

		];











		$settings_fields['element_pack_third_party_widget'][] = [
			'name'         => 'gravity-forms',
			'label'        => esc_html__('Gravity Forms', 'bdthemes-element-pack'),
			'type'         => 'checkbox',
			'default'      => 'on',
			'plugin_name'  => 'gravityforms',
			'plugin_path'  => 'gravityforms/gravityforms.php',
			'paid'         => 'https://www.gravityforms.com/',
			'widget_type'  => 'free',
			'content_type' => 'forms',
			'demo_url'     => 'https://elementpack.pro/demo/element/gravity-forms/',
			'video_url'    => 'https://youtu.be/452ZExESiBI',

		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'        => 'instagram-feed',
			'label'       => esc_html__('Instagram Feed', 'bdthemes-element-pack'),
			'type'        => 'checkbox',
			'default'     => 'on',
			'plugin_name' => 'instagram-feed',
			'plugin_path' => 'instagram-feed/instagram-feed.php',
			'widget_type' => 'pro',
			'demo_url'    => 'https://elementpack.pro/demo/element/instagram-feed/',
			'video_url'   => 'https://youtu.be/Wf7naA7EL7s',

		];


		$settings_fields['element_pack_third_party_widget'][] = [
			'name'        => 'learnpress-grid',
			'label'       => esc_html__('LearnPress Grid', 'bdthemes-element-pack'),
			'type'        => 'checkbox',
			'default'     => 'off',
			'plugin_name' => 'learnpress',
			'plugin_path' => 'learnpress/learnpress.php',
			'widget_type' => 'pro',
			'demo_url'    => 'https://elementpack.pro/demo/element/learnpress-grid/',
			'video_url'   => '',
		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'         => 'learnpress-carousel',
			'label'        => esc_html__('LearnPress Carousel', 'bdthemes-element-pack'),
			'type'         => 'checkbox',
			'default'      => 'off',
			'plugin_name'  => 'learnpress',
			'plugin_path'  => 'learnpress/learnpress.php',
			'widget_type'  => 'pro',
			'content_type' => 'carousel',
			'demo_url'     => 'https://elementpack.pro/demo/element/learnpress-carousel/',
			'video_url'    => '',
		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'        => 'mailchimp-for-wp',
			'label'       => esc_html__('Mailchimp For WP', 'bdthemes-element-pack'),
			'type'        => 'checkbox',
			'default'     => 'on',
			'plugin_name' => 'mailchimp-for-wp',
			'plugin_path' => 'mailchimp-for-wp/mailchimp-for-wp.php',
			'widget_type' => 'pro',
			'demo_url'    => 'https://elementpack.pro/demo/element/mailchimp-for-wordpress',
			'video_url'   => 'https://youtu.be/AVqliwiyMLg',

		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'         => 'ninja-forms',
			'label'        => esc_html__('Ninja Forms', 'bdthemes-element-pack'),
			'type'         => 'checkbox',
			'default'      => 'on',
			'plugin_name'  => 'ninja-forms',
			'plugin_path'  => 'ninja-forms/ninja-forms.php',
			'widget_type'  => 'free',
			'content_type' => 'forms',
			'demo_url'     => 'https://elementpack.pro/demo/element/ninja-forms/',
			'video_url'    => 'https://youtu.be/rMKAUIy1fKc',

		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'         => 'portfolio-gallery',
			'label'        => esc_html__('Portfolio Gallery', 'bdthemes-element-pack'),
			'type'         => 'checkbox',
			'default'      => 'on',
			'plugin_name'  => 'bdthemes-portfolio',
			'plugin_path'  => 'bdthemes-portfolio/bdthemes-portfolio.php',
			'paid'         => 'https://bdthemes.com/secure/plugins/bdthemes-portfolio.zip?key=40fb823b8016d31411a7fe281f41044g',
			'widget_type'  => 'pro',
			'content_type' => 'post',
			'demo_url'     => 'https://elementpack.pro/demo/element/portfolio-gallery/',
			'video_url'    => 'https://youtu.be/dkKPuZwWFks',

		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'         => 'portfolio-carousel',
			'label'        => esc_html__('Portfolio Carousel', 'bdthemes-element-pack'),
			'type'         => 'checkbox',
			'default'      => 'on',
			'plugin_name'  => 'bdthemes-portfolio',
			'plugin_path'  => 'bdthemes-portfolio/bdthemes-portfolio.php',
			'paid'         => 'https://bdthemes.com/secure/plugins/bdthemes-portfolio.zip?key=40fb823b8016d31411a7fe281f41044g',
			'widget_type'  => 'pro',
			'content_type' => 'post',
			'demo_url'     => 'https://elementpack.pro/demo/element/portfolio-carousel/',
			'video_url'    => 'https://youtu.be/6fMQzv47HTU',

		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'         => 'portfolio-list',
			'label'        => esc_html__('Portfolio List', 'bdthemes-element-pack'),
			'type'         => 'checkbox',
			'default'      => 'on',
			'plugin_name'  => 'bdthemes-portfolio',
			'plugin_path'  => 'bdthemes-portfolio/bdthemes-portfolio.php',
			'paid'         => 'https://bdthemes.com/secure/plugins/bdthemes-portfolio.zip?key=40fb823b8016d31411a7fe281f41044g',
			'widget_type'  => 'pro',
			'content_type' => 'post',
			'demo_url'     => 'https://elementpack.pro/demo/element/portfolio-list/',
			'video_url'    => 'https://youtu.be/WdXZMoEEn4I',

		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'         => 'quform',
			'label'        => esc_html__('QuForm', 'bdthemes-element-pack'),
			'type'         => 'checkbox',
			'default'      => 'on',
			'plugin_name'  => 'quform',
			'plugin_path'  => 'quform/quform.php',
			'paid'         => 'https://codecanyon.net/item/quform-wordpress-form-builder/706149',
			'widget_type'  => 'pro',
			'content_type' => 'forms',
			'demo_url'     => 'https://elementpack.pro/demo/element/quform/',
			'video_url'    => 'https://youtu.be/LM0JtQ58UJM',

		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'        => 'revolution-slider',
			'label'       => esc_html__('Revolution Slider', 'bdthemes-element-pack'),
			'type'        => 'checkbox',
			'default'     => 'on',
			'plugin_name' => 'revslider',
			'plugin_path' => 'revslider/revslider.php',
			'paid'        => 'https://codecanyon.net/item/slider-revolution-responsive-wordpress-plugin/2751380',
			'widget_type' => 'pro',
			'demo_url'    => 'https://elementpack.pro/demo/element/revolution-slider/',
			'video_url'   => 'https://youtu.be/S3bs8FfTBsI',

		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'        => 'tablepress',
			'label'       => esc_html__('TablePress', 'bdthemes-element-pack'),
			'type'        => 'checkbox',
			'default'     => 'on',
			'plugin_name' => 'tablepress',
			'plugin_path' => 'tablepress/tablepress.php',
			'widget_type' => 'pro',
			'demo_url'    => 'https://elementpack.pro/demo/element/tablepress/',
			'video_url'   => 'https://youtu.be/TGnc0ap-cWs',
		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'         => 'testimonial-carousel',
			'label'        => esc_html__('Testimonial Carousel', 'bdthemes-element-pack'),
			'type'         => 'checkbox',
			'default'      => 'on',
			'plugin_name'  => 'bdthemes-testimonials',
			'plugin_path'  => 'bdthemes-testimonials/bdthemes-testimonials.php',
			'paid'         => 'https://bdthemes.com/secure/plugins/bdthemes-testimonials.zip?key=40fb823b8016d31411a7fe281f41044g',
			'widget_type'  => 'pro',
			'content_type' => 'post carousel',
			'demo_url'     => 'https://elementpack.pro/demo/element/testimonial-carousel/',
			'video_url'    => 'https://youtu.be/VbojVJzayvE',
		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'         => 'testimonial-grid',
			'label'        => esc_html__('Testimonial Grid', 'bdthemes-element-pack'),
			'type'         => 'checkbox',
			'default'      => 'on',
			'plugin_name'  => 'bdthemes-testimonials',
			'plugin_path'  => 'bdthemes-testimonials/bdthemes-testimonials.php',
			'paid'         => 'https://bdthemes.com/secure/plugins/bdthemes-testimonials.zip?key=40fb823b8016d31411a7fe281f41044g',
			'widget_type'  => 'free',
			'content_type' => 'post',
			'demo_url'     => 'https://elementpack.pro/demo/element/testimonial-grid/',
			'video_url'    => 'https://youtu.be/pYMTXyDn8g4',
		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'         => 'testimonial-slider',
			'label'        => esc_html__('Testimonial Slider', 'bdthemes-element-pack'),
			'type'         => 'checkbox',
			'default'      => 'on',
			'plugin_name'  => 'bdthemes-testimonials',
			'plugin_path'  => 'bdthemes-testimonials/bdthemes-testimonials.php',
			'paid'         => 'https://bdthemes.com/secure/plugins/bdthemes-testimonials.zip?key=40fb823b8016d31411a7fe281f41044g',
			'widget_type'  => 'pro',
			'content_type' => 'post',
			'demo_url'     => 'https://elementpack.pro/demo/element/testimonial-slider/',
			'video_url'    => 'https://youtu.be/pI-DLKNlTGg',
		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'         => 'the-newsletter',
			'label'        => esc_html__('The Newsletter', 'bdthemes-element-pack'),
			'type'         => 'checkbox',
			'default'      => 'off',
			'plugin_name'  => 'newsletter',
			'plugin_path'  => 'newsletter/plugin.php',
			'widget_type'  => 'pro',
			'content_type' => 'forms',
			'demo_url'     => 'https://elementpack.pro/demo/element/the-newsletter/',
			'video_url'    => 'https://youtu.be/nFbzp1Pttf4',
		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'        => 'tutor-lms-course-grid',
			'label'       => esc_html__('Tutor LMS Grid', 'bdthemes-element-pack'),
			'type'        => 'checkbox',
			'default'     => 'on',
			'plugin_name' => 'tutor',
			'plugin_path' => 'tutor/tutor.php',
			'widget_type' => 'free',
			'demo_url'    => 'https://elementpack.pro/demo/element/tutor-lms-course-grid/',
			'video_url'   => 'https://youtu.be/WWCE-_Po1uo',
		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'        => 'tutor-lms-course-carousel',
			'label'       => esc_html__('Tutor LMS Carousel', 'bdthemes-element-pack'),
			'type'        => 'checkbox',
			'default'     => 'on',
			'plugin_name' => 'tutor',
			'plugin_path' => 'tutor/tutor.php',
			'widget_type' => 'free',
			'demo_url'    => 'https://elementpack.pro/demo/element/tutor-lms-course-carousel/',
			'video_url'   => 'https://youtu.be/VYrIYQESjXs',
		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'         => 'wc-products',
			'label'        => esc_html__('Woocommerce Products', 'bdthemes-element-pack'),
			'type'         => 'checkbox',
			'default'      => 'on',
			'plugin_name'  => 'woocommerce',
			'plugin_path'  => 'woocommerce/woocommerce.php',
			'widget_type'  => 'pro',
			'content_type' => 'ecommerce grid gallery',
			'demo_url'     => 'https://elementpack.pro/demo/element/woocommerce-products/',
			'video_url'    => 'https://youtu.be/3VkvEpVaNAM',
		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'         => 'wc-add-to-cart',
			'label'        => esc_html__('WooCommerce Add To Cart', 'bdthemes-element-pack'),
			'type'         => 'checkbox',
			'default'      => 'on',
			'plugin_name'  => 'woocommerce',
			'plugin_path'  => 'woocommerce/woocommerce.php',
			'widget_type'  => 'pro',
			'content_type' => 'ecommerce',
			'demo_url'     => 'https://elementpack.pro/demo/element/woocommerce-add-to-cart/',
			'video_url'    => 'https://youtu.be/1gZJm2-xMqY',
		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'         => 'wc-elements',
			'label'        => esc_html__('WooCommerce Elements', 'bdthemes-element-pack'),
			'type'         => 'checkbox',
			'default'      => 'on',
			'plugin_name'  => 'woocommerce',
			'plugin_path'  => 'woocommerce/woocommerce.php',
			'widget_type'  => 'pro',
			'content_type' => 'ecommerce',
			'demo_url'     => 'https://elementpack.pro/demo/element/woocommerce-checkout-page/',
			'video_url'    => 'https://youtu.be/9IoAw7MUomA?si=LGU9PzwZ1Wx4Jm5k',
		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'         => 'wc-categories',
			'label'        => esc_html__('WooCommerce Categories', 'bdthemes-element-pack'),
			'type'         => 'checkbox',
			'default'      => 'on',
			'plugin_name'  => 'woocommerce',
			'plugin_path'  => 'woocommerce/woocommerce.php',
			'widget_type'  => 'pro',
			'content_type' => 'ecommerce grid gallery',
			'demo_url'     => 'https://elementpack.pro/demo/element/woocommerce-categories/',
			'video_url'    => 'https://youtu.be/SJuArqtnC1U',
		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'         => 'wc-carousel',
			'label'        => esc_html__('WooCommerce Carousel', 'bdthemes-element-pack'),
			'type'         => 'checkbox',
			'default'      => 'on',
			'plugin_name'  => 'woocommerce',
			'plugin_path'  => 'woocommerce/woocommerce.php',
			'widget_type'  => 'pro',
			'content_type' => 'ecommerce carousel',
			'demo_url'     => 'https://elementpack.pro/demo/element/woocommerce-carousel/',
			'video_url'    => 'https://youtu.be/5lxli5E9pc4',
		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'         => 'wc-slider',
			'label'        => esc_html__('WooCommerce Slider', 'bdthemes-element-pack'),
			'type'         => 'checkbox',
			'default'      => 'on',
			'plugin_name'  => 'woocommerce',
			'plugin_path'  => 'woocommerce/woocommerce.php',
			'widget_type'  => 'pro',
			'content_type' => 'ecommerce slider',
			'demo_url'     => 'https://elementpack.pro/demo/element/woocommerce-slider',
			'video_url'    => 'https://youtu.be/ic8p-3jO35U',
		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'         => 'wc-mini-cart',
			'label'        => esc_html__('WooCommerce Mini Cart', 'bdthemes-element-pack'),
			'type'         => 'checkbox',
			'default'      => 'on',
			'plugin_name'  => 'woocommerce',
			'plugin_path'  => 'woocommerce/woocommerce.php',
			'widget_type'  => 'pro',
			'content_type' => 'ecommerce slider',
			'demo_url'     => 'https://elementpack.pro/demo/element/woocommerce-slider',
			'video_url'    => 'https://youtu.be/ic8p-3jO35U',
		];

		$settings_fields['element_pack_third_party_widget'][] = [
			'name'         => 'we-forms',
			'label'        => esc_html__('weForms', 'bdthemes-element-pack'),
			'type'         => 'checkbox',
			'default'      => 'off',
			'plugin_name'  => 'weforms',
			'plugin_path'  => 'weforms/weforms.php',
			'widget_type'  => 'free',
			'content_type' => 'forms',
			'demo_url'     => 'https://elementpack.pro/demo/element/we-forms/',
			'video_url'    => 'https://youtu.be/D-vUfbMclOk',
		];

		if (ModuleService::_is_plugin_installed('wpforms-lite', 'wpforms-lite/wpforms.php') === true && is_plugin_active('wpforms/wpforms.php') !== true) {
			$settings_fields['element_pack_third_party_widget'][] = [
				'name'         => 'wp-forms',
				'label'        => esc_html__('Wp Forms', 'bdthemes-element-pack'),
				'type'         => 'checkbox',
				'default'      => 'on',
				'plugin_name'  => 'wpforms-lite',
				'plugin_path'  => 'wpforms-lite/wpforms.php',
				'paid'         => 'https://wpforms.com/pricing/',
				'widget_type'  => 'pro',
				'content_type' => 'forms',
				'demo_url'     => 'https://elementpack.pro/demo/element/wp-forms/',
				'video_url'    => 'https://youtu.be/p_FRLsEVNjQ',
			];
		} else {
			$settings_fields['element_pack_third_party_widget'][] = [
				'name'         => 'wp-forms',
				'label'        => esc_html__('Wp Forms', 'bdthemes-element-pack'),
				'type'         => 'checkbox',
				'default'      => 'on',
				'plugin_name'  => 'wpforms',
				'plugin_path'  => 'wpforms/wpforms.php',
				'paid'         => 'https://wpforms.com/pricing/',
				'widget_type'  => 'pro',
				'content_type' => 'forms',
				'demo_url'     => 'https://elementpack.pro/demo/element/wp-forms/',
				'video_url'    => 'https://youtu.be/p_FRLsEVNjQ',
			];
		}

		/**
		 * Let companion plugins (currently Element Pack Addon) append their own
		 * module entries to the three tiers. Filtered before the per-request memo
		 * so every consumer — dashboard, editor, permission manager and the
		 * front-end loader — sees exactly the same list.
		 *
		 * @param array $settings_fields Tier name => list of module entries.
		 */
		$filtered = apply_filters('element_pack/modules/settings_fields', $settings_fields);
		if (is_array($filtered)) {
			$settings_fields = $filtered;
		}

		$settings = [];
		$settings['settings_fields'] = $settings_fields;

		self::$settings_cache = $settings;

		return $callable($settings);
	}

	/**
	 * Per-request memo of the normalised external-module map.
	 *
	 * @var array<string, array{dir: string, url: string, namespace: string, version: string}>|null
	 */
	private static $external_modules_cache = null;

	/**
	 * Modules that live in a companion plugin instead of this one.
	 *
	 * A companion plugin (currently Element Pack Addon, which carries the legacy
	 * widgets removed from Pro) registers its modules through the
	 * `element_pack/modules/external_sources` filter:
	 *
	 *     add_filter( 'element_pack/modules/external_sources', function ( $sources ) {
	 *         $sources['my-widget'] = [
	 *             'dir'       => MY_PLUGIN_PATH,            // plugin root, trailing slash optional
	 *             'url'       => MY_PLUGIN_URL,             // plugin root URL
	 *             'namespace' => 'MyPlugin',                // root PHP namespace
	 *             'version'   => MY_PLUGIN_VER,             // optional, defaults to BDTEP_VER
	 *         ];
	 *         return $sources;
	 *     } );
	 *
	 * Entries missing dir/url/namespace, or keyed by anything other than a module
	 * slug, are dropped so a malformed registration can never produce a bad path.
	 *
	 * @return array<string, array{dir: string, url: string, namespace: string, version: string}>
	 */
	public static function get_external_modules() {
		if (is_array(self::$external_modules_cache)) {
			return self::$external_modules_cache;
		}

		$sources = apply_filters('element_pack/modules/external_sources', []);
		$modules = [];

		if (is_array($sources)) {
			foreach ($sources as $slug => $source) {
				if (!is_string($slug) || '' === $slug || !is_array($source)) {
					continue;
				}

				$dir       = isset($source['dir']) ? (string) $source['dir'] : '';
				$url       = isset($source['url']) ? (string) $source['url'] : '';
				$namespace = isset($source['namespace']) ? trim((string) $source['namespace'], '\\') : '';

				if ('' === $dir || '' === $url || '' === $namespace) {
					continue;
				}

				$modules[$slug] = [
					'dir'       => rtrim($dir, '/\\') . '/',
					'url'       => rtrim($url, '/') . '/',
					'namespace' => $namespace,
					'version'   => isset($source['version']) && $source['version'] ? (string) $source['version'] : BDTEP_VER,
				];
			}
		}

		return self::$external_modules_cache = $modules;
	}

	/**
	 * The external source for one module, or null when it ships with Pro.
	 *
	 * @param string $module_id
	 * @return array{dir: string, url: string, namespace: string, version: string}|null
	 */
	public static function get_external_module($module_id) {
		$modules = self::get_external_modules();

		return isset($modules[$module_id]) ? $modules[$module_id] : null;
	}

	/**
	 * Absolute path of a module folder, wherever the module lives (no trailing slash).
	 *
	 * @param string $module_id
	 * @return string
	 */
	public static function get_module_dir($module_id) {
		$external = self::get_external_module($module_id);

		if ($external) {
			return $external['dir'] . 'modules/' . $module_id;
		}

		return BDTEP_MODULES_PATH . $module_id;
	}

	private static function _is_plugin_installed($plugin, $plugin_path) {
		$installed_plugins = get_plugins();
		return isset($installed_plugins[$plugin_path]);
	}

	/**
	 * Per-request cache of parsed module.info.php files.
	 *
	 * Previously is_module_active(), has_module_style() and has_module_script()
	 * each ran their own file_exists() + require on every call, so the same
	 * module.info.php was stat'd and parsed up to 3x per module per page load
	 * (and the script/style checks run for every enabled module). Caching the
	 * parsed array collapses that to a single read per module per request.
	 *
	 * @var array<string, array|null>
	 */
	private static $module_info_cache = [];

	/**
	 * Read and memoize a module's module.info.php metadata.
	 *
	 * @param string $module_id
	 * @return array|null Parsed metadata, or null when the module has no info file.
	 */
	private static function get_module_info($module_id) {
		if (array_key_exists($module_id, self::$module_info_cache)) {
			return self::$module_info_cache[$module_id];
		}

		$info = null;
		$file = self::get_module_dir($module_id) . '/module.info.php';

		if (file_exists($file)) {
			$info = require $file;
		}

		return self::$module_info_cache[$module_id] = $info;
	}

	/**
	 * Per-request cache of the module enable/disable option arrays.
	 *
	 * The enabled-state helpers (element_pack_is_widget_enabled() etc.) run dozens
	 * of times per page (≈74 in the asset-registration pass alone), each fetching
	 * the same option. WordPress already caches options in memory, but this also
	 * skips the repeated default-array handling. The cache is flushed via
	 * flush_modules_option_cache() whenever one of these options is updated, so a
	 * settings save in the same request is never served a stale value.
	 *
	 * @var array<string, array>
	 */
	private static $modules_option_cache = [];

	/**
	 * Get one of the module option arrays with a per-request cache.
	 *
	 * @param string $key Option name.
	 * @return array
	 */
	public static function get_modules_option($key) {
		if (!array_key_exists($key, self::$modules_option_cache)) {
			self::$modules_option_cache[$key] = get_option($key, []);
		}
		return self::$modules_option_cache[$key];
	}

	/**
	 * Invalidate the cached option(s). Pass null to clear everything.
	 *
	 * @param string|null $key
	 * @return void
	 */
	public static function flush_modules_option_cache($key = null) {
		if ($key === null) {
			self::$modules_option_cache   = [];
			self::$runtime_lists_cache    = null;
			self::$settings_cache         = null;
			self::$external_modules_cache = null;
			self::$module_info_cache      = [];
		} else {
			unset(self::$modules_option_cache[$key]);
		}
	}

	/**
	 * Per-request memo of the reduced runtime module lists.
	 *
	 * @var array<string, array>|null
	 */
	private static $runtime_lists_cache = null;

	/**
	 * The lean module lists the front-end loader (Manager) actually needs: the
	 * candidate module names per tier, plus plugin_path for third-party entries.
	 *
	 * The full get_widget_settings() array is ~4,200 lines and rebuilding it on
	 * every request runs hundreds of esc_html__() calls and a get_plugins()
	 * directory scan — none of which the loader reads. The candidate list is fixed
	 * by the plugin code; the only request-varying part is third-party plugin_path
	 * selection, which depends on which plugins are active. So the result is cached
	 * in a transient keyed by plugin version + the active-plugin fingerprint:
	 * activating/deactivating any plugin changes the key and rebuilds, keeping
	 * plugin_path correct, while normal requests skip the full build entirely.
	 *
	 * Widget enable/disable toggles do NOT affect this list — those are read live
	 * from options by element_pack_is_*_enabled(), so no flush is needed on save.
	 *
	 * @return array{element_pack_active_modules: array, element_pack_elementor_extend: array, element_pack_third_party_widget: array}
	 */
	public static function get_runtime_module_lists() {
		if (is_array(self::$runtime_lists_cache)) {
			return self::$runtime_lists_cache;
		}

		$fingerprint = md5(
			BDTEP_VER . '|'
			. wp_json_encode(get_option('active_plugins', [])) . '|'
			. wp_json_encode(get_site_option('active_sitewide_plugins', [])) . '|'
			. wp_json_encode(self::get_external_modules())
		);

		// One key, with the fingerprint stored alongside the lists. Keying the
		// transient by the fingerprint left a ~15 KB orphan behind on every plugin
		// (de)activation until it expired a week later.
		$cache_key = 'ep_runtime_modules';

		$cached = get_transient($cache_key);
		if (is_array($cached)
			&& isset($cached['fingerprint'], $cached['lists'])
			&& $cached['fingerprint'] === $fingerprint
			&& self::is_valid_runtime_lists($cached['lists'])
		) {
			return self::$runtime_lists_cache = $cached['lists'];
		}

		$lists = self::get_widget_settings(function ($settings) {
			$fields = isset($settings['settings_fields']) && is_array($settings['settings_fields'])
				? $settings['settings_fields']
				: [];

			return [
				'element_pack_active_modules'     => self::reduce_runtime_list($fields['element_pack_active_modules'] ?? []),
				'element_pack_elementor_extend'   => self::reduce_runtime_list($fields['element_pack_elementor_extend'] ?? []),
				'element_pack_third_party_widget' => self::reduce_runtime_list($fields['element_pack_third_party_widget'] ?? []),
			];
		});

		set_transient(
			$cache_key,
			['fingerprint' => $fingerprint, 'lists' => $lists],
			defined('WEEK_IN_SECONDS') ? WEEK_IN_SECONDS : 604800
		);

		return self::$runtime_lists_cache = $lists;
	}

	/**
	 * Reduce a full settings tier to the fields the loader reads.
	 *
	 * @param array $items
	 * @return array
	 */
	private static function reduce_runtime_list($items) {
		$out = [];
		if (!is_array($items)) {
			return $out;
		}
		foreach ($items as $item) {
			if (!isset($item['name'])) {
				continue;
			}
			$entry = ['name' => $item['name']];
			if (isset($item['plugin_path'])) {
				$entry['plugin_path'] = $item['plugin_path'];
			}
			$out[] = $entry;
		}
		return $out;
	}

	/**
	 * @param mixed $lists
	 * @return bool
	 */
	private static function is_valid_runtime_lists($lists) {
		return is_array($lists)
			&& isset(
				$lists['element_pack_active_modules'],
				$lists['element_pack_elementor_extend'],
				$lists['element_pack_third_party_widget']
			);
	}

	public static function is_module_active($module_id, $options) {
		if (!isset($options[$module_id])) {
			$module_data = self::get_module_info($module_id);
			if (is_array($module_data) && isset($module_data['default_activation'])) {
				return $module_data['default_activation'];
			}
			return null;
		}

		return $options[$module_id] == 'on';
	}

	public static function is_plugin_active($plugin_path) {
		if ($plugin_path) {
			return is_plugin_active($plugin_path);
		}
	}

	/**
	 * Elementor widget names registered by a module.
	 *
	 * Widgets are named `bdt-<module>` by convention. A module whose widget
	 * keeps another name (legacy names stay so saved pages still resolve)
	 * lists it under `widget_names` in module.info.php, so usage lookups and
	 * role restrictions still find it.
	 *
	 * @param string $module_id Module slug.
	 * @return string[]
	 */
	public static function get_module_widget_names($module_id) {
		$module_data = self::get_module_info($module_id);
		if (is_array($module_data) && !empty($module_data['widget_names'])) {
			return array_values((array) $module_data['widget_names']);
		}

		return ['bdt-' . str_replace('_', '-', $module_id)];
	}

	public static function has_module_style($module_id) {
		$module_data = self::get_module_info($module_id);
		if (is_array($module_data) && isset($module_data['has_style'])) {
			return $module_data['has_style'];
		}
	}

	public static function has_module_script($module_id) {
		$module_data = self::get_module_info($module_id);
		if (is_array($module_data) && isset($module_data['has_script'])) {
			return $module_data['has_script'];
		}
	}
}
