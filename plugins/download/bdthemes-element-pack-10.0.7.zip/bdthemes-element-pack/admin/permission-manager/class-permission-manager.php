<?php

namespace ElementPack\Admin;

if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

/**
 * Permission Manager — runtime widget access checks and menu visibility.
 *
 * Admin UI lives in the React SPA; Elementor editor filtering uses Role_Filters.
 */
class ElementPack_Permission_Manager
{

    /**
     * Get allowed widgets for user
     *
     * @param string $widget_name
     * @return bool
     */
    public function bdt_get_allowed_widgets_for_user($widget_name)
    {
        // If license check fails → always allow
        if (!$this->is_permission_manager_license()) {
            return true;
        }

        /**
         * 🔹 Multisite restrictions
         */
        if (is_multisite()) {

            // Main site admin → always allowed
            if (is_main_site() && current_user_can('administrator')) {
                return true;
            }

            $current_blog_id = get_current_blog_id();

            // Get subsite elements from the main site
            $main_site_id = get_main_site_id();
            switch_to_blog($main_site_id);
            $subsite_elements = get_option('ep_subsite_elements', []);
            restore_current_blog();

            // No restrictions configured → allow everything
            if (empty($subsite_elements)) {
                return true;
            }

            // Subsite-specific restriction
            return !empty($subsite_elements[$current_blog_id][$widget_name])
                && $subsite_elements[$current_blog_id][$widget_name] === 'on';
        }

        /**
         * 🔹 Role-based restrictions
         */
        $role_elements = get_option('ep_role_elements', []);

        // No role restrictions or admin → allow everything
        if (empty($role_elements) || current_user_can('administrator')) {
            return true;
        }

        $current_user = wp_get_current_user();
        $user_roles = (array) $current_user->roles;

        $allowed_widgets = [];

        foreach ($user_roles as $role) {
            if (!empty($role_elements[$role]) && is_array($role_elements[$role])) {
                foreach ($role_elements[$role] as $role_element => $status) {
                    if ($status === 'on') {
                        $allowed_widgets[] = $role_element;
                    }
                }
            }
        }

        $allowed_widgets = array_unique($allowed_widgets);

        return in_array($widget_name, $allowed_widgets, true);
    }


    /**
     * Check if current license supports Permission Manager functionality
     * Only agency and developer license holders can access Permission Manager
     *
     * @access private
     * @return bool
     */
    public function is_permission_manager_license()
    {
        $license_info = \ElementPack\Base\Element_Pack_Base::get_register_info();

        // Check if license info is valid and available
        if (
            empty($license_info) ||
            !is_object($license_info) ||
            empty($license_info->license_title) ||
            empty($license_info->is_valid)
        ) {
            return false;
        }

        $license_title = strtolower($license_info->license_title);

        // Check for agency or developer license
        if (
            strpos($license_title, 'agency') !== false ||
            strpos($license_title, 'developer') !== false
        ) {
            return true;
        }

        return false;
    }

    /**
     * Get admin settings (similar to element_pack_admin_settings in admin-settings.php)
     *
     * @return array
     */
    private function get_element_pack_admin_settings()
    {
        return \ElementPack\Admin\ModuleService::get_widget_settings(function ($settings) {
            return $settings['settings_fields'];
        });
    }

    /**
     * Determine which menus should be visible for the current user based on their role permissions
     *
     * @return array
     */
    public function get_visible_menus_for_current_user()
    {

        $is_permission_manager_license = $this->is_permission_manager_license();
        // Administrators always see all menus
        if (
            (!is_multisite() && current_user_can('administrator')) // single-site admin
            || (is_multisite() && is_main_site() && current_user_can('administrator')) // multisite main site admin
            || !$is_permission_manager_license // license bypass
        ) {
            return [
                'core_widgets' => true,
                'third_party' => true,
                'extensions' => true,
                'special_features' => true,
                'api_settings' => true,
            ];
        }

        $allowed_widgets = [];

        if (is_multisite() && !is_main_site()) {
            // Multisite subsite: get restrictions from main site
            $current_blog_id = get_current_blog_id();
            $main_site_id = get_main_site_id();
            switch_to_blog($main_site_id);
            $subsite_elements = get_option('ep_subsite_elements', []);
            restore_current_blog();

            if (empty($subsite_elements)) {
                return [
                    'core_widgets' => true,
                    'third_party' => true,
                    'extensions' => true,
                    'special_features' => true,
                    'api_settings' => true,
                ];
            }

            // Allowed widgets for this subsite
            if (!empty($subsite_elements[$current_blog_id]) && is_array($subsite_elements[$current_blog_id])) {

                // Filter only widgets that are 'on' for this subsite
                $subsite_widgets = array_filter(
                    $subsite_elements[$current_blog_id],
                    fn($status) => $status === 'on'
                );

                $allowed_widgets = array_merge($allowed_widgets, array_keys($subsite_widgets));
            }

        } else {
            // Role-based permissions
            $role_elements = get_option('ep_role_elements', []);
            if (empty($role_elements)) {
                return [
                    'core_widgets' => true,
                    'third_party' => true,
                    'extensions' => true,
                    'special_features' => true,
                    'api_settings' => true,
                ];
            }
            $current_user = wp_get_current_user();
            $user_roles = $current_user->roles;

            foreach ($user_roles as $role) {
                if (!empty($role_elements[$role]) && is_array($role_elements[$role])) {

                    // Filter only widgets that are 'on'
                    $role_widgets = array_filter(
                        $role_elements[$role],
                        fn($status) => $status === 'on'
                    );

                    $allowed_widgets = array_merge($allowed_widgets, array_keys($role_widgets));
                }
            }
        }

        // Remove duplicates
        $allowed_widgets = array_unique($allowed_widgets);

        // Count widgets per category (even if empty - let individual sections decide)
        $category_counts = $this->count_widgets_by_category($allowed_widgets);

        // Determine menu visibility based on widget counts
        return [
            'core_widgets' => $category_counts['core_widgets'] > 0,
            'third_party' => $category_counts['third_party'] > 0,
            'extensions' => $category_counts['extensions'] > 0,
            'special_features' => $category_counts['special_features'] > 0,
        ];
    }

    /**
     * Count widgets by category for given widget list
     *
     * @param array $widget_names
     * @return array
     */
    public function count_widgets_by_category($widget_names)
    {
        $counts = [
            'core_widgets' => 0,
            'third_party' => 0,
            'extensions' => 0,
            'special_features' => 0,
        ];

        // Get all widget settings to determine categories
        $all_settings = $this->get_element_pack_admin_settings();

        // Check each allowed widget and categorize
        foreach ($widget_names as $widget_name) {
            // Remove common prefixes to match settings keys
            $clean_name = str_replace(['bdt-', 'ep-'], '', $widget_name);

            // Check core widgets
            if (isset($all_settings['element_pack_active_modules'])) {
                foreach ($all_settings['element_pack_active_modules'] as $setting) {
                    if (isset($setting['name']) && ($setting['name'] === $clean_name || $setting['name'] === $widget_name)) {
                        $counts['core_widgets']++;
                        continue 2;
                    }
                }
            }

            // Check 3rd party widgets
            if (isset($all_settings['element_pack_third_party_widget'])) {
                foreach ($all_settings['element_pack_third_party_widget'] as $setting) {
                    if (isset($setting['name']) && ($setting['name'] === $clean_name || $setting['name'] === $widget_name)) {
                        $counts['third_party']++;
                        continue 2;
                    }
                }
            }

            // Check extensions
            if (isset($all_settings['element_pack_elementor_extend'])) {
                foreach ($all_settings['element_pack_elementor_extend'] as $setting) {
                    if (isset($setting['name']) && ($setting['name'] === $clean_name || $setting['name'] === $widget_name)) {
                        $counts['extensions']++;
                        continue 2;
                    }
                }
            }

            // Check special features
            if (isset($all_settings['element_pack_other_settings'])) {
                foreach ($all_settings['element_pack_other_settings'] as $setting) {
                    if (isset($setting['name']) && ($setting['name'] === $clean_name || $setting['name'] === $widget_name)) {
                        $counts['special_features']++;
                        continue 2;
                    }
                }
            }
        }

        return $counts;
    }
}
