<?php

namespace ElementPack;

use Elementor\Core\Kits\Documents\Kit;
use Elementor\Plugin;
use ElementPack\Includes\ElementPack_FB_Access_Token_Generator_Control;
use ElementPack\Includes\ElementPack_JSON_File_Upload_Control;
use ElementPack\Includes\Element_Pack_WPML;
use ElementPack\Includes\Pro_Widget_Map;
use ElementPack\Includes\EP_License_Admin_Guard;
use ElementPack\Includes\SVG_Support;

if ( !defined( 'ABSPATH' ) ) {
    exit;
}

// Exit if accessed directly

if ( !defined( 'BDTEP_PC' ) ) {
    define( 'BDTEP_PC', '' );
}
// pro control badge
define( 'BDTEP_IS_PC', '' );
define( 'BDTEP_LOCK_CLASS', '' );

if ( !defined( 'BDTEP_LOCK' ) ) {
    define( 'BDTEP_LOCK', '' );
}

// lock control badge
/**
 * Main class for element pack
 */
class Element_Pack_Loader {

	/**
	 * @var Element_Pack_Loader
	 */
	private static $_instance;
	public $_modules_manager;

	public $elements_data = [ 
		'sections' => [],
		'columns'  => [],
		'widgets'  => [],
	];

	private function get_upload_dir() {
		return trailingslashit( wp_upload_dir()['basedir'] ) . 'element-pack/minified/';
	}

	private function get_upload_url() {
		/**
		 * Baclup
		 * return trailingslashit( wp_upload_dir()['baseurl'] ) . 'element-pack/minified/';
		 */
		$upload_dir = wp_upload_dir();
		$upload_url = $upload_dir['baseurl'] . '/element-pack/minified/';

		/**
		 * Use the current scheme (http or https) of the page
		 */
		$upload_url = set_url_scheme( $upload_url );

		return $upload_url;
	}

	/**
	 * @return string
	 * @deprecated
	 *
	 */
	public function get_version() {
		return BDTEP_VER;
	}

	/**
	 * return active theme
	 */
	public function get_theme() {
		return wp_get_theme();
	}

	/**
	 * Throw error on object clone
	 *
	 * The whole idea of the singleton design pattern is that there is a single
	 * object therefore, we don't want the object to be cloned.
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function __clone() {
		// Cloning instances of the class is forbidden
		_doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'bdthemes-element-pack' ), '1.6.0' );
	}

	/**
	 * Disable unserializing of the class
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function __wakeup() {
		// Unserializing instances of the class is forbidden
		_doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'bdthemes-element-pack' ), '1.6.0' );
	}

	/**
	 * @return Plugin
	 */

	public static function elementor() {
		return Plugin::$instance;
	}

	function pro_return() {
		return true;
	}

	/**
	 * @return Element_Pack_Loader
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * we loaded module manager + admin php from here
	 * @return [type] [description]
	 */
	private function _includes() {

		// Capture earliest possible timing for the debug system
		if ( ! defined( 'BDTEP_DEBUG_PAGE_START' ) ) {
			define( 'BDTEP_DEBUG_PAGE_START', microtime( true ) );
			define( 'BDTEP_DEBUG_PAGE_START_MEMORY', memory_get_usage( true ) );
		}

		// Debug system (self-gating: only activates for admins with BDTEP_DEBUG or ?ep_debug=1)
		require_once BDTEP_INC_PATH . 'debug/class-ep-debug-manager.php';

		$live_copy            = element_pack_option( 'live-copy', 'element_pack_other_settings', 'off' );
		$essential_shortcodes = element_pack_option( 'essential-shortcodes', 'element_pack_other_settings', 'off' );
		$template_library     = element_pack_option( 'template-library', 'element_pack_other_settings', 'on' );
		$context_menu         = element_pack_option( 'context-menu', 'element_pack_other_settings', 'off' );
		$duplicator           = element_pack_option( 'duplicator', 'element_pack_other_settings', 'off' );
		$mega_menu            = element_pack_option( 'mega-menu', 'element_pack_other_settings', 'off' );
		$smooth_scroller      = element_pack_option( 'smooth-scroller', 'element_pack_other_settings', 'off' );
		$variation_swatches   = element_pack_option( 'variation-swatches', 'element_pack_other_settings', 'off' );
		$dynamic_content      = element_pack_option( 'dynamic-content', 'element_pack_other_settings', 'off' );

		if ( 'on' === $dynamic_content ) {
			require_once BDTEP_INC_PATH . 'dynamic-content/index.php';
		}

		// Admin settings controller
		require_once BDTEP_ADMIN_PATH . 'module-settings.php';
		// Assets Manager: autoloaded (see autoload()) — it pulls in the minify
		// library, which only a bundle rebuild needs.

		// React admin SPA: REST API layer + dashboard mount (additive, legacy-safe).
		require_once BDTEP_INC_PATH . 'react-admin-init.php';

		// Custom Fonts - Always active
	 	require_once BDTEP_INC_PATH . 'custom-fonts/init.php';

		// Custom Icons - Always active
		require_once BDTEP_INC_PATH . 'custom-icons/init.php';

		EP_License_Admin_Guard::register_hooks();

		// Dynamic Select control
		require_once BDTEP_INC_PATH . 'controls/select-input/dynamic-select-input-module.php';
		require_once BDTEP_INC_PATH . 'controls/select-input/dynamic-select.php';

		// Global Controls
		require_once BDTEP_PATH . 'traits/global-widget-controls.php';
		require_once BDTEP_PATH . 'traits/global-swiper-controls.php';
		require_once BDTEP_PATH . 'traits/global-mask-controls.php';
		require_once BDTEP_PATH . 'traits/global-controls-functions.php';
		require_once BDTEP_PATH . 'traits/global-terms-query-controls.php';

		// Load Context Menu
		if ( 'on' === $context_menu ) {
			require_once 'includes/context-menu/settings.php';
			require_once 'includes/context-menu/controls.php';
		}
		if ( 'on' === $mega_menu ) {
			require_once BDTEP_INC_PATH . 'mega-menu/classes/class-mega-menu-init.php';
		}

		if ( 'on' === $smooth_scroller ) {
			require_once BDTEP_INC_PATH . 'smooth-scroller/settings.php';
		}

		$options = get_option('ultimate_store_kit_other_settings'); // Store Kit Options check
		if (
			( ! is_plugin_active( 'ultimate-store-kit-pro/ultimate-store-kit-pro.php' ) || 'on' !== ($options['variation-swatches'] ?? '') )
			&& class_exists('WooCommerce') 
			&& 'on' === $variation_swatches
		) {
			require_once BDTEP_INC_PATH . 'swatches/variation-swatches.php';
		}




		// json upload support for wordpress
		require_once BDTEP_INC_PATH . 'class-json-file-upload-control.php';
		// svg support for full wordpress site
		require_once BDTEP_INC_PATH . 'class-svg-support.php';
		// All modules loading from here
		require_once BDTEP_INC_PATH . 'modules-manager.php';
		// Asset optimization: per-page combined module files
		require_once BDTEP_INC_PATH . 'class-asset-combiner.php';
		// Keeps UIkit component attributes out of content saved by users without unfiltered_html
		require_once BDTEP_INC_PATH . 'class-content-guard.php';
		Includes\Content_Guard::init();

		// AI Tools — Abilities API integration (WordPress 6.9+).
		// Loaded wherever abilities can be listed or run: wp-admin (including the
		// Elementor editor, where Angie runs), REST, AJAX, cron and WP-CLI. A plain
		// frontend page view uses none of it, and the framework is ~9k lines.
		if ( function_exists( 'wp_register_ability' ) && $this->may_use_abilities() ) {
			require_once BDTEP_PATH . 'abilities/class-ep-abilities.php';
		}

		// wpml compatibility class for wpml support
		require_once BDTEP_INC_PATH . 'class-elements-wpml-compatibility.php';
		// For changelog file parse
		require_once BDTEP_INC_PATH . 'class-parsedown.php';

		if ( ( $live_copy == 'on' ) && ( ! is_plugin_active( 'live-copy-paste/live-copy-paste.php' ) ) ) {
			require_once BDTEP_INC_PATH . 'live-copy/class-live-copy.php';
		}

		// register the elementor template loading widget in widgets
		require_once BDTEP_INC_PATH . 'widgets/elementor-template.php';

		// Facebook access token generator control for editor
		require_once BDTEP_INC_PATH . 'class-fb-access-token-generator-control.php';

		require_once BDTEP_INC_PATH . 'class-google-recaptcha.php';

		// Shortcode loader for works some essential shortcode that need for any purpose
		if ( $essential_shortcodes == 'on' ) {
			require_once BDTEP_INC_PATH . 'shortcodes/shortcode-loader.php';
		}

		if ( $duplicator == 'on' ) {
			require_once BDTEP_INC_PATH . 'class-duplicator.php';
		}
		
		/**
		 * Editor template library
		 */
		if ( ! defined( 'BDTEP_CH' ) and $template_library == 'on' ) {
			require_once BDTEP_INC_PATH . 'template-library/editor/init.php';
			require_once BDTEP_INC_PATH . 'template-library/template-library-base.php';
			require_once BDTEP_INC_PATH . 'template-library/editor/manager/api.php';
		}

		/**
		 * Page Builder
		 */
		require BDTEP_PATH . 'base/support/helpers.php';
		require BDTEP_INC_PATH . 'builder/loading-builder.php';
	}

	/**
	 * Classes whose file does not follow the namespace-to-path convention below.
	 *
	 * @var array<string, string> Class name => path relative to BDTEP_PATH.
	 */
	private static $class_map = [
		'ElementPack\Admin\AssetMinifier\Asset_Minifier' => 'admin/optimizer/asset-minifier-manager.php',
	];

	/**
	 * Whether this request can list or execute abilities.
	 *
	 * Runs at plugins_loaded, before WordPress has decided whether the request is a
	 * REST request (REST_REQUEST is defined during parse_request), so REST is
	 * recognised from the URL, the same way rest_api_loaded() does.
	 *
	 * @return bool
	 */
	private function may_use_abilities() {
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'WP_CLI' ) && WP_CLI ) || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return true;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Routing check only.
		if ( isset( $_GET['rest_route'] ) ) {
			return true;
		}

		$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Only compared, never output.
		$rest_prefix = '/' . trim( rest_get_url_prefix(), '/' ) . '/';

		return false !== strpos( $request_uri, $rest_prefix );
	}

	/**
	 * Autoloader function for all classes files
	 *
	 * @param  [type] class [description]
	 *
	 * @return [type]        [description]
	 */
	public function autoload( $class ) {
		if ( 0 !== strpos( $class, __NAMESPACE__ ) ) {
			return;
		}

		if ( isset( self::$class_map[ $class ] ) ) {
			require_once BDTEP_PATH . self::$class_map[ $class ];
			return;
		}

		$class_to_load = $class;

		if ( ! class_exists( $class_to_load ) ) {
			$filename = strtolower(
				preg_replace(
					[ '/^' . __NAMESPACE__ . '\\\/', '/([a-z])([A-Z0-9])/', '/_/', '/\\\/' ],
					[ '', '$1-$2', '-', DIRECTORY_SEPARATOR ],
					$class_to_load
				)
			);

			$filename = BDTEP_PATH . $filename . '.php';

			if ( is_readable( $filename ) ) {
				include $filename;
			}
		}
	}

	/**
	 * Register the third-party libraries widgets and extensions depend on.
	 *
	 * Every library is registered unconditionally. Registering a handle costs next to
	 * nothing and loads nothing; only a widget that is rendered enqueues it. These used
	 * to be gated on hand-maintained "is widget X or Y enabled" lists, and any list
	 * that missed a dependent broke that dependent silently: Webhook Form lost its
	 * reCAPTCHA, ACF Gallery its justified layout, Global Badge its Lottie icons.
	 *
	 * @return void
	 */
	public function register_site_scripts() {

		$api_settings = get_option( 'element_pack_api_settings' );

		wp_register_script( 'goodshare', BDTEP_ASSETS_URL . 'vendor/js/goodshare.min.js', [ 'jquery' ], '4.1.2', true );
		wp_register_script( 'aspieprogress', BDTEP_ASSETS_URL . 'vendor/js/jquery-asPieProgress.min.js', [ 'jquery' ], '0.4.7', true );
		wp_register_script( 'morphext', BDTEP_ASSETS_URL . 'vendor/js/morphext.min.js', [ 'jquery' ], '2.4.7', true );
		wp_register_script( 'typed', BDTEP_ASSETS_URL . 'vendor/js/typed.min.js', [ 'jquery' ], BDTEP_VER, true );
		wp_register_script( 'qrcode', BDTEP_ASSETS_URL . 'vendor/js/jquery-qrcode.min.js', [ 'jquery' ], '0.14.0', true );
		wp_register_script( 'jsBarcode', BDTEP_ASSETS_URL . 'vendor/js/jsBarcode.min.js', [], 'v3.11.5', true );
		wp_register_script( 'jplayer', BDTEP_ASSETS_URL . 'vendor/js/jquery.jplayer.min.js', [ 'jquery' ], '2.9.2', true );
		wp_register_script( 'circle-menu', BDTEP_ASSETS_URL . 'vendor/js/jQuery.circleMenu.min.js', [ 'jquery' ], '0.1.1', true );
		wp_register_script( 'cookieconsent', BDTEP_ASSETS_URL . 'vendor/js/cookieconsent.min.js', [ 'jquery' ], '3.1.0', true );
		wp_register_script( 'gridtab', BDTEP_ASSETS_URL . 'vendor/js/gridtab.min.js', [ 'jquery' ], '2.1.1', true );
		wp_register_script( 'recaptcha', 'https://www.google.com/recaptcha/api.js', [ 'jquery' ], BDTEP_VER, true );
		wp_register_script( 'chart', BDTEP_ASSETS_URL . 'vendor/js/chart.min.js', [ 'jquery' ], '3.9.1', true );

		if ( ! empty( $api_settings['google_map_key'] ) ) {
			wp_register_script( 'gmap-api', 'https://maps.googleapis.com/maps/api/js?key=' . $api_settings['google_map_key'] . '&loading=async&libraries=marker', [ 'jquery' ], BDTEP_VER, true );
		}

		wp_register_script( 'leaflet', BDTEP_ASSETS_URL . 'vendor/js/leaflet.min.js', [ 'jquery' ], BDTEP_VER, true );
		wp_register_script( 'bdt-parallax', BDTEP_ASSETS_URL . 'vendor/js/parallax.min.js', [ 'jquery' ], BDTEP_VER, true );
		wp_register_script( 'tocify', BDTEP_ASSETS_URL . 'vendor/js/tocify.min.js', [ 'jquery' ], BDTEP_VER, true );
		wp_register_script( 'imagezoom', BDTEP_ASSETS_URL . 'vendor/js/jquery.imagezoom.min.js', [ 'jquery' ], BDTEP_VER, true );

		wp_register_script( 'datatables', BDTEP_ASSETS_URL . 'vendor/js/datatables.min.js', [ 'jquery' ], BDTEP_VER, true );
		wp_register_script( 'datatables-uikit', BDTEP_ASSETS_URL . 'vendor/js/datatables.uikit.min.js', [ 'jquery', 'datatables' ], BDTEP_VER, true );

		wp_register_script( 'popper', BDTEP_ASSETS_URL . 'vendor/js/popper.min.js', [ 'jquery' ], BDTEP_VER, true );
		wp_register_script( 'tippyjs', BDTEP_ASSETS_URL . 'vendor/js/tippy.all.min.js', [ 'jquery' ], BDTEP_VER, true );

		wp_register_script( 'tilt', BDTEP_ASSETS_URL . 'vendor/js/vanilla-tilt.min.js', [ 'jquery' ], BDTEP_VER, true );
		wp_register_script( 'rvslider', BDTEP_ASSETS_URL . 'vendor/js/rvslider.min.js', [ 'jquery' ], BDTEP_VER, true );
		wp_register_script( 'spritespin', BDTEP_ASSETS_URL . 'vendor/js/spritespin.min.js', [ 'jquery' ], '4.0.5', true );
		wp_register_script( 'recliner', BDTEP_ASSETS_URL . 'vendor/js/recliner.min.js', [ 'jquery' ], '0.2.2', true );
		wp_register_script( 'ep-justified-gallery', BDTEP_ASSETS_URL . 'vendor/js/jquery.justifiedGallery.min.js', [ 'jquery' ], '1.0.0', true );
		wp_register_script( 'lottie', BDTEP_ASSETS_URL . 'vendor/js/lottie.min.js', [], '5.6.10', true );
		wp_register_script( 'thumbnail-scroller', BDTEP_ASSETS_URL . 'vendor/js/jquery.mThumbnailScroller.min.js', [ 'jquery' ], '2.0.2', true );
		wp_register_script( 'progressHorizontal', BDTEP_ASSETS_URL . 'vendor/js/jquery.progressHorizontal.min.js', [ 'jquery' ], '2.0.2', true );
		wp_register_script( 'prism', BDTEP_ASSETS_URL . 'vendor/js/prism.min.js', [], '1.17.1', true );
		wp_register_script( 'advanced-counter', BDTEP_ASSETS_URL . 'vendor/js/countUp.min.js', [ 'jquery' ], '2.0.4', true );
		wp_register_script( 'jclock', BDTEP_ASSETS_URL . 'vendor/js/jquery.jclock.min.js', [ 'jquery' ], '0.0.1', true );
		wp_register_script( 'image-compare-viewer', BDTEP_ASSETS_URL . 'vendor/js/image-compare-viewer.min.js', [ 'jquery' ], '0.0.1', true );

		wp_register_script( 'gsap', BDTEP_ASSETS_URL . 'vendor/js/gsap.min.js', [], '3.12.5', true );
		wp_register_script( 'split-text-js', BDTEP_ASSETS_URL . 'vendor/js/SplitText.min.js', [ 'jquery', 'gsap' ], '3.9.1', true );
		wp_register_script( 'wavify', BDTEP_ASSETS_URL . 'vendor/js/wavify.min.js', [ 'gsap' ], '0.0.1', true );
		wp_register_script( 'scroll-trigger', BDTEP_ASSETS_URL . 'vendor/js/ScrollTrigger.min.js', [ 'gsap' ], '3.12.5', true );
		wp_register_script( 'scroll-to-plugin-js', BDTEP_ASSETS_URL . 'vendor/js/ScrollToPlugin.min.js', [ 'gsap' ], '3.9.1', true );
		wp_register_script( 'draw-svg-plugin-js', BDTEP_ASSETS_URL . 'vendor/js/DrawSVGPlugin.min.js', [ 'gsap' ], '3.11.3', true );
		wp_register_script( 'draggable', BDTEP_ASSETS_URL . 'vendor/js/Draggable.min.js', [ 'gsap' ], '3.12.2', true );
		wp_register_script( 'InertiaPlugin', BDTEP_ASSETS_URL . 'vendor/js/InertiaPlugin.min.js', [ 'gsap' ], '3.12.2', true );

		// One anime.js file under two handles: extensions use `anime`, SVG Blob uses
		// `animejs`. Registering the second as an alias keeps a page that mixes them
		// from downloading and executing the library twice.
		wp_register_script( 'anime', BDTEP_ASSETS_URL . 'vendor/js/anime.min.js', [], '3.2.1', true );
		wp_register_script( 'animejs', false, [ 'anime' ], '3.2.1', true );

		// phpcs:ignore PluginCheck.CodeAnalysis.EnqueuedResourceOffloading.OffloadedContent -- Google Charts loader is required for SVG Maps widget.
		wp_register_script( 'gs-charts', '//www.gstatic.com/charts/loader.js', [], '0.0.1', true );
		wp_register_script( 'ep-video-player', BDTEP_ASSETS_URL . 'js/widget/ep-video-player.min.js', [], '2.9', true );
		wp_register_script( 'metis-menu', BDTEP_ASSETS_URL . 'vendor/js/metisMenu.min.js', [ 'jquery' ], '3.0.6', true );
		wp_register_script( 'calendly', BDTEP_ASSETS_URL . 'vendor/js/calendly.min.js', [ 'jquery' ], '0.0.1', true );
		wp_register_script( 'jstat', BDTEP_ASSETS_URL . 'vendor/js/jstat.min.js', [], '1.9.2', true );
		wp_register_script( 'formula', BDTEP_ASSETS_URL . 'vendor/js/formula.min.js', [], '2.9.2', true );
		wp_register_script( 'simple-parallax-js', BDTEP_ASSETS_URL . 'vendor/js/simpleParallax.min.js', [], '6.0.1', true );
		wp_register_script( 'ep-text-read-more-toggle', BDTEP_ASSETS_URL . 'vendor/js/ep-text-read-more-toggle.min.js', [ 'jquery', 'bdt-uikit' ], BDTEP_VER, true );

		/**
		 * TODO: Need to separate wc widget js
		 */
		wp_register_script( 'ep-woocommerce', BDTEP_ASSETS_URL . 'vendor/js/ep-woocommerce.min.js', [ 'jquery', 'datatables' ], BDTEP_VER, true );
		wp_register_script( 'ep-ticker', BDTEP_ASSETS_URL . 'vendor/js/ticker.min.js', [ 'jquery' ], BDTEP_VER, true );

		// ACF widgets reuse the core widgets' files. Skip them in the editor and
		// preview, where the ep-scripts bundle already carries them.
		foreach ( self::acf_shared_module_assets() as $acf_widget => $shared ) {
			list( $module, $has_script ) = $shared;

			if ( ! $has_script || ! element_pack_is_third_party_enabled( $acf_widget ) || self::module_assets_are_bundled( $module ) ) {
				continue;
			}

			wp_register_script( 'ep-' . $module, BDTEP_ASSETS_URL . 'js/modules/ep-' . $module . '.min.js', [ 'jquery', 'bdt-uikit', 'element-pack-helper' ], BDTEP_VER, true );
		}
	}

	/**
	 * ACF widgets that render with a core widget's CSS/JS, mapped to that module.
	 *
	 * @return array<string, array{0: string, 1: bool}> ACF widget slug => [ core module slug, whether it has a script ].
	 */
	private static function acf_shared_module_assets() {
		return [
			'acf-accordion' => [ 'accordion', true ],
			'acf-gallery'   => [ 'advanced-image-gallery', true ],
			'acf-list'      => [ 'fancy-list', false ],
			'acf-slider'    => [ 'slider', true ],
			'acf-tabs'      => [ 'tabs', true ],
		];
	}

	/**
	 * Whether this request renders the Elementor editor or its preview.
	 *
	 * @return bool
	 */
	public static function is_editor_request() {
		$elementor = self::elementor();

		return $elementor->preview->is_preview_mode() || $elementor->editor->is_edit_mode();
	}

	/**
	 * Modules the static bundle does not wholly carry: assets/css/ep-styles.css and
	 * assets/js/ep-scripts.min.js (see scripts/build-config.mjs) leave out Source
	 * Code's stylesheet (58 KB of Prism themes) and SVG Image's script. Their widgets
	 * name their own `ep-<module>` handle for that file in edit mode too. In a
	 * static-bundle preview the Manager registers it with the module's file, and
	 * wherever the bundle carries the file, as an alias of the bundle.
	 * tests/Unit/StaticBundleOmitsTest.php keeps this in step with the build and the
	 * widgets.
	 */
	const STATIC_BUNDLE_OMITS = [ 'source-code', 'svg-image' ];

	/**
	 * `element_pack/optimization/bundle_module_handles`: whether the Manager registers
	 * a module's `ep-<module>` handles as aliases of the ep-styles/ep-scripts bundle.
	 *
	 * Only in the Elementor preview, which loads the bundle in either optimization
	 * mode: a module that declares or enqueues its own handle there (Content Switcher,
	 * Mega Menu and WC Products declare theirs in edit mode too, Notation enqueues its
	 * own) would otherwise load its file next to the bundle and bind its handlers
	 * twice. A module the bundle does not carry keeps its files. The frontend registers
	 * the module files in every mode, and with asset optimization on
	 * Includes\Asset_Combiner joins the ones a page prints. The Manager runs before
	 * Elementor can tell a preview request apart, hence the query argument rather than
	 * is_editor_request().
	 *
	 * @param bool   $bundled   The Manager's default: whether asset optimization is on.
	 * @param string $module_id Module slug.
	 * @return bool
	 */
	public static function bundle_module_handles( $bundled, $module_id = '' ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Only picks which asset URLs to register.
		return isset( $_GET['elementor-preview'] ) && self::preview_bundle_carries( $module_id );
	}

	/**
	 * Whether a module's CSS/JS reaches the page through the ep-styles/ep-scripts
	 * bundle instead of its own `ep-<module>` files.
	 *
	 * Only in the Elementor editor/preview, which load the bundle, and only for a
	 * module the bundle carries. The frontend always loads the module's own files;
	 * with asset optimization on, the ones a page uses are joined into combined files
	 * (see Includes\Asset_Combiner).
	 *
	 * @param string $module Module slug.
	 * @return bool
	 */
	public static function module_assets_are_bundled( $module ) {
		return self::is_editor_request() && self::preview_bundle_carries( $module );
	}

	/**
	 * Whether the bundle the editor preview loads carries all of an enabled module's
	 * CSS/JS. The optimized bundle is built from the files of every enabled module,
	 * companion plugins' included; the static fallback from this plugin's modules
	 * only, less STATIC_BUNDLE_OMITS.
	 *
	 * @param string $module Module slug.
	 * @return bool
	 */
	private static function preview_bundle_carries( $module ) {
		if ( self::serves_optimized_bundle() ) {
			return true;
		}

		return ! in_array( $module, self::STATIC_BUNDLE_OMITS, true ) && ! Admin\ModuleService::get_external_module( $module );
	}

	public function register_site_styles() {
		$direction_suffix = is_rtl() ? '.rtl' : '';

		wp_register_style( 'datatables', BDTEP_ASSETS_URL . 'css/datatables' . $direction_suffix . '.css', [], BDTEP_VER );
		wp_register_style( 'datatables-uikit', BDTEP_ASSETS_URL . 'css/datatables-uikit' . $direction_suffix . '.css', [], BDTEP_VER );
		wp_register_style( 'imagezoom', BDTEP_ASSETS_URL . 'css/imagezoom' . $direction_suffix . '.css', [], BDTEP_VER );
		wp_register_style( 'mThumbnailScroller', BDTEP_ASSETS_URL . 'css/jquery-mThumbnailScroller' . $direction_suffix . '.css', [], BDTEP_VER );

		// ACF widgets: see register_site_scripts().
		foreach ( self::acf_shared_module_assets() as $acf_widget => $shared ) {
			$module = $shared[0];

			if ( ! element_pack_is_third_party_enabled( $acf_widget ) || self::module_assets_are_bundled( $module ) ) {
				continue;
			}

			wp_register_style( 'ep-' . $module, BDTEP_ASSETS_URL . 'css/ep-' . $module . '.css', [ 'bdt-uikit', 'ep-helper' ], BDTEP_VER );
		}

		// Shared by the Tutor LMS course grid/carousel widgets; their only stylesheet,
		// so like any `ep-<module>` style it brings UIkit and the helper along.
		wp_register_style( 'ep-tutor-lms', BDTEP_ASSETS_URL . 'css/ep-tutor-lms.css', [ 'bdt-uikit', 'ep-helper' ], BDTEP_VER );

		// Vendor styles: unconditional for the same reason as the scripts.
		wp_register_style( 'tippy', BDTEP_ASSETS_URL . 'css/tippy.css', [], BDTEP_VER );
		wp_register_style( 'prism', BDTEP_ASSETS_URL . 'vendor/css/prism.css', [], BDTEP_VER );
	}

	/**
	 * Register the shared frontend styles (UIkit + helper).
	 *
	 * They are not enqueued on every request: a page that renders no Element Pack
	 * content has no use for ~145 KB of CSS. Whatever needs them declares them. Every
	 * widget's style depends reach both handles (see Module_Base::get_style_depends()),
	 * `ep-<module>` styles and the ep-styles bundle depend on them, and extensions
	 * enqueue them while they are switched on. enqueue_core_assets() loads them up
	 * front for Theme Builder templates and essential shortcodes.
	 */
	public function enqueue_site_styles() {

		$direction_suffix = is_rtl() ? '.rtl' : '';

		wp_register_style( 'bdt-uikit', BDTEP_ASSETS_URL . 'css/bdt-uikit' . $direction_suffix . '.css', [], '3.21.7' );
		wp_register_style( 'ep-helper', BDTEP_ASSETS_URL . 'css/ep-helper.css', [], BDTEP_VER );

		if ( $this->should_enqueue_core_assets() ) {
			self::enqueue_core_assets();
		}
	}

	/**
	 * Register the shared frontend scripts (UIkit + helper) and their config.
	 */
	public function enqueue_site_scripts() {

		wp_register_script( 'bdt-uikit', BDTEP_ASSETS_URL . 'js/bdt-uikit.min.js', [ 'jquery' ], '3.21.7', true );

		if ( self::is_editor_request() && self::serves_optimized_bundle() ) {
			// The optimized bundle starts with helper.min.js. Loading the file a second
			// time would bind its handlers twice (the password toggle would flip back).
			wp_register_script( 'element-pack-helper', false, [ 'ep-scripts' ], BDTEP_VER, true );
		} else {
			wp_register_script( 'element-pack-helper', BDTEP_ASSETS_URL . 'js/common/helper.min.js', [ 'jquery' ], BDTEP_VER, true );
		}

		$script_config = [
			'ajaxurl'       => admin_url( 'admin-ajax.php' ),
			'nonce'         => wp_create_nonce( 'element-pack-site' ),
			// When the page came out of a page cache, lets the browser tell whether the
			// nonce above is old enough to have expired (see nonce_refresh_script()).
			'nonce_time'    => time(),
			'data_table'    => [ 
				'language' => [
					// translators: 1: Start item number, 2: End item number, 3: Total items 
					'sLengthMenu'  => sprintf( esc_html_x( 'Show %1$s Entries', 'DataTable String', 'bdthemes-element-pack' ), '_MENU_' ),
					// translators: 1: Start item number, 2: End item number, 3: Total items 
					'sInfo'        => sprintf( esc_html_x( 'Showing %1$s to %2$s of %3$s entries', 'DataTable String', 'bdthemes-element-pack' ), '_START_', '_END_', '_TOTAL_' ),
					'sSearch'      => esc_html_x( 'Search :', 'DataTable String', 'bdthemes-element-pack' ),
					'sZeroRecords' => esc_html_x( 'No matching records found', 'DataTable String', 'bdthemes-element-pack' ),
					'oPaginate'    => [ 
						'sPrevious' => esc_html_x( 'Previous', 'DataTable String', 'bdthemes-element-pack' ),
						'sNext'     => esc_html_x( 'Next', 'DataTable String', 'bdthemes-element-pack' ),
					],
				],
			],
			'contact_form'  => [ 
				'sending_msg' => esc_html_x( 'Sending message please wait...', 'Contact Form String', 'bdthemes-element-pack' ),
				'captcha_nd'  => esc_html_x( 'Invisible captcha not defined!', 'Contact Form String', 'bdthemes-element-pack' ),
				'captcha_nr'  => esc_html_x( 'Could not get invisible captcha response!', 'Contact Form String', 'bdthemes-element-pack' ),

			],
			'mailchimp'     => [ 
				'subscribing' => esc_html_x( 'Subscribing you please wait...', 'Mailchimp String', 'bdthemes-element-pack' ),
			],
			'search'        => [ 
				'more_result'   => esc_html_x( 'More Results', 'Search Widget String', 'bdthemes-element-pack' ),
				'search_result' => esc_html_x( 'SEARCH RESULT', 'Search Widget String', 'bdthemes-element-pack' ),
				'not_found'     => esc_html_x( 'not found', 'Search Widget String', 'bdthemes-element-pack' ),
			],
			'words_limit'   => [ 
				'read_more' => esc_html_x( '[read more]', 'Read More String', 'bdthemes-element-pack' ),
				'read_less' => esc_html_x( '[read less]', 'Read Less String', 'bdthemes-element-pack' ),
			],
			'elements_data' => $this->elements_data,
		];

		// localize for user login widget ajax login script

		wp_localize_script(
			'bdt-uikit',
			'element_pack_ajax_login_config',
			array(
				'ajaxurl'        => admin_url( 'admin-ajax.php' ),
				'language'       => substr( get_locale(), 0, 2 ),
				'loadingmessage' => esc_html_x( 'Sending user info, please wait...', 'User Login and Register', 'bdthemes-element-pack' ),
				'unknownerror'   => esc_html_x( 'Unknown error, make sure access is correct!', 'User Login and Register', 'bdthemes-element-pack' ),
			)
		);

		$script_config = apply_filters( 'element_pack/frontend/localize_settings', $script_config );

		// TODO for editor script
		wp_localize_script( 'bdt-uikit', 'ElementPackConfig', $script_config );

		wp_add_inline_script( 'bdt-uikit', $this->nonce_refresh_script(), 'before' );
	}

	/**
	 * Enqueue the shared frontend assets: UIkit and the helper CSS/JS.
	 *
	 * Elementor content does not need this: widgets and extensions declare these
	 * handles themselves, so a page built only from core Elementor widgets loads none
	 * of them. It is for markup that renders outside that system — Theme Builder
	 * templates (so their widgets get UIkit in the head) and essential shortcodes —
	 * and for the `element_pack/frontend/enqueue_core_assets` filter. The widgets in
	 * a template still declare their own module files, so no bundle is needed here,
	 * with or without asset optimization.
	 * Safe to call any number of times, and before the handles are registered
	 * (WordPress queues those and enqueues them on registration).
	 *
	 * @return void
	 */
	public static function enqueue_core_assets() {
		wp_enqueue_style( 'bdt-uikit' );
		wp_enqueue_style( 'ep-helper' );
		wp_enqueue_script( 'bdt-uikit' );
		wp_enqueue_script( 'element-pack-helper' );
	}

	/**
	 * Whether the shared assets must be enqueued up front for this request, rather
	 * than waiting for Elementor content to ask for them.
	 *
	 * @return bool
	 */
	private function should_enqueue_core_assets() {
		$load = false;

		// Essential shortcodes print UIkit markup inside ordinary post content, where
		// Elementor is never involved. Load in the head when the post uses one; the
		// shortcode callbacks also enqueue on render as a fallback.
		if ( is_singular() && function_exists( 'ep_get_shortcode_prefix' ) ) {
			$post = get_queried_object();

			if ( $post instanceof \WP_Post && false !== strpos( $post->post_content, '[' . ep_get_shortcode_prefix() ) ) {
				$load = true;
			}
		}

		/**
		 * Filters whether Element Pack's shared frontend assets (UIkit and the helper
		 * CSS/JS) are enqueued on this request regardless of whether the page renders
		 * Element Pack content.
		 *
		 * Return true to restore the old always-on behaviour, e.g. for a theme that
		 * prints `bdt-` UIkit markup of its own.
		 *
		 * @param bool $load Whether to enqueue on this request.
		 */
		return (bool) apply_filters( 'element_pack/frontend/enqueue_core_assets', $load );
	}

	/**
	 * Inline script that swaps in a fresh `element-pack-site` nonce when the page was
	 * served from a page cache long enough ago for the printed nonce to have expired.
	 *
	 * A nonce is valid for 12–24 hours, so a cached page older than that makes every
	 * AJAX call that sends ElementPackConfig.nonce (search, webhook form, …) fail.
	 * Pages younger than 10 hours cost nothing: no request is made.
	 *
	 * @return string
	 */
	private function nonce_refresh_script() {
		return '(function(c){'
			. 'if(!c||!c.nonce_time||!window.fetch||Date.now()/1000-c.nonce_time<36000){return;}'
			. 'fetch(c.ajaxurl+"?action=element_pack_refresh_nonce",{credentials:"same-origin"})'
			. '.then(function(r){return r.json();})'
			. '.then(function(r){if(r&&r.success&&r.data&&r.data.nonce){c.nonce=r.data.nonce;c.nonce_time=Date.now()/1000;}})'
			. '.catch(function(){});'
			. '})(window.ElementPackConfig);';
	}

	/**
	 * AJAX: return a fresh `element-pack-site` nonce for a page that came out of a
	 * page cache. The value is the same one any page load would print for this
	 * visitor, so handing it out grants nothing new.
	 *
	 * @return void
	 */
	public function ajax_refresh_nonce() {
		nocache_headers();

		wp_send_json_success( [ 'nonce' => wp_create_nonce( 'element-pack-site' ) ] );
	}

	public function enqueue_editor_scripts() {

		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
		$api_settings = get_option( 'element_pack_api_settings' );

		wp_register_script(
			'element-pack',
			BDTEP_ASSETS_URL . 'js/ep-editor.min.js',
			[ 
				'backbone-marionette',
				'elementor-common-modules',
				'elementor-editor-modules',
			],
			BDTEP_VER,
			true
		);

		wp_enqueue_script( 'element-pack' );

	if ( element_pack_is_widget_enabled( 'advanced-gmap' ) ) {
		if ( ! empty( $api_settings['google_map_key'] ) ) {
			wp_register_script( 'gmap-api', 'https://maps.googleapis.com/maps/api/js?key=' . $api_settings['google_map_key'] . '&loading=async&libraries=marker', [ 'jquery' ], BDTEP_VER, true );
			wp_enqueue_script( 'gmap-api' );
		}
	}

		$localize_data = [ 
			'pro_installed'       => element_pack_pro_activated(),
			'promotional_widgets' => [],
		];

		
		if ( ! element_pack_pro_activated() ) {
			$pro_widget_map                       = new Pro_Widget_Map();
			$localize_data['promotional_widgets'] = $pro_widget_map->get_pro_widget_map();
		}

		wp_localize_script(
			'element-pack',
			'ElementPackConfigPromotional',
			$localize_data
		);
	}

	/**
	 * Load editor editor related style from here
	 */
	public function enqueue_preview_styles() {
		wp_enqueue_style( 'ep-preview', BDTEP_ASSETS_URL . 'css/ep-preview.css', [], BDTEP_VER );
	}

	public function enqueue_editor_styles() {
		wp_register_style( 'ep-editor', BDTEP_ASSETS_URL . 'css/ep-editor.css', [], BDTEP_VER );
		wp_enqueue_style( 'ep-editor' );
		wp_add_inline_style(
			'ep-editor',
			'#elementor-panel{'
				. '--ep-pro-control-message:' . wp_json_encode( __( 'This is a pro control, available with Element Pack Pro version.', 'bdthemes-element-pack' ) ) . ';'
				. '--ep-badge-new:' . wp_json_encode( __( 'NEW', 'bdthemes-element-pack' ) ) . ';'
				. '--ep-badge-pro:' . wp_json_encode( __( 'PRO', 'bdthemes-element-pack' ) ) . ';'
				. '--ep-badge-updated:' . wp_json_encode( __( 'UPDATED', 'bdthemes-element-pack' ) ) . ';'
			. '}'
		);
	}

	/**
	 * Whether the optimized bundle in uploads can be served on this request.
	 *
	 * The bundle only serves the Elementor editor and preview: the frontend loads
	 * each page's own module files (combined by Includes\Asset_Combiner).
	 *
	 * Only when asset optimization is on, both files exist, and they were built for
	 * the current plugin version and module registry. A stale bundle (just after an
	 * update, or while companion-plugin modules changed) or a missing one (e.g. after
	 * a site migration) is swapped for the static full bundle shipped with the plugin
	 * while a rebuild is scheduled, so visitors never get a half-matching file set.
	 *
	 * @return bool
	 */
	public static function serves_optimized_bundle() {
		static $serves = null;

		if ( null !== $serves ) {
			return $serves;
		}

		if ( ! element_pack_is_asset_optimization_enabled() ) {
			return $serves = false;
		}

		$instance = self::instance();
		$current  = get_option( 'element_pack_optimized_assets_fingerprint' ) === self::optimized_assets_fingerprint();
		$exists   = file_exists( $instance->get_upload_dir() . 'css/ep-styles.css' )
			&& file_exists( $instance->get_upload_dir() . 'js/ep-scripts.js' );

		if ( ! $current || ! $exists ) {
			self::schedule_optimized_assets_rebuild();

			return $serves = false;
		}

		return $serves = true;
	}

	public function enqueue_minified_css() {

		// The bundle holds widget CSS only; the UIkit and helper styles it is written
		// against are separate files, so anything that loads the bundle needs them.
		if ( self::serves_optimized_bundle() ) {
			$version = get_option( 'element-pack-minified-asset-manager-version' );
			wp_register_style( 'ep-styles', $this->get_upload_url() . 'css/ep-styles.css', [ 'bdt-uikit', 'ep-helper' ], $version );
		} else {
			wp_register_style( 'ep-styles', BDTEP_URL . 'assets/css/ep-styles.css', [ 'bdt-uikit', 'ep-helper' ], BDTEP_VER );
		}

		// Registered in every mode, although both bundles carry a copy: widgets without a
		// stylesheet of their own, the WooCommerce swatches and the rating shortcode ask
		// for the icon font alone, and would otherwise get nothing (or, as an alias of
		// the bundle, every enabled widget's CSS for one icon font). Next to the bundle
		// it is not printed; see skip_bundled_font().
		wp_register_style( 'ep-font', BDTEP_ASSETS_URL . 'css/ep-font.css', [], BDTEP_VER );

		// The bundle is only for the editor and preview. On the frontend, widgets and
		// extensions load their own `ep-<module>` files, in every mode; with asset
		// optimization on, Includes\Asset_Combiner joins the ones a page uses.

		/**
		 * Must load into Editor for Extension Support
		 * 
		 * by U-011
		 */
		if ( Element_Pack_Loader::elementor()->preview->is_preview_mode() || Element_Pack_Loader::elementor()->editor->is_edit_mode() ) {
			wp_enqueue_style( 'ep-styles' );
		}
	}

	/**
	 * Leave the standalone ep-font.css out wherever the ep-styles bundle is printed;
	 * both the static and the optimized bundle contain it.
	 *
	 * @param string[] $to_do Style handles about to be printed.
	 * @return string[]
	 */
	public static function skip_bundled_font( $to_do ) {
		$font = array_search( 'ep-font', $to_do, true );

		if ( false !== $font && ( in_array( 'ep-styles', $to_do, true ) || wp_style_is( 'ep-styles', 'done' ) ) ) {
			unset( $to_do[ $font ] );
			$to_do = array_values( $to_do );
		}

		return $to_do;
	}

	public function enqueue_minified_js() {

		// Module scripts call bdtUIkit and the helper globals, and neither is part of
		// the bundle, except that the optimized one starts with helper.min.js.
		if ( self::serves_optimized_bundle() ) {
			$version = get_option( 'element-pack-minified-asset-manager-version' );
			wp_register_script( 'ep-scripts', $this->get_upload_url() . 'js/ep-scripts.js', [ 'jquery', 'bdt-uikit' ], $version, true );
		} else {
			// The static bundle ships with the plugin, so it must be versioned by the
			// plugin: the optimizer's option is unset here, or belongs to another file.
			wp_register_script( 'ep-scripts', BDTEP_URL . 'assets/js/ep-scripts.min.js', [ 'jquery', 'bdt-uikit', 'element-pack-helper' ], BDTEP_VER, true );
		}

		/**
		 * Must load into Editor for Extension Support
		 * 
		 * by U-011
		 */
		if ( Element_Pack_Loader::elementor()->preview->is_preview_mode() || Element_Pack_Loader::elementor()->editor->is_edit_mode() ) {
			wp_enqueue_script( 'ep-scripts' );
		}
	}

	/**
	 * Callback to shortcodes template
	 * @param array $atts attributes for shortcode.
	 */
	public function shortcode_template( $atts ) {

		$atts = shortcode_atts(
			array(
				'id' => '',
			),
			$atts,
			'rooten_custom_template'
		);

		$id = ! empty( $atts['id'] ) ? intval( $atts['id'] ) : '';

		if ( empty( $id ) ) {
			return '';
		}

		return self::elementor()->frontend->get_builder_content_for_display( $id , true);
	}

	/**
	 * Add element_pack_ajax_login() function with wp_ajax_nopriv_ function
	 */
	public function element_pack_ajax_login_init() {
		add_action( 'wp_ajax_nopriv_element_pack_ajax_login', [ $this, "element_pack_ajax_login" ] );
	}

	/**
	 * For ajax login
	 */
	public function element_pack_ajax_login() {
		// First check the nonce, if it fails the function will break
		check_ajax_referer( 'ajax-login-nonce', 'bdt-user-login-sc' );

		// Nonce is checked, get the POST data and sign user on
		$access_info                  = [];
		$access_info['user_login']    = ! empty( $_POST['user_login'] ) ? sanitize_user( wp_unslash( $_POST['user_login'] ) ) : '';
		$access_info['user_password'] = ! empty( $_POST['user_password'] ) ? wp_unslash( $_POST['user_password'] ) : '';
		$access_info['remember']      = ! empty( $_POST['rememberme'] ) ? true : false;
		$user_signon                  = wp_signon( $access_info, false );

		if ( ! is_wp_error( $user_signon ) ) {
			echo wp_json_encode(
				[ 
					'loggedin' => true,
					'message'  => esc_html_x( 'Login successful, Redirecting...', 'User Login and Register', 'bdthemes-element-pack' ),
				]
			);
		} else {
			echo wp_json_encode(
				[ 
					'loggedin' => false,
					'message'  => esc_html_x( 'Oops! Wrong username or password!', 'User Login and Register', 'bdthemes-element-pack' ),
				]
			);
		}

		die();
	}

	// Load WPML compatibility instance
	public function wpml_compatiblity() {
		return Element_Pack_WPML::get_instance();
	}

	/**
	 * initialize the category
	 * @return void
	 */
	public function element_pack_init() {
		$context_menu = element_pack_option( 'context-menu', 'element_pack_other_settings', 'off' );

		$this->_modules_manager = new Manager();

		do_action( 'bdthemes_element_pack/init' );

		if ( 'on' === $context_menu ) {
			add_action( 'elementor/kit/register_tabs', function (Kit $kit) {
				$kit->register_tab( 'element-pack-context-menu', Includes\Settings\Context_Menu_Controls::class);
			}, 1, 40 );
		}
	}

	public function ElementPack_Json_File_Import_register_controls() {
		$controls_manager = Plugin::$instance->controls_manager;
		$controls_manager->register( new ElementPack_JSON_File_Upload_Control() );
	}

	public function ElementPack_FB_Token_Register_Controls() {

		$controls_manager = Plugin::$instance->controls_manager;
		$controls_manager->register( new ElementPack_FB_Access_Token_Generator_Control() );
	}

	/**
	 * initialize the category
	 * @return [type] [description]
	 */
	public function element_pack_category_register() {

		$elementor = Plugin::$instance;

		if ( ! element_pack_pro_activated() ) {
			$elementor->elements_manager->add_category( BDTEP_SLUG, [ 'title' => 'Element Pack (Lite)', 'icon' => 'font' ] );
		} else {
			$elementor->elements_manager->add_category( BDTEP_SLUG, [ 'title' => BDTEP_TITLE, 'icon' => 'font' ] );
		}
	}

	public function bdt_builder_single_category_register() {
		$elementor = Plugin::$instance;
		$elementor->elements_manager->add_category(
			'bdt-template-builder',
			[ 
				'title' => esc_html__( 'Element Pack (Single)', 'bdthemes-element-pack' ),
				'icon'  => 'font'
			]
		);
	}

	/**
	 * Keep the optimized asset bundle (uploads/element-pack/minified) in sync
	 * with the set of modules that can contribute to it.
	 *
	 * The bundle is otherwise only rebuilt when the dashboard settings are saved
	 * or the cache is cleared. So when a companion plugin such as Element Pack
	 * Addon is activated, deactivated or updated, or Pro itself is updated, the
	 * bundle keeps serving the old file set and its widgets render unstyled.
	 * This compares a fingerprint of (Pro version + registered external modules)
	 * with the one the current bundle was built from and rebuilds once when it
	 * differs. Costs one (autoloaded) option read per request.
	 *
	 * The rebuild reads ~2.6 MB of CSS/JS and runs the minifier, so it never runs
	 * inside a visitor's page view: admin requests rebuild inline, everyone else
	 * hands it to WP-Cron, and the editor preview gets the static bundle until it
	 * has finished (see serves_optimized_bundle()). Frontend pages do not use it.
	 */
	public function maybe_regenerate_optimized_assets() {
		if ( wp_doing_ajax() || ( defined( 'DOING_CRON' ) && DOING_CRON ) ) {
			return;
		}

		$fingerprint = self::optimized_assets_fingerprint();

		if ( get_option( 'element_pack_optimized_assets_fingerprint' ) === $fingerprint ) {
			return;
		}

		if ( ! element_pack_is_asset_optimization_enabled() ) {
			update_option( 'element_pack_optimized_assets_fingerprint', $fingerprint, true );
			return;
		}

		if ( is_admin() ) {
			self::regenerate_optimized_assets();
		} else {
			self::schedule_optimized_assets_rebuild();
		}
	}

	/**
	 * WP-Cron hook that rebuilds the optimized bundle off the request path.
	 */
	const OPTIMIZED_ASSETS_CRON_HOOK = 'element_pack_regenerate_optimized_assets';

	/**
	 * Fingerprint of everything the optimized bundle is built from, other than the
	 * enabled-module settings (saving those rebuilds the bundle directly).
	 *
	 * @return string
	 */
	public static function optimized_assets_fingerprint() {
		return md5( BDTEP_VER . '|' . wp_json_encode( Admin\ModuleService::get_external_modules() ) );
	}

	/**
	 * Drop the asset lists Elementor cached per page when Element Pack's code changes.
	 *
	 * Elementor stores the style/script handles a document's elements declare in
	 * `_elementor_page_assets` once, and its element cache replays the handles that
	 * were enqueued while the markup rendered. Neither is rebuilt when an update
	 * changes what the widgets and extensions declare, so every page cached before
	 * the update would keep loading the old list — e.g. without UIkit, which pages
	 * used to get regardless. Both are caches that Elementor rebuilds on the next view
	 * of each page, as it does after its own "Regenerate CSS & Data". Keyed on the
	 * same inputs as the optimized bundle: this plugin's version and the companion
	 * plugins' modules.
	 *
	 * @return void
	 */
	public function maybe_flush_elementor_asset_caches() {
		$fingerprint = self::optimized_assets_fingerprint();

		if ( get_option( 'element_pack_elementor_assets_fingerprint' ) === $fingerprint ) {
			return;
		}

		delete_post_meta_by_key( '_elementor_page_assets' );
		delete_post_meta_by_key( '_elementor_element_cache' );

		update_option( 'element_pack_elementor_assets_fingerprint', $fingerprint, true );
	}

	/**
	 * Have the next request drop Elementor's cached asset lists.
	 *
	 * Hooked to changes of the enabled-module settings: a list Elementor built while
	 * a module was switched off lacks that module's handles once it is back on.
	 *
	 * @return void
	 */
	public static function forget_elementor_asset_caches() {
		delete_option( 'element_pack_elementor_assets_fingerprint' );
	}

	/**
	 * Queue a single background rebuild of the optimized bundle.
	 *
	 * Backs off for an hour after a failed rebuild (e.g. uploads not writable), so a
	 * broken filesystem costs one attempt per hour instead of one per request.
	 *
	 * @return void
	 */
	public static function schedule_optimized_assets_rebuild() {
		if ( get_transient( 'element_pack_optimized_assets_failed' ) ) {
			return;
		}

		if ( ! wp_next_scheduled( self::OPTIMIZED_ASSETS_CRON_HOOK ) ) {
			wp_schedule_single_event( time(), self::OPTIMIZED_ASSETS_CRON_HOOK );
		}
	}

	/**
	 * Rebuild the optimized CSS/JS bundle from the currently enabled modules.
	 * Safe to call from anywhere after plugins_loaded (used by the dashboard
	 * "clear cache" flow and by companion plugins on (de)activation).
	 *
	 * Only one rebuild runs at a time; a call made while another is in progress
	 * returns false straight away. The files are written atomically, so a request
	 * reading them mid-rebuild still gets a complete file.
	 *
	 * @return bool Whether the bundle was rebuilt.
	 */
	public static function regenerate_optimized_assets() {
		if ( ! self::acquire_optimized_assets_lock() ) {
			return false;
		}

		$built = false;

		try {
			$minifier = new \ElementPack\Admin\AssetMinifier\Asset_Minifier();
			$built    = $minifier->minifyCss() && $minifier->minifyJs();
		} finally {
			self::release_optimized_assets_lock();
		}

		if ( ! $built ) {
			set_transient( 'element_pack_optimized_assets_failed', 1, HOUR_IN_SECONDS );

			return false;
		}

		delete_transient( 'element_pack_optimized_assets_failed' );
		update_option( 'element-pack-minified-asset-manager-version', time() );
		update_option( 'element_pack_optimized_assets_fingerprint', self::optimized_assets_fingerprint(), true );

		return true;
	}

	/**
	 * Take the rebuild lock.
	 *
	 * add_option() is not a lock (it upserts), so this uses an INSERT IGNORE on the
	 * options table's unique key, the same approach as WP_Upgrader::create_lock().
	 * A lock older than five minutes belongs to a rebuild that died and is taken over.
	 *
	 * @return bool Whether this process now holds the lock.
	 */
	private static function acquire_optimized_assets_lock() {
		global $wpdb;

		$lock = 'element_pack_optimized_assets_lock';
		$now  = time();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Atomic lock; must bypass the options cache.
		$inserted = $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$wpdb->options} ( option_name, option_value, autoload ) VALUES ( %s, %s, 'no' )", $lock, $now ) );

		if ( $inserted ) {
			return true;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Atomic lock; must bypass the options cache.
		$locked_at = (int) $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $lock ) );

		if ( $locked_at > $now - 5 * MINUTE_IN_SECONDS ) {
			return false;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Atomic lock; must bypass the options cache.
		return (bool) $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->options} SET option_value = %s WHERE option_name = %s AND option_value = %s", $now, $lock, $locked_at ) );
	}

	/**
	 * Release the rebuild lock.
	 *
	 * @return void
	 */
	private static function release_optimized_assets_lock() {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Atomic lock; must bypass the options cache.
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name = %s", 'element_pack_optimized_assets_lock' ) );
	}

	public function element_pack_svg_support() {

		return SVG_Support::get_instance();
	}

	private function setup_hooks() {
		// ── Debug System ──────────────────────────────────────────
		// Frontend / Elementor preview: full debug panel
		add_action( 'wp', function () {
			if ( class_exists( '\\ElementPack\\Includes\\Debug\\EP_Debug_Manager' )
				&& \ElementPack\Includes\Debug\EP_Debug_Manager::should_enable()
			) {
				\ElementPack\Includes\Debug\EP_Debug_Manager::instance();
			}
		}, 1 );
		// Admin: persist ?ep_debug flag so the preview iframe can read it
		add_action( 'admin_init', function () {
			if ( class_exists( '\\ElementPack\\Includes\\Debug\\EP_Debug_Manager' ) ) {
				\ElementPack\Includes\Debug\EP_Debug_Manager::persist_debug_flag();
			}
		} );
		// Elementor editor: show debug badge when active
		add_action( 'elementor/editor/after_enqueue_scripts', function () {
			if ( class_exists( '\\ElementPack\\Includes\\Debug\\EP_Debug_Manager' ) ) {
				\ElementPack\Includes\Debug\EP_Debug_Manager::inject_editor_ui();
			}
		} );

		add_action( 'elementor/init', [ $this, 'element_pack_init' ] );

		add_action( 'init', [ $this, 'maybe_regenerate_optimized_assets' ], 20 );
		add_action( 'init', [ $this, 'maybe_flush_elementor_asset_caches' ], 20 );
		foreach ( [ 'element_pack_active_modules', 'element_pack_elementor_extend', 'element_pack_third_party_widget' ] as $modules_option ) {
			add_action( "add_option_{$modules_option}", [ __CLASS__, 'forget_elementor_asset_caches' ] );
			add_action( "update_option_{$modules_option}", [ __CLASS__, 'forget_elementor_asset_caches' ] );
		}
		add_action( self::OPTIMIZED_ASSETS_CRON_HOOK, [ __CLASS__, 'regenerate_optimized_assets' ] );

		add_action( 'elementor/controls/register', [ $this, 'ElementPack_Json_File_Import_register_controls' ] );
		add_action( 'elementor/controls/register', [ $this, 'ElementPack_FB_Token_Register_Controls' ] );
		add_action( 'elementor/elements/categories_registered', [ $this, 'bdt_builder_single_category_register' ], 1, 2 );
		add_action( 'elementor/elements/categories_registered', [ $this, 'element_pack_category_register' ] );

		add_action( 'elementor/editor/after_enqueue_styles', [ $this, 'enqueue_editor_styles' ] );

		add_action( 'wp_enqueue_scripts', [ $this, 'register_site_styles' ], 99999 );
		add_action( 'wp_enqueue_scripts', [ $this, 'register_site_scripts' ], 99999 );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_site_styles' ], 99999 );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_site_scripts' ], 99999 );

		add_action( 'wp_ajax_element_pack_refresh_nonce', [ $this, 'ajax_refresh_nonce' ] );
		add_action( 'wp_ajax_nopriv_element_pack_refresh_nonce', [ $this, 'ajax_refresh_nonce' ] );

		add_action( 'elementor/preview/enqueue_styles', [ $this, 'enqueue_preview_styles' ] );
		add_action( 'elementor/editor/after_enqueue_scripts', [ $this, 'enqueue_editor_scripts' ] );


		// For frontend css load
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_minified_css' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_minified_js' ], 99999 );
		add_filter( 'print_styles_array', [ __CLASS__, 'skip_bundled_font' ] );

		add_filter( 'element_pack/optimization/bundle_module_handles', [ __CLASS__, 'bundle_module_handles' ], 10, 2 );
		Includes\Asset_Combiner::init();

		add_shortcode( 'rooten_custom_template', [ $this, 'shortcode_template' ] );

		// When user not login add this action
		if ( ! is_user_logged_in() ) {
			add_action( 'elementor/init', [ $this, 'element_pack_ajax_login_init' ] );
		}

		add_action('elementor/init', function() {
			if ( ! element_pack_pro_activated() ) {
				// Build the pro widget map inside the editor filter: it walks the full
				// module settings array and a get_plugins() scan, which is wasted work on
				// every frontend, REST and AJAX request of an unlicensed site.
				add_filter(
					'elementor/editor/localize_settings',
					function ( $settings ) {
						if ( ! is_array( $settings ) || ! isset( $settings['initial_document']['widgets'] ) ) {
							return $settings;
						}

						$pro_widget_map       = new Pro_Widget_Map();
						$pro_widgets_raw_data = $pro_widget_map->get_pro_widget_map();

						if ( ! is_array( $pro_widgets_raw_data ) ) {
							return $settings;
						}

						$pro_widget_names = array_filter( array_column( $pro_widgets_raw_data, 'name' ) );

						foreach ( $pro_widget_names as $widget_name ) {
							$widget_key = 'bdt-' . $widget_name;

							if ( ! isset( $settings['initial_document']['widgets'][ $widget_key ] ) ) {
								continue;
							}

							$settings['initial_document']['widgets'][ $widget_key ]['show_in_panel'] = false;
						}

						return $settings;
					},
					99
				);
			}
		});
	}

	/**
	 * Load files on init
	 */
	public function init() {
		if ( is_admin() ) {
			if ( ! defined( 'BDTEP_CH' ) ) {

				// Biggopti class
				require_once(BDTEP_ADMIN_PATH . 'admin-biggopti.php');

				require_once BDTEP_ADMIN_PATH . 'admin.php';
				new Admin();
			}
		}
	}

	/**
	 * Element_Pack_Loader constructor.
	 */
	private function __construct() {
		// Register class automatically
		spl_autoload_register( [ $this, 'autoload' ] );
		// Include some backend files
		$this->_includes();

		add_filter( 'bdt_ep_init_pro', [ $this, 'pro_return' ], 100 );

		// Finally hooked up all things here
		$this->setup_hooks();


		$svg_support = element_pack_option( 'svg-support', 'element_pack_other_settings', 'on' );

		if ( 'on' === $svg_support ) {
			$this->element_pack_svg_support()->init();
		}

		$this->wpml_compatiblity()->init();

		add_action( 'init', [ $this, 'init' ] );
	}
}

if ( !defined( 'BDTEP_TESTS' ) ) {
    // In tests we run the instance manually.
    Element_Pack_Loader::instance();
}

// handy function for push data
function element_pack_config() {
    return Element_Pack_Loader::instance();
}
