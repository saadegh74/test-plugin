<?php

namespace ElementPack\Base;

use ElementPack\Includes\Builder\Builder_Widget_Base;
use ElementPack\Element_Pack_Loader;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

abstract class Module_Base extends Builder_Widget_Base {

	/**
	 * Prevent duplicate Elementor control registration notices.
	 *
	 * Some widgets (or editor hooks) may attempt to register the same control
	 * twice — e.g. "set_api_key" — which triggers _doing_it_wrong in Elementor.
	 */
	public function add_control( $id, array $args, $options = [] ) {
		$options = is_array( $options ) ? $options : [];

		if ( empty( $options['overwrite'] ) && isset( $this->get_controls()[ $id ] ) ) {
			return;
		}

		parent::add_control( $id, $args, $options );
	}

	/**
	 * Show a missing API key notice in the Elementor panel.
	 *
	 * Always pass a unique $control_id per widget/section (never reuse "set_api_key").
	 */
	protected function register_api_key_missing_notice( $control_id, $message, $args = [] ) {
		if ( isset( $this->get_controls()[ $control_id ] ) ) {
			return;
		}

		$this->add_control(
			$control_id,
			array_merge(
				[
					'type'            => \Elementor\Controls_Manager::RAW_HTML,
					'raw'             => $message,
					'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
				],
				$args
			)
		);
	}

	/**
	 * Styles for a widget that has no stylesheet of its own.
	 *
	 * UIkit and the helper stylesheet are not loaded on every page; each widget has to
	 * reach them through what it declares. A widget's own `ep-<module>` style already
	 * depends on both, so this default only matters to widgets without one, and an
	 * override that returns other handles must add `bdt-uikit` and `ep-helper` itself.
	 *
	 * @return string[]
	 */
	public function get_style_depends() {
		if ( $this->ep_is_edit_mode() ) {
			return [ 'ep-styles' ];
		}

		return [ 'bdt-uikit', 'ep-helper' ];
	}

	/**
	 * Scripts for a widget that has no script of its own: UIkit, which initialises
	 * every `bdt-*` component and carries ElementPackConfig, and the helper globals.
	 *
	 * @see get_style_depends()
	 *
	 * @return string[]
	 */
	public function get_script_depends() {
		if ( $this->ep_is_edit_mode() ) {
			return [ 'ep-scripts' ];
		}

		return [ 'bdt-uikit', 'element-pack-helper' ];
	}

	protected function ep_is_edit_mode() {

		if ( Element_Pack_Loader::elementor()->preview->is_preview_mode() || Element_Pack_Loader::elementor()->editor->is_edit_mode() ) {
			return true;
		}

		return false;
	}
}

