<?php
namespace ElementPack\Base;

// Elementor Classes
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * \Base\Condition
 * @since  5.3.0
 */
abstract class Condition {

	/**
	 * @var Module_Base
	 */
	protected static $_instances = [];

	protected $element_id;

	/**
	 * @return string of the current module class name
	 * @since 5.3.0
	 */
	public static function class_name() {
		return get_called_class();
	}

	/**
	 * @return static
	 */
	public static function instance() {
		if ( empty( static::$_instances[ static::class_name() ] ) ) {
			static::$_instances[ static::class_name() ] = new static();
		}

		return static::$_instances[ static::class_name() ];
	}

	/**
	 * Defaults to true
	 * @return bool if current condition is supported
	 * @since  5.3.0
	 */
	public static function is_supported() {
		return true;
	}

	/**
	 * Get the name of condition
	 * @return string as per our condition control name
	 * @since  5.3.0
	 */
	public function get_name() {}

	/**
	 * Get the title of condition
	 * @return string as per condition control title
	 * @since  5.3.0
	 */
	public function get_title() {}

	/**
	 * Get the control name
	 * @return string as per condition control name
	 * @since  5.3.0
	 */
	public function get_name_control() {
		return false; }

	/**
	 * Get the control value
	 * @return string as per condition control value
	 * @since  5.3.0
	 */
	public function get_value_control() {}

	/**
	 * Check the condition
	 * @param string $relation Comparison operator for compare function
	 * @param mixed $val will check the control value as per condition needs
	 * @since 5.3.0
	 */
	public function check( $relation, $val ) {}

	/**
	 * Compare conditions.
	 * Calls compare method
	 * @param mixed  $left_val  First value to compare.
	 * @param mixed  $right_val Second value to compare.
	 * @param string $relation  Comparison operator.
	 * @return bool
	 * @since 5.3.0
	 *
	 */
	public function compare( $left_val, $right_val, $relation ) {
		switch ( $relation ) {
			case 'is':
				return $left_val == $right_val;
			case 'not':
				return $left_val != $right_val;
			default:
				return $left_val === $right_val;
		}
	}

	/**
	 * Set Condition Element ID
	 * Set the element ID for this condition
	 * @return string
	 * @since  5.3.0
	 */
	public function set_element_id( $id ) {
		$this->element_id = $id;
	}

	/**
	 * Get Condition Element ID
	 * Returns the previously set element id
	 * @return string
	 * @since  5.3.0
	 */
	protected function get_element_id() {
		return $this->element_id;
	}

	/**
	 * Cookies that could not be sent as headers, printed from wp_footer.
	 *
	 * @var array<string, array{value: string, expires: int, path: string}>
	 */
	private static $deferred_cookies = [];

	/**
	 * Set a cookie from inside an element's render.
	 *
	 * Conditions are checked while the page body is already being output, when the
	 * response headers are normally gone. Conditions used to cope by holding the whole
	 * page in an output buffer from `template_redirect` on every request, so nothing
	 * reached the browser before PHP finished. Now the cookie goes out as a header when
	 * that is still possible and is otherwise set by a small script in the footer,
	 * which has the same effect for the visitor's next request.
	 *
	 * @param string $name    Cookie name.
	 * @param string $value   Cookie value.
	 * @param int    $expires Unix timestamp, or 0 for a session cookie.
	 * @param string $path    Cookie path; empty for the browser/PHP default (the current directory).
	 * @return void
	 */
	protected static function set_cookie( $name, $value, $expires = 0, $path = '' ) {
		if ( ! headers_sent() ) {
			setcookie( $name, $value, $expires, $path );
			return;
		}

		if ( empty( self::$deferred_cookies ) ) {
			add_action( 'wp_footer', [ __CLASS__, 'print_deferred_cookies' ], 1 );
		}

		self::$deferred_cookies[ $name ] = [
			'value'   => (string) $value,
			'expires' => (int) $expires,
			'path'    => (string) $path,
		];
	}

	/**
	 * Print the cookies queued by set_cookie() after the headers were sent.
	 *
	 * @return void
	 */
	public static function print_deferred_cookies() {
		if ( empty( self::$deferred_cookies ) ) {
			return;
		}

		$statements = '';

		foreach ( self::$deferred_cookies as $name => $cookie ) {
			// Same encoding PHP's setcookie() uses, so $_COOKIE decodes it identically.
			$pair = rawurlencode( $name ) . '=' . rawurlencode( $cookie['value'] );

			if ( $cookie['expires'] > 0 ) {
				$pair .= '; expires=' . gmdate( 'D, d M Y H:i:s', $cookie['expires'] ) . ' GMT';
			}

			if ( '' !== $cookie['path'] ) {
				$pair .= '; path=' . $cookie['path'];
			}

			$statements .= 'document.cookie=' . wp_json_encode( $pair . '; SameSite=Lax' ) . ';';
		}

		self::$deferred_cookies = [];

		wp_print_inline_script_tag( $statements );
	}

	/**
	 * ID of the visitor's current browser session, kept in a session cookie.
	 *
	 * Replaces PHP's native session (session_start()), which locked the session file
	 * for the rest of the request, serialising the visitor's parallel requests, and
	 * sent no-cache headers that disabled page caching.
	 *
	 * @return string
	 */
	protected static function get_browser_session_id() {
		static $id = null;

		if ( null !== $id ) {
			return $id;
		}

		$name = 'ep_vc_session';

		if ( ! empty( $_COOKIE[ $name ] ) ) {
			$id = sanitize_key( wp_unslash( $_COOKIE[ $name ] ) );
		}

		if ( empty( $id ) ) {
			// Lowercase hex, so it survives sanitize_key() unchanged on the next request.
			$id = wp_generate_uuid4();
			self::set_cookie( $name, $id, 0, '/' );
		}

		return $id;
	}
}
