<?php

namespace ElementPack\Modules\ImageMasking\Atomic;

use Elementor\Modules\AtomicWidgets\PropTypes\Image_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Image_Src_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\Utils\Image\Image_Sizes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Mask_Custom_Shape_Image_Prop_Type extends Image_Prop_Type {
	protected function define_shape(): array {
		return [
			'src' => Image_Src_Prop_Type::make(),
			'size' => String_Prop_Type::make()
				->default( 'full' )
				->initial_value( 'full' )
				->enum( Image_Sizes::get_keys() )
				->required()
				->description( 'The image file size to use for the mask shape.' ),
		];
	}
}
