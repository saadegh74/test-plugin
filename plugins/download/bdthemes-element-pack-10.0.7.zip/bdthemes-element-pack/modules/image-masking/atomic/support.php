<?php

namespace ElementPack\Modules\ImageMasking\Atomic;

use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Image_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Select_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Size_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Switch_Control;
use Elementor\Modules\AtomicWidgets\PropDependencies\Manager as Dependency_Manager;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Size_Prop_Type;
use Elementor\Modules\AtomicWidgets\Styles\Size_Constants;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Support {
	public const ACTIVE_KEY = 'image_mask_popover';
	public const SHAPE_KEY = 'image_mask_shape';
	public const SHAPE_DEFAULT_KEY = 'image_mask_shape_default';
	public const SHAPE_CUSTOM_KEY = 'image_mask_shape_custom';
	public const POSITION_KEY = 'image_mask_shape_position';
	public const SIZE_KEY = 'image_mask_shape_size';
	public const CUSTOM_SIZE_KEY = 'image_mask_shape_custom_size';
	public const REPEAT_KEY = 'image_mask_shape_repeat';

	public function register_schema( array $schema ): array {
		$active_dependencies = $this->get_active_dependencies();
		$default_shape_dependencies = $this->get_shape_dependencies( 'default' );
		$custom_shape_dependencies = $this->get_shape_dependencies( 'custom' );
		$custom_size_dependencies = $this->get_custom_size_dependencies();

		$schema[ self::ACTIVE_KEY ] = $schema[ self::ACTIVE_KEY ] ?? Boolean_Prop_Type::make()->default( false );
		$schema[ self::SHAPE_KEY ] = $schema[ self::SHAPE_KEY ] ?? String_Prop_Type::make()
			->default( 'default' )
			->set_dependencies( $active_dependencies );
		$schema[ self::SHAPE_DEFAULT_KEY ] = $schema[ self::SHAPE_DEFAULT_KEY ] ?? String_Prop_Type::make()
			->default( 'shape-1' )
			->set_dependencies( $default_shape_dependencies );
		$schema[ self::SHAPE_CUSTOM_KEY ] = $schema[ self::SHAPE_CUSTOM_KEY ] ?? Mask_Custom_Shape_Image_Prop_Type::make()
			->set_dependencies( $custom_shape_dependencies );
		$schema[ self::POSITION_KEY ] = $schema[ self::POSITION_KEY ] ?? String_Prop_Type::make()
			->default( 'center-center' )
			->set_dependencies( $active_dependencies );
		$schema[ self::SIZE_KEY ] = $schema[ self::SIZE_KEY ] ?? String_Prop_Type::make()
			->default( 'contain' )
			->set_dependencies( $active_dependencies );
		$schema[ self::CUSTOM_SIZE_KEY ] = $schema[ self::CUSTOM_SIZE_KEY ] ?? Size_Prop_Type::make()
			->units( [ Size_Constants::UNIT_PX, Size_Constants::UNIT_EM, Size_Constants::UNIT_PERCENT, Size_Constants::UNIT_VW ] )
			->default_unit( Size_Constants::UNIT_PERCENT )
			->default( [ 'size' => 100, 'unit' => Size_Constants::UNIT_PERCENT ] )
			->set_dependencies( $custom_size_dependencies );
		$schema[ self::REPEAT_KEY ] = $schema[ self::REPEAT_KEY ] ?? String_Prop_Type::make()
			->default( 'no-repeat' )
			->set_dependencies( $active_dependencies );

		return $schema;
	}

	public function register_controls( array $controls ): array {
		$item = Section::make()
			->set_id( 'ep_section_image_masking' )
			->set_label( esc_html__( 'Image Masking', 'bdthemes-element-pack' ) )
			->set_items( [] );

		$controls[] = $item;

		$item->add_item(
			Switch_Control::bind_to( self::ACTIVE_KEY )
				->set_label( esc_html__( 'Image Masking', 'bdthemes-element-pack' ) )
		);

		$item->add_item(
			Select_Control::bind_to( self::SHAPE_KEY )
				->set_label( esc_html__( 'Masking Shape', 'bdthemes-element-pack' ) )
				->set_options( [
					[ 'value' => 'default', 'label' => esc_html__( 'Default Shapes', 'bdthemes-element-pack' ) ],
					[ 'value' => 'custom', 'label' => esc_html__( 'Custom Shape', 'bdthemes-element-pack' ) ],
				] )
		);

		$item->add_item(
			Select_Control::bind_to( self::SHAPE_DEFAULT_KEY )
				->set_label( esc_html__( 'Default Shape', 'bdthemes-element-pack' ) )
				->set_options( $this->get_default_shape_options() )
		);

		$item->add_item(
			Image_Control::bind_to( self::SHAPE_CUSTOM_KEY )
				->set_label( esc_html__( 'Custom Shape', 'bdthemes-element-pack' ) )
		);

		$item->add_item(
			Select_Control::bind_to( self::POSITION_KEY )
				->set_label( esc_html__( 'Position', 'bdthemes-element-pack' ) )
				->set_options( $this->get_position_options() )
		);

		$item->add_item(
			Select_Control::bind_to( self::SIZE_KEY )
				->set_label( esc_html__( 'Size', 'bdthemes-element-pack' ) )
				->set_options( [
					[ 'value' => 'auto', 'label' => esc_html__( 'Auto', 'bdthemes-element-pack' ) ],
					[ 'value' => 'cover', 'label' => esc_html__( 'Cover', 'bdthemes-element-pack' ) ],
					[ 'value' => 'contain', 'label' => esc_html__( 'Contain', 'bdthemes-element-pack' ) ],
					[ 'value' => 'initial', 'label' => esc_html__( 'Custom', 'bdthemes-element-pack' ) ],
				] )
		);

		$item->add_item(
			Size_Control::bind_to( self::CUSTOM_SIZE_KEY )
				->set_label( esc_html__( 'Custom Size', 'bdthemes-element-pack' ) )
				->set_units( [ Size_Constants::UNIT_PX, Size_Constants::UNIT_EM, Size_Constants::UNIT_PERCENT, Size_Constants::UNIT_VW ] )
				->set_default_unit( Size_Constants::UNIT_PERCENT )
		);

		$item->add_item(
			Select_Control::bind_to( self::REPEAT_KEY )
				->set_label( esc_html__( 'Repeat', 'bdthemes-element-pack' ) )
				->set_options( $this->get_repeat_options() )
		);

		return $controls;
	}

	private function get_default_shape_options(): array {
		$options = [];

		foreach ( element_pack_mask_shapes() as $shape_key => $shape_name ) {
			if ( 0 === $shape_key ) {
				continue;
			}

			$options[] = [
				'value' => $shape_key,
				'label' => $shape_name,
			];
		}

		return $options;
	}

	private function get_position_options(): array {
		$positions = [
			'center-center' => esc_html__( 'Center Center', 'bdthemes-element-pack' ),
			'center-left'   => esc_html__( 'Center Left', 'bdthemes-element-pack' ),
			'center-right'  => esc_html__( 'Center Right', 'bdthemes-element-pack' ),
			'top-center'    => esc_html__( 'Top Center', 'bdthemes-element-pack' ),
			'top-left'      => esc_html__( 'Top Left', 'bdthemes-element-pack' ),
			'top-right'     => esc_html__( 'Top Right', 'bdthemes-element-pack' ),
			'bottom-center' => esc_html__( 'Bottom Center', 'bdthemes-element-pack' ),
			'bottom-left'   => esc_html__( 'Bottom Left', 'bdthemes-element-pack' ),
			'bottom-right'  => esc_html__( 'Bottom Right', 'bdthemes-element-pack' ),
		];

		$options = [];

		foreach ( $positions as $value => $label ) {
			$options[] = [
				'value' => $value,
				'label' => $label,
			];
		}

		return $options;
	}

	private function get_repeat_options(): array {
		$repeats = [
			'repeat'          => esc_html__( 'Repeat', 'bdthemes-element-pack' ),
			'repeat-x'        => esc_html__( 'Repeat-x', 'bdthemes-element-pack' ),
			'repeat-y'        => esc_html__( 'Repeat-y', 'bdthemes-element-pack' ),
			'space'           => esc_html__( 'Space', 'bdthemes-element-pack' ),
			'round'           => esc_html__( 'Round', 'bdthemes-element-pack' ),
			'no-repeat'       => esc_html__( 'No-repeat', 'bdthemes-element-pack' ),
			'repeat-space'    => esc_html__( 'Repeat Space', 'bdthemes-element-pack' ),
			'round-space'     => esc_html__( 'Round Space', 'bdthemes-element-pack' ),
			'no-repeat-round' => esc_html__( 'No-repeat Round', 'bdthemes-element-pack' ),
		];

		$options = [];

		foreach ( $repeats as $value => $label ) {
			$options[] = [
				'value' => $value,
				'label' => $label,
			];
		}

		return $options;
	}

	private function get_active_dependencies(): ?array {
		return Dependency_Manager::make( Dependency_Manager::RELATION_AND )
			->where(
				[
					'operator' => 'eq',
					'path' => [ self::ACTIVE_KEY ],
					'value' => true,
					'effect' => 'hide',
				]
			)
			->get();
	}

	private function get_shape_dependencies( string $shape ): ?array {
		return Dependency_Manager::make( Dependency_Manager::RELATION_AND )
			->where(
				[
					'operator' => 'eq',
					'path' => [ self::ACTIVE_KEY ],
					'value' => true,
					'effect' => 'hide',
				]
			)
			->where(
				[
					'operator' => 'eq',
					'path' => [ self::SHAPE_KEY ],
					'value' => $shape,
					'effect' => 'hide',
				]
			)
			->get();
	}

	private function get_custom_size_dependencies(): ?array {
		return Dependency_Manager::make( Dependency_Manager::RELATION_AND )
			->where(
				[
					'operator' => 'eq',
					'path' => [ self::ACTIVE_KEY ],
					'value' => true,
					'effect' => 'hide',
				]
			)
			->where(
				[
					'operator' => 'eq',
					'path' => [ self::SIZE_KEY ],
					'value' => 'initial',
					'effect' => 'hide',
				]
			)
			->get();
	}
}
