<?php

namespace ElementPack\Modules\TextGradientBackground\Atomic;

use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Number_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Switch_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Text_Control;
use Elementor\Modules\AtomicWidgets\PropDependencies\Manager as Dependency_Manager;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Number_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Union_Prop_Type;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Support {
	public const ENABLE_KEY = 'element_pack_tgb_enable';
	public const SELECTOR_KEY = 'element_pack_tgb_selector';
	public const BACKGROUND_KEY = 'element_pack_tgb_background';
	public const BACKGROUND_START_COLOR_KEY = 'element_pack_tgb_background_start_color';
	public const BACKGROUND_END_COLOR_KEY = 'element_pack_tgb_background_end_color';
	public const BACKGROUND_START_COLOR_LOCATION_KEY = 'element_pack_tgb_background_start_color_location';
	public const BACKGROUND_END_COLOR_LOCATION_KEY = 'element_pack_tgb_background_end_color_location';
	public const BACKGROUND_ANGLE_KEY = 'element_pack_tgb_background_angle';

	public function register_schema( array $schema ): array {
		$active_dependencies = $this->get_active_dependencies();

		$schema[ self::ENABLE_KEY ] = $schema[ self::ENABLE_KEY ] ?? Boolean_Prop_Type::make()->default( false );
		$schema[ self::SELECTOR_KEY ] = $schema[ self::SELECTOR_KEY ] ?? String_Prop_Type::make()
			->default( '' )
			->set_dependencies( $active_dependencies );
		$schema[ self::BACKGROUND_KEY ] = $schema[ self::BACKGROUND_KEY ] ?? String_Prop_Type::make()
			->default( '' )
			->set_dependencies( $active_dependencies );
		$schema[ self::BACKGROUND_START_COLOR_KEY ] = $schema[ self::BACKGROUND_START_COLOR_KEY ] ?? String_Prop_Type::make()
			->default( '#08aeec' )
			->set_dependencies( $active_dependencies );
		$schema[ self::BACKGROUND_END_COLOR_KEY ] = $schema[ self::BACKGROUND_END_COLOR_KEY ] ?? String_Prop_Type::make()
			->default( '#2af598' )
			->set_dependencies( $active_dependencies );
		$schema[ self::BACKGROUND_START_COLOR_LOCATION_KEY ] = $schema[ self::BACKGROUND_START_COLOR_LOCATION_KEY ] ?? $this->number_schema( 0, $active_dependencies, false );
		$schema[ self::BACKGROUND_END_COLOR_LOCATION_KEY ] = $schema[ self::BACKGROUND_END_COLOR_LOCATION_KEY ] ?? $this->number_schema( 100, $active_dependencies, false );
		$schema[ self::BACKGROUND_ANGLE_KEY ] = $schema[ self::BACKGROUND_ANGLE_KEY ] ?? $this->number_schema( 90, $active_dependencies, false );

		return $schema;
	}

	private function number_schema( $default, ?array $dependencies, bool $float = true ): Union_Prop_Type {
		$number_schema = Number_Prop_Type::make();

		if ( $float ) {
			$number_schema->float();
		}

		return Union_Prop_Type::make()
			->add_prop_type( $number_schema )
			->add_prop_type( String_Prop_Type::make() )
			->default( $default, 'number' )
			->set_dependencies( $dependencies );
	}

	public function register_controls( array $controls ): array {
		$item = Section::make()
			->set_id( 'ep_section_text_gradient_background' )
			->set_label( esc_html__( 'Text Gradient Background', 'bdthemes-element-pack' ) )
			->set_items( [] );

		$controls[] = $item;

		$item->add_item(
			Switch_Control::bind_to( self::ENABLE_KEY )
				->set_label( esc_html__( 'Use Text Gradient Background?', 'bdthemes-element-pack' ) )
		);

		$item->add_item(
			Text_Control::bind_to( self::SELECTOR_KEY )
				->set_label( esc_html__( 'Class & ID Selector', 'bdthemes-element-pack' ) )
				->set_placeholder( esc_html__( '.class or #id', 'bdthemes-element-pack' ) )
		);

		$item->add_item(
			Text_Control::bind_to( self::BACKGROUND_START_COLOR_KEY )
				->set_label( esc_html__( 'Gradient Start Color', 'bdthemes-element-pack' ) )
				->set_placeholder( '#08aeec' )
		);

		$item->add_item(
			Number_Control::bind_to( self::BACKGROUND_START_COLOR_LOCATION_KEY )
				->set_label( esc_html_x( 'Location', 'Background Control', 'bdthemes-element-pack' ) )
				->set_min( 0 )
				->set_max( 100 )
				->set_step( 1 )
		);

		$item->add_item(
			Text_Control::bind_to( self::BACKGROUND_END_COLOR_KEY )
				->set_label( esc_html__( 'Gradient End Color', 'bdthemes-element-pack' ) )
				->set_placeholder( '#2af598' )
		);

		$item->add_item(
			Number_Control::bind_to( self::BACKGROUND_END_COLOR_LOCATION_KEY )
				->set_label( esc_html_x( 'Location', 'Background Control', 'bdthemes-element-pack' ) )
				->set_min( 0 )
				->set_max( 100 )
				->set_step( 1 )
		);

		$item->add_item(
			Number_Control::bind_to( self::BACKGROUND_ANGLE_KEY )
				->set_label( esc_html__( 'Gradient Angle', 'bdthemes-element-pack' ) )
				->set_min( 0 )
				->set_max( 360 )
				->set_step( 1 )
		);

		return $controls;
	}

	private function get_active_dependencies(): ?array {
		return Dependency_Manager::make( Dependency_Manager::RELATION_AND )
			->where(
				[
					'operator' => 'eq',
					'path' => [ self::ENABLE_KEY ],
					'value' => true,
					'effect' => 'hide',
				]
			)
			->get();
	}
}
