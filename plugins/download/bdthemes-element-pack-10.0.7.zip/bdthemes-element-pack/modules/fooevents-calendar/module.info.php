<?php
if (!defined('ABSPATH')) exit; // Exit if accessed directly

return [
	'title'				 => esc_html__('FooEvents Calendar', 'bdthemes-element-pack'),
	'required'			 => true,
	'default_activation' => true,
	'widget_names'       => [ 'fooevents-calendar' ],
];
