<?php

namespace ElementPack\Modules\FooeventsCalendar;

use ElementPack\Base\Element_Pack_Module_Base;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

class Module extends Element_Pack_Module_Base {

	public function get_name() {
		return 'fooevents-calendar';
	}

	public function get_widgets() {

		$widgets = ['Fooevents_Calendar'];

		return $widgets;
	}
}
