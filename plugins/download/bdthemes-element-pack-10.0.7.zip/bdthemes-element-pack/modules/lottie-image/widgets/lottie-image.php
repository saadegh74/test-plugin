<?php

namespace ElementPack\Modules\LottieImage\Widgets;

use ElementPack\Base\Module_Base;
use ElementPack\Traits\Global_Controls_Functions;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Lottie_Image extends Module_Base {
	use Global_Controls_Functions;

	public function get_name() {
		return 'bdt-lottie-image';
	}

	public function get_title() {
		return BDTEP . esc_html__( 'Lottie Image', 'bdthemes-element-pack' );
	}

	public function get_icon() {
		return 'bdt-wi-lottie-image';
	}

	public function get_categories() {
		return [ 'element-pack' ];
	}

	public function get_keywords() {
		return [ 'lottie', 'animation', 'bodymovin', 'transition', 'image', 'svg' ];
	}

	public function get_script_depends() {
		if ( $this->ep_is_edit_mode() ) {
			return [ 'lottie', 'ep-scripts' ];
		}

		return [ 'lottie', 'ep-lottie-image' ];
	}

	public function get_custom_help_url() {
		return 'https://youtu.be/CbODBtLTxWc';
	}

	public function has_widget_inner_wrapper(): bool {
		return ! \Elementor\Plugin::$instance->experiments->is_feature_active( 'e_optimized_markup' );
	}

	protected function is_dynamic_content(): bool {
		return false;
	}

	protected function register_controls() {
		$this->register_lottie_controls( 'image' );
	}

	private function get_link_url( $settings ) {
		return $this->get_lottie_image_link_url( $settings );
	}

	private function get_caption( $settings ) {
		return $this->get_lottie_image_caption( $settings );
	}

	protected function render() {
		$this->render_lottie_image();
	}
}
