<?php

namespace ElementPack\Modules\ConfettiEffects\Atomic;

use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Number_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Select_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Switch_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Text_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Textarea_Control;
use Elementor\Modules\AtomicWidgets\PropDependencies\Manager as Dependency_Manager;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Number_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Union_Prop_Type;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Support {
	public const ACTIVE_KEY = 'ep_widget_cf_confetti';
	public const TYPE_KEY = 'ep_widget_cf_type';
	public const FIREWORKS_DURATION_KEY = 'ep_widget_cf_fireworks_duration';
	public const ANIM_INFINITE_KEY = 'ep_widget_cf_anim_infinite';
	public const PARTICLE_COUNT_KEY = 'ep_widget_cf_particle_count';
	public const START_VELOCITY_KEY = 'ep_widget_cf_start_velocity';
	public const SPREAD_KEY = 'ep_widget_cf_spread';
	public const ANGLE_KEY = 'ep_widget_cf_angle';
	public const COLORS_KEY = 'ep_widget_cf_colors';
	public const SHAPE_TYPE_KEY = 'ep_widget_cf_shape_type';
	public const SHAPES_KEY = 'ep_widget_cf_shapes';
	public const SHAPES_EMOJI_KEY = 'ep_widget_cf_shapes_emoji';
	public const SHAPES_SVG_KEY = 'ep_widget_cf_shapes_svg';
	public const SCALAR_KEY = 'ep_widget_cf_scalar';
	public const ORIGIN_KEY = 'ep_widget_cf_origin';
	public const ORIGIN_X_KEY = 'ep_widget_cf_origin_x';
	public const ORIGIN_Y_KEY = 'ep_widget_cf_origin_y';
	public const TRIGGER_TYPE_KEY = 'ep_widget_cf_trigger_type';
	public const TRIGGER_SELECTOR_KEY = 'ep_widget_cf_trigger_selector';
	public const TRIGGER_DELAY_KEY = 'ep_widget_cf_trigger_delay';
	public const Z_INDEX_KEY = 'ep_widget_cf_z_index';

	public function register_schema( array $schema ): array {
		$active_dependencies = $this->get_active_dependencies();
		$active_random_or_pride_dependencies = $this->get_active_type_dependencies( [ 'random', 'school-pride' ] );
		$active_fireworks_type_dependencies = $this->get_active_type_dependencies( [ 'fireworks', 'snow', 'school-pride' ] );
		$active_snow_type_dependencies = $this->get_active_type_dependencies( [ 'snow' ] );
		$active_shape_basic_dependencies = $this->get_active_shape_type_dependencies( 'basic' );
		$active_shape_emoji_dependencies = $this->get_active_shape_type_dependencies( 'emoji' );
		$active_shape_svg_dependencies = $this->get_active_shape_type_dependencies( 'svg' );
		$active_origin_dependencies = $this->get_active_origin_dependencies();
		$active_trigger_click_or_hover_dependencies = $this->get_active_trigger_type_dependencies( [ 'click', 'mouseenter' ] );
		$active_trigger_delay_dependencies = $this->get_active_trigger_type_dependencies( [ 'delay' ] );

		$schema[ self::ACTIVE_KEY ] = $schema[ self::ACTIVE_KEY ] ?? Boolean_Prop_Type::make()->default( false );
		$schema[ self::TYPE_KEY ] = $schema[ self::TYPE_KEY ] ?? String_Prop_Type::make()
			->default( 'basic' )
			->set_dependencies( $active_dependencies );
		$schema[ self::FIREWORKS_DURATION_KEY ] = $schema[ self::FIREWORKS_DURATION_KEY ] ?? $this->number_schema( 1500, $active_fireworks_type_dependencies );
		$schema[ self::ANIM_INFINITE_KEY ] = $schema[ self::ANIM_INFINITE_KEY ] ?? Boolean_Prop_Type::make()
			->default( false )
			->set_dependencies( $active_snow_type_dependencies );
		$schema[ self::PARTICLE_COUNT_KEY ] = $schema[ self::PARTICLE_COUNT_KEY ] ?? $this->number_schema( 100, $active_dependencies );
		$schema[ self::START_VELOCITY_KEY ] = $schema[ self::START_VELOCITY_KEY ] ?? $this->number_schema( 45, $active_dependencies );
		$schema[ self::SPREAD_KEY ] = $schema[ self::SPREAD_KEY ] ?? $this->number_schema( 70, $active_dependencies );
		$schema[ self::ANGLE_KEY ] = $schema[ self::ANGLE_KEY ] ?? $this->number_schema( 90, $active_random_or_pride_dependencies );
		$schema[ self::COLORS_KEY ] = $schema[ self::COLORS_KEY ] ?? String_Prop_Type::make()
			->default( '#D30C5C, #0EBCDC, #EAED41, #ED5A78, #DF33DF' )
			->set_dependencies( $active_dependencies );
		$schema[ self::SHAPE_TYPE_KEY ] = $schema[ self::SHAPE_TYPE_KEY ] ?? String_Prop_Type::make()
			->default( 'basic' )
			->set_dependencies( $active_dependencies );
		$schema[ self::SHAPES_KEY ] = $schema[ self::SHAPES_KEY ] ?? String_Prop_Type::make()
			->default( 'square|circle' )
			->set_dependencies( $active_shape_basic_dependencies );
		$schema[ self::SHAPES_EMOJI_KEY ] = $schema[ self::SHAPES_EMOJI_KEY ] ?? String_Prop_Type::make()
			->default( '🎃|🎄|💜' )
			->set_dependencies( $active_shape_emoji_dependencies );
		$schema[ self::SHAPES_SVG_KEY ] = $schema[ self::SHAPES_SVG_KEY ] ?? String_Prop_Type::make()
			->default( '' )
			->set_dependencies( $active_shape_svg_dependencies );
		$schema[ self::SCALAR_KEY ] = $schema[ self::SCALAR_KEY ] ?? $this->number_schema( 1, $active_dependencies );
		$schema[ self::ORIGIN_KEY ] = $schema[ self::ORIGIN_KEY ] ?? Boolean_Prop_Type::make()
			->default( false )
			->set_dependencies( $active_dependencies );
		$schema[ self::ORIGIN_X_KEY ] = $schema[ self::ORIGIN_X_KEY ] ?? $this->number_schema( 0.5, $active_origin_dependencies );
		$schema[ self::ORIGIN_Y_KEY ] = $schema[ self::ORIGIN_Y_KEY ] ?? $this->number_schema( 0.6, $active_origin_dependencies );
		$schema[ self::TRIGGER_TYPE_KEY ] = $schema[ self::TRIGGER_TYPE_KEY ] ?? String_Prop_Type::make()
			->default( 'load' )
			->set_dependencies( $active_dependencies );
		$schema[ self::TRIGGER_SELECTOR_KEY ] = $schema[ self::TRIGGER_SELECTOR_KEY ] ?? String_Prop_Type::make()
			->default( '' )
			->set_dependencies( $active_trigger_click_or_hover_dependencies );
		$schema[ self::TRIGGER_DELAY_KEY ] = $schema[ self::TRIGGER_DELAY_KEY ] ?? $this->number_schema( 3000, $active_trigger_delay_dependencies );
		$schema[ self::Z_INDEX_KEY ] = $schema[ self::Z_INDEX_KEY ] ?? Union_Prop_Type::make()
			->add_prop_type( Number_Prop_Type::make()->float() )
			->add_prop_type( String_Prop_Type::make() )
			->default( '', 'string' )
			->set_dependencies( $active_dependencies );

		return $schema;
	}

	public function register_controls( array $controls ): array {
		$target_section = Section::make()
			->set_id( 'ep_section_confetti_effects' )
			->set_label( esc_html__( 'Confetti Effects', 'bdthemes-element-pack' ) )
			->set_items( [] );

		$controls[] = $target_section;

		$target_section->add_item(
				Switch_Control::bind_to( self::ACTIVE_KEY )
					->set_label( esc_html__( 'Confetti Effects', 'bdthemes-element-pack' ) )
		);

		$target_section->add_item(
				Select_Control::bind_to( self::TYPE_KEY )
					->set_label( esc_html__( 'Confetti Type', 'bdthemes-element-pack' ) )
					->set_options(
						[
							[ 'value' => 'basic', 'label' => esc_html__( 'Basic', 'bdthemes-element-pack' ) ],
							[ 'value' => 'random', 'label' => esc_html__( 'Random Direction', 'bdthemes-element-pack' ) ],
							[ 'value' => 'fireworks', 'label' => esc_html__( 'Fireworks', 'bdthemes-element-pack' ) ],
							[ 'value' => 'snow', 'label' => esc_html__( 'Snow', 'bdthemes-element-pack' ) ],
							[ 'value' => 'school-pride', 'label' => esc_html__( 'School Pride', 'bdthemes-element-pack' ) ],
						]
					)
		);

		$target_section->add_item(
				Number_Control::bind_to( self::FIREWORKS_DURATION_KEY )
					->set_label( esc_html__( 'Animation End Time (ms)', 'bdthemes-element-pack' ) )
					->set_min( 1000 )
					->set_max( 10000 )
					->set_step( 100 )
		);

		$target_section->add_item(
				Switch_Control::bind_to( self::ANIM_INFINITE_KEY )
					->set_label( esc_html__( 'Infinite End Time', 'bdthemes-element-pack' ) )
		);

		$target_section->add_item(
				Number_Control::bind_to( self::PARTICLE_COUNT_KEY )
					->set_label( esc_html__( 'Particle Count', 'bdthemes-element-pack' ) )
					->set_min( 1 )
					->set_max( 1000 )
					->set_step( 1 )
		);

		$target_section->add_item(
				Number_Control::bind_to( self::START_VELOCITY_KEY )
					->set_label( esc_html__( 'Start Velocity', 'bdthemes-element-pack' ) )
					->set_min( 0 )
					->set_max( 100 )
					->set_step( 1 )
		);

		$target_section->add_item(
				Number_Control::bind_to( self::SPREAD_KEY )
					->set_label( esc_html__( 'Spread', 'bdthemes-element-pack' ) )
					->set_min( 0 )
					->set_max( 360 )
					->set_step( 1 )
		);

		$target_section->add_item(
				Number_Control::bind_to( self::ANGLE_KEY )
					->set_label( esc_html__( 'Angle', 'bdthemes-element-pack' ) )
					->set_min( 0 )
					->set_max( 360 )
					->set_step( 1 )
		);

		$target_section->add_item(
				Textarea_Control::bind_to( self::COLORS_KEY )
					->set_label( esc_html__( 'Colors', 'bdthemes-element-pack' ) )
		);

		$target_section->add_item(
				Select_Control::bind_to( self::SHAPE_TYPE_KEY )
					->set_label( esc_html__( 'Shape Type', 'bdthemes-element-pack' ) )
					->set_options(
						[
							[ 'value' => 'basic', 'label' => esc_html__( 'Basic', 'bdthemes-element-pack' ) ],
							[ 'value' => 'emoji', 'label' => esc_html__( 'Emoji', 'bdthemes-element-pack' ) ],
							[ 'value' => 'svg', 'label' => esc_html__( 'SVG Path', 'bdthemes-element-pack' ) ],
						]
					)
		);

		$target_section->add_item(
				Textarea_Control::bind_to( self::SHAPES_KEY )
					->set_label( esc_html__( 'Shapes', 'bdthemes-element-pack' ) )
		);

		$target_section->add_item(
				Textarea_Control::bind_to( self::SHAPES_EMOJI_KEY )
					->set_label( esc_html__( 'Emoji', 'bdthemes-element-pack' ) )
		);

		$target_section->add_item(
				Textarea_Control::bind_to( self::SHAPES_SVG_KEY )
					->set_label( esc_html__( 'SVG Path', 'bdthemes-element-pack' ) )
		);

		$target_section->add_item(
				Number_Control::bind_to( self::SCALAR_KEY )
					->set_label( esc_html__( 'Scalar', 'bdthemes-element-pack' ) )
					->set_min( 0 )
					->set_max( 20 )
					->set_step( 1 )
		);

		$target_section->add_item(
				Switch_Control::bind_to( self::ORIGIN_KEY )
					->set_label( esc_html__( 'Origin', 'bdthemes-element-pack' ) )
		);

		$target_section->add_item(
				Number_Control::bind_to( self::ORIGIN_X_KEY )
					->set_label( esc_html__( 'Origin X', 'bdthemes-element-pack' ) )
					->set_min( 0 )
					->set_max( 1 )
					->set_step( 1 )
		);

		$target_section->add_item(
				Number_Control::bind_to( self::ORIGIN_Y_KEY )
					->set_label( esc_html__( 'Origin Y', 'bdthemes-element-pack' ) )
					->set_min( 0 )
					->set_max( 1 )
					->set_step( 1 )
		);

		$target_section->add_item(
				Select_Control::bind_to( self::TRIGGER_TYPE_KEY )
					->set_label( esc_html__( 'Trigger Action', 'bdthemes-element-pack' ) )
					->set_options(
						[
							[ 'value' => 'load', 'label' => esc_html__( 'On Load', 'bdthemes-element-pack' ) ],
							[ 'value' => 'onview', 'label' => esc_html__( 'On View', 'bdthemes-element-pack' ) ],
							[ 'value' => 'click', 'label' => esc_html__( 'On Click', 'bdthemes-element-pack' ) ],
							[ 'value' => 'mouseenter', 'label' => esc_html__( 'On Hover', 'bdthemes-element-pack' ) ],
							[ 'value' => 'delay', 'label' => esc_html__( 'Delay', 'bdthemes-element-pack' ) ],
							[ 'value' => 'ajax-success', 'label' => esc_html__( 'Ajax Success', 'bdthemes-element-pack' ) ],
						]
					)
		);

		$target_section->add_item(
				Text_Control::bind_to( self::TRIGGER_SELECTOR_KEY )
					->set_label( esc_html__( 'Trigger Selector', 'bdthemes-element-pack' ) )
		);

		$target_section->add_item(
				Number_Control::bind_to( self::TRIGGER_DELAY_KEY )
					->set_label( esc_html__( 'Delay Time (ms)', 'bdthemes-element-pack' ) )
					->set_min( 1000 )
					->set_max( 10000 )
					->set_step( 100 )
		);

		$target_section->add_item(
				Number_Control::bind_to( self::Z_INDEX_KEY )
					->set_label( esc_html__( 'Z-index', 'bdthemes-element-pack' ) )
					->set_step( 1 )
		);

		return $controls;
	}

	private function get_active_dependencies(): ?array {
		return Dependency_Manager::make( Dependency_Manager::RELATION_AND )
			->where(
				[
					'operator' => 'eq',
					'path' => [ self::ACTIVE_KEY ],
					'value' => true,
					'effect' => 'hide',
				]
			)
			->get();
	}

	private function number_schema( $default, ?array $dependencies ): Union_Prop_Type {
		return Union_Prop_Type::make()
			->add_prop_type( Number_Prop_Type::make()->float() )
			->add_prop_type( String_Prop_Type::make() )
			->default( $default, 'number' )
			->set_dependencies( $dependencies );
	}

	private function get_active_type_dependencies( array $types ): ?array {
		return Dependency_Manager::make( Dependency_Manager::RELATION_AND )
			->where(
				[
					'operator' => 'eq',
					'path' => [ self::ACTIVE_KEY ],
					'value' => true,
					'effect' => 'hide',
				]
			)
			->where(
				[
					'operator' => 'in',
					'path' => [ self::TYPE_KEY ],
					'value' => $types,
					'effect' => 'hide',
				]
			)
			->get();
	}

	private function get_active_shape_type_dependencies( string $shape_type ): ?array {
		return Dependency_Manager::make( Dependency_Manager::RELATION_AND )
			->where(
				[
					'operator' => 'eq',
					'path' => [ self::ACTIVE_KEY ],
					'value' => true,
					'effect' => 'hide',
				]
			)
			->where(
				[
					'operator' => 'eq',
					'path' => [ self::SHAPE_TYPE_KEY ],
					'value' => $shape_type,
					'effect' => 'hide',
				]
			)
			->get();
	}

	private function get_active_origin_dependencies(): ?array {
		return Dependency_Manager::make( Dependency_Manager::RELATION_AND )
			->where(
				[
					'operator' => 'eq',
					'path' => [ self::ACTIVE_KEY ],
					'value' => true,
					'effect' => 'hide',
				]
			)
			->where(
				[
					'operator' => 'eq',
					'path' => [ self::ORIGIN_KEY ],
					'value' => true,
					'effect' => 'hide',
				]
			)
			->get();
	}

	private function get_active_trigger_type_dependencies( array $trigger_types ): ?array {
		return Dependency_Manager::make( Dependency_Manager::RELATION_AND )
			->where(
				[
					'operator' => 'eq',
					'path' => [ self::ACTIVE_KEY ],
					'value' => true,
					'effect' => 'hide',
				]
			)
			->where(
				[
					'operator' => 'in',
					'path' => [ self::TRIGGER_TYPE_KEY ],
					'value' => $trigger_types,
					'effect' => 'hide',
				]
			)
			->get();
	}
}
