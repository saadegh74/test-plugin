<?php

namespace ElementPack\Modules\Elementor;

use Elementor\Core\Kits\Documents\Tabs\Tab_Base;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Site Settings tab holding Element Pack's global style sections.
 *
 * These sections used to be appended to every document's page settings via
 * `elementor/element/after_section_end`. Every selector they write is
 * site-wide (`.bdt-lightbox`, `.elementor-widget .tippy-tooltip` — none of them
 * scoped with {{WRAPPER}}), so the values were global in effect but stored per
 * page. That cost 78 extra controls on every page-settings stack, which is paid
 * once per document Elementor instantiates — on Elementor > Tools, Maintenance
 * Mode loads the whole page-template library to build a dropdown, so a site with
 * a few hundred templates exhausted the PHP memory limit there. On the Kit these
 * are registered once.
 */
class Global_Style_Tab extends Tab_Base {

	const TAB_ID = 'element-pack-global-style';

	public function get_id() {
		return self::TAB_ID;
	}

	public function get_title() {
		return esc_html__( 'Element Pack Global Style', 'bdthemes-element-pack' );
	}

	public function get_icon() {
		return 'eicon-lightbox';
	}

	public function get_help_url() {
		return '';
	}

	protected function register_tab_controls() {
		$module = Module::instance();

		$module->lightbox_settings( $this );
		$module->tooltip_settings( $this );
	}
}
