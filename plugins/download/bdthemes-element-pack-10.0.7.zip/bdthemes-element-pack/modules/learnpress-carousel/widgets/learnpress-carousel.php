<?php

namespace ElementPack\Modules\LearnpressCarousel\Widgets;

use ElementPack\Base\Module_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Typography;

use ElementPack\Traits\Global_Widget_Controls;
use ElementPack\Traits\Global_Swiper_Controls;
use ElementPack\Traits\Global_Controls_Functions;
use ElementPack\Includes\Controls\GroupQuery\Group_Control_Query;
use ElementPack\Utils;
use WP_Query;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Learnpress_Carousel extends Module_Base {
	use Global_Widget_Controls;
	use Global_Swiper_Controls;
	use Global_Controls_Functions;
	use Group_Control_Query;

	/** @var \WP_Query */
	private $_query = null;

	public function get_name() {
		return 'bdt-learnpress-carousel';
	}

	public function get_title() {
		return BDTEP . esc_html__( 'LearnPress Carousel', 'bdthemes-element-pack' );
	}

	public function get_icon() {
		return 'bdt-wi-learnpress-carousel bdt-new';
	}

	public function get_categories() {
		return [ 'element-pack' ];
	}

	public function get_keywords() {
		return [ 'learnpress', 'lms', 'course', 'learning', 'management', 'carousel' ];
	}

	public function get_style_depends() {
		if ( $this->ep_is_edit_mode() ) {
			return [ 'swiper', 'ep-styles' ];
		}
		return [ 'swiper', 'ep-font', 'ep-learnpress-carousel' ];
	}

	public function get_script_depends() {
		if ( $this->ep_is_edit_mode() ) {
			return [ 'swiper', 'ep-scripts' ];
		}
		return [ 'swiper', 'ep-learnpress-carousel' ];
	}

	public function get_query() {
		return $this->_query;
	}

	public function has_widget_inner_wrapper(): bool {
		return ! \Elementor\Plugin::$instance->experiments->is_feature_active( 'e_optimized_markup' );
	}

	protected function register_controls() {
		$this->render_controls_layout();
		$this->render_controls_query();
		$this->render_style_controls_item();
		$this->render_controls_additional();
		$this->render_style_controls_category();
		$this->render_style_controls_title();
		$this->render_style_controls_instructor();
		$this->render_style_controls_meta();
		$this->render_style_controls_price();
		$this->render_swiper_navigation();
	}

	public function render_controls_layout() {
	    $this->start_controls_section(
	        'section_content_layout',
	        [
	            'label' => esc_html__('Layout', 'bdthemes-element-pack'),
	        ]
	    );

	    //swiper carousel columns & item gap controls
		$this->register_carousel_column_gap_controls();

	    		$this->register_learnpress_alignment_control( 'carousel' );

				$this->register_learnpress_image_size_control();

		$this->end_controls_section();
	}

	public function render_swiper_navigation() {
	    //Navigation Controls
	    $this->start_controls_section(
	        'section_content_navigation',
	        [
	            'label' => __('Navigation', 'bdthemes-element-pack'),
	        ]
	    );

	    //Global Navigation Controls
	    $this->register_navigation_controls();

	    $this->end_controls_section();

	    //Global Carousel Settings Controls
	    $this->register_carousel_settings_controls();

	    //Navigation Style
	    $this->start_controls_section(
	        'section_style_navigation',
	        [
	            'label'      => __('Navigation', 'bdthemes-element-pack'),
	            'tab'        => Controls_Manager::TAB_STYLE,
	            'conditions' => [
	                'relation' => 'or',
	                'terms'    => [
	                    [
	                        'name'     => 'navigation',
	                        'operator' => '!=',
	                        'value'    => 'none',
	                    ],
	                    [
	                        'name'  => 'show_scrollbar',
	                        'value' => 'yes',
	                    ],
	                ],
	            ],
	        ]
	    );

	    //Global Navigation Style Controls
	    $this->register_navigation_style_controls('ep-learnpress-carousel');

	    $this->end_controls_section();
	}

	public function render_controls_query() {
		$this->register_learnpress_query_controls();
	}

	public function render_controls_additional() {
		$this->register_learnpress_additional_controls( [ 'section_id' => 'section_additional' ] );
	}

	public function render_style_controls_item() {
		$this->register_learnpress_style_item_controls( 'carousel' );
	}

	public function render_style_controls_category() {
		$this->register_learnpress_style_category_controls( 'carousel' );
	}

	public function render_style_controls_title() {
		$this->register_learnpress_style_title_controls( 'carousel' );
	}

	public function render_style_controls_instructor() {
		$this->register_learnpress_style_instructor_controls( 'carousel' );
	}

	public function render_style_controls_meta() {
		$this->register_learnpress_style_meta_controls( 'carousel' );
	}

	public function render_style_controls_price() {
		$this->register_learnpress_style_price_controls( 'carousel' );
	}

	public function render_header() {
	    $settings = $this->get_settings_for_display();

	    //Global Function
	    $this->render_swiper_header_attribute('ep-learnpress-carousel');

	    $this->add_render_attribute('carousel', 'class', ['ep-learnpress-carousel', 'ep-learnpress-lms-grid']); ?>
	    <div <?php $this->print_render_attribute_string('carousel'); ?>>
	        <div <?php $this->print_render_attribute_string('swiper'); ?>>
	            <div class="swiper-wrapper">
	                <?php
	            }

	public function render() {
	                $this->render_header();
	                $this->render_loop_item();
	                $this->render_footer();
	            }

	public function render_loop_item() {
		$settings = $this->get_settings_for_display();
		$this->query_product();
		$this->render_learnpress_carousel_loop( $settings );
	}
}
