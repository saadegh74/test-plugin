<?php

namespace ElementPack\Modules\EventsCalendarCarousel\Widgets;

use ElementPack\Base\Module_Base;
use ElementPack\Modules\EventsCalendarCarousel\Skins;
use ElementPack\Traits\Global_Controls_Functions;
use ElementPack\Traits\Global_Swiper_Controls;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Events_Calendar_Carousel extends Module_Base {
	use Global_Controls_Functions;
	use Global_Swiper_Controls;

	public $_query = null;

	public function get_name() {
		return 'bdt-event-carousel';
	}

	public function get_title() {
		return BDTEP . __( 'Events Calendar Carousel', 'bdthemes-element-pack' );
	}

	public function get_icon() {
		return 'bdt-wi-events-calendar-carousel';
	}

	public function get_categories() {
		return [ 'element-pack' ];
	}

	public function get_keywords() {
		return [ 'events', 'carousel', 'calendar', 'the' ];
	}

	public function get_style_depends() {
		if ( $this->ep_is_edit_mode() ) {
			return [ 'swiper', 'ep-styles' ];
		}
		return [ 'swiper', 'ep-events-calendar-carousel', 'ep-font' ];
	}

	public function get_script_depends() {
		if ( $this->ep_is_edit_mode() ) {
			return [ 'swiper', 'ep-scripts' ];
		}
		return [ 'swiper', 'ep-events-calendar-carousel' ];
	}

	public function get_custom_help_url() {
		return 'https://youtu.be/_ZPPBmKmGGg';
	}

	public function register_skins() {
		$this->add_skin( new Skins\Skin_Fable( $this ) );
		$this->add_skin( new Skins\Skin_Altra( $this ) );
	}

	public function get_query() {
		return $this->_query;
	}

	public function has_widget_inner_wrapper(): bool {
		return ! \Elementor\Plugin::$instance->experiments->is_feature_active( 'e_optimized_markup' );
	}

	public function register_controls() {
		$this->register_events_calendar_layout_controls( 'carousel' );
		$this->register_events_calendar_image_controls( 'carousel' );
		$this->register_events_calendar_query_controls( 'carousel' );

		$this->start_controls_section(
			'section_content_navigation',
			[
				'label' => __( 'Navigation', 'bdthemes-element-pack' ),
			]
		);
		$this->register_navigation_controls();
		$this->end_controls_section();

		$this->register_carousel_settings_controls();

		$this->register_events_calendar_style_item_controls( 'carousel' );
		$this->register_events_calendar_style_image_controls( 'carousel' );
		$this->register_events_calendar_style_title_controls( 'carousel' );
		$this->register_events_calendar_style_date_controls( 'carousel' );
		$this->register_events_calendar_style_time_controls( 'carousel' );
		$this->register_events_calendar_style_excerpt_controls( 'carousel' );
		$this->register_events_calendar_style_meta_controls( 'carousel' );
		$this->register_events_calendar_style_meta_price_controls( 'carousel' );
		$this->register_events_calendar_style_address_controls( 'carousel' );

		$this->start_controls_section(
			'section_style_navigation',
			[
				'label' => __( 'Navigation', 'bdthemes-element-pack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'conditions' => [
					'relation' => 'or',
					'terms' => [
						[
							'name'     => 'navigation',
							'operator' => '!=',
							'value'    => 'none',
						],
						[
							'name'  => 'show_scrollbar',
							'value' => 'yes',
						],
					],
				],
			]
		);
		$this->register_navigation_style_controls( 'swiper-carousel' );
		$this->end_controls_section();
	}

	public function render() {
		$this->render_events_calendar_carousel();
	}

	public function render_image() {
		$this->render_events_calendar_image();
	}

	public function render_title() {
		$this->render_events_calendar_title();
	}

	public function render_date() {
		$this->render_events_calendar_date( 'carousel' );
	}

	public function render_time() {
		$this->render_events_calendar_time();
	}

	public function render_excerpt( $post ) {
		$this->render_events_calendar_excerpt( $post );
	}

	public function render_meta() {
		$this->render_events_calendar_meta( 'carousel' );
	}

	public function render_header( $skin_name = 'default' ) {
		$this->render_events_calendar_carousel_header( $skin_name );
	}

	public function render_loop_item( $post ) {
		$this->render_events_calendar_carousel_loop_item( $post );
	}
}
