<?php

namespace ElementPack\Modules\WcSlider\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Text_Stroke;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use ElementPack\Base\Module_Base;
use ElementPack\Includes\Controls\GroupQuery\Group_Control_Query;
use ElementPack\Traits\Global_Widget_Controls;
use ElementPack\Utils;
use WP_Query;

use Elementor\Group_Control_Css_Filter;

if (!defined('ABSPATH')) {
    exit;
}
// Exit if accessed directly

class WC_Slider extends Module_Base {
    use Group_Control_Query;
    use Global_Widget_Controls;

    private $_query = null;

    public function get_name()
    {
        return 'bdt-wc-slider';
    }

    public function get_title()
    {
        return BDTEP . __('WC - Slider', 'bdthemes-element-pack');
    }

    public function get_icon()
    {
        return 'bdt-wi-wc-slider';
    }

    public function get_categories()
    {
        return ['element-pack'];
    }

    public function get_keywords()
    {
        return ['slider', 'woocommerce', 'wc', 'product', 'carousel', 'wc slider'];
    }

    public function get_style_depends()
    {
        if ($this->ep_is_edit_mode()) {
            return ['swiper', 'ep-styles'];
        } else {
            return ['swiper', 'ep-font', 'ep-wc-slider'];
        }
    }

    public function get_script_depends()
    {
        if ($this->ep_is_edit_mode()) {
            return ['swiper', 'imagesloaded', 'ep-woocommerce', 'ep-scripts'];
        } else {
            return ['bdt-uikit', 'element-pack-helper', 'swiper', 'imagesloaded', 'ep-woocommerce', 'ep-wc-slider'];
        }
    }

    public function get_custom_help_url()
    {
        return 'https://youtu.be/ic8p-3jO35U';
    }

    public function get_query()
    {
        return $this->_query;
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'section_content_layout',
            [
                'label' => __('Layout', 'bdthemes-element-pack'),
            ]
        );

        $this->add_control(
            'slider_size_ratio',
            [
                'label' => esc_html__('Size Ratio', 'bdthemes-element-pack'),
                'type' => Controls_Manager::IMAGE_DIMENSIONS,
                'description' => esc_html__( 'Slider ratio to width and height, such as 16:9', 'bdthemes-element-pack' ),
                'condition' => [ 
                    'enable_height!' => 'yes'
                ]
            ]
        );

        $this->add_control(
            'slider_min_height',
            [
                'label' => esc_html__('Minimum Height', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 50,
                        'max' => 1024,
                    ],
                ],
                'condition' => [ 
                    'enable_height!' => 'yes'
                ]
            ]
        );
        $this->add_control(
			'enable_height',
			[ 
				'label'   => esc_html__( 'Enable Responsive Height', 'bdthemes-element-pack' ) . BDTEP_NC,
				'type'    => Controls_Manager::SWITCHER,
			]
		);

		$this->add_responsive_control(
			'viewport_height',
			[ 
				'label'       => esc_html__( 'Height', 'bdthemes-element-pack' ),
				'type'        => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'vh' ],
				'range'      => [ 
					'px' => [ 
						'min' => 100,
						'max' => 1024,
					],
					'em' => [ 
						'min' => 10,
						'max' => 100,
					],
					'vh' => [ 
						'min' => 10,
						'max' => 100,
					],
				],
				'default'     => [ 
					'unit' => 'vh',
					'size' => 70,
				],
				'condition'   => [ 
					'enable_height' => 'yes'
				],
				'selectors'   => [ 
					'{{WRAPPER}} .bdt-slideshow .bdt-slideshow-items' => 'min-height: {{SIZE}}{{UNIT}} !important;',
				],
				'render_type' => 'template',
			]
		);

        $this->add_control(
            'slider_fullscreen',
            [
                'label' => __('Slideshow Fullscreen', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SWITCHER,
                'condition' => [ 
                    'enable_height!' => 'yes'
                ]
            ]
        );

        $this->add_control(
            'text_align',
            [
                'label' => __('Text Align', 'bdthemes-element-pack'),
                'type' => Controls_Manager::CHOOSE,
                'toggle' => false,
                'default' => 'left',
                'options' => [
                    'left' => [
                        'title' => __('Start', 'bdthemes-element-pack'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'bdthemes-element-pack'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('End', 'bdthemes-element-pack'),
                        'icon' => 'eicon-text-align-right',
                    ],
                    'justify' => [
                        'title' => __('Justified', 'bdthemes-element-pack'),
                        'icon' => 'eicon-text-align-justify',
                    ],
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'vertical_align',
            [
                'label' => __('Vertical Align', 'bdthemes-element-pack'),
                'type' => Controls_Manager::CHOOSE,
                'toggle' => false,
                'default' => 'middle',
                'options' => [
                    'top' => [
                        'title' => __('Top', 'bdthemes-element-pack'),
                        'icon' => 'eicon-v-align-top',
                    ],
                    'middle' => [
                        'title' => __('Middle', 'bdthemes-element-pack'),
                        'icon' => 'eicon-v-align-middle',
                    ],
                    'bottom' => [
                        'title' => __('Bottom', 'bdthemes-element-pack'),
                        'icon' => 'eicon-v-align-bottom',
                    ],
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'image',
                'label' => __('Image Size', 'bdthemes-element-pack'),
                'exclude' => ['custom'], // phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_exclude -- Elementor control option, not WP_Query.
                'default' => 'full',
            ]
        );

        $this->add_control(
            'content_reverse',
            [
                'label' => __('Content Reverse', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_content_additional',
            [
                'label' => __('Additional Settings', 'bdthemes-element-pack'),
            ]
        );

        $this->add_control(
            'show_price',
            [
                'label' => __('Price', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_title',
            [
                'label' => __('Show Title', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'title_tags',
            [
                'label' => __('Title HTML Tag', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SELECT,
                'default' => 'h2',
                'options' => element_pack_title_tags(),
                'condition' => [
                    'show_title' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'show_rating',
            [
                'label' => __('Rating', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_text',
            [
                'label' => __('Show Text', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        $this->add_control(
            'excerpt_length',
            [
                'label'     => __('Text Limit', 'bdthemes-element-pack') . BDTEP_NC,
                'type'      => Controls_Manager::NUMBER,
                'default'   => 25,
                'condition' => [ 
                    'show_text' => 'yes',
                ],
                'description' => __('It\'s just work for main content, but not working with excerpt. If you set 0 so you will get full main content.', 'bdthemes-element-pack'),
            ]
        );

        $this->add_control(
            'show_cart',
            [
                'label' => __('Add to Cart', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_readmore',
            [
                'label' => esc_html__('Read More', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_badge',
            [
                'label' => __('Show Badge', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        // $this->add_control(
        //     'show_thumbnav',
        //     [
        //         'label'   => __( 'Show Thumbnav', 'bdthemes-element-pack' ),
        //         'type'    => Controls_Manager::SWITCHER,
        //         'default' => 'yes',
        //     ]
        // );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_content_readmore',
            [
                'label' => __('Read More', 'bdthemes-element-pack'),
                'condition' => [
                    'show_readmore' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'readmore_text',
            [
                'label' => esc_html__('Read More Text', 'bdthemes-element-pack'),
                'type' => Controls_Manager::TEXT,
                'dynamic' => ['active' => true],
                'default' => esc_html__('Read More', 'bdthemes-element-pack'),
                'placeholder' => esc_html__('Read More', 'bdthemes-element-pack'),
            ]
        );

        $this->add_control(
            'wc_slider_readmore_icon',
            [
                'label' => esc_html__('Icon', 'bdthemes-element-pack'),
                'type' => Controls_Manager::ICONS,
                'fa4compatibility' => 'readmore_icon',
                'label_block' => false,
                'skin' => 'inline',
            ]
        );

        $this->add_control(
            'readmore_icon_align',
            [
                'label' => esc_html__('Icon Position', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SELECT,
                'default' => 'right',
                'options' => [
                    'left' => esc_html__('Before', 'bdthemes-element-pack'),
                    'right' => esc_html__('After', 'bdthemes-element-pack'),
                ],
                'condition' => [
                    'wc_slider_readmore_icon[value]!' => '',
                ],
            ]
        );

        $this->add_control(
            'readmore_icon_indent',
            [
                'label' => esc_html__('Icon Spacing', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 8,
                ],
                'range' => [
                    'px' => [
                        'max' => 50,
                    ],
                ],
                'condition' => [
                    'wc_slider_readmore_icon[value]!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider-readmore' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_content_navigation',
            [
                'label' => __('Navigation', 'bdthemes-element-pack'),
            ]
        );

        $this->add_control(
            'navigation',
            [
                'label' => __('Navigation', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SELECT,
                'default' => 'arrows',
                'options' => [
                    'both' => __('Arrows and Dots', 'bdthemes-element-pack'),
                    'arrows' => __('Arrows', 'bdthemes-element-pack'),
                    'dots' => __('Dots', 'bdthemes-element-pack'),
                    'none' => __('None', 'bdthemes-element-pack'),
                ],
            ]
        );

        $this->add_control(
            'nav_arrows_icon',
            [
                'label' => esc_html__('Arrows Icon', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SELECT,
                'default' => '0',
                'options' => [
                    '0' => esc_html__('Default', 'bdthemes-element-pack'),
                    '1' => esc_html__('Style 1', 'bdthemes-element-pack'),
                    '2' => esc_html__('Style 2', 'bdthemes-element-pack'),
                    '3' => esc_html__('Style 3', 'bdthemes-element-pack'),
                    '4' => esc_html__('Style 4', 'bdthemes-element-pack'),
                    '5' => esc_html__('Style 5', 'bdthemes-element-pack'),
                    '6' => esc_html__('Style 6', 'bdthemes-element-pack'),
                    '7' => esc_html__('Style 7', 'bdthemes-element-pack'),
                    '8' => esc_html__('Style 8', 'bdthemes-element-pack'),
                    '9' => esc_html__('Style 9', 'bdthemes-element-pack'),
                    '10' => esc_html__('Style 10', 'bdthemes-element-pack'),
                    '11' => esc_html__('Style 11', 'bdthemes-element-pack'),
                    '12' => esc_html__('Style 12', 'bdthemes-element-pack'),
                    '13' => esc_html__('Style 13', 'bdthemes-element-pack'),
                    '14' => esc_html__('Style 14', 'bdthemes-element-pack'),
                    '15' => esc_html__('Style 15', 'bdthemes-element-pack'),
                    '16' => esc_html__('Style 16', 'bdthemes-element-pack'),
                    '17' => esc_html__('Style 17', 'bdthemes-element-pack'),
                    '18' => esc_html__('Style 18', 'bdthemes-element-pack'),
                    'circle-1' => esc_html__('Style 19', 'bdthemes-element-pack'),
                    'circle-2' => esc_html__('Style 20', 'bdthemes-element-pack'),
                    'circle-3' => esc_html__('Style 21', 'bdthemes-element-pack'),
                    'circle-4' => esc_html__('Style 22', 'bdthemes-element-pack'),
                    'square-1' => esc_html__('Style 23', 'bdthemes-element-pack'),
                ],
                'condition' => [
                    'navigation' => ['both', 'arrows'],
                ],
            ]
        );

        $this->add_control(
            'both_position',
            [
                'label' => __('Arrows and Dots Position', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SELECT,
                'default' => 'center',
                'options' => element_pack_navigation_position(),
                'condition' => [
                    'navigation' => 'both',
                ],
            ]
        );

        $this->add_control(
            'arrows_position',
            [
                'label' => __('Arrows Position', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SELECT,
                'default' => 'bottom-right',
                'options' => element_pack_navigation_position(),
                'condition' => [
                    'navigation' => ['arrows'],
                ],
            ]
        );

        $this->add_control(
            'dots_position',
            [
                'label' => __('Dots Position', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SELECT,
                'default' => 'bottom-center',
                'options' => element_pack_pagination_position(),
                'condition' => [
                    'navigation' => 'dots',
                ],
            ]
        );

        $this->add_control(
            'hide_arrow_on_mobile',
            [
                'label' => __('Hide Arrow on Mobile ?', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_content_slider_settings',
            [
                'label' => __('Slider Settings', 'bdthemes-element-pack'),
            ]
        );

        $this->add_control(
            'slider_animations',
            [
                'label' => esc_html__('Slider Animations', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SELECT,
                'separator' => 'before',
                'default' => 'slide',
                'options' => [
                    'slide' => esc_html__('Slide', 'bdthemes-element-pack'),
                    'fade' => esc_html__('Fade', 'bdthemes-element-pack'),
                    'scale' => esc_html__('Scale', 'bdthemes-element-pack'),
                    'push' => esc_html__('Push', 'bdthemes-element-pack'),
                    'pull' => esc_html__('Pull', 'bdthemes-element-pack'),
                ],
            ]
        );

        $this->add_control(
            'autoplay',
            [
                'label' => __('Autoplay', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'autoplay_interval',
            [
                'label' => __('Autoplay Interval(ms)', 'bdthemes-element-pack'),
                'type' => Controls_Manager::NUMBER,
                'default' => 7000,
                'condition' => [
                    'autoplay' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'pause_on_hover',
            [
                'label' => __('Pause on Hover', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        $this->add_control(
            'velocity',
            [
                'label' => __('Animation Speed', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0.1,
                        'max' => 1,
                        'step' => 0.1,
                    ],
                ],
            ]
        );

        $this->end_controls_section();

        //New Query Builder Settings
        $this->start_controls_section(
            'section_post_query_builder',
            [
                'label' => __('Query', 'bdthemes-element-pack'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->register_query_builder_controls();
        $this->register_wc_query_additional('3');
        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_content',
            [
                'label' => __('Content', 'bdthemes-element-pack'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'content_background',
            [
                'label' => __('Background', 'bdthemes-element-pack'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-slider-item-content' => 'background: {{VALUE}};',
                ],

            ]
        );

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => __('Content Padding', 'bdthemes-element-pack'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'rem', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-slideshow-content-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'item_background',
            [
                'label' => __('Item Background', 'bdthemes-element-pack'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-slideshow-item-inner' => 'background: {{VALUE}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_price',
            [
                'label' => __('Price', 'bdthemes-element-pack'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_price' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'old_price_heading',
            [
                'label' => __('Old Price', 'bdthemes-element-pack'),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
            'old_price_color',
            [
                'label' => __('Color', 'bdthemes-element-pack'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-wc-slider-price del, .bdt-wc-slider .bdt-slider-skin-price del' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'old_price_margin',
            [
                'label' => __('Margin', 'bdthemes-element-pack'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'rem', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-wc-slider-price del, .bdt-wc-slider .bdt-slider-skin-price del' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'old_price_typography',
                'label' => __('Typography', 'bdthemes-element-pack'),
                //'scheme'   => Schemes\Typography::TYPOGRAPHY_4,
                'selector' => '{{WRAPPER}} .bdt-wc-slider .bdt-wc-slider-price del, .bdt-wc-slider .bdt-slider-skin-price del',
            ]
        );

        $this->add_control(
            'sale_price_heading',
            [
                'label' => __('Sale Price', 'bdthemes-element-pack'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'sale_price_color',
            [
                'label' => __('Color', 'bdthemes-element-pack'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-wc-slider-price, .bdt-wc-slider .bdt-slider-skin-price, {{WRAPPER}} .bdt-wc-slider .bdt-wc-slider-price ins, .bdt-wc-slider .bdt-slider-skin-price ins' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'sale_price_margin',
            [
                'label' => __('Margin', 'bdthemes-element-pack'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'rem', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-wc-slider-price, .bdt-wc-slider .bdt-slider-skin-price, {{WRAPPER}} .bdt-wc-slider .bdt-wc-slider-price ins, .bdt-wc-slider .bdt-slider-skin-price ins' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'sale_price_typography',
                'label' => __('Typography', 'bdthemes-element-pack'),
                //'scheme'   => Schemes\Typography::TYPOGRAPHY_4,
                'selector' => '{{WRAPPER}} .bdt-wc-slider .bdt-wc-slider-price, .bdt-wc-slider .bdt-slider-skin-price, {{WRAPPER}} .bdt-wc-slider .bdt-wc-slider-price ins, .bdt-wc-slider .bdt-slider-skin-price ins',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_title',
            [
                'label' => __('Title', 'bdthemes-element-pack'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_title' => ['yes'],
                ],
            ]
        );

        // $this->add_responsive_control(
        //     'title_width',
        //     [
        //         'label'   => __( 'Width (px)', 'bdthemes-element-pack' ),
        //         'type'    => Controls_Manager::SLIDER,
        //         'range' => [
        //             'px' => [
        //                 'min' => 50,
        //                 'max' => 550,
        //             ],
        //         ],
        //         'selectors' => [
        //             '{{WRAPPER}} .bdt-wc-slider-slade-skin .bdt-wc-slider-title' => 'max-width: {{SIZE}}{{UNIT}};',
        //         ],
        //         'condition' => [
        //             '_skin!' => '',
        //         ],
        //     ]
        // );

        // $this->add_control(
        //     'show_text_stroke',
        //     [
        //         'label'        => esc_html__('Text Stroke', 'bdthemes-element-pack') . BDTEP_NC,
        //         'type'         => Controls_Manager::SWITCHER,
        //         'prefix_class' => 'bdt-text-stroke--',
        //     ]
        // );

        // $this->add_responsive_control(
        //     'text_stroke_width',
        //     [
        //         'label'     => esc_html__('Text Stroke Width', 'bdthemes-element-pack') . BDTEP_NC,
        //         'type'      => Controls_Manager::SLIDER,
        //         'selectors' => [
        //             '{{WRAPPER}} .bdt-wc-slider .bdt-slideshow-items .bdt-wc-slider-title' => '-webkit-text-stroke-width: {{SIZE}}{{UNIT}};',
        //         ],
        //         'condition' => [
        //             'show_text_stroke' => 'yes'
        //         ]
        //     ]
        // );

        $this->add_control(
            'title_color',
            [
                'label' => __('Color', 'bdthemes-element-pack'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-slideshow-items .bdt-wc-slider-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'title_background',
            [
                'label' => __('Background', 'bdthemes-element-pack'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-slideshow-items .bdt-wc-slider-title' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_padding',
            [
                'label' => __('Padding', 'bdthemes-element-pack'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'rem', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-slideshow-items .bdt-wc-slider-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_radius',
            [
                'label' => __('Radius', 'bdthemes-element-pack'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'rem', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-slideshow-items .bdt-wc-slider-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'label' => __('Typography', 'bdthemes-element-pack'),
                'selector' => '{{WRAPPER}} .bdt-wc-slider .bdt-slideshow-items .bdt-wc-slider-title',
            ]
        );

        $this->add_group_control(
            Group_Control_Text_Stroke::get_type(),
            [
                'name' => 'title_text_stroke',
                'label' => __('Text Stroke', 'bdthemes-element-pack'),
                'selector' => '{{WRAPPER}} .bdt-wc-slider .bdt-slideshow-items .bdt-wc-slider-title',
            ]
        );

        $this->add_responsive_control(
            'title_spacing',
            [
                'label' => __('Spacing', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'rem', '%'],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-slideshow-items .bdt-wc-slider-title' => 'margin-top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_rating',
            [
                'label' => __('Rating', 'bdthemes-element-pack'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_rating' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'rating_color',
            [
                'label' => __('Color', 'bdthemes-element-pack'),
                'type' => Controls_Manager::COLOR,
                'default' => '#e7e7e7',
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .star-rating:before' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'active_rating_color',
            [
                'label' => __('Active Color', 'bdthemes-element-pack'),
                'type' => Controls_Manager::COLOR,
                'default' => '#FFCC00',
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .star-rating span' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'rating_spacing',
            [
                'label' => __('Spacing', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'rem', '%'],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-wc-rating' => 'margin-top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_text',
            [
                'label' => __('Text', 'bdthemes-element-pack'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        // $this->add_responsive_control(
        //     'text_width',
        //     [
        //         'label'   => __( 'Width (px)', 'bdthemes-element-pack' ),
        //         'type'    => Controls_Manager::SLIDER,
        //         'range' => [
        //             'px' => [
        //                 'min' => 50,
        //                 'max' => 650,
        //             ],
        //         ],
        //         'selectors' => [
        //             '{{WRAPPER}} .bdt-wc-slider-slade-skin .bdt-wc-slider-text' => 'max-width: {{SIZE}}{{UNIT}};',
        //         ],
        //         'condition' => [
        //             '_skin!' => '',
        //         ],
        //     ]
        // );

        $this->add_control(
            'text_color',
            [
                'label' => __('Text Color', 'bdthemes-element-pack'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-slideshow-items .bdt-wc-slider-text' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'text_background',
            [
                'label' => __('Background', 'bdthemes-element-pack'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-slideshow-items .bdt-wc-slider-text' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'text_padding',
            [
                'label' => __('Padding', 'bdthemes-element-pack'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'rem', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-slideshow-items .bdt-wc-slider-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'text_typography',
                'label' => __('Text Typography', 'bdthemes-element-pack'),
                //'scheme'   => Schemes\Typography::TYPOGRAPHY_4,
                'selector' => '{{WRAPPER}} .bdt-wc-slider .bdt-slideshow-items .bdt-wc-slider-text, .bdt-wc-slider .bdt-slideshow-items .bdt-wc-slider-text p',
            ]
        );

        $this->add_responsive_control(
            'text_spacing',
            [
                'label' => __('Spacing', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'rem', '%'],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-slideshow-items .bdt-wc-slider-text' => 'margin-top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_button',
            [
                'label' => __('Add to Cart Button', 'bdthemes-element-pack'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_cart' => 'yes',
                ],
            ]
        );

        $this->start_controls_tabs('tabs_button_style');

        $this->start_controls_tab(
            'tab_button_normal',
            [
                'label' => __('Normal', 'bdthemes-element-pack'),
            ]
        );

        $this->add_control(
            'button_color',
            [
                'label' => __('Color', 'bdthemes-element-pack'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-wc-add-to-cart a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_background',
            [
                'label' => __('Background', 'bdthemes-element-pack'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-wc-add-to-cart a' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_shadow',
                'selector' => '{{WRAPPER}} .bdt-wc-slider .bdt-wc-add-to-cart a',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'button_border',
                'label' => __('Border', 'bdthemes-element-pack'),
                'placeholder' => '1px',
                'default' => '1px',
                'selector' => '{{WRAPPER}} .bdt-wc-slider .bdt-wc-add-to-cart a',
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'button_radius',
            [
                'label' => __('Radius', 'bdthemes-element-pack'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'rem', '%'],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-wc-add-to-cart a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_padding',
            [
                'label' => __('Padding', 'bdthemes-element-pack'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'rem', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-wc-add-to-cart a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'add_to_cart_spacing',
            [
                'label' => __('Spacing', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'rem', '%'],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-wc-add-to-cart-readmore' => 'margin-top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'label' => __('Typography', 'bdthemes-element-pack'),
                'selector' => '{{WRAPPER}} .bdt-wc-slider .bdt-wc-add-to-cart a',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_button_hover',
            [
                'label' => __('Hover', 'bdthemes-element-pack'),
            ]
        );

        $this->add_control(
            'button_hover_background',
            [
                'label' => __('Background', 'bdthemes-element-pack'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-wc-add-to-cart a:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_hover_color',
            [
                'label' => __('Color', 'bdthemes-element-pack'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-wc-add-to-cart a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_hover_border_color',
            [
                'label' => __('Border Color', 'bdthemes-element-pack'),
                'type' => Controls_Manager::COLOR,
                'condition' => [
                    'button_border_border!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-wc-add-to-cart a:hover' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_readmore',
            [
                'label' => esc_html__('Read More', 'bdthemes-element-pack'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_readmore' => 'yes',
                ],
            ]
        );

        $this->start_controls_tabs('tabs_readmore_style');

        $this->start_controls_tab(
            'tab_readmore_normal',
            [
                'label' => esc_html__('Normal', 'bdthemes-element-pack'),
            ]
        );

        $this->add_control(
            'readmore_color',
            [
                'label' => esc_html__('Color', 'bdthemes-element-pack'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider-readmore' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .bdt-wc-slider-readmore svg' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'readmore_background',
            [
                'label' => esc_html__('Background Color', 'bdthemes-element-pack'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider-readmore' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'readmore_border',
                'label' => esc_html__('Border', 'bdthemes-element-pack'),
                'placeholder' => '1px',
                'default' => '1px',
                'selector' => '{{WRAPPER}} .bdt-wc-slider-readmore',
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'readmore_radius',
            [
                'label' => esc_html__('Radius', 'bdthemes-element-pack'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'rem', '%'],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider-readmore' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'readmore_shadow',
                'selector' => '{{WRAPPER}} .bdt-wc-slider-readmore',
            ]
        );

        $this->add_responsive_control(
            'readmore_padding',
            [
                'label' => esc_html__('Padding', 'bdthemes-element-pack'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'rem', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider-readmore' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'readmore_space_between',
            [
                'label' => esc_html__('Space Between', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SLIDER,
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-wc-slider-readmore' => 'margin-left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'readmore_typography',
                'label' => esc_html__('Typography', 'bdthemes-element-pack'),
                //'scheme'   => Schemes\Typography::TYPOGRAPHY_4,
                'selector' => '{{WRAPPER}} .bdt-wc-slider-readmore',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_readmore_hover',
            [
                'label' => esc_html__('Hover', 'bdthemes-element-pack'),
            ]
        );

        $this->add_control(
            'readmore_hover_color',
            [
                'label' => esc_html__('Color', 'bdthemes-element-pack'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider-readmore:hover' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .bdt-wc-slider-readmore:hover svg' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'readmore_hover_background',
            [
                'label' => esc_html__('Background Color', 'bdthemes-element-pack'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider-readmore:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'readmore_hover_border_color',
            [
                'label' => esc_html__('Border Color', 'bdthemes-element-pack'),
                'type' => Controls_Manager::COLOR,
                'condition' => [
                    'readmore_border_border!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider-readmore:hover' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'readmore_hover_animation',
            [
                'label' => esc_html__('Animation', 'bdthemes-element-pack'),
                'type' => Controls_Manager::HOVER_ANIMATION,
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_badge',
            [
                'label' => __('Badge', 'bdthemes-element-pack'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_badge' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'badge_text_color',
            [
                'label' => __('Text Color', 'bdthemes-element-pack'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-badge' => 'color: {{VALUE}} !important;',
                ],
            ]
        );

        $this->add_control(
            'badge_background',
            [
                'label' => __('Background', 'bdthemes-element-pack'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-badge' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'badge_border',
                'label' => __('Border Color', 'bdthemes-element-pack'),
                'placeholder' => '1px',
                'default' => '1px',
                'selector' => '{{WRAPPER}} .bdt-wc-slider .bdt-badge',
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'badge_radius',
            [
                'label' => __('Radius', 'bdthemes-element-pack'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'rem', '%'],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-badge' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'badge_padding',
            [
                'label' => __('Padding', 'bdthemes-element-pack'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'rem', '%'],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-badge' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'badge_margin',
            [
                'label' => __('Margin', 'bdthemes-element-pack'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'rem', '%'],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-wc-slider-badge' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'badge_typography',
                //'scheme'   => Schemes\Typography::TYPOGRAPHY_4,
                'selector' => '{{WRAPPER}} .bdt-wc-slider .bdt-badge',
            ]
        );

        $this->add_responsive_control(
			'badge_position',
			[
				'label'     => esc_html__('Choose Position', 'bdthemes-element-pack') . BDTEP_NC,
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'  => [
						'title' => esc_html__('Left', 'bdthemes-element-pack'),
						'icon'  => 'eicon-h-align-left',
					],
					'right' => [
						'title' => esc_html__('Right', 'bdthemes-element-pack'), 
						'icon'  => 'eicon-h-align-right',
					],
				],
				'default'   => 'left',
				'selectors' => [
					'{{WRAPPER}} .bdt-wc-slider .bdt-badge' => '{{VALUE}}',
				],
				'selectors_dictionary' => [
					'left'  => 'right: auto; left: 0',
					'right' => 'left: auto; right: 0', 
				],
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_navigation',
            [
                'label' => __('Navigation', 'bdthemes-element-pack'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'navigation' => ['arrows', 'dots', 'both'],
                ],
            ]
        );

        $this->add_control(
            'heading_arrows',
            [
                'label' => __('Arrows', 'bdthemes-element-pack'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'after',
                'condition' => [
                    'navigation!' => ['none', 'dots'],
                ],
            ]
        );

        $this->add_responsive_control(
            'arrows_size',
            [
                'label' => __('Size', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-navigation-prev i, {{WRAPPER}} .bdt-wc-slider .bdt-navigation-next i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'navigation!' => ['none', 'dots'],
                ],
            ]
        );

        $this->add_control(
            'arrows_background',
            [
                'label' => __('Background Color', 'bdthemes-element-pack'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-navigation-prev i, {{WRAPPER}} .bdt-wc-slider .bdt-navigation-next i' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'navigation!' => ['none', 'dots'],
                ],
            ]
        );

        $this->add_control(
            'arrows_hover_background',
            [
                'label' => __('Hover Background Color', 'bdthemes-element-pack'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-navigation-prev:hover i, {{WRAPPER}} .bdt-wc-slider .bdt-navigation-next:hover i' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'navigation!' => ['none', 'dots'],
                ],
            ]
        );

        $this->add_control(
            'arrows_color',
            [
                'label' => __('Color', 'bdthemes-element-pack'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-navigation-prev i, {{WRAPPER}} .bdt-wc-slider .bdt-navigation-next i' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'navigation!' => ['none', 'dots'],
                ],
            ]
        );

        $this->add_control(
            'arrows_hover_color',
            [
                'label' => __('Hover Color', 'bdthemes-element-pack'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-navigation-prev:hover i, {{WRAPPER}} .bdt-wc-slider .bdt-navigation-next:hover i' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'navigation!' => ['none', 'dots'],
                ],
            ]
        );

        $this->add_responsive_control(
            'arrows_padding',
            [
                'label' => __('Padding', 'bdthemes-element-pack'),
                'type' => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-navigation-prev i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .bdt-wc-slider .bdt-navigation-next i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'navigation!' => ['none', 'dots'],
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'arrows_border',
                'placeholder' => '1px',
                'default' => '1px',
                'selector' => '{{WRAPPER}} .bdt-wc-slider .bdt-navigation-prev i, {{WRAPPER}} .bdt-wc-slider .bdt-navigation-next i',
                'condition' => [
                    'navigation!' => ['none', 'dots'],
                ],
            ]
        );

        $this->add_responsive_control(
            'arrows_radius',
            [
                'label' => __('Radius', 'bdthemes-element-pack'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'rem', '%'],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-navigation-prev i, {{WRAPPER}} .bdt-wc-slider .bdt-navigation-next i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'navigation!' => ['none', 'dots'],
                ],
            ]
        );

        $this->add_responsive_control(
            'arrows_space',
            [
                'label' => __('Space Between Arrows', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-navigation-prev' => 'margin-right: {{SIZE}}px;',
                    '{{WRAPPER}} .bdt-wc-slider .bdt-navigation-next' => 'margin-left: {{SIZE}}px;',
                ],
                'condition' => [
                    'navigation!' => ['dots', 'progressbar', 'none'],
                ],
            ]
        );

        $this->add_control(
            'heading_dots',
            [
                'label' => __('Dots', 'bdthemes-element-pack'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'after',
                'condition' => [
                    'navigation!' => ['arrows', 'none'],
                ],
            ]
        );

        $this->add_responsive_control(
            'dots_size',
            [
                'label' => __('Size', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 5,
                        'max' => 20,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-dotnav li a' => 'height: {{SIZE}}{{UNIT}};width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'navigation!' => ['arrows', 'none'],
                ],
            ]
        );

        $this->add_responsive_control(
            'dots_width',
            [
                'label' => __('Active Size', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 5,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-dotnav li.bdt-active a' => 'width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'navigation!' => ['arrows', 'none'],
                ],
            ]
        );

        $this->add_responsive_control(
            'active_dot_radius',
            [
                'label' => __('Radius', 'bdthemes-element-pack'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'rem', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-dotnav li a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'navigation!' => ['arrows', 'none'],
                ],
            ]
        );

        $this->add_control(
            'dots_color',
            [
                'label' => __('Color', 'bdthemes-element-pack'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-dotnav li a' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'navigation!' => ['arrows', 'none'],
                ],
            ]
        );

        $this->add_control(
            'active_dot_color',
            [
                'label' => __('Active Color', 'bdthemes-element-pack'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-dotnav li.bdt-active a' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'navigation!' => ['arrows', 'none'],
                ],
            ]
        );

        $this->add_control(
            'heading_position',
            [
                'label' => __('Position', 'bdthemes-element-pack'),
                'type' => Controls_Manager::HEADING,
                'condition' => [
                    'navigation!' => 'none',
                ],
            ]
        );

        $this->add_responsive_control(
            'arrows_ncx_position',
            [
                'label' => __('Arrows Horizontal Offset', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SLIDER,
                'separator' => 'before',
                'default' => [
                    'size' => -30,
                ],
                'range' => [
                    'px' => [
                        'min' => -200,
                        'max' => 200,
                    ],
                ],
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'navigation',
                            'operator' => 'in',
                            'value' => ['arrows'],
                        ],
                        [
                            'name' => 'arrows_position',
                            'operator' => '!=',
                            'value' => 'center',
                        ],
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}' => '--ep-swiper-carousel-arrows-ncx: {{SIZE}}px;',
                ],
            ]
        );

        $this->add_responsive_control(
            'arrows_ncy_position',
            [
                'label' => __('Arrows Vertical Offset', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => -30,
                ],
                'range' => [
                    'px' => [
                        'min' => -200,
                        'max' => 200,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}' => '--ep-swiper-carousel-arrows-ncy: {{SIZE}}px;',
                ],
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'navigation',
                            'operator' => 'in',
                            'value' => ['arrows'],
                        ],
                        [
                            'name' => 'arrows_position',
                            'operator' => '!=',
                            'value' => 'center',
                        ],
                    ],
                ],
            ]
        );

        $this->add_responsive_control(
            'arrows_acx_position',
            [
                'label' => __('Arrows Horizontal Offset', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 0,
                ],
                'range' => [
                    'px' => [
                        'min' => -200,
                        'max' => 200,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-navigation-prev' => is_rtl() ? 'right: {{SIZE}}px;' : 'left: {{SIZE}}px;',
                    '{{WRAPPER}} .bdt-wc-slider .bdt-navigation-next' => is_rtl() ? 'left: {{SIZE}}px;' : 'right: {{SIZE}}px;',
                ],
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'navigation',
                            'operator' => 'in',
                            'value' => ['arrows'],
                        ],
                        [
                            'name' => 'arrows_position',
                            'value' => 'center',
                        ],
                    ],
                ],
            ]
        );

        $this->add_responsive_control(
            'dots_nnx_position',
            [
                'label' => __('Horizontal Offset', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 0,
                ],
                'range' => [
                    'px' => [
                        'min' => -200,
                        'max' => 200,
                    ],
                ],
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'navigation',
                            'value' => 'dots',
                        ],
                        [
                            'name' => 'dots_position',
                            'operator' => '!=',
                            'value' => '',
                        ],
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}' => '--ep-swiper-carousel-dots-nnx: {{SIZE}}px;',
                ],
            ]
        );

        $this->add_responsive_control(
            'dots_nny_position',
            [
                'label' => __('Vertical Offset', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 30,
                ],
                'range' => [
                    'px' => [
                        'min' => -200,
                        'max' => 200,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}' => '--ep-swiper-carousel-dots-nny: {{SIZE}}px;',
                ],
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'navigation',
                            'value' => 'dots',
                        ],
                        [
                            'name' => 'dots_position',
                            'operator' => '!=',
                            'value' => '',
                        ],
                    ],
                ],
            ]
        );

        $this->add_responsive_control(
            'both_ncx_position',
            [
                'label' => __('Horizontal Offset', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 0,
                ],
                'range' => [
                    'px' => [
                        'min' => -200,
                        'max' => 200,
                    ],
                ],
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'navigation',
                            'value' => 'both',
                        ],
                        [
                            'name' => 'both_position',
                            'operator' => '!=',
                            'value' => 'center',
                        ],
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}' => '--ep-swiper-carousel-both-ncx: {{SIZE}}px;',
                ],
            ]
        );

        $this->add_responsive_control(
            'both_ncy_position',
            [
                'label' => __('Vertical Offset', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 40,
                ],
                'range' => [
                    'px' => [
                        'min' => -200,
                        'max' => 200,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}' => '--ep-swiper-carousel-both-ncy: {{SIZE}}px;',
                ],
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'navigation',
                            'value' => 'both',
                        ],
                        [
                            'name' => 'both_position',
                            'operator' => '!=',
                            'value' => 'center',
                        ],
                    ],
                ],
            ]
        );

        $this->add_responsive_control(
            'both_cx_position',
            [
                'label' => __('Arrows Offset', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 20,
                ],
                'range' => [
                    'px' => [
                        'min' => -200,
                        'max' => 200,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-navigation-prev' => is_rtl() ? 'right: {{SIZE}}px;' : 'left: {{SIZE}}px;',
                    '{{WRAPPER}} .bdt-wc-slider .bdt-navigation-next' => is_rtl() ? 'left: {{SIZE}}px;' : 'right: {{SIZE}}px;',
                ],
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'navigation',
                            'value' => 'both',
                        ],
                        [
                            'name' => 'both_position',
                            'value' => 'center',
                        ],
                    ],
                ],
            ]
        );

        $this->add_responsive_control(
            'both_cy_position',
            [
                'label' => __('Dots Offset', 'bdthemes-element-pack'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => -40,
                ],
                'range' => [
                    'px' => [
                        'min' => -200,
                        'max' => 200,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .bdt-wc-slider .bdt-dots-container' => 'transform: translateY({{SIZE}}px);',
                ],
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'navigation',
                            'value' => 'both',
                        ],
                        [
                            'name' => 'both_position',
                            'value' => 'center',
                        ],
                    ],
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
			'section_style_image',
			[
				'label' => esc_html__( 'Image', 'bdthemes-element-pack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'separator_panel_style',
			[
				'type' => Controls_Manager::DIVIDER,
				'style' => 'thick',
			]
		);

		$this->start_controls_tabs( 'image_effects' );

		$this->start_controls_tab( 'normal',
			[
				'label' => esc_html__( 'Normal', 'bdthemes-element-pack' ),
			]
		);

		$this->add_control(
			'opacity',
			[
				'label' => esc_html__( 'Opacity', 'bdthemes-element-pack' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 1,
						'min' => 0.10,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} img' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Css_Filter::get_type(),
			[
				'name' => 'css_filters',
				'selector' => '{{WRAPPER}} img',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab( 'hover',
			[
				'label' => esc_html__( 'Hover', 'bdthemes-element-pack' ),
			]
		);

		$this->add_control(
			'opacity_hover',
			[
				'label' => esc_html__( 'Opacity', 'bdthemes-element-pack' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 1,
						'min' => 0.10,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}}:hover img' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Css_Filter::get_type(),
			[
				'name' => 'css_filters_hover',
				'selector' => '{{WRAPPER}}:hover img',
			]
		);

		$this->add_control(
			'background_hover_transition',
			[
				'label' => esc_html__( 'Transition Duration', 'bdthemes-element-pack' ) . ' (s)',
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 3,
						'step' => 0.1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} img' => 'transition-duration: {{SIZE}}s',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
    }

    public function render_query( $posts_per_page, $settings ) {
        $default = $this->getGroupControlQueryArgs();
        $args    = [
            'posts_per_page' => $posts_per_page,
            'post_type'      => 'product',
        ];
        $product_visibility_term_ids = wc_get_product_visibility_term_ids();
        if ( 'yes' === $settings['product_hide_free'] ) {
            $args['meta_query'][] = [
                'key'     => '_price',
                'value'   => 0,
                'compare' => '>',
                'type'    => 'DECIMAL',
            ];
        }
        if ( 'yes' === $settings['product_hide_out_stock'] ) {
            $args['tax_query'][] = [
                [
                    'taxonomy' => 'product_visibility',
                    'field'    => 'term_taxonomy_id',
                    'terms'    => $product_visibility_term_ids['outofstock'],
                    'operator' => 'NOT IN',
                ],
            ];
        }
        $product_type = $settings['product_show_product_type'];
        switch ( $product_type ) {
            case 'featured':
                $args['tax_query'][] = [
                    'taxonomy' => 'product_visibility',
                    'field'    => 'term_taxonomy_id',
                    'terms'    => $product_visibility_term_ids['featured'],
                ];
                break;
            case 'onsale':
                $product_ids_on_sale   = wc_get_product_ids_on_sale();
                $product_ids_on_sale[] = 0;
                $args['post__in']      = $product_ids_on_sale;
                break;
        }
        $orderby = $settings['posts_orderby'];
        switch ( $orderby ) {
            case 'price':
                // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- WooCommerce price sorting requires meta_key.
                $args['meta_key'] = '_price';
                $args['orderby']  = 'meta_value_num';
                break;
            case 'sales':
                // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- WooCommerce sales sorting requires meta_key.
                $args['meta_key'] = 'total_sales';
                $args['orderby']  = 'meta_value_num';
                break;
            default:
                $args['orderby'] = $orderby;
        }
        $args     = array_merge( $default, $args );
        $wp_query = new WP_Query( $args );
        return $wp_query;
    }

    public function render_navigation( $settings ) {
        $hide_arrow_on_mobile = ! empty( $settings['hide_arrow_on_mobile'] ) ? 'bdt-visible@m' : '';
        $arrows_position      = isset( $settings['arrows_position'] ) ? $settings['arrows_position'] : 'bottom-right';
        $nav_arrows_icon      = isset( $settings['nav_arrows_icon'] ) ? $settings['nav_arrows_icon'] : '0';
        ?>
        <div class="bdt-position-z-index bdt-position-<?php echo esc_attr( $arrows_position . ' ' . $hide_arrow_on_mobile ); ?>">
            <div class="bdt-arrows-container bdt-slidenav-container">
                <a href="" class="bdt-navigation-prev bdt-slidenav-previous bdt-icon bdt-slidenav" data-bdt-slideshow-item="previous">
                    <i class="ep-icon-arrow-left-<?php echo esc_attr( $nav_arrows_icon ); ?>" aria-hidden="true"></i>
                </a>
                <a href="" class="bdt-navigation-next bdt-slidenav-next bdt-icon bdt-slidenav" data-bdt-slideshow-item="next">
                    <i class="ep-icon-arrow-right-<?php echo esc_attr( $nav_arrows_icon ); ?>" aria-hidden="true"></i>
                </a>
            </div>
        </div>
        <?php
    }

    public function render_dotnavs( $settings, $wp_query ) {
        $hide_arrow_on_mobile = ! empty( $settings['hide_arrow_on_mobile'] ) ? 'bdt-visible@m' : '';
        $dots_position        = isset( $settings['dots_position'] ) ? $settings['dots_position'] : 'bottom-center';
        ?>
        <div class="bdt-position-z-index bdt-position-<?php echo esc_attr( $dots_position . ' ' . $hide_arrow_on_mobile ); ?>">
            <div class="bdt-dotnav-wrapper bdt-dots-container">
                <ul class="bdt-dotnav bdt-flex-center">
                    <?php
                    $bdt_counter = 0;
                    $wp_query->rewind_posts();
                    while ( $wp_query->have_posts() ) :
                        $wp_query->the_post();
                        $active = ( $bdt_counter === 0 ) ? ' bdt-active' : '';
                        echo '<li class="bdt-slideshow-dotnav' . esc_attr( $active ) . '" data-bdt-slideshow-item=" ' . esc_attr( $bdt_counter ) . ' "><a href="#"></a></li>';
                        $bdt_counter++;
                    endwhile;
                    wp_reset_postdata();
                    ?>
                </ul>
            </div>
        </div>
        <?php
    }

    public function render_both_navigation( $settings, $wp_query ) {
        $hide_arrow_on_mobile = ! empty( $settings['hide_arrow_on_mobile'] ) ? 'bdt-visible@m' : '';
        $both_position        = isset( $settings['both_position'] ) ? $settings['both_position'] : 'center';
        $nav_arrows_icon      = isset( $settings['nav_arrows_icon'] ) ? $settings['nav_arrows_icon'] : '0';
        ?>
        <div class="bdt-position-z-index bdt-position-<?php echo esc_attr( $both_position ); ?>">
            <div class="bdt-arrows-dots-container bdt-slidenav-container ">
                <div class="bdt-flex bdt-flex-middle">
                    <div class="<?php echo esc_attr( $hide_arrow_on_mobile ); ?>">
                        <a href="" class="bdt-navigation-prev bdt-slidenav-previous bdt-icon bdt-slidenav" data-bdt-slideshow-item="previous">
                            <i class="ep-icon-arrow-left-<?php echo esc_attr( $nav_arrows_icon ); ?>" aria-hidden="true"></i>
                        </a>
                    </div>
                    <?php if ( $both_position !== 'center' ) : ?>
                        <div class="bdt-dotnav-wrapper bdt-dots-container">
                            <ul class="bdt-dotnav">
                                <?php
                                $bdt_counter = 0;
                                $wp_query->rewind_posts();
                                while ( $wp_query->have_posts() ) :
                                    $wp_query->the_post();
                                    echo '<li class="bdt-slideshow-dotnav" data-bdt-slideshow-item="' . esc_attr( (string) $bdt_counter ) . '"><a href="#"></a></li>';
                                    $bdt_counter++;
                                endwhile;
                                wp_reset_postdata();
                                ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <div class="<?php echo esc_attr( $hide_arrow_on_mobile ); ?>">
                        <a href="" class="bdt-navigation-next bdt-slidenav-next bdt-icon bdt-slidenav" data-bdt-slideshow-item="next">
                            <i class="ep-icon-arrow-right-<?php echo esc_attr( $nav_arrows_icon ); ?>" aria-hidden="true"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    public function render_item_image( $settings ) {
        $thumb_id   = get_post_thumbnail_id();
        $image_size = isset( $settings['image_size'] ) ? $settings['image_size'] : 'full';

        if ( ! $thumb_id ) {
            return;
        }

        echo wp_get_attachment_image(
            $thumb_id,
            $image_size,
            false,
            array(
                'alt' => esc_attr( get_the_title() ),
            )
        );
    }

    public function render_header( $settings ) {

        // slider_size_ratio is null until the control is touched, so read it
        // defensively — the ratio check below already treats empty as "default".
        $size_ratio   = isset( $settings['slider_size_ratio'] ) && is_array( $settings['slider_size_ratio'] ) ? $settings['slider_size_ratio'] : array();
        $ratio_width  = isset( $size_ratio['width'] ) ? $size_ratio['width'] : '';
        $ratio_height = isset( $size_ratio['height'] ) ? $size_ratio['height'] : '';
        $ratio        = ( ! empty( $ratio_width ) && ! empty( $ratio_height ) ) ? $ratio_width . ':' . $ratio_height : '1920:768';
        if ( ! empty( $settings['enable_height'] ) && ! empty( $settings['viewport_height']['size'] ) ) {
            $ratio = false;
        }

        $slider_animations = isset( $settings['slider_animations'] ) ? $settings['slider_animations'] : 'slide';
        $autoplay          = ! empty( $settings['autoplay'] );
        $autoplay_interval = isset( $settings['autoplay_interval'] ) ? (int) $settings['autoplay_interval'] : 7000;
        $pause_on_hover    = ( isset( $settings['pause_on_hover'] ) && $settings['pause_on_hover'] === 'yes' );
        $velocity_size     = ( isset( $settings['velocity']['size'] ) && $settings['velocity']['size'] !== '' ) ? (float) $settings['velocity']['size'] : 1;
        $min_height        = ( ! empty( $settings['slider_min_height']['size'] ) && $ratio !== false ) ? $settings['slider_min_height']['size'] : false;

        $this->add_render_attribute(
            [
                'slider_settings' => [
                    'data-bdt-slideshow' => [
                        wp_json_encode(
                            [
                                'animation'         => $slider_animations,
                                'ratio'             => $ratio,
                                'min-height'        => $min_height,
                                'autoplay'          => $autoplay,
                                'autoplay-interval' => $autoplay_interval,
                                'pause-on-hover'    => $pause_on_hover,
                                'velocity'          => $velocity_size,
                            ]
                        ),
                    ],
                ],
            ]
        );

        $this->add_render_attribute( 'slider_settings', 'class', 'bdt-wc-slider' );
        $navigation = isset( $settings['navigation'] ) ? $settings['navigation'] : 'arrows';
        if ( $navigation === 'both' ) {
            $both_position = isset( $settings['both_position'] ) ? $settings['both_position'] : 'center';
            $this->add_render_attribute( 'slider_settings', 'class', 'bdt-arrows-dots-align-' . esc_attr( $both_position ) );
        } elseif ( $navigation === 'arrows' ) {
            $arrows_position = isset( $settings['arrows_position'] ) ? $settings['arrows_position'] : 'bottom-right';
            $this->add_render_attribute( 'slider_settings', 'class', 'bdt-arrows-align-' . esc_attr( $arrows_position ) );
        } elseif ( $navigation === 'dots' ) {
            $dots_position = isset( $settings['dots_position'] ) ? $settings['dots_position'] : 'bottom-center';
            $this->add_render_attribute( 'slider_settings', 'class', 'bdt-dots-align-' . esc_attr( $dots_position ) );
        }
        $slider_fullscreen = '';
        if ( ! empty( $settings['slider_fullscreen'] ) && empty( $settings['enable_height'] ) ) {
            $slider_fullscreen = 'bdt-height-viewport="offset-top: true"';
        }
        ?>
        <div <?php $this->print_render_attribute_string( 'slider_settings' ); ?>>
            <div class="bdt-position-relative bdt-visible-toggle">
                <ul class="bdt-slideshow-items bdt-child-width-1-1" <?php echo $slider_fullscreen; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed literal attribute built above. ?>>
        <?php
    }

    public function render_footer( $settings, $wp_query ) {
        ?>
                </ul>
                <?php
                $navigation = isset( $settings['navigation'] ) ? $settings['navigation'] : 'arrows';
                if ( $navigation === 'both' ) :
                    $this->render_both_navigation( $settings, $wp_query );
                    if ( ( isset( $settings['both_position'] ) ? $settings['both_position'] : '' ) === 'center' ) :
                        $this->render_dotnavs( $settings, $wp_query );
                    endif;
                elseif ( $navigation === 'arrows' ) :
                    $this->render_navigation( $settings );
                elseif ( $navigation === 'dots' ) :
                    $this->render_dotnavs( $settings, $wp_query );
                endif;
                ?>
            </div>
        </div>
        <?php
    }

    public function render_readmore( $settings ) {

        $animation                = ( $this->get_settings( 'readmore_hover_animation' ) ) ? ' elementor-animation-' . esc_attr( $this->get_settings( 'readmore_hover_animation' ) ) : '';
        if ( ! isset( $settings['readmore_icon'] ) && ! Icons_Manager::is_migration_allowed() ) {
            $settings['readmore_icon'] = 'fas fa-arrow-right';
        }
        $migrated = isset( $settings['__fa4_migrated']['wc_slider_readmore_icon'] );
        $is_new   = empty( $settings['readmore_icon'] ) && Icons_Manager::is_migration_allowed();
        $readmore_text       = $this->get_settings( 'readmore_text' ) ?: esc_html__( 'Read More', 'bdthemes-element-pack' );
        $readmore_icon_align = $this->get_settings( 'readmore_icon_align' ) ?: 'right';
        $use_render_icon     = ( $is_new || $migrated ) && ! empty( $settings['wc_slider_readmore_icon']['library'] );
        $use_legacy_icon     = ! $use_render_icon && ! empty( $settings['readmore_icon'] );

        ?>
        <a href="<?php echo esc_url( get_permalink() ); ?>" class="bdt-wc-slider-readmore <?php echo esc_attr( $animation ); ?>">
            <?php if ( ( $use_render_icon || $use_legacy_icon ) && 'left' === $readmore_icon_align ) : ?>
                <?php if ( $use_render_icon ) : ?>
                    <?php Icons_Manager::render_icon( $settings['wc_slider_readmore_icon'], [ 'aria-hidden' => 'true', 'class' => 'fa-fw' ] ); ?>
                <?php else : ?>
                    <i class="<?php echo esc_attr( $settings['readmore_icon'] ); ?>" aria-hidden="true"></i>
                <?php endif; ?>
            <?php endif; ?>
            <span class="bdt-wc-slider-readmore-text">
                <?php echo esc_html( $readmore_text ); ?>
            </span>
            <?php if ( ( $use_render_icon || $use_legacy_icon ) && 'right' === $readmore_icon_align ) : ?>
                <?php if ( $use_render_icon ) : ?>
                    <?php Icons_Manager::render_icon( $settings['wc_slider_readmore_icon'], [ 'aria-hidden' => 'true', 'class' => 'fa-fw' ] ); ?>
                <?php else : ?>
                    <i class="<?php echo esc_attr( $settings['readmore_icon'] ); ?>" aria-hidden="true"></i>
                <?php endif; ?>
            <?php endif; ?>
        </a>
        <?php
    }

    public function render_item_content( $settings ) {

        $this->add_render_attribute( 'bdt-wc-slider-title', 'class', 'bdt-wc-slider-title', true );
        $text_align     = isset( $settings['text_align'] ) ? $settings['text_align'] : 'left';
        $show_price     = ! empty( $settings['show_price'] );
        $show_title     = ! empty( $settings['show_title'] );
        $show_rating    = ! empty( $settings['show_rating'] );
        $show_text      = ! empty( $settings['show_text'] );
        $excerpt_length = isset( $settings['excerpt_length'] ) ? (int) $settings['excerpt_length'] : 25;
        $show_cart      = ! empty( $settings['show_cart'] );
        $show_readmore  = ! empty( $settings['show_readmore'] );
        $title_tag      = Utils::get_valid_html_tag( $settings['title_tags'] );

        ?>
        <div class="bdt-slideshow-content-wrapper bdt-padding bdt-text-<?php echo esc_attr( $text_align ); ?>">
            <?php if ( $show_price ) : ?>
                <div class="bdt-wc-slider-price">
                    <div class="wae-product-price"><?php woocommerce_template_single_price(); ?></div>
                </div>
            <?php endif; ?>
            <?php if ( $show_title ) : ?>
                <<?php echo esc_attr( $title_tag ); ?> <?php $this->print_render_attribute_string( 'bdt-wc-slider-title' ); ?>>
                    <?php the_title(); ?>
                </<?php echo esc_attr( $title_tag ); ?>>
            <?php endif; ?>
            <?php if ( $show_rating ) : ?>
                <div class="bdt-wc-rating bdt-flex bdt-flex-<?php echo esc_attr( $text_align ); ?>">
                    <?php woocommerce_template_loop_rating(); ?>
                </div>
            <?php endif; ?>
            <?php if ( $show_text ) : ?>
                <div class="bdt-wc-slider-text">
                    <?php if ( has_excerpt() ) : ?>
                        <?php the_excerpt(); ?>
                    <?php else : ?>
                        <?php echo wp_kses_post( element_pack_custom_excerpt( $excerpt_length, false, '…' ) ); ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <?php if ( $show_cart || $show_readmore ) : ?>
                <div class="bdt-wc-add-to-cart-readmore bdt-flex bdt-flex-<?php echo esc_attr( $text_align ); ?> bdt-flex-middle">
                    <?php if ( $show_cart ) : ?>
                        <div class="bdt-wc-add-to-cart">
                            <?php woocommerce_template_loop_add_to_cart(); ?>
                        </div>
                    <?php endif; ?>
                    <?php if ( $show_readmore ) : ?>
                        <?php $this->render_readmore( $settings ); ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }

    protected function render() {

        $settings        = $this->get_settings_for_display();
        $content_reverse = ! empty( $settings['content_reverse'] ) ? ' bdt-flex-first' : '';
        $vertical_align  = isset( $settings['vertical_align'] ) ? $settings['vertical_align'] : 'middle';
        $show_badge      = ! empty( $settings['show_badge'] );
        $posts_per_page  = isset( $settings['posts_per_page'] ) ? (int) $settings['posts_per_page'] : 3;
        $this->render_header( $settings );
        $wp_query = $this->render_query( $posts_per_page, $settings );

        while ( $wp_query->have_posts() ) :
            $wp_query->the_post();
            global $post, $product;
            ?>
            <li class="bdt-slideshow-item">
                <div class="bdt-slideshow-item-inner bdt-grid bdt-grid-collapse bdt-height-1-1" data-bdt-grid>
                    <div class="bdt-width-1-2@m bdt-flex bdt-flex-<?php echo esc_attr( $vertical_align ); ?> bdt-slider-item-content">
                        <?php $this->render_item_content( $settings ); ?>
                    </div>
                    <div class="bdt-width-1-2@m bdt-flex bdt-flex-<?php echo esc_attr( $vertical_align ); ?> bdt-mobile-order<?php echo esc_attr( $content_reverse ); ?>">
                        <div class="bdt-position-relative bdt-wc-slider-image">
                            <?php $this->render_item_image( $settings ); ?>
                            <?php if ( $show_badge && ! $product->is_in_stock() ) : ?>
                                <div class="bdt-badge bdt-position-top-left bdt-position-small">
                                    <?php
                                    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                                    echo apply_filters( 'woocommerce_product_is_in_stock', '<span class="bdt-onsale">' . esc_html__( 'Out of Stock!', 'bdthemes-element-pack' ) . '</span>', $post, $product );
                                    ?>
                                </div>
                            <?php elseif ( $show_badge && $product->is_on_sale() ) : ?>
                                <div class="bdt-badge bdt-position-top-left bdt-position-small">
                                    <?php
                                    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                                    echo apply_filters( 'woocommerce_sale_flash', '<span class="bdt-onsale">' . esc_html__( 'Sale!', 'bdthemes-element-pack' ) . '</span>', $post, $product );
                                    ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </li>
            <?php
        endwhile;
        wp_reset_postdata();
        $this->render_footer( $settings, $wp_query );
    }
}
