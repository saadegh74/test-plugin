<?php

namespace ElementPack\Modules\TestimonialSlider\Widgets;

use ElementPack\Base\Module_Base;
use ElementPack\Includes\Controls\GroupQuery\Group_Control_Query;
use ElementPack\Modules\TestimonialSlider\Skins;
use ElementPack\Traits\Global_Controls_Functions;
use ElementPack\Traits\Global_Swiper_Controls;
use ElementPack\Traits\Global_Widget_Controls;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Testimonial_Slider extends Module_Base {
	use Group_Control_Query;
	use Global_Widget_Controls;
	use Global_Swiper_Controls;
	use Global_Controls_Functions;

	private $_query = null;

	public function get_name() {
		return 'bdt-testimonial-slider';
	}

	public function get_title() {
		return BDTEP . esc_html__( 'Testimonial Slider', 'bdthemes-element-pack' );
	}

	public function get_icon() {
		return 'bdt-wi-testimonial-slider';
	}

	public function get_categories() {
		return [ 'element-pack' ];
	}

	public function get_keywords() {
		return [ 'testimonial', 'slider' ];
	}

	public function get_style_depends() {
		return $this->ep_is_edit_mode()
			? [ 'swiper', 'ep-styles' ]
			: [ 'swiper', 'ep-font', 'ep-testimonial-slider' ];
	}

	public function get_script_depends() {
		return $this->ep_is_edit_mode()
			? [ 'swiper', 'ep-scripts' ]
			: [ 'swiper', 'ep-testimonial-slider' ];
	}

	public function get_custom_help_url() {
		return 'https://youtu.be/pI-DLKNlTGg';
	}

	public function register_skins() {
		$this->add_skin( new Skins\Skin_Thumb( $this ) );
		$this->add_skin( new Skins\Skin_Single( $this ) );
	}

	public function get_query() {
		return $this->_query;
	}

	public function has_widget_inner_wrapper(): bool {
		return ! \Elementor\Plugin::$instance->experiments->is_feature_active( 'e_optimized_markup' );
	}

	public function register_controls() {
		$this->register_testimonial_controls( 'slider' );
	}

	public function render_query( $posts_per_page ) {
		return $this->query_testimonial_posts( 'slider', $posts_per_page );
	}

	public function render_header( $skin, $id, $settings ) {
		$this->render_testimonial_slider_header( $skin, $id, $settings );
	}

	public function render_navigation( $settings ) {
		$this->render_testimonial_slider_navigation( $settings );
	}

	public function render_pagination( $settings ) {
		$this->render_testimonial_slider_pagination( $settings );
	}

	public function render_both_navigation( $settings ) {
		$this->render_testimonial_slider_both_navigation( $settings );
	}

	public function render_arrows_fraction( $settings ) {
		$this->render_testimonial_slider_arrows_fraction( $settings );
	}

	public function render_footer( $settings ) {
		$this->render_testimonial_slider_footer( $settings );
	}

	public function render_schema_item_reviewed( $settings ) {
		$this->render_testimonial_schema_item_reviewed( $settings );
	}

	public function render_rating_schema_only( $post_id, $settings ) {
		$this->render_testimonial_rating_schema_only( $post_id, $settings );
	}

	public function render_review_platform( $post_id, $settings ) {
		$this->render_testimonial_review_platform( $post_id, $settings );
	}

	public function render_designation( $post_id, $settings ) {
		$this->render_testimonial_designation( 'slider', $post_id, $settings );
	}

	public function render_image( $settings ) {
		$this->render_testimonial_slider_image( $settings );
	}

	public function render_excerpt( $settings ) {
		$this->render_testimonial_slider_excerpt( $settings );
	}

	public function render_meta( $element_key, $settings ) {
		$this->render_testimonial_slider_meta( $element_key, $settings );
	}

	public function render() {
		$this->render_testimonial_slider();
	}
}
