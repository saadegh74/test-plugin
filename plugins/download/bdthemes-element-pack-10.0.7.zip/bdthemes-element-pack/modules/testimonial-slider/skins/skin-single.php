<?php

namespace ElementPack\Modules\TestimonialSlider\Skins;

use Elementor\Skin_Base as Elementor_Skin_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @property \ElementPack\Modules\TestimonialSlider\Widgets\Testimonial_Slider $parent
 */
class Skin_Single extends Elementor_Skin_Base {

	public function get_id() {
		return 'bdt-single';
	}

	public function get_title() {
		return __( 'Single', 'bdthemes-element-pack' );
	}

	public function render_image( $settings ) {
		$thumb = wp_get_attachment_image_src( get_post_thumbnail_id(), 'medium' );
		$src   = ( $thumb && isset( $thumb[0] ) ) ? $thumb[0] : BDTEP_ASSETS_URL . 'images/member.svg';
		$title = get_the_title();
		?>
		<div class="bdt-testimonial-thumb-wrap bdt-flex bdt-position-relative">
			<div class="bdt-testimonial-thumb bdt-position-relative">
				<img src="<?php echo esc_url( $src ); ?>" alt="<?php echo esc_attr( $title ); ?>" />
			</div>
			<?php $this->parent->render_review_platform( get_the_ID(), $settings ); ?>
		</div>
		<?php
	}

	public function render() {
		$settings = $this->parent->get_settings_for_display();
		$id       = $this->parent->get_id();
		$index    = 1;
		$per_page = isset( $settings['posts_per_page'] ) ? (int) $settings['posts_per_page'] : 4;
		$wp_query = $this->parent->render_query( $per_page );

		if ( ! $wp_query->found_posts ) {
			return;
		}

		$this->parent->render_header( 'single', $id, $settings );

		$schema_on   = $settings['schema_rich_results'] === 'yes';
		$show_rating = $settings['rating'] === 'yes';
		$alignment   = $settings['alignment'] ?? 'left';
		$meta_pos    = $settings['meta_position'] ?? 'after';

		while ( $wp_query->have_posts() ) :
			$wp_query->the_post();
			$post_id  = get_the_ID();
			$platform = get_post_meta( $post_id, 'bdthemes_tm_platform', true );
			$platform = $platform !== '' ? strtolower( $platform ) : '';
			$slide_key = 'slide-' . $post_id;
			$this->parent->add_render_attribute( $slide_key, 'class', 'swiper-slide bdt-review-' . $platform );
			if ( $schema_on ) {
				$this->parent->add_render_attribute( $slide_key, 'itemprop', 'review' );
				$this->parent->add_render_attribute( $slide_key, 'itemscope', '' );
				$this->parent->add_render_attribute( $slide_key, 'itemtype', 'https://schema.org/Review' );
			}
			?>
			<div <?php $this->parent->print_render_attribute_string( $slide_key ); ?>>
				<?php $this->parent->render_schema_item_reviewed( $settings ); ?>
				<?php if ( $schema_on && ! $show_rating ) : ?>
					<?php $this->parent->render_rating_schema_only( $post_id, $settings ); ?>
				<?php endif; ?>
				<div class="bdt-grid bdt-flex-middle" data-bdt-grid data-bdt-height-match="target: > div > div">
					<?php if ( $alignment !== 'right' ) : ?>
						<div class="bdt-testimonial-image-part bdt-width-auto@m">
							<?php $this->render_image( $settings ); ?>
						</div>
					<?php endif; ?>
					<div class="bdt-testimonial-desc-part bdt-width-expand@m">
						<div class="bdt-slider-item-inner bdt-grid-item-match">
							<?php if ( $meta_pos === 'after' ) : ?>
								<div class="bdt-testimonial-text bdt-text-<?php echo esc_attr( $alignment ); ?>">
									<?php $this->parent->render_excerpt( $settings ); ?>
								</div>
							<?php endif; ?>
							<div class="bdt-flex bdt-flex-<?php echo esc_attr( $alignment ); ?> bdt-flex-middle">
								<?php $this->parent->render_meta( 'testmonial-meta-' . $index, $settings ); ?>
							</div>
							<?php if ( $meta_pos === 'before' ) : ?>
								<div class="bdt-testimonial-text bdt-text-<?php echo esc_attr( $alignment ); ?>">
									<?php $this->parent->render_excerpt( $settings ); ?>
								</div>
							<?php endif; ?>
						</div>
					</div>
					<?php if ( $alignment === 'right' ) : ?>
						<div class="bdt-testimonial-image-part bdt-width-auto@m">
							<?php $this->render_image( $settings ); ?>
						</div>
					<?php endif; ?>
				</div>
			</div>
			<?php
			$index++;
		endwhile;

		wp_reset_postdata();
		$this->parent->render_footer( $settings );
	}
}