<?php

namespace ElementPack\Modules\TestimonialSlider\Skins;

use Elementor\Skin_Base as Elementor_Skin_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @property \ElementPack\Modules\TestimonialSlider\Widgets\Testimonial_Slider $parent
 */
class Skin_Thumb extends Elementor_Skin_Base {

	public function get_id() {
		return 'bdt-thumb';
	}

	public function get_title() {
		return __( 'Thumb', 'bdthemes-element-pack' );
	}

	public function render_image( $bdt_counter, $settings ) {
		$thumb = wp_get_attachment_image_src( get_post_thumbnail_id(), 'medium' );
		$src   = ( $thumb && isset( $thumb[0] ) ) ? $thumb[0] : BDTEP_ASSETS_URL . 'images/member.svg';
		$platform = get_post_meta( get_the_ID(), 'bdthemes_tm_platform', true );
		$platform = $platform !== '' ? strtolower( $platform ) : '';
		?>
		<li class="bdt-slider-thumbnav bdt-review-<?php echo esc_attr( $platform ); ?>"
			data-bdt-slider-item="<?php echo esc_attr( (string) $bdt_counter ); ?>">
			<div class="bdt-slider-thumbnav-inner bdt-position-relative">
				<a href="#">
					<img src="<?php echo esc_url( $src ); ?>" alt="<?php echo esc_attr( get_the_title() ); ?>" />
				</a>
				<?php $this->parent->render_review_platform( get_the_ID(), $settings ); ?>
			</div>
		</li>
		<?php
	}

	public function render_thumbnavs( $settings, $wp_query ) {
		$alignment = $settings['alignment'] ?? 'center';
		?>
		<div class="bdt-thumbnav-wrapper bdt-flex bdt-flex-<?php echo esc_attr( $alignment ); ?>">
			<ul class="bdt-thumbnav">
				<?php
				$bdt_counter = 0;
				$wp_query->rewind_posts();
				while ( $wp_query->have_posts() ) :
					$wp_query->the_post();
					$this->render_image( $bdt_counter, $settings );
					$bdt_counter++;
				endwhile;
				wp_reset_postdata();
				?>
			</ul>
		</div>
		<?php
	}

	public function render_header( $skin, $id, $settings ) {
		$this->parent->add_render_attribute( 'testimonial-slider', 'id', 'bdt-testimonial-slider-' . esc_attr( $id ) );
		$this->parent->add_render_attribute( 'testimonial-slider', 'class', [ 'bdt-testimonial-slider', 'skin-' . esc_attr( $skin ) ] );
		$slider_config = array_filter( [
			'autoplay'          => $settings['autoplay'] ?? '',
			'autoplay-interval' => isset( $settings['autoplay_interval'] ) ? (int) $settings['autoplay_interval'] : 7000,
			'finite'            => $settings['loop'] !== 'yes',
			'pause-on-hover'    => ! empty( $settings['pause_on_hover'] ),
			'velocity'          => isset( $settings['velocity'] ) ? (int) $settings['velocity'] : 500,
		] );
		$this->parent->add_render_attribute( 'slider-settings', 'data-bdt-slider', wp_json_encode( $slider_config ) );
		?>
		<div <?php $this->parent->print_render_attribute_string( 'testimonial-slider' ); ?>>
			<div <?php $this->parent->print_render_attribute_string( 'slider-settings' ); ?>>
				<ul class="bdt-slider-items bdt-child-width-1-1 bdt-grid bdt-grid-match" data-bdt-grid>
		<?php
	}

	public function render_footer( $settings, $wp_query ) {
		?>
				</ul>
				<?php $this->render_thumbnavs( $settings, $wp_query ); ?>
			</div>
		</div>
		<?php
	}

	public function render() {
		$settings = $this->parent->get_settings_for_display();
		$id       = $this->parent->get_id();
		$index    = 1;
		$per_page = isset( $settings['posts_per_page'] ) ? (int) $settings['posts_per_page'] : 4;
		$wp_query = $this->parent->render_query( $per_page );

		if ( ! $wp_query->found_posts ) {
			return;
		}

		$this->render_header( 'thumb', $id, $settings );

		$schema_on   = $settings['schema_rich_results'] === 'yes';
		$show_rating = $settings['rating'] === 'yes';
		$alignment   = $settings['alignment'] ?? 'center';
		$meta_pos    = $settings['meta_position'] ?? 'after';

		while ( $wp_query->have_posts() ) :
			$wp_query->the_post();
			$post_id  = get_the_ID();
			$platform = get_post_meta( $post_id, 'bdthemes_tm_platform', true );
			$platform = $platform !== '' ? strtolower( $platform ) : '';
			$item_key = 'slide-li-' . $post_id;
			$this->parent->add_render_attribute( $item_key, 'class', 'bdt-slider-item bdt-review-' . $platform );
			if ( $schema_on ) {
				$this->parent->add_render_attribute( $item_key, 'itemprop', 'review' );
				$this->parent->add_render_attribute( $item_key, 'itemscope', '' );
				$this->parent->add_render_attribute( $item_key, 'itemtype', 'https://schema.org/Review' );
			}
			?>
			<li <?php $this->parent->print_render_attribute_string( $item_key ); ?>>
				<?php $this->parent->render_schema_item_reviewed( $settings ); ?>
				<?php if ( $schema_on && ! $show_rating ) : ?>
					<?php $this->parent->render_rating_schema_only( $post_id, $settings ); ?>
				<?php endif; ?>
				<div class="bdt-slider-item-inner bdt-box-shadow-small bdt-padding">
					<?php if ( $meta_pos === 'after' ) : ?>
						<div class="bdt-testimonial-text bdt-text-<?php echo esc_attr( $alignment ); ?> bdt-padding-remove-vertical">
							<?php $this->parent->render_excerpt( $settings ); ?>
						</div>
					<?php endif; ?>
					<div class="bdt-flex bdt-flex-<?php echo esc_attr( $alignment ); ?> bdt-flex-middle">
						<?php $this->parent->render_meta( 'testmonial-meta-' . $index, $settings ); ?>
					</div>
					<?php if ( $meta_pos === 'before' ) : ?>
						<div class="bdt-testimonial-text bdt-text-<?php echo esc_attr( $alignment ); ?> bdt-padding-remove-vertical">
							<?php $this->parent->render_excerpt( $settings ); ?>
						</div>
					<?php endif; ?>
				</div>
			</li>
			<?php
			$index++;
		endwhile;

		wp_reset_postdata();
		$this->render_footer( $settings, $wp_query );
	}
}
