<?php

namespace ElementPack\Modules\WrapperLink;

use Elementor\Controls_Manager;
use Elementor\Modules\AtomicWidgets\Controls\Types\Link_Control;
use ElementPack\Base\Element_Pack_Module_Base;
use ElementPack\Modules\WrapperLink\Atomic\Wrapper_Link_Prop_Type;
use ElementPack\Modules\WrapperLink\Normalizers\Link_Settings_Normalizer;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

class Module extends Element_Pack_Module_Base {
	private const LEGACY_LINK_CONTROL_KEY = 'element_pack_wrapper_link';
	private const ATOMIC_LINK_PROP_KEY = 'element_pack_wrapper_link_url';
	private const WRAPPER_SECTION_KEY = 'section_element_pack_wrapper_link';
	private $link_settings_normalizer = null;

	// Elements whose markup we are buffering, keyed by spl_object_id, mapped to
	// their normalized link settings so after_render can inject the overlay.
	private $open_wrapper_links = [];

	public function __construct() {
		parent::__construct();
		$this->add_actions();
	}

	public function get_name() {
		return 'bdt-wrapper-link';
	}

	public function register_section( $element ) {

		if ( 'section' === $element->get_name() || 'column' === $element->get_name() || 'container' === $element->get_name() ) {
			$tabs = Controls_Manager::TAB_LAYOUT;
		} else {
			$tabs = Controls_Manager::TAB_CONTENT;
		}

		$element->start_controls_section(
			self::WRAPPER_SECTION_KEY,
			[ 
				'tab' => $tabs,
				'label' => BDTEP_CP . esc_html__( 'Wrapper Link', 'bdthemes-element-pack' ),
			]
		);

		$element->end_controls_section();
	}


	public function register_controls( $widget, $args ) {
		$this->register_legacy_controls( $widget );
	}

	private function register_legacy_controls( $widget ) {
		$widget->add_control(
			self::LEGACY_LINK_CONTROL_KEY,
			[ 
				'label' => esc_html__( 'Link', 'bdthemes-element-pack' ),
				'type' => Controls_Manager::URL,
				'placeholder' => 'https://example.com',
				'show_external' => true,
				'default' => [ 'url' => '' ],
				'dynamic' => [ 'active' => true ],
				'render_type' => 'none',
			]
		);
	}

	public function register_atomic_schema( $schema ) {
		if ( ! class_exists( '\Elementor\Modules\AtomicWidgets\PropTypes\Base\Object_Prop_Type' ) ) {
			return $schema;
		}

		if ( ! isset( $schema[ self::ATOMIC_LINK_PROP_KEY ] ) ) {
			$schema[ self::ATOMIC_LINK_PROP_KEY ] = Wrapper_Link_Prop_Type::make();
		}

		return $schema;
	}

	public function register_atomic_controls( $controls, $element ) {
		if ( ! class_exists( '\Elementor\Modules\AtomicWidgets\Controls\Types\Link_Control' ) ) {
			return $controls;
		}

		$schema = method_exists( $element, 'get_props_schema' ) ? $element::get_props_schema() : [];

		if ( ! isset( $schema[ self::ATOMIC_LINK_PROP_KEY ] ) ) {
			return $controls;
		}

		$section = \Elementor\Modules\AtomicWidgets\Controls\Section::make()
			->set_id( 'ep_section_wrapper_link' )
			->set_label( esc_html__( 'Wrapper Link', 'bdthemes-element-pack' ) )
			->set_items( [] );

		$controls[] = $section;

		$section->add_item(
			Link_Control::bind_to( self::ATOMIC_LINK_PROP_KEY )
				->set_placeholder( esc_html__( 'Type or paste a URL', 'bdthemes-element-pack' ) )
				->set_label( esc_html__( 'Wrapper Link', 'bdthemes-element-pack' ) )
				->set_description( esc_html__( 'If the URL is not a link, the link will be opened in a new tab.', 'bdthemes-element-pack' ) )
		);

		return $controls;
	}

	private function normalize_wrapper_link_settings( $widget ) {
		return $this->get_link_settings_normalizer()->normalize( $widget );
	}

	private function get_link_settings_normalizer() {
		if ( null === $this->link_settings_normalizer ) {
			$this->link_settings_normalizer = new Link_Settings_Normalizer();
		}

		return $this->link_settings_normalizer;
	}

	private function get_sanitized_wrapper_link_settings( $widget ) {
		$element_link = $this->normalize_wrapper_link_settings( $widget );

		if ( ! $element_link || empty( $element_link['url'] ) ) {
			return null;
		}

		$element_link['url'] = esc_url( $element_link['url'], [ 'http', 'https', 'tel', 'mailto', 'sms' ] );

		return $element_link;
	}

	/**
	 * Start buffering the element markup so we can inject a stretched-link anchor.
	 *
	 * Rather than wrapping the element in an <a> (which would nest interactive
	 * descendants inside an anchor and produce invalid HTML), we inject an empty,
	 * absolutely-positioned overlay anchor as the first child of the element and
	 * make the element itself the positioning context — the same "position cover"
	 * pattern already used across the plugin (e.g. `bdt-position-cover` in
	 * Post Grid, Advanced Image Gallery, Member). The anchor is a real crawlable
	 * `href`, so it still passes SEO link equity.
	 *
	 * `elementor/frontend/before_render` fires before the element prints anything,
	 * so opening a buffer here captures the full element markup, which
	 * wrapper_link_after_render() then rewrites.
	 */
	public function wrapper_link_before_render( $widget ) {
		// Don't touch the editor canvas — a live overlay anchor would intercept
		// element selection. The frontend and preview windows are unaffected.
		if ( function_exists( 'element_pack_is_edit' ) && element_pack_is_edit() ) {
			return;
		}

		$element_link = $this->get_sanitized_wrapper_link_settings( $widget );

		if ( ! $element_link ) {
			return;
		}

		// Stash the link and open a buffer; after_render does the injection.
		$this->open_wrapper_links[ spl_object_id( $widget ) ] = $element_link;

		ob_start();
	}

	/**
	 * Inject the overlay anchor into the buffered element markup and flush it.
	 */
	public function wrapper_link_after_render( $widget ) {
		$object_id = spl_object_id( $widget );

		if ( ! isset( $this->open_wrapper_links[ $object_id ] ) ) {
			return;
		}

		$element_link = $this->open_wrapper_links[ $object_id ];
		unset( $this->open_wrapper_links[ $object_id ] );

		$markup = ob_get_clean();

		if ( ! is_string( $markup ) || '' === $markup ) {
			echo $markup; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			return;
		}

		// Give the element a positioning context (unless it is already absolutely
		// or fixed positioned) and a hook class, then place the overlay anchor as
		// its first child so it stretches to cover the whole element.
		$needs_relative = ! $this->is_positioned_element( $widget );

		echo $this->inject_overlay_anchor( $markup, $element_link, $needs_relative ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Whether the element already establishes its own positioning context, so we
	 * must not override it with `position: relative`.
	 */
	private function is_positioned_element( $widget ) {
		if ( ! method_exists( $widget, 'get_settings_for_display' ) ) {
			return false;
		}

		$position = (string) $widget->get_settings_for_display( 'position' );

		return in_array( $position, [ 'absolute', 'fixed' ], true );
	}

	/**
	 * Add the hook class / positioning to the element's opening tag and insert the
	 * overlay anchor right after it. Uses WP_HTML_Tag_Processor for the attribute
	 * edits and a quote-aware regex to locate the insertion point.
	 */
	private function inject_overlay_anchor( $markup, array $element_link, $needs_relative ) {
		if ( class_exists( '\WP_HTML_Tag_Processor' ) ) {
			$processor = new \WP_HTML_Tag_Processor( $markup );

			if ( $processor->next_tag() ) {
				$processor->add_class( 'bdt-element-link' );

				if ( $needs_relative ) {
					$style = trim( (string) $processor->get_attribute( 'style' ) );

					if ( false === stripos( $style, 'position:' ) ) {
						$style = $style ? rtrim( $style, ';' ) . '; position: relative;' : 'position: relative;';
						$processor->set_attribute( 'style', $style );
					}
				}

				$markup = $processor->get_updated_html();
			}
		}

		$overlay = $this->build_overlay_anchor( $element_link );

		// Insert the overlay just after the first opening tag (quote-aware so a
		// `>` inside an attribute value doesn't end the tag prematurely).
		$tag_pattern = '/<[a-zA-Z][a-zA-Z0-9:_-]*(?:\s+[^\s"\'=<>`]+(?:\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s"\'=<>`]+))?)*\s*\/?>/';

		if ( preg_match( $tag_pattern, $markup, $matches, PREG_OFFSET_CAPTURE ) ) {
			$insert_at = $matches[0][1] + strlen( $matches[0][0] );

			return substr( $markup, 0, $insert_at ) . $overlay . substr( $markup, $insert_at );
		}

		// No opening tag found (element rendered nothing) — emit unchanged.
		return $markup;
	}

	/**
	 * Build the escaped, absolutely-positioned overlay <a> tag.
	 */
	private function build_overlay_anchor( array $element_link ) {
		// href was already run through esc_url() in get_sanitized_wrapper_link_settings().
		$html = '<a href="' . $element_link['url'] . '"';

		$attributes = [
			'class' => 'bdt-element-link-anchor bdt-position-cover',
			'style' => 'position:absolute;top:0;left:0;width:100%;height:100%;z-index:1;',
			'aria-label' => esc_html__( 'Visit link', 'bdthemes-element-pack' ),
		];

		if ( ! empty( $element_link['is_external'] ) ) {
			$attributes['target'] = '_blank';
		}

		$rel = [];

		if ( ! empty( $element_link['is_external'] ) ) {
			$rel[] = 'noopener';
			$rel[] = 'noreferrer';
		}

		if ( ! empty( $element_link['nofollow'] ) ) {
			$rel[] = 'nofollow';
		}

		if ( $rel ) {
			$attributes['rel'] = implode( ' ', array_unique( $rel ) );
		}

		// Optional custom attributes in Elementor's "key|value,key2|value2" form.
		if ( ! empty( $element_link['custom_attributes'] ) && is_string( $element_link['custom_attributes'] ) ) {
			foreach ( explode( ',', $element_link['custom_attributes'] ) as $attribute ) {
				$parts = explode( '|', $attribute, 2 );
				$key   = trim( $parts[0] );

				// Skip empties and never let a custom attribute override href/rel/etc.
				if ( '' === $key || 'href' === $key || isset( $attributes[ $key ] ) ) {
					continue;
				}

				$attributes[ $key ] = isset( $parts[1] ) ? trim( $parts[1] ) : '';
			}
		}

		foreach ( $attributes as $key => $value ) {
			$html .= sprintf( ' %s="%s"', esc_attr( $key ), esc_attr( $value ) );
		}

		return $html . '></a>';
	}

	public function maybe_register_atomic_hooks() {
		if ( ! class_exists( '\Elementor\Plugin' ) ) {
			return;
		}

		// Prevent duplicate callbacks if this method is called more than once.
		if ( has_filter( 'elementor/atomic-widgets/props-schema', [ $this, 'register_atomic_schema' ] ) ) {
			return;
		}

		add_filter( 'elementor/atomic-widgets/props-schema', [ $this, 'register_atomic_schema' ], 20 );
		add_filter( 'elementor/atomic-widgets/controls', [ $this, 'register_atomic_controls' ], 30, 2 );
	}

	protected function add_actions() {

		// Add container settings
		add_action( 'elementor/element/container/section_layout_container/after_section_end', [ $this, 'register_section' ] );
		add_action( 'elementor/element/container/' . self::WRAPPER_SECTION_KEY . '/before_section_end', [ $this, 'register_controls' ], 10, 2 );


		// Add section settings
		add_action( 'elementor/element/section/section_advanced/after_section_end', [ $this, 'register_section' ] );
		add_action( 'elementor/element/section/' . self::WRAPPER_SECTION_KEY . '/before_section_end', [ $this, 'register_controls' ], 10, 2 );

		// Add column settings
		add_action( 'elementor/element/column/section_advanced/after_section_end', [ $this, 'register_section' ] );
		add_action( 'elementor/element/column/' . self::WRAPPER_SECTION_KEY . '/before_section_end', [ $this, 'register_controls' ], 10, 2 );

		// Add widget settings
		add_action( 'elementor/element/common/_section_style/after_section_end', [ $this, 'register_section' ] );
		add_action( 'elementor/element/common/' . self::WRAPPER_SECTION_KEY . '/before_section_end', [ $this, 'register_controls' ], 10, 2 );


		// Inject an absolutely-positioned overlay <a> as the element's first child
		// (a "stretched link") instead of wrapping it, so interactive descendants
		// stay valid. before_render opens a buffer; after_render rewrites and
		// flushes it. Works for classic and atomic widgets alike since both route
		// through Element_Base::print_element(). Late priority on after_render so
		// our ob_get_clean() runs after other after_render output is captured.
		add_action( 'elementor/frontend/before_render', [ $this, 'wrapper_link_before_render' ], 10, 1 );
		add_action( 'elementor/frontend/after_render', [ $this, 'wrapper_link_after_render' ], 999, 1 );

		// Register now if Elementor is already initialized, otherwise wait.
		if ( did_action( 'elementor/init' ) ) {
			$this->maybe_register_atomic_hooks();
		} else {
			add_action( 'elementor/init', [ $this, 'maybe_register_atomic_hooks' ] );
		}
	}
}
