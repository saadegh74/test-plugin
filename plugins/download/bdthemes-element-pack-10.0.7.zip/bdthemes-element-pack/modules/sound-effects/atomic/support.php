<?php

namespace ElementPack\Modules\SoundEffects\Atomic;

use Elementor\Modules\AtomicWidgets\PropDependencies\Manager as Dependency_Manager;
use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Select_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Switch_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Text_Control;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Support {
	public const SECTION_ID = 'section_element_pack_sound_effects_controls';
	public const ACTIVE_KEY = 'ep_sound_effects_active';
	public const SELECT_TYPE_KEY = 'ep_sound_effects_select_type';
	public const ELEMENT_SELECTOR_KEY = 'ep_sound_effects_element_selector';
	public const EVENT_KEY = 'ep_sound_effects_event';
	public const SOURCE_KEY = 'ep_sound_effects_source';
	public const SOURCE_LOCAL_LINK_KEY = 'ep_sound_effects_source_local_link';
	public const HOSTED_URL_KEY = 'ep_sound_effects_hosted_url';
	public const HOSTED_URL_MP3_KEY = 'ep_sound_effects_hosted_url_mp3';

	public function register_schema( array $schema ): array {
		$active_dependencies = $this->get_active_dependencies();
		$custom_selector_dependencies = $this->get_custom_selector_dependencies();
		$hosted_url_dependencies = $this->get_hosted_url_dependencies();

		$schema[ self::ACTIVE_KEY ] = $schema[ self::ACTIVE_KEY ] ?? Boolean_Prop_Type::make()->default( false );
		$schema[ self::SELECT_TYPE_KEY ] = $schema[ self::SELECT_TYPE_KEY ] ?? String_Prop_Type::make()
			->default( 'widget' )
			->set_dependencies( $active_dependencies );
		$schema[ self::ELEMENT_SELECTOR_KEY ] = $schema[ self::ELEMENT_SELECTOR_KEY ] ?? String_Prop_Type::make()
			->default( '' )
			->set_dependencies( $custom_selector_dependencies );
		$schema[ self::EVENT_KEY ] = $schema[ self::EVENT_KEY ] ?? String_Prop_Type::make()
			->default( 'click' )
			->set_dependencies( $active_dependencies );
		$schema[ self::SOURCE_KEY ] = $schema[ self::SOURCE_KEY ] ?? String_Prop_Type::make()
			->default( 'bubble' )
			->set_dependencies( $active_dependencies );
		$schema[ self::SOURCE_LOCAL_LINK_KEY ] = $schema[ self::SOURCE_LOCAL_LINK_KEY ] ?? String_Prop_Type::make()
			->default( BDTEP_ASSETS_URL . 'sounds/' );
		$schema[ self::HOSTED_URL_KEY ] = $schema[ self::HOSTED_URL_KEY ] ?? String_Prop_Type::make()
			->default( '' )
			->set_dependencies( $hosted_url_dependencies );
		$schema[ self::HOSTED_URL_MP3_KEY ] = $schema[ self::HOSTED_URL_MP3_KEY ] ?? String_Prop_Type::make()
			->default( '' )
			->set_dependencies( $hosted_url_dependencies );

		return $schema;
	}

	public function register_controls( array $controls ): array {
		$item = Section::make()
			->set_id( 'ep_section_sound_effects' )
			->set_label( esc_html__( 'Sound Effects', 'bdthemes-element-pack' ) )
			->set_items( [] );

		$controls[] = $item;

			$item->add_item(
				Switch_Control::bind_to( self::ACTIVE_KEY )
					->set_label( esc_html__( 'Sound Effects', 'bdthemes-element-pack' ) )
			);

			$item->add_item(
				Select_Control::bind_to( self::SELECT_TYPE_KEY )
					->set_label( esc_html__( 'Element Type', 'bdthemes-element-pack' ) )
					->set_options( [
						[ 'value' => 'widget', 'label' => esc_html__( 'Widget', 'bdthemes-element-pack' ) ],
						[ 'value' => 'anchor_tag', 'label' => esc_html__( 'Widget / Inner Anchor Tags', 'bdthemes-element-pack' ) ],
						[ 'value' => 'custom', 'label' => esc_html__( 'Widget / Custom Selector', 'bdthemes-element-pack' ) ],
					] )
			);

			$item->add_item(
				Text_Control::bind_to( self::ELEMENT_SELECTOR_KEY )
					->set_label( esc_html__( 'Element Selector', 'bdthemes-element-pack' ) )
			);

			$item->add_item(
				Select_Control::bind_to( self::EVENT_KEY )
					->set_label( esc_html__( 'Event', 'bdthemes-element-pack' ) )
					->set_options( [
						[ 'value' => 'hover', 'label' => esc_html__( 'Hover', 'bdthemes-element-pack' ) ],
						[ 'value' => 'click', 'label' => esc_html__( 'Click', 'bdthemes-element-pack' ) ],
					] )
			);

			$item->add_item(
				Select_Control::bind_to( self::SOURCE_KEY )
					->set_label( esc_html__( 'Source', 'bdthemes-element-pack' ) )
					->set_options( [
						[ 'value' => 'bubble', 'label' => esc_html__( 'Bubble', 'bdthemes-element-pack' ) ],
						[ 'value' => 'button-click', 'label' => esc_html__( 'Button Click', 'bdthemes-element-pack' ) ],
						[ 'value' => 'mouse-click', 'label' => esc_html__( 'Mouse Click', 'bdthemes-element-pack' ) ],
						[ 'value' => 'mountain', 'label' => esc_html__( 'Bell Ring', 'bdthemes-element-pack' ) ],
						[ 'value' => 'hosted_url', 'label' => esc_html__( 'Local Audio (.ogg only)', 'bdthemes-element-pack' ) ],
					] )
			);

			$item->add_item(
				Text_Control::bind_to( self::HOSTED_URL_KEY )
					->set_label( esc_html__( 'Local Audio', 'bdthemes-element-pack' ) )
			);

			$item->add_item(
				Text_Control::bind_to( self::HOSTED_URL_MP3_KEY )
					->set_label( esc_html__( 'Local Audio MP3 (Fallback)', 'bdthemes-element-pack' ) )
			);

		return $controls;
	}

	private function get_active_dependencies(): ?array {
		return Dependency_Manager::make( Dependency_Manager::RELATION_AND )
			->where(
				[
					'operator' => 'eq',
					'path' => [ self::ACTIVE_KEY ],
					'value' => true,
					'effect' => 'hide',
				]
			)
			->get();
	}

	private function get_custom_selector_dependencies(): ?array {
		return Dependency_Manager::make( Dependency_Manager::RELATION_AND )
			->where(
				[
					'operator' => 'eq',
					'path' => [ self::ACTIVE_KEY ],
					'value' => true,
					'effect' => 'hide',
				]
			)
			->where(
				[
					'operator' => 'eq',
					'path' => [ self::SELECT_TYPE_KEY ],
					'value' => 'custom',
					'effect' => 'hide',
				]
			)
			->get();
	}

	private function get_hosted_url_dependencies(): ?array {
		return Dependency_Manager::make( Dependency_Manager::RELATION_AND )
			->where(
				[
					'operator' => 'eq',
					'path' => [ self::ACTIVE_KEY ],
					'value' => true,
					'effect' => 'hide',
				]
			)
			->where(
				[
					'operator' => 'eq',
					'path' => [ self::SOURCE_KEY ],
					'value' => 'hosted_url',
					'effect' => 'hide',
				]
			)
			->get();
	}
}
