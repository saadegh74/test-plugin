<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

return [
	'title'              => esc_html__( 'AdBlock Detector', 'bdthemes-element-pack' ),
	'required'           => true,
	'default_activation' => true,
	// No has_style/has_script: there is no ep-adblock-detector build output. The
	// module enqueues its vendor files itself; flagging them here made the Manager
	// register the handle first against a missing file, so the vendor src was ignored.
];
