<?php

namespace ElementPack\Modules\EventsCalendarList\Widgets;

use ElementPack\Base\Module_Base;
use ElementPack\Traits\Global_Controls_Functions;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Events_Calendar_List extends Module_Base {
	use Global_Controls_Functions;

	public $_query = null;

	public function get_name() {
		return 'bdt-event-list';
	}

	public function get_title() {
		return BDTEP . __( 'Events Calendar List', 'bdthemes-element-pack' );
	}

	public function get_icon() {
		return 'bdt-wi-events-calendar-list';
	}

	public function get_categories() {
		return [ 'element-pack' ];
	}

	public function get_keywords() {
		return [ 'events', 'the', 'calendar', 'list', 'grid' ];
	}

	public function get_style_depends() {
		if ( $this->ep_is_edit_mode() ) {
			return [ 'ep-styles' ];
		}
		return [ 'ep-events-calendar-list', 'ep-font' ];
	}

	public function get_custom_help_url() {
		return 'https://youtu.be/2J4XhOe8J0o';
	}

	public function on_import( $element ) {
		if ( ! get_post_type_object( $element['settings']['posts_post_type'] ) ) {
			$element['settings']['posts_post_type'] = 'post';
		}
		return $element;
	}

	public function get_query() {
		return $this->_query;
	}

	public function has_widget_inner_wrapper(): bool {
		return ! \Elementor\Plugin::$instance->experiments->is_feature_active( 'e_optimized_markup' );
	}

	public function register_controls() {
		$this->register_events_calendar_layout_controls( 'list' );
		$this->register_events_calendar_image_controls( 'list' );
		$this->register_events_calendar_query_controls( 'list' );
		$this->register_events_calendar_style_item_controls( 'list' );
		$this->register_events_calendar_style_image_controls( 'list' );
		$this->register_events_calendar_style_title_controls( 'list' );
		$this->register_events_calendar_style_date_controls( 'list' );
		$this->register_events_calendar_style_excerpt_controls( 'list' );
		$this->register_events_calendar_style_meta_controls( 'list' );
		$this->register_events_calendar_style_address_controls( 'list' );
	}

	public function render() {
		$this->render_events_calendar_list();
	}

	public function render_image() {
		$this->render_events_calendar_image();
	}

	public function render_title() {
		$this->render_events_calendar_title();
	}

	public function render_date() {
		$this->render_events_calendar_date( 'list' );
	}

	public function render_excerpt( $post ) {
		$this->render_events_calendar_excerpt( $post );
	}

	public function render_meta() {
		$this->render_events_calendar_meta( 'list' );
	}

	public function render_header() {
		$this->render_events_calendar_list_header();
	}

	public function render_footer() {
		$this->render_events_calendar_list_footer();
	}

	public function render_loop_item( $post ) {
		$this->render_events_calendar_list_loop_item( $post );
	}
}
