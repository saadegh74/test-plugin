<?php
if (!defined('ABSPATH')) exit; // Exit if accessed directly

return [
	'title'				 => esc_html__('Events Calendar List', 'bdthemes-element-pack'),
	'required'			 => true,
	'default_activation' => true,
	'has_style'			 => true,
	'widget_names'       => [ 'bdt-event-list' ],
];
