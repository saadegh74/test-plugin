<?php

namespace ElementPack\Modules\LearnPressGrid\Widgets;

use ElementPack\Base\Module_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Background;

use ElementPack\Traits\Global_Widget_Controls;
use ElementPack\Traits\Global_Controls_Functions;
use ElementPack\Includes\Controls\GroupQuery\Group_Control_Query;
use ElementPack\Utils;
use WP_Query;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Learnpress_Grid extends Module_Base {
	use Global_Widget_Controls;
	use Global_Controls_Functions;
	use Group_Control_Query;

	/** @var \WP_Query */
	private $_query = null;

	public function get_name() {
		return 'bdt-learnpress-grid';
	}

	public function get_title() {
		return esc_html__( 'LearnPress Grid', 'bdthemes-element-pack' );
	}

	public function get_icon() {
		return 'bdt-wi-learnpress-grid bdt-new';
	}

	public function get_categories() {
		return [ 'element-pack' ];
	}

	public function get_keywords() {
		return [ 'learnpress', 'lms', 'course', 'learning', 'management', 'grid' ];
	}

	public function get_style_depends() {
		if ( $this->ep_is_edit_mode() ) {
			return [ 'ep-styles' ];
		}
		return [ 'ep-font', 'ep-learnpress-grid' ];
	}

	public function get_query() {
		return $this->_query;
	}

	public function has_widget_inner_wrapper(): bool {
		return ! \Elementor\Plugin::$instance->experiments->is_feature_active( 'e_optimized_markup' );
	}

	protected function register_controls() {
		$this->render_controls_layout();
		$this->render_controls_query();
		$this->render_controls_filter();
		$this->render_controls_additional();
		$this->render_style_controls_item();
		$this->render_style_controls_category();
		$this->render_style_controls_title();
		$this->render_style_controls_instructor();
		$this->render_style_controls_meta();
		$this->render_style_controls_price();
		$this->register_style_controls_filter();
		$this->render_style_controls_pagination();
	}

	public function render_controls_layout() {
	    $this->start_controls_section(
	        'section_woocommerce_layout',
	        [
	            'label' => esc_html__('Layout', 'bdthemes-element-pack'),
	        ]
	    );
	    $this->add_control(
	        'layout_type',
	        [
	            'label'          => esc_html__('Layout Type', 'bdthemes-element-pack'),
	            'type'           => Controls_Manager::SELECT,
	            'default'        => 'grid',
	            'options'        => [
	                'grid' => esc_html__('Grid', 'bdthemes-element-pack'),
	                'list' => esc_html__('List', 'bdthemes-element-pack'),
	            ]
	        ]
	    );

	    $this->add_responsive_control(
	        'columns',
	        [
	            'label'          => esc_html__('Columns', 'bdthemes-element-pack'),
	            'type'           => Controls_Manager::SELECT,
	            'default'        => '3',
	            'tablet_default' => '2',
	            'mobile_default' => '1',
	            'options'        => [
	                '1' => '1',
	                '2' => '2',
	                '3' => '3',
	                '4' => '4',
	                '5' => '5',
	                '6' => '6',
	            ],
	            'selectors' => [
	                '{{WRAPPER}} .ep-learnpress-lms-wrap' => 'grid-template-columns: repeat({{VALUE}}, 1fr)'
	            ]
	        ]
	    );

	    $this->add_responsive_control(
	        'items_columns_gap',
	        [
	            'label'     => esc_html__('Columns Gap', 'bdthemes-element-pack'),
	            'type'      => Controls_Manager::SLIDER,
	            'default'   => [
	                'size' => 30,
	            ],
	            'selectors' => [
	                '{{WRAPPER}} .ep-learnpress-lms-wrap' => 'grid-column-gap: {{SIZE}}px;',
	            ],
	        ]
	    );

	    $this->add_responsive_control(
	        'items_row_gap',
	        [
	            'label'     => esc_html__('Row Gap', 'bdthemes-element-pack'),
	            'type'      => Controls_Manager::SLIDER,
	            'default'   => [
	                'size' => 30,
	            ],
	            'selectors' => [
	                '{{WRAPPER}} .ep-learnpress-lms-wrap' => 'grid-row-gap: {{SIZE}}px;',
	            ],
	        ]
	    );
	    		$this->register_learnpress_alignment_control( 'grid' );

				$this->register_learnpress_image_size_control();

		$this->add_control(
	        'show_pagination',
	        [
	            'label'     => esc_html__('Pagination', 'bdthemes-element-pack'),
	            'type'      => Controls_Manager::SWITCHER,
	        ]
	    );
	    $this->end_controls_section();
	}

	public function render_controls_query() {
		$this->register_learnpress_query_controls();
	}

	public function render_controls_filter() {
		$this->register_learnpress_filter_controls();
	}

	public function render_controls_additional() {
		$this->register_learnpress_additional_controls( [ 'section_id' => 'section_edd_additional' ] );
	}

	public function render_style_controls_item() {
		$this->register_learnpress_style_item_controls( 'grid' );
	}

	public function render_style_controls_category() {
		$this->register_learnpress_style_category_controls( 'grid' );
	}

	public function render_style_controls_title() {
		$this->register_learnpress_style_title_controls( 'grid' );
	}

	public function render_style_controls_instructor() {
		$this->register_learnpress_style_instructor_controls( 'grid' );
	}

	public function render_style_controls_meta() {
		$this->register_learnpress_style_meta_controls( 'grid' );
	}

	public function render_style_controls_price() {
		$this->register_learnpress_style_price_controls( 'grid' );
	}

	public function render_style_controls_pagination() {
		$this->register_learnpress_style_pagination_controls();
	}

	public function render_header() {
	    $settings = $this->get_settings_for_display();
	    $this->add_render_attribute(
	        'learnpress-grid',
	        'class',
	        [
	            'ep-learnpress-grid',
	            'ep-edd-content-position-' . (isset($settings['alignment']) ? $settings['alignment'] : 'left')
	        ],
	        true
	    );

	    if ($settings['show_filter_bar']) {
	        $this->add_render_attribute('learnpress-grid', 'data-bdt-filter', 'target: #ep-learnpress-grid-' . $this->get_id());
	    } ?>

	    <div <?php $this->print_render_attribute_string('learnpress-grid'); ?>>
	        <?php if ($settings['show_filter_bar']) {
	            $this->render_filter_menu();
	        }
	    }

	public function render_filter_menu() {
		$this->render_learnpress_filter_menu();
	}

	public function render_footer() { ?>
	    </div>
	    <?php
	    }

	public function render() {
	        $this->render_header();
	        $this->render_loop_item();
	        $this->render_footer();
	    }

	public function render_loop_item() {
		$settings = $this->get_settings_for_display();
		$this->query_product();
		$this->render_learnpress_grid_loop( $settings );
	}
}
