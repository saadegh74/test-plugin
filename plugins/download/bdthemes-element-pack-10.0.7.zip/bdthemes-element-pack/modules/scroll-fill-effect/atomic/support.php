<?php

namespace ElementPack\Modules\ScrollFillEffect\Atomic;

use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Number_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Select_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Switch_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Text_Control;
use Elementor\Modules\AtomicWidgets\PropDependencies\Manager as Dependency_Manager;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Number_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Union_Prop_Type;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Support {
	public const ACTIVE_KEY = 'ep_widget_sf_fx_enable';
	public const ANIMATION_TYPE_KEY = 'ep_widget_sf_fx_animation_type';
	public const BASE_COLOR_KEY = 'ep_widget_sf_fx_base_color';
	public const FILL_BG_KEY = 'ep_widget_sf_fx_fill_bg';
	public const FILL_BG_START_COLOR_KEY = 'ep_widget_sf_fx_fill_bg_start_color';
	public const FILL_BG_END_COLOR_KEY = 'ep_widget_sf_fx_fill_bg_end_color';
	public const FILL_BG_ANGLE_KEY = 'ep_widget_sf_fx_fill_bg_angle';
	public const SG_START_SCALE_KEY = 'ep_widget_sf_fx_sg_start_scale';
	public const SG_END_SCALE_KEY = 'ep_widget_sf_fx_sg_end_scale';
	public const SG_START_OPACITY_KEY = 'ep_widget_sf_fx_sg_start_opacity';
	public const SG_END_OPACITY_KEY = 'ep_widget_sf_fx_sg_end_opacity';
	public const SG_START_COLOR_KEY = 'ep_widget_sf_fx_sg_start_color';
	public const SG_END_COLOR_KEY = 'ep_widget_sf_fx_sg_end_color';
	public const SG_STAGGER_KEY = 'ep_widget_sf_fx_sg_stagger';
	public const SG_DURATION_KEY = 'ep_widget_sf_fx_sg_duration';
	public const SG_START_TRIGGER_KEY = 'ep_widget_sf_fx_sg_start_trigger';
	public const SG_END_TRIGGER_KEY = 'ep_widget_sf_fx_sg_end_trigger';
	public const RGM_MASK_COLOR_KEY = 'ep_widget_sf_fx_rgm_mask_color';
	public const RGM_X_PERCENT_KEY = 'ep_widget_sf_fx_rgm_x_percent';
	public const RGM_START_TRIGGER_KEY = 'ep_widget_sf_fx_rgm_start_trigger';
	public const RGM_END_TRIGGER_KEY = 'ep_widget_sf_fx_rgm_end_trigger';

	public function register_schema( array $schema ): array {
		$active_dependencies = $this->get_active_dependencies();
		$scroll_fill_dependencies = $this->get_animation_dependencies( 'scroll_fill' );
		$scaling_dependencies = $this->get_animation_dependencies( 'scaling_gradient_text' );
		$reveal_dependencies = $this->get_animation_dependencies( 'reveal_gradient_mask' );

		$schema[ self::ACTIVE_KEY ] = $schema[ self::ACTIVE_KEY ] ?? Boolean_Prop_Type::make()->default( false );
		$schema[ self::ANIMATION_TYPE_KEY ] = $schema[ self::ANIMATION_TYPE_KEY ] ?? String_Prop_Type::make()
			->default( 'scroll_fill' )
			->set_dependencies( $active_dependencies );
		$schema[ self::BASE_COLOR_KEY ] = $schema[ self::BASE_COLOR_KEY ] ?? String_Prop_Type::make()
			->default( 'rgba(156, 156, 156, 0.5)' )
			->set_dependencies( $scroll_fill_dependencies );
		$schema[ self::FILL_BG_KEY ] = $schema[ self::FILL_BG_KEY ] ?? String_Prop_Type::make()
			->default( '' )
			->set_dependencies( $scroll_fill_dependencies );
		$schema[ self::FILL_BG_START_COLOR_KEY ] = $schema[ self::FILL_BG_START_COLOR_KEY ] ?? String_Prop_Type::make()
			->default( '#08aeec' )
			->set_dependencies( $scroll_fill_dependencies );
		$schema[ self::FILL_BG_END_COLOR_KEY ] = $schema[ self::FILL_BG_END_COLOR_KEY ] ?? String_Prop_Type::make()
			->default( '#2af598' )
			->set_dependencies( $scroll_fill_dependencies );
		$schema[ self::FILL_BG_ANGLE_KEY ] = $schema[ self::FILL_BG_ANGLE_KEY ] ?? $this->number_schema( 90, $scroll_fill_dependencies, false );
		$schema[ self::SG_START_SCALE_KEY ] = $schema[ self::SG_START_SCALE_KEY ] ?? $this->number_schema( 2, $scaling_dependencies );
		$schema[ self::SG_END_SCALE_KEY ] = $schema[ self::SG_END_SCALE_KEY ] ?? $this->number_schema( 1, $scaling_dependencies );
		$schema[ self::SG_START_OPACITY_KEY ] = $schema[ self::SG_START_OPACITY_KEY ] ?? $this->number_schema( 0, $scaling_dependencies );
		$schema[ self::SG_END_OPACITY_KEY ] = $schema[ self::SG_END_OPACITY_KEY ] ?? $this->number_schema( 1, $scaling_dependencies );
		$schema[ self::SG_START_COLOR_KEY ] = $schema[ self::SG_START_COLOR_KEY ] ?? String_Prop_Type::make()
			->default( '#00e239' )
			->set_dependencies( $scaling_dependencies );
		$schema[ self::SG_END_COLOR_KEY ] = $schema[ self::SG_END_COLOR_KEY ] ?? String_Prop_Type::make()
			->default( '#ffffff' )
			->set_dependencies( $scaling_dependencies );
		$schema[ self::SG_STAGGER_KEY ] = $schema[ self::SG_STAGGER_KEY ] ?? $this->number_schema( 0.1, $scaling_dependencies );
		$schema[ self::SG_DURATION_KEY ] = $schema[ self::SG_DURATION_KEY ] ?? $this->number_schema( 1.5, $scaling_dependencies );
		$schema[ self::SG_START_TRIGGER_KEY ] = $schema[ self::SG_START_TRIGGER_KEY ] ?? String_Prop_Type::make()
			->default( 'top 80%' )
			->set_dependencies( $scaling_dependencies );
		$schema[ self::SG_END_TRIGGER_KEY ] = $schema[ self::SG_END_TRIGGER_KEY ] ?? String_Prop_Type::make()
			->default( 'top 30%' )
			->set_dependencies( $scaling_dependencies );
		$schema[ self::RGM_MASK_COLOR_KEY ] = $schema[ self::RGM_MASK_COLOR_KEY ] ?? String_Prop_Type::make()
			->default( '#000000' )
			->set_dependencies( $reveal_dependencies );
		$schema[ self::RGM_X_PERCENT_KEY ] = $schema[ self::RGM_X_PERCENT_KEY ] ?? $this->number_schema( -100, $reveal_dependencies );
		$schema[ self::RGM_START_TRIGGER_KEY ] = $schema[ self::RGM_START_TRIGGER_KEY ] ?? String_Prop_Type::make()
			->default( 'top 80%' )
			->set_dependencies( $reveal_dependencies );
		$schema[ self::RGM_END_TRIGGER_KEY ] = $schema[ self::RGM_END_TRIGGER_KEY ] ?? String_Prop_Type::make()
			->default( 'top 20%' )
			->set_dependencies( $reveal_dependencies );

		return $schema;
	}

	private function number_schema( $default, ?array $dependencies, bool $float = true ): Union_Prop_Type {
		$number_schema = Number_Prop_Type::make();

		if ( $float ) {
			$number_schema->float();
		}

		return Union_Prop_Type::make()
			->add_prop_type( $number_schema )
			->add_prop_type( String_Prop_Type::make() )
			->default( $default, 'number' )
			->set_dependencies( $dependencies );
	}

	public function register_controls( array $controls ): array {
		$item = Section::make()
			->set_id( 'ep_section_scroll_fill_effect' )
			->set_label( esc_html__( 'Scroll Fill Effect', 'bdthemes-element-pack' ) )
			->set_items( [] );

		$controls[] = $item;

			$item->add_item(
				Switch_Control::bind_to( self::ACTIVE_KEY )
					->set_label( esc_html__( 'Use Scroll Fill Effect?', 'bdthemes-element-pack' ) )
			);

			$item->add_item(
				Select_Control::bind_to( self::ANIMATION_TYPE_KEY )
					->set_label( esc_html__( 'Animation Type', 'bdthemes-element-pack' ) )
					->set_options( [
						[ 'value' => 'scroll_fill', 'label' => esc_html__( 'Scroll Fill', 'bdthemes-element-pack' ) ],
						[ 'value' => 'scaling_gradient_text', 'label' => esc_html__( 'Scaling Gradient Text', 'bdthemes-element-pack' ) ],
						[ 'value' => 'reveal_gradient_mask', 'label' => esc_html__( 'Gradient Text Reveal', 'bdthemes-element-pack' ) ],
					] )
			);

			$item->add_item(
				Text_Control::bind_to( self::BASE_COLOR_KEY )
					->set_label( esc_html__( 'Base Color', 'bdthemes-element-pack' ) )
			);

			$item->add_item(
				Text_Control::bind_to( self::FILL_BG_START_COLOR_KEY )
					->set_label( esc_html__( 'Fill Start Color', 'bdthemes-element-pack' ) )
					->set_placeholder( '#08aeec' )
			);

			$item->add_item(
				Text_Control::bind_to( self::FILL_BG_END_COLOR_KEY )
					->set_label( esc_html__( 'Fill End Color', 'bdthemes-element-pack' ) )
					->set_placeholder( '#2af598' )
			);

			$item->add_item(
				Number_Control::bind_to( self::FILL_BG_ANGLE_KEY )
					->set_label( esc_html__( 'Fill Angle', 'bdthemes-element-pack' ) )
					->set_min( 0 )
					->set_max( 360 )
					->set_step( 1 )
			);

			$item->add_item(
				Number_Control::bind_to( self::SG_START_SCALE_KEY )
					->set_label( esc_html__( 'Start Scale', 'bdthemes-element-pack' ) )
			);

			$item->add_item(
				Number_Control::bind_to( self::SG_END_SCALE_KEY )
					->set_label( esc_html__( 'End Scale', 'bdthemes-element-pack' ) )
			);

			$item->add_item(
				Number_Control::bind_to( self::SG_START_OPACITY_KEY )
					->set_label( esc_html__( 'Start Opacity', 'bdthemes-element-pack' ) )
			);

			$item->add_item(
				Number_Control::bind_to( self::SG_END_OPACITY_KEY )
					->set_label( esc_html__( 'End Opacity', 'bdthemes-element-pack' ) )
			);

			$item->add_item(
				Text_Control::bind_to( self::SG_START_COLOR_KEY )
					->set_label( esc_html__( 'Start Color', 'bdthemes-element-pack' ) )
			);

			$item->add_item(
				Text_Control::bind_to( self::SG_END_COLOR_KEY )
					->set_label( esc_html__( 'End Color', 'bdthemes-element-pack' ) )
			);

			$item->add_item(
				Number_Control::bind_to( self::SG_STAGGER_KEY )
					->set_label( esc_html__( 'Stagger Delay', 'bdthemes-element-pack' ) )
			);

			$item->add_item(
				Number_Control::bind_to( self::SG_DURATION_KEY )
					->set_label( esc_html__( 'Animation Duration', 'bdthemes-element-pack' ) )
			);

			$item->add_item(
				Text_Control::bind_to( self::SG_START_TRIGGER_KEY )
					->set_label( esc_html__( 'Start Trigger', 'bdthemes-element-pack' ) )
			);

			$item->add_item(
				Text_Control::bind_to( self::SG_END_TRIGGER_KEY )
					->set_label( esc_html__( 'End Trigger', 'bdthemes-element-pack' ) )
			);

			$item->add_item(
				Text_Control::bind_to( self::RGM_MASK_COLOR_KEY )
					->set_label( esc_html__( 'Mask Color', 'bdthemes-element-pack' ) )
			);

			$item->add_item(
				Number_Control::bind_to( self::RGM_X_PERCENT_KEY )
					->set_label( esc_html__( 'Reveal Distance (%)', 'bdthemes-element-pack' ) )
			);

			$item->add_item(
				Text_Control::bind_to( self::RGM_START_TRIGGER_KEY )
					->set_label( esc_html__( 'Start Trigger', 'bdthemes-element-pack' ) )
			);

			$item->add_item(
				Text_Control::bind_to( self::RGM_END_TRIGGER_KEY )
					->set_label( esc_html__( 'End Trigger', 'bdthemes-element-pack' ) )
			);

		return $controls;
	}

	private function get_active_dependencies(): ?array {
		return Dependency_Manager::make( Dependency_Manager::RELATION_AND )
			->where(
				[
					'operator' => 'eq',
					'path' => [ self::ACTIVE_KEY ],
					'value' => true,
					'effect' => 'hide',
				]
			)
			->get();
	}

	private function get_animation_dependencies( string $animation_type ): ?array {
		return Dependency_Manager::make( Dependency_Manager::RELATION_AND )
			->where(
				[
					'operator' => 'eq',
					'path' => [ self::ACTIVE_KEY ],
					'value' => true,
					'effect' => 'hide',
				]
			)
			->where(
				[
					'operator' => 'eq',
					'path' => [ self::ANIMATION_TYPE_KEY ],
					'value' => $animation_type,
					'effect' => 'hide',
				]
			)
			->get();
	}
}
