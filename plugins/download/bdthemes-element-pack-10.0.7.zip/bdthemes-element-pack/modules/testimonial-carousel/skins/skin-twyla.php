<?php

namespace ElementPack\Modules\TestimonialCarousel\Skins;

use Elementor\Skin_Base as Elementor_Skin_Base;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

class Skin_Twyla extends Elementor_Skin_Base {
	public function get_id() {
		return 'bdt-twyla';
	}

	public function get_title() {
		return __('Twyla', 'bdthemes-element-pack');
	}

	public function render() {
		$settings = $this->parent->get_settings();
		
		$wp_query = $this->parent->render_query( $settings['posts_per_page'] );

		if ($wp_query->have_posts()) : ?>

			<?php $this->parent->render_header( 'twyla', $settings ); ?>

			<?php while ($wp_query->have_posts()) : $wp_query->the_post(); 
			$platform = get_post_meta(get_the_ID(), 'bdthemes_tm_platform', true);
			?>
				<div class="swiper-slide bdt-testimonial-carousel-item bdt-review-<?php echo esc_attr(strtolower($platform)); ?>" itemprop="review" itemscope itemtype="https://schema.org/Review">
					<?php $this->parent->render_schema_item_reviewed( $settings ); ?>
					<?php if ( ! empty( $settings['schema_rich_results'] ) && 'yes' === $settings['schema_rich_results'] && ( empty( $settings['show_rating'] ) || 'yes' !== $settings['show_rating'] ) ) : ?>
						<?php $this->parent->render_rating_schema_only( get_the_ID(), $settings ); ?>
					<?php endif; ?>
					<div class="bdt-testimonial-carousel-item-wrapper">
						<div class="testimonial-item-header">
							<?php $this->parent->render_image( get_the_ID(), $settings ); ?>
						</div>

						<div class="bdt-twyla-content-wrap">
							<?php
							$this->parent->render_excerpt( $settings ); ?>
							<div class="bdt-testimonial-meta <?php echo ($settings['meta_multi_line']) ? '' : 'bdt-meta-multi-line'; ?>">
								<?php
								$this->parent->render_title( get_the_ID(), $settings );
								$this->parent->render_designation( get_the_ID(), $settings );
								$this->parent->render_address( get_the_ID(), $settings ); ?>
							</div>
							<?php
							if (($settings['show_rating']) && ($settings['show_text'])) : ?>
								<div class="bdt-testimonial-carousel-rating bdt-display-inline-block">
									<?php $this->parent->render_rating( get_the_ID(), $settings ); ?>
								</div>
							<?php endif; ?>
						</div>

					</div>
				</div>
			<?php endwhile;
			wp_reset_postdata(); ?>

<?php $this->parent->render_footer();

		endif;
	}
}
