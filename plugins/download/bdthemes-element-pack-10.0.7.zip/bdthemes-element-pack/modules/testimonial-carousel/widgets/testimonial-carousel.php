<?php

namespace ElementPack\Modules\TestimonialCarousel\Widgets;

use ElementPack\Base\Module_Base;
use ElementPack\Includes\Controls\GroupQuery\Group_Control_Query;
use ElementPack\Modules\TestimonialCarousel\Skins;
use ElementPack\Traits\Global_Controls_Functions;
use ElementPack\Traits\Global_Swiper_Controls;
use ElementPack\Traits\Global_Widget_Controls;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Testimonial_Carousel extends Module_Base {
	use Group_Control_Query;
	use Global_Widget_Controls;
	use Global_Swiper_Controls;
	use Global_Controls_Functions;

	private $_query = null;

	public function get_name() {
		return 'bdt-testimonial-carousel';
	}

	public function get_title() {
		return BDTEP . esc_html__( 'Testimonial Carousel', 'bdthemes-element-pack' );
	}

	public function get_icon() {
		return 'bdt-wi-testimonial-carousel';
	}

	public function get_categories() {
		return [ 'element-pack' ];
	}

	public function get_keywords() {
		return [ 'testimonial', 'carousel' ];
	}

	public function get_style_depends() {
		return $this->ep_is_edit_mode() ? [ 'swiper', 'ep-styles' ] : [ 'swiper', 'ep-font', 'ep-testimonial-carousel' ];
	}

	public function get_script_depends() {
		return $this->ep_is_edit_mode() ? [ 'swiper', 'ep-scripts' ] : [ 'swiper', 'ep-testimonial-carousel', 'ep-text-read-more-toggle' ];
	}

	public function get_custom_help_url() {
		return 'https://youtu.be/VbojVJzayvE';
	}

	public function get_query() {
		return $this->_query;
	}

	protected function register_skins() {
		$this->add_skin( new Skins\Skin_Twyla( $this ) );
		$this->add_skin( new Skins\Skin_Vyxo( $this ) );
	}

	public function has_widget_inner_wrapper(): bool {
		return ! \Elementor\Plugin::$instance->experiments->is_feature_active( 'e_optimized_markup' );
	}

	protected function register_controls() {
		$this->register_testimonial_controls( 'carousel' );
	}

	public function render_review_platform( $post_id, $settings ) {
		$this->render_testimonial_review_platform( $post_id, $settings );
	}

	public function render_image( $image_id, $settings ) {
		$this->render_testimonial_image( 'carousel', $image_id, $settings );
	}

	public function render_title( $post_id, $settings ) {
		$this->render_testimonial_title( 'carousel', $post_id, $settings );
	}

	public function render_address( $post_id, $settings ) {
		$this->render_testimonial_address( 'carousel', $post_id, $settings );
	}

	public function render_designation( $post_id, $settings ) {
		$this->render_testimonial_designation( 'carousel', $post_id, $settings );
	}

	public function render_excerpt( $settings ) {
		$this->render_testimonial_excerpt( 'carousel', $settings );
	}

	public function render_schema_item_reviewed( $settings ) {
		$this->render_testimonial_schema_item_reviewed( $settings );
	}

	public function render_rating_schema_only( $post_id, $settings ) {
		$this->render_testimonial_rating_schema_only( $post_id, $settings );
	}

	public function render_rating( $post_id, $settings ) {
		$this->render_testimonial_rating( 'carousel', $post_id, $settings );
	}

	public function render_header( $skin, $settings ) {
		$this->render_testimonial_carousel_header( $skin, $settings );
	}

	public function render_query( $posts_per_page ) {
		return $this->query_testimonial_posts( 'carousel', $posts_per_page );
	}

	public function render_loop_item( $settings ) {
		$this->render_testimonial_carousel_loop_item( $settings );
	}

	public function render() {
		$this->render_testimonial_carousel();
	}
}
