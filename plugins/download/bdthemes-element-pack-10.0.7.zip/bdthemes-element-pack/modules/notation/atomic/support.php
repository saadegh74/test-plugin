<?php

namespace ElementPack\Modules\Notation\Atomic;

use Elementor\Modules\AtomicWidgets\Controls\Section;
use Elementor\Modules\AtomicWidgets\Controls\Types\Number_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Select_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Switch_Control;
use Elementor\Modules\AtomicWidgets\Controls\Types\Text_Control;
use Elementor\Modules\AtomicWidgets\PropDependencies\Manager as Dependency_Manager;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Boolean_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\Number_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Primitives\String_Prop_Type;
use Elementor\Modules\AtomicWidgets\PropTypes\Union_Prop_Type;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Support {
	public const ACTIVE_KEY = 'ep_notation_active';
	public const SELECT_TYPE_KEY = 'ep_notation_select_type';
	public const CUSTOM_SELECTOR_KEY = 'ep_notation_custom_selector';
	public const TYPE_KEY = 'ep_notation_type';
	public const BRACKET_ON_KEY = 'ep_notation_bracket_on';
	public const COLOR_KEY = 'ep_notation_color';
	public const STROKE_WIDTH_KEY = 'ep_notation_stroke_width';
	public const INFINITY_LOOP_KEY = 'ep_notation_infinity_loop';
	public const ANIM_DURATION_KEY = 'ep_notation_anim_duration';
	public const LOOP_DELAY_KEY = 'ep_notation_loop_delay';
	public const WAYPOINT_OFFSET_KEY = 'ep_notation_waypoint_offset';

	/**
	 * Atomic root keys that map to one notation item (parity with repeater row fields).
	 *
	 * @return string[]
	 */
	public static function item_setting_keys(): array {
		return [
			self::SELECT_TYPE_KEY,
			self::CUSTOM_SELECTOR_KEY,
			self::TYPE_KEY,
			self::BRACKET_ON_KEY,
			self::COLOR_KEY,
			self::STROKE_WIDTH_KEY,
			self::INFINITY_LOOP_KEY,
			self::ANIM_DURATION_KEY,
			self::LOOP_DELAY_KEY,
			self::WAYPOINT_OFFSET_KEY,
		];
	}

	public function register_schema( array $schema ): array {
		$active_dependencies = $this->get_active_dependencies();
		$custom_dependencies = $this->get_custom_selector_dependencies();
		$bracket_dependencies = $this->get_bracket_dependencies();
		$loop_delay_dependencies = $this->get_loop_delay_dependencies();

		$schema[ self::ACTIVE_KEY ] = $schema[ self::ACTIVE_KEY ] ?? Boolean_Prop_Type::make()->default( false );
		$schema[ self::SELECT_TYPE_KEY ] = $schema[ self::SELECT_TYPE_KEY ] ?? String_Prop_Type::make()
			->default( 'widget' )
			->set_dependencies( $active_dependencies );
		$schema[ self::CUSTOM_SELECTOR_KEY ] = $schema[ self::CUSTOM_SELECTOR_KEY ] ?? String_Prop_Type::make()
			->default( '' )
			->set_dependencies( $custom_dependencies );
		$schema[ self::TYPE_KEY ] = $schema[ self::TYPE_KEY ] ?? String_Prop_Type::make()
			->default( 'underline' )
			->set_dependencies( $active_dependencies );
		$schema[ self::BRACKET_ON_KEY ] = $schema[ self::BRACKET_ON_KEY ] ?? String_Prop_Type::make()
			->default( 'left,right' )
			->set_dependencies( $bracket_dependencies );
		$schema[ self::COLOR_KEY ] = $schema[ self::COLOR_KEY ] ?? String_Prop_Type::make()
			->default( '#f23427' )
			->set_dependencies( $active_dependencies );
		$schema[ self::STROKE_WIDTH_KEY ] = $schema[ self::STROKE_WIDTH_KEY ] ?? $this->number_prop( 1, $active_dependencies );
		$schema[ self::INFINITY_LOOP_KEY ] = $schema[ self::INFINITY_LOOP_KEY ] ?? Boolean_Prop_Type::make()
			->default( false )
			->set_dependencies( $active_dependencies );
		$schema[ self::ANIM_DURATION_KEY ] = $schema[ self::ANIM_DURATION_KEY ] ?? $this->number_prop( 800, $active_dependencies, false );
		$schema[ self::LOOP_DELAY_KEY ] = $schema[ self::LOOP_DELAY_KEY ] ?? $this->number_prop( 5000, $loop_delay_dependencies, false );
		$schema[ self::WAYPOINT_OFFSET_KEY ] = $schema[ self::WAYPOINT_OFFSET_KEY ] ?? String_Prop_Type::make()
			->default( '' )
			->set_dependencies( $active_dependencies );

		return $schema;
	}

	public function register_controls( array $controls ): array {
		$item = Section::make()
			->set_id( 'ep_section_notation' )
			->set_label( esc_html__( 'Notation', 'bdthemes-element-pack' ) )
			->set_items( [] );

		$controls[] = $item;

			$item->add_item(
				Switch_Control::bind_to( self::ACTIVE_KEY )
					->set_label( esc_html__( 'Notation', 'bdthemes-element-pack' ) )
			);

			$item->add_item(
				Select_Control::bind_to( self::SELECT_TYPE_KEY )
					->set_label( esc_html__( 'Element Type', 'bdthemes-element-pack' ) )
					->set_options(
						[
							[ 'value' => 'widget', 'label' => esc_html__( 'Widget', 'bdthemes-element-pack' ) ],
							[ 'value' => 'custom', 'label' => esc_html__( 'Widget / Custom Selector', 'bdthemes-element-pack' ) ],
						]
					)
			);

			$item->add_item(
				Text_Control::bind_to( self::CUSTOM_SELECTOR_KEY )
					->set_label( esc_html__( 'Custom Selector', 'bdthemes-element-pack' ) )
					->set_placeholder( '#id, .class' )
			);

			$item->add_item(
				Select_Control::bind_to( self::TYPE_KEY )
					->set_label( esc_html__( 'Select Style', 'bdthemes-element-pack' ) )
					->set_options(
						[
							[ 'value' => 'underline', 'label' => esc_html__( 'Underline', 'bdthemes-element-pack' ) ],
							[ 'value' => 'box', 'label' => esc_html__( 'Box', 'bdthemes-element-pack' ) ],
							[ 'value' => 'circle', 'label' => esc_html__( 'Circle', 'bdthemes-element-pack' ) ],
							[ 'value' => 'highlight', 'label' => esc_html__( 'Highlight', 'bdthemes-element-pack' ) ],
							[ 'value' => 'strike-through', 'label' => esc_html__( 'Strike-through', 'bdthemes-element-pack' ) ],
							[ 'value' => 'crossed-off', 'label' => esc_html__( 'Crossed-off', 'bdthemes-element-pack' ) ],
							[ 'value' => 'bracket', 'label' => esc_html__( 'Bracket', 'bdthemes-element-pack' ) ],
							[ 'value' => 'soft-wave', 'label' => esc_html__( 'Soft Wave', 'bdthemes-element-pack' ) ],
						]
					)
			);

			$item->add_item(
				Text_Control::bind_to( self::BRACKET_ON_KEY )
					->set_label( esc_html__( 'Bracket On', 'bdthemes-element-pack' ) )
			);

			$item->add_item(
				Text_Control::bind_to( self::COLOR_KEY )
					->set_label( esc_html__( 'Color', 'bdthemes-element-pack' ) )
			);

			$item->add_item(
				Number_Control::bind_to( self::STROKE_WIDTH_KEY )
					->set_label( esc_html__( 'Stroke Width', 'bdthemes-element-pack' ) )
					->set_min( 0 )
					->set_max( 100 )
					->set_step( 1 )
			);

			$item->add_item(
				Switch_Control::bind_to( self::INFINITY_LOOP_KEY )
					->set_label( esc_html__( 'Infinity Loop', 'bdthemes-element-pack' ) )
			);

			$item->add_item(
				Number_Control::bind_to( self::ANIM_DURATION_KEY )
					->set_label( esc_html__( 'Animation Duration (ms)', 'bdthemes-element-pack' ) )
					->set_min( 0 )
					->set_max( 5000 )
					->set_step( 10 )
			);

			$item->add_item(
				Number_Control::bind_to( self::LOOP_DELAY_KEY )
					->set_label( esc_html__( 'Loop Delay (ms)', 'bdthemes-element-pack' ) )
					->set_min( 500 )
					->set_max( 10000 )
					->set_step( 100 )
			);

			$item->add_item(
				Text_Control::bind_to( self::WAYPOINT_OFFSET_KEY )
					->set_label( esc_html__( 'Waypoint Offset', 'bdthemes-element-pack' ) )
					->set_placeholder( 'bottom-in-view' )
			);

		return $controls;
	}

	private function number_prop( $default, ?array $dependencies, bool $float = true ): Union_Prop_Type {
		$number_schema = Number_Prop_Type::make();

		if ( $float ) {
			$number_schema->float();
		}

		return Union_Prop_Type::make()
			->add_prop_type( $number_schema )
			->add_prop_type( String_Prop_Type::make() )
			->default( $default, 'number' )
			->set_dependencies( $dependencies );
	}

	private function get_active_dependencies(): ?array {
		return Dependency_Manager::make( Dependency_Manager::RELATION_AND )
			->where(
				[
					'operator' => 'eq',
					'path' => [ self::ACTIVE_KEY ],
					'value' => true,
					'effect' => 'hide',
				]
			)
			->get();
	}

	private function get_custom_selector_dependencies(): ?array {
		return Dependency_Manager::make( Dependency_Manager::RELATION_AND )
			->where(
				[
					'operator' => 'eq',
					'path' => [ self::ACTIVE_KEY ],
					'value' => true,
					'effect' => 'hide',
				]
			)
			->where(
				[
					'operator' => 'eq',
					'path' => [ self::SELECT_TYPE_KEY ],
					'value' => 'custom',
					'effect' => 'hide',
				]
			)
			->get();
	}

	private function get_bracket_dependencies(): ?array {
		return Dependency_Manager::make( Dependency_Manager::RELATION_AND )
			->where(
				[
					'operator' => 'eq',
					'path' => [ self::ACTIVE_KEY ],
					'value' => true,
					'effect' => 'hide',
				]
			)
			->where(
				[
					'operator' => 'eq',
					'path' => [ self::TYPE_KEY ],
					'value' => 'bracket',
					'effect' => 'hide',
				]
			)
			->get();
	}

	private function get_loop_delay_dependencies(): ?array {
		return Dependency_Manager::make( Dependency_Manager::RELATION_AND )
			->where(
				[
					'operator' => 'eq',
					'path' => [ self::ACTIVE_KEY ],
					'value' => true,
					'effect' => 'hide',
				]
			)
			->where(
				[
					'operator' => 'eq',
					'path' => [ self::INFINITY_LOOP_KEY ],
					'value' => true,
					'effect' => 'hide',
				]
			)
			->get();
	}
}
