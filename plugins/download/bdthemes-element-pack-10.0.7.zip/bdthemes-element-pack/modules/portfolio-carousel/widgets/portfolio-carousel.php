<?php

namespace ElementPack\Modules\PortfolioCarousel\Widgets;

use Elementor\Controls_Manager;
use ElementPack\Base\Module_Base;
use ElementPack\Includes\Controls\GroupQuery\Group_Control_Query;
use ElementPack\Modules\PortfolioCarousel\Skins;
use ElementPack\Traits\Global_Controls_Functions;
use ElementPack\Traits\Global_Swiper_Controls;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Portfolio_Carousel extends Module_Base {
	use Group_Control_Query;
	use Global_Swiper_Controls;
	use Global_Controls_Functions;

	private $_query = null;
	private $widget_prefix = 'portfolio-carousel';

	public function get_name() {
		return 'bdt-portfolio-carousel';
	}

	public function get_title() {
		return BDTEP . esc_html__( 'Portfolio Carousel', 'bdthemes-element-pack' );
	}

	public function get_icon() {
		return 'bdt-wi-portfolio-carousel';
	}

	public function get_categories() {
		return [ 'element-pack' ];
	}

	public function get_keywords() {
		return [ 'portfolio', 'gallery', 'blog', 'recent', 'news', 'works', 'portfolio-carousel' ];
	}

	public function get_style_depends(): array {
		return $this->ep_is_edit_mode() ? [ 'swiper', 'ep-styles' ] : [ 'swiper', 'ep-font', 'ep-portfolio-carousel' ];
	}

	public function get_script_depends(): array {
		return $this->ep_is_edit_mode() ? [ 'swiper', 'imagesloaded', 'ep-scripts' ] : [ 'swiper', 'imagesloaded', 'ep-portfolio-carousel' ];
	}

	public function register_skins() {
		$this->add_skin( new Skins\Skin_Abetis( $this ) );
		$this->add_skin( new Skins\Skin_Fedara( $this ) );
		$this->add_skin( new Skins\Skin_Trosia( $this ) );
		$this->add_skin( new Skins\Skin_Janes( $this ) );
	}

	public function on_import( $element ) {
		if ( ! get_post_type_object( $element['settings']['posts_post_type'] ) ) {
			$element['settings']['posts_post_type'] = 'post';
		}
		return $element;
	}

	public function get_query() {
		return $this->_query;
	}

	public function register_controls() {
		$this->register_section_controls();
	}

	public function has_widget_inner_wrapper(): bool {
		return ! \Elementor\Plugin::$instance->experiments->is_feature_active( 'e_optimized_markup' );
	}

	private function register_section_controls() {
		$this->start_controls_section(
			'section_carousel_layout',
			[
				'label' => esc_html__( 'Layout', 'bdthemes-element-pack' ),
			]
		);

		$this->register_carousel_column_gap_controls();
		$this->add_control(
			'match_height',
			[
				'label' => esc_html__( 'Item Match Height', 'bdthemes-element-pack' ),
				'type'  => Controls_Manager::SWITCHER,
			]
		);

		$this->register_portfolio_thumbnail_size_control();
		$this->end_controls_section();

		$this->register_portfolio_query_section_controls( [ 'posts_per_page_default' => 9 ] );
		$this->register_portfolio_additional_options_controls( [
			'include_link_controls'    => true,
			'excerpt_limit_default'      => 10,
			'show_excerpt_default'       => '',
		] );

		$this->start_controls_section(
			'section_content_navigation',
			[
				'label' => esc_html__( 'Navigation', 'bdthemes-element-pack' ),
			]
		);
		$this->register_navigation_controls();
		$this->end_controls_section();

		$this->register_carousel_settings_controls();

		$this->register_portfolio_style_items_controls( $this->widget_prefix );
		$this->register_portfolio_style_title_controls( $this->widget_prefix );
		$this->register_portfolio_style_excerpt_controls( $this->widget_prefix );
		$this->register_portfolio_style_link_controls( $this->widget_prefix );
		$this->register_portfolio_style_category_controls( $this->widget_prefix );

		$this->start_controls_section(
			'section_style_navigation',
			[
				'label'      => esc_html__( 'Navigation', 'bdthemes-element-pack' ),
				'tab'        => Controls_Manager::TAB_STYLE,
				'conditions' => [
					'relation' => 'or',
					'terms'    => [
						[
							'name'     => 'navigation',
							'operator' => '!=',
							'value'    => 'none',
						],
						[
							'name'  => 'show_scrollbar',
							'value' => 'yes',
						],
					],
				],
			]
		);
		$this->register_navigation_style_controls( 'swiper-carousel' );
		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->query_posts( $settings['posts_per_page'] );

		$wp_query = $this->get_query();
		if ( ! $wp_query->found_posts ) {
			return;
		}

		$this->render_header( 'default', $settings );

		while ( $wp_query->have_posts() ) {
			$wp_query->the_post();
			$this->render_post( $settings );
		}

		$this->render_footer();
		wp_reset_postdata();
	}

	public function render_header( $skin, $settings ) {
		$this->render_swiper_header_attribute( 'portfolio-carousel' );

		$this->add_render_attribute( 'carousel', 'class', [ 'bdt-portfolio-carousel', 'skin-' . $skin ] );

		if ( $settings['match_height'] === 'yes' ) {
			$this->add_render_attribute( 'carousel', 'data-bdt-height-match', 'target: > div > div > .bdt-gallery-item' );
		}

		$show_link = $settings['show_link'];

		if ( $show_link === 'lightbox' || $show_link === 'both' ) {
			$anim = $settings['lightbox_animation'] ?? 'slide';

			$this->add_render_attribute( 'carousel', 'data-bdt-lightbox', 'toggle: .bdt-gallery-lightbox-item; animation:' . $anim . ';' );

			if ( ! empty( $settings['lightbox_autoplay'] ) ) {
				$this->add_render_attribute( 'carousel', 'data-bdt-lightbox', 'autoplay: 500;' );
				if ( ! empty( $settings['lightbox_pause'] ) ) {
					$this->add_render_attribute( 'carousel', 'data-bdt-lightbox', 'pause-on-hover: true;' );
				}
			}
		}
		?>
		<div <?php $this->print_render_attribute_string( 'carousel' ); ?>>
			<div <?php $this->print_render_attribute_string( 'swiper' ); ?>>
				<div class="swiper-wrapper">
		<?php
	}

	public function render_post( $settings ) {
		$this->add_render_attribute( 'portfolio-item-inner', 'class', 'bdt-portfolio-inner', true );
		$this->add_render_attribute( 'portfolio-item', 'class', 'swiper-slide bdt-gallery-item bdt-transition-toggle', true );
		?>
		<div <?php $this->print_render_attribute_string( 'portfolio-item' ); ?>>
			<div <?php $this->print_render_attribute_string( 'portfolio-item-inner' ); ?>>
				<div class="bdt-portfolio-content-inner">
					<?php
					$this->render_thumbnail( $settings );
					$this->render_overlay( $settings );
					?>
				</div>
				<?php $this->render_desc( $settings ); ?>
				<?php $this->render_categories_names( $settings ); ?>
			</div>
		</div>
		<?php
	}
}
