<?php

namespace ElementPack\Modules\PortfolioCarousel\Skins;

use Elementor\Utils;
use Elementor\Controls_Manager;

use Elementor\Skin_Base as Elementor_Skin_Base;

if ( ! defined( 'ABSPATH' ) )
	exit; // Exit if accessed directly

class Skin_Janes extends Elementor_Skin_Base {
	public function get_id() {
		return 'bdt-janes';
	}

	public function get_title() {
		return esc_html__( 'Janes', 'bdthemes-element-pack' );
	}

	public function render_overlay( array $settings ) {

		$this->parent->add_render_attribute(
			[ 
				'content-position' => [ 
					'class' => [ 
						'bdt-position-cover',
					]
				]
			],
			'',
			'',
			true
		);

		?>
		<div <?php $this->parent->print_render_attribute_string( 'content-position' ); ?>>
			<div class="bdt-portfolio-content">
				<div class="bdt-gallery-content-inner">
					<?php

					$placeholder_img_src = Utils::get_placeholder_image_src();

					$img_url = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full' );

					if ( ! $img_url ) {
						$img_url = $placeholder_img_src;
					} else {
						$img_url = $img_url[0];
					}

					$this->parent->add_render_attribute(
						[ 
							'lightbox-settings' => [ 
								'class'                        => [ 
									'bdt-gallery-item-link',
									'bdt-gallery-lightbox-item',
									( ( $settings['link_type'] ?? 'icon' ) === 'icon' ) ? 'bdt-link-icon' : 'bdt-link-text'
								],
								'data-elementor-open-lightbox' => 'no',
								'data-caption'                 => wp_kses_post(get_the_title()),
								'href'                         => esc_url( $img_url )
							]
						],
						'',
						'',
						true
					);

					if ( ( $settings['show_link'] ?? 'none' ) !== 'none' ) : ?>
						<div class="bdt-flex-inline bdt-gallery-item-link-wrapper">
							<?php if ( ( $settings['show_link'] ?? '' ) === 'lightbox' || ( $settings['show_link'] ?? '' ) === 'both' ) : ?>
								<a <?php $this->parent->print_render_attribute_string( 'lightbox-settings' ); ?>>
									<?php if ( ( $settings['link_type'] ?? 'icon' ) === 'icon' ) : ?>
										<i class="ep-icon-plus" aria-hidden="true"></i>
									<?php elseif ( ( $settings['link_type'] ?? '' ) === 'text' && ! empty( $settings['lightbox_link_text'] ) ) : ?>
										<span><?php echo esc_html( $settings['lightbox_link_text'] ); ?></span>
									<?php endif; ?>
								</a>
							<?php endif; ?>

							<?php if ( ( $settings['show_link'] ?? '' ) === 'post' || ( $settings['show_link'] ?? '' ) === 'both' ) : ?>
								<?php
								$link_type_class = ( ( $settings['link_type'] ?? 'icon' ) === 'icon' ) ? ' bdt-link-icon' : ' bdt-link-text';
								$target          = ! empty( $settings['external_link'] ) ? '_blank' : '_self';
								?>
								<a class="bdt-gallery-item-link<?php echo esc_attr( $link_type_class ); ?>"
									href="<?php echo esc_url( get_permalink() ); ?>" target="<?php echo esc_attr( $target ); ?>">
									<?php if ( ( $settings['link_type'] ?? 'icon' ) === 'icon' ) : ?>
										<i class="ep-icon-link" aria-hidden="true"></i>
									<?php elseif ( ( $settings['link_type'] ?? '' ) === 'text' && ! empty( $settings['post_link_text'] ) ) : ?>
										<span><?php echo esc_html( $settings['post_link_text'] ); ?></span>
									<?php endif; ?>
								</a>
							<?php endif; ?>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php
	}

	public function render_desc( array $settings ) {
		?>
		<div class="bdt-portfolio-desc">
			<div>
				<?php $this->parent->render_title( $settings ); ?>
				<?php $this->parent->render_categories_names( $settings ); ?>
			</div>
			<?php $this->parent->render_excerpt( $settings ); ?>
		</div>
		<?php
	}

	public function render_post( array $settings ) {
		$this->parent->add_render_attribute( 'portfolio-item-inner', 'class', 'bdt-portfolio-inner', true );
		$this->parent->add_render_attribute( 'portfolio-item', 'class', 'swiper-slide bdt-gallery-item bdt-transition-toggle', true );
		?>
		<div <?php $this->parent->print_render_attribute_string( 'portfolio-item' ); ?>>
			<div <?php $this->parent->print_render_attribute_string( 'portfolio-item-inner' ); ?>>
				<?php
				$this->parent->render_thumbnail( $settings );
				$this->render_overlay( $settings );
				?>
				<?php $this->render_desc( $settings ); ?>
			</div>
		</div>
		<?php
	}

	public function render() {
		$settings = $this->parent->get_settings_for_display();

		$this->parent->query_posts( (int) ( $settings['posts_per_page'] ?? 9 ) );

		$wp_query = $this->parent->get_query();
		if ( ! $wp_query->found_posts ) {
			return;
		}

		$this->parent->render_header( 'janes', $settings );

		while ( $wp_query->have_posts() ) {
			$wp_query->the_post();
			$this->render_post( $settings );
		}

		$this->parent->render_footer();
		wp_reset_postdata();
	}
}
