<?php
/**
 * Shared Abilities Helpers.
 *
 * Provides common utilities used across multiple ability classes:
 * template validation, theme compatibility resolution, and location normalization.
 *
 * @package ElementPack
 * @since 9.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Trait EP_Abilities_Helpers
 *
 * Shared helper methods for Element Pack ability classes.
 *
 * @since 9.9.0
 */
trait EP_Abilities_Helpers {

	/**
	 * Validate that a post ID belongs to any Elementor-enabled post type.
	 *
	 * Accepts pages, posts, templates, and any custom post type that
	 * Elementor supports (configured in Elementor > Settings > General).
	 *
	 * @since 9.9.0
	 *
	 * @param int $post_id Post ID to validate.
	 * @return WP_Post|WP_Error The post object or error.
	 */
	protected function validate_elementor_post( $post_id ) {
		$post = get_post( $post_id );

		if ( ! $post ) {
			return new WP_Error(
				'ep_ai_post_not_found',
				__( 'Post not found.', 'bdthemes-element-pack' ),
				array( 'status' => 404 )
			);
		}

		$is_supported = false;

		// Always accept Elementor library templates.
		if ( 'elementor_library' === $post->post_type ) {
			$is_supported = true;
		} else {
			// Accept any post type Elementor supports.
			$supported_cpts = get_option( 'elementor_cpt_support', array( 'page', 'post' ) );

			if ( is_array( $supported_cpts ) && in_array( $post->post_type, $supported_cpts, true ) ) {
				$is_supported = true;
			} elseif ( 'builder' === get_post_meta( $post->ID, '_elementor_edit_mode', true ) ) {
				// Accept any post already edited with Elementor.
				$is_supported = true;
			}
		}

		if ( ! $is_supported ) {
			return new WP_Error(
				'ep_ai_unsupported_post_type',
				sprintf(
					/* translators: %s: post type slug */
					__( 'Post type "%s" is not supported by Elementor.', 'bdthemes-element-pack' ),
					$post->post_type
				),
				array( 'status' => 400 )
			);
		}

		// Object-level authorization: a capability check on the ability is not
		// enough — verify the current user is allowed to edit THIS specific post.
		// `edit_post` is a meta capability that respects per-object ownership,
		// so an Author cannot tamper with pages/templates authored by others.
		if ( ! current_user_can( 'edit_post', $post->ID ) ) {
			return new WP_Error(
				'ep_ai_forbidden',
				__( 'You are not allowed to edit this post.', 'bdthemes-element-pack' ),
				array( 'status' => 403 )
			);
		}

		return $post;
	}

	/**
	 * Guard write operations behind the AI Tools "allow modifications" setting.
	 *
	 * Shared by every handler that creates, edits, or deletes content so the
	 * check stays in one place. Returns boolean true when modifications are
	 * permitted; callers should bail with the returned WP_Error otherwise.
	 *
	 * @since 9.9.0
	 *
	 * @return true|WP_Error True when allowed, WP_Error (403) when disabled.
	 */
	protected function check_modifications_allowed() {
		$settings = get_option( 'element_pack_ai_settings', array() );

		if ( empty( $settings['allow_modifications'] ) ) {
			return new \WP_Error(
				'ep_ai_modifications_disabled',
				__( 'Modifications disabled in AI Tools settings.', 'bdthemes-element-pack' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}
}
