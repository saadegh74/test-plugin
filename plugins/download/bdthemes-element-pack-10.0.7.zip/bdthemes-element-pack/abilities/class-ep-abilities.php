<?php
/**
 * Element Pack Abilities Bootstrap.
 *
 * Wires the AI Tools feature: registers Element Pack abilities with the WP
 * Abilities API (WP 6.9+), exposes them through a dedicated MCP server (via
 * the MCP Adapter plugin) and through Elementor's Angie assistant, and mounts
 * the AI Tools admin page.
 *
 * Master switch is `element_pack_ai_settings['enable_abilities']` — off by
 * default. Side effects (ability registration, MCP server, Angie bridge) only
 * attach when the user opts in.
 *
 * @package ElementPack
 * @since 9.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Only proceed if the Abilities API exists (WP 6.9+).
if ( ! function_exists( 'wp_register_ability' ) ) {
	return;
}

/**
 * Class EP_Abilities_Bootstrap
 *
 * @since 9.9.0
 */
class EP_Abilities_Bootstrap {

	/**
	 * Option name holding all AI Tools settings.
	 *
	 * @var string
	 */
	const OPTION = 'element_pack_ai_settings';

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * Registry instance.
	 *
	 * @var EP_Ability_Registry|null
	 */
	private $registry = null;

	/**
	 * Get singleton instance.
	 *
	 * @return self
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Get the registry instance.
	 *
	 * @return EP_Ability_Registry|null
	 */
	public function get_registry() {
		return $this->registry;
	}

	/**
	 * Map of tier key => module option name.
	 *
	 * Shared by the widget/info handlers so the tier vocabulary stays in one place.
	 *
	 * @return array<string,string>
	 */
	public static function get_tier_map() {
		return array(
			'core'        => 'element_pack_active_modules',
			'extension'   => 'element_pack_elementor_extend',
			'third-party' => 'element_pack_third_party_widget',
		);
	}

	/**
	 * Get the AI settings merged over defaults.
	 *
	 * @return array
	 */
	public static function get_settings() {
		$defaults = array(
			'enable_abilities'    => false,
			'allow_modifications' => true,
			'dedicated_server'    => false,
			'angie_enabled'       => false,
			'disabled_abilities'  => array(),
		);

		$settings = get_option( self::OPTION, array() );

		return wp_parse_args( is_array( $settings ) ? $settings : array(), $defaults );
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		// Framework + registry load unconditionally so the settings UI can
		// introspect the ability catalogue even when AI tools are turned off.
		$this->load_framework();

		$this->registry = new EP_Ability_Registry();

		// Settings REST API + admin page are always available (that is where the
		// feature gets switched on).
		require_once BDTEP_PATH . 'abilities/settings/class-ep-ai-settings-api.php';
		EP_AI_Settings_Api::instance( $this );

		if ( is_admin() ) {
			// The screen itself is a React dashboard route; this only forwards
			// the retired standalone page slug to it.
			require_once BDTEP_PATH . 'abilities/admin/class-ep-ai-legacy-page.php';
			EP_AI_Legacy_Page::instance( $this );
		}

		$settings = self::get_settings();

		if ( empty( $settings['enable_abilities'] ) ) {
			return;
		}

		add_action( 'wp_abilities_api_categories_init', array( $this, 'register_categories' ) );
		add_action( 'wp_abilities_api_init', array( $this, 'register_abilities' ) );

		// Dedicated MCP server — only when the user explicitly opts in.
		if ( ! empty( $settings['dedicated_server'] ) ) {
			add_action( 'mcp_adapter_init', array( $this, 'register_mcp_server' ), 20 );

			// Boot the adapter ourselves. `mcp_adapter_init` only fires once
			// someone calls McpAdapter::instance(), and the class merely being
			// autoloadable proves nothing — several plugins vendor the library
			// without ever starting it. Without this the endpoint silently 404s
			// whenever no other plugin happens to boot the adapter first.
			// instance()/init() are both idempotent, so this is safe to call
			// alongside any plugin that does the same.
			if ( class_exists( '\WP\MCP\Core\McpAdapter' ) ) {
				\WP\MCP\Core\McpAdapter::instance();
			}
		}

		// Angie bridge — only when the user explicitly opts in.
		if ( ! empty( $settings['angie_enabled'] ) ) {
			$this->init_angie();
		}
	}

	/**
	 * Load framework files.
	 *
	 * @return void
	 */
	private function load_framework() {
		$base = BDTEP_PATH . 'abilities/';

		require_once $base . 'contracts/interface-ep-ability-handler.php';
		require_once $base . 'registry/class-ep-ability-registry.php';
		require_once $base . 'trait-ep-abilities-helpers.php';
		require_once $base . 'class-ep-element-helpers.php';
	}

	/**
	 * Register ability categories.
	 *
	 * @return void
	 */
	public function register_categories() {
		$plugin_name = defined( 'BDTEP_TITLE' ) ? BDTEP_TITLE : __( 'Element Pack Pro', 'bdthemes-element-pack' );

		$categories = array(
			'element-pack-widgets'     => array(
				'label'       => __( 'EP Widget Management', 'bdthemes-element-pack' ),
				'description' => __( 'List, activate, and deactivate Element Pack modules.', 'bdthemes-element-pack' ),
			),
			'element-pack-builder'     => array(
				'label'       => __( 'EP Page Builder', 'bdthemes-element-pack' ),
				'description' => __( 'Build and manage page content with Elementor widgets.', 'bdthemes-element-pack' ),
			),
			'element-pack-pages'       => array(
				'label'       => __( 'EP Page Management', 'bdthemes-element-pack' ),
				'description' => __( 'Create, update, and manage WordPress pages.', 'bdthemes-element-pack' ),
			),
			'element-pack-settings'    => array(
				'label'       => __( 'EP Integrations', 'bdthemes-element-pack' ),
				'description' => __( 'Manage integration API keys.', 'bdthemes-element-pack' ),
			),
			'element-pack-info'        => array(
				'label'       => $plugin_name . ' ' . __( 'Information', 'bdthemes-element-pack' ),
				'description' => __( 'Read-only plugin info: version, modules, tiers.', 'bdthemes-element-pack' ),
			),
			'element-pack-design'      => array(
				'label'       => __( 'EP Design System', 'bdthemes-element-pack' ),
				'description' => __( 'Read the site\'s global colors, fonts, and spacing.', 'bdthemes-element-pack' ),
			),
			'element-pack-maintenance' => array(
				'label'       => __( 'EP Maintenance', 'bdthemes-element-pack' ),
				'description' => __( 'Cache clearing and maintenance tasks.', 'bdthemes-element-pack' ),
			),
		);

		foreach ( $categories as $slug => $args ) {
			wp_register_ability_category( $slug, $args );
		}
	}

	/**
	 * Ensure handler classes are loaded and registered in the registry.
	 *
	 * Safe to call multiple times — skips if handlers are already populated.
	 * Does NOT call discover(); use register_abilities() for full registration
	 * with the WP Abilities API.
	 *
	 * @return void
	 */
	public function ensure_handlers_loaded() {
		if ( ! $this->registry || ! empty( $this->registry->get_handler_names() ) ) {
			return;
		}

		$this->load_handlers();
		$this->register_all_handlers();
	}

	/**
	 * Load and register all handlers, then register with the WP Abilities API.
	 *
	 * @return void
	 */
	public function register_abilities() {
		$this->load_handlers();
		$this->register_all_handlers();
		$this->registry->discover();
	}

	/**
	 * Load all handler files.
	 *
	 * @return void
	 */
	private function load_handlers() {
		$base = BDTEP_PATH . 'abilities/handlers/';

		// Widgets.
		require_once $base . 'widgets/class-ep-widget-list-handler.php';
		require_once $base . 'widgets/class-ep-widget-toggle-handler.php';
		require_once $base . 'widgets/class-ep-widget-usage-handler.php';

		// Builder.
		require_once $base . 'builder/class-ep-build-handler.php';
		require_once $base . 'builder/class-ep-insert-widget-handler.php';
		require_once $base . 'builder/class-ep-update-widget-handler.php';
		require_once $base . 'builder/class-ep-remove-element-handler.php';
		require_once $base . 'builder/class-ep-move-element-handler.php';
		require_once $base . 'builder/class-ep-structure-handler.php';
		require_once $base . 'builder/class-ep-add-section-handler.php';
		require_once $base . 'builder/class-ep-add-column-handler.php';
		require_once $base . 'builder/class-ep-css-handler.php';
		require_once $base . 'builder/class-ep-widget-types-handler.php';
		require_once $base . 'builder/class-ep-schema-handler.php';
		require_once $base . 'builder/class-ep-undo-handler.php';

		// Pages.
		require_once $base . 'pages/class-ep-page-create-handler.php';
		require_once $base . 'pages/class-ep-page-list-handler.php';
		require_once $base . 'pages/class-ep-page-delete-handler.php';
		require_once $base . 'pages/class-ep-page-restore-handler.php';
		require_once $base . 'pages/class-ep-page-update-status-handler.php';
		require_once $base . 'pages/class-ep-page-update-meta-handler.php';

		// Design System.
		require_once $base . 'design-system/class-ep-design-tokens-handler.php';

		// Maintenance.
		require_once $base . 'maintenance/class-ep-maintenance-clear-cache-handler.php';

		// Info.
		require_once $base . 'info/class-ep-info-handler.php';

		// Integrations.
		require_once $base . 'integrations/class-ep-integrations-handler.php';
	}

	/**
	 * Register all handler instances with the registry.
	 *
	 * @return void
	 */
	private function register_all_handlers() {
		$handlers = array(
			// Widgets (6).
			new EP_Widget_List_Handler(),
			new EP_Widget_Activate_Handler(),
			new EP_Widget_Deactivate_Handler(),
			new EP_Widget_Bulk_Toggle_Handler(),
			new EP_Widget_Deactivate_Unused_Handler(),
			new EP_Widget_Usage_Handler(),

			// Builder (12).
			new EP_Build_Handler(),
			new EP_Insert_Widget_Handler(),
			new EP_Update_Widget_Handler(),
			new EP_Remove_Element_Handler(),
			new EP_Move_Element_Handler(),
			new EP_Structure_Handler(),
			new EP_Add_Section_Handler(),
			new EP_Add_Column_Handler(),
			new EP_CSS_Handler(),
			new EP_Widget_Types_Handler(),
			new EP_Schema_Handler(),
			new EP_Undo_Handler(),

			// Pages (6).
			new EP_Page_Create_Handler(),
			new EP_Page_List_Handler(),
			new EP_Page_Delete_Handler(),
			new EP_Page_Restore_Handler(),
			new EP_Page_Update_Status_Handler(),
			new EP_Page_Update_Meta_Handler(),

			// Design System (1).
			new EP_Design_Tokens_Handler(),

			// Maintenance (1).
			new EP_Maintenance_Clear_Cache_Handler(),

			// Info (3).
			new EP_Info_Get_Handler(),
			new EP_Info_Widget_Handler(),
			new EP_Info_Categories_Handler(),

			// Integrations (2).
			new EP_Integrations_Get_Handler(),
			new EP_Integrations_Update_Handler(),
		);

		foreach ( $handlers as $handler ) {
			$this->registry->register( $handler, 'element-pack' );
		}

		/**
		 * Let other plugins register additional handlers into the registry.
		 *
		 * @since 9.9.0
		 *
		 * @param EP_Ability_Registry $registry The ability registry.
		 */
		do_action( 'element_pack_ai_register_abilities', $this->registry );
	}

	/**
	 * Register the dedicated MCP server.
	 *
	 * Endpoint: /wp-json/element-pack/mcp
	 *
	 * @param object $mcp_adapter The MCP Adapter instance.
	 * @return void
	 */
	public function register_mcp_server( $mcp_adapter ) {
		$settings = self::get_settings();

		// Strict opt-in — the server is only created when explicitly enabled.
		if ( empty( $settings['dedicated_server'] ) ) {
			return;
		}

		// The core abilities registry is lazy: `wp_abilities_api_init` only
		// fires once something asks for an ability. On a REST request the MCP
		// Adapter boots at rest_api_init:15, which can be *before* anything has
		// touched the registry — leaving `$registered_names` empty, skipping
		// server creation, and 404-ing every client while the settings screen
		// still reports the endpoint as on. Touch the registry first so the
		// names are always populated by the time we read them.
		if ( function_exists( 'wp_get_abilities' ) ) {
			wp_get_abilities();
		}

		$ability_names = $this->registry->get_registered_names();

		if ( empty( $ability_names ) ) {
			return;
		}

		$plugin_name = defined( 'BDTEP_TITLE' ) ? BDTEP_TITLE : __( 'Element Pack Pro', 'bdthemes-element-pack' );

		// Transport class fallback — older MCP Adapter builds expose
		// HttpTransport at a different namespace.
		$transport_class = class_exists( '\WP\MCP\Transport\HttpTransport' )
			? \WP\MCP\Transport\HttpTransport::class
			: '\WP\MCP\Transport\Http\RestTransport';

		// Explicit error + observability handlers — newer MCP Adapter releases
		// require concrete classes rather than null.
		$error_handler = class_exists( '\WP\MCP\Infrastructure\ErrorHandling\ErrorLogMcpErrorHandler' )
			? \WP\MCP\Infrastructure\ErrorHandling\ErrorLogMcpErrorHandler::class
			: null;

		$observability = class_exists( '\WP\MCP\Infrastructure\Observability\NullMcpObservabilityHandler' )
			? \WP\MCP\Infrastructure\Observability\NullMcpObservabilityHandler::class
			: null;

		$mcp_adapter->create_server(
			'element-pack-mcp',
			'element-pack',
			'mcp',
			$plugin_name . ' ' . __( 'MCP Server', 'bdthemes-element-pack' ),
			__( 'AI tools for Element Pack — manage widgets, build pages, and configure settings.', 'bdthemes-element-pack' ),
			'v' . ( defined( 'BDTEP_VER' ) ? BDTEP_VER : '0.0.0' ),
			array( $transport_class ),
			$error_handler,
			$observability,
			$ability_names,
			array(),
			array()
		);
	}

	/**
	 * Initialize the Angie integration.
	 *
	 * @return void
	 */
	public function init_angie() {
		require_once BDTEP_PATH . 'abilities/angie/class-ep-angie.php';
		new EP_Angie( $this->registry );
	}
}

// Boot.
EP_Abilities_Bootstrap::instance();
