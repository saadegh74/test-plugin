<?php
/**
 * AI Tools Settings REST API.
 *
 * Routes (namespace element-pack/v1):
 * - GET  /ai-settings      → settings + environment flags
 * - POST /ai-settings      → update settings
 * - GET  /ai-abilities     → ability catalogue for the settings UI
 * - POST /ai-app-password  → mint an Application Password for an AI client
 *
 * @package ElementPack
 * @since 9.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class EP_AI_Settings_Api
 *
 * @since 9.9.0
 */
class EP_AI_Settings_Api {

	/**
	 * REST namespace.
	 *
	 * @var string
	 */
	const REST_NAMESPACE = 'element-pack/v1';

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * Bootstrap reference.
	 *
	 * @var EP_Abilities_Bootstrap
	 */
	private $bootstrap;

	/**
	 * Get singleton instance.
	 *
	 * @param EP_Abilities_Bootstrap|null $bootstrap Bootstrap instance.
	 * @return self
	 */
	public static function instance( $bootstrap = null ) {
		if ( null === self::$instance ) {
			self::$instance = new self( $bootstrap );
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @param EP_Abilities_Bootstrap $bootstrap Bootstrap instance.
	 */
	private function __construct( $bootstrap ) {
		$this->bootstrap = $bootstrap;

		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Register REST routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			self::REST_NAMESPACE,
			'/ai-settings',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( $this, 'get_settings' ),
					'permission_callback' => array( $this, 'permissions_check' ),
				),
				array(
					'methods'             => 'POST',
					'callback'            => array( $this, 'update_settings' ),
					'permission_callback' => array( $this, 'permissions_check' ),
				),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/ai-abilities',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_abilities' ),
				'permission_callback' => array( $this, 'permissions_check' ),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/ai-app-password',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'create_app_password' ),
				'permission_callback' => array( $this, 'permissions_check' ),
			)
		);
	}

	/**
	 * Permission check: admin capability + valid REST nonce.
	 *
	 * Rejects unauthorized or CSRF requests with a 403 before any route
	 * callback runs.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return true|WP_Error
	 */
	public function permissions_check( $request ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new \WP_Error(
				'ep_ai_rest_not_allowed',
				__( 'Sorry, you are not authorized to perform this action.', 'bdthemes-element-pack' ),
				array( 'status' => 403 )
			);
		}

		$nonce = ( $request instanceof \WP_REST_Request ) ? $request->get_header( 'X-WP-Nonce' ) : '';

		if ( ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
			return new \WP_Error(
				'ep_ai_rest_invalid_nonce',
				__( 'Invalid nonce.', 'bdthemes-element-pack' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * GET /ai-settings
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public function get_settings( $request ) {
		$settings = EP_Abilities_Bootstrap::get_settings();

		$settings['is_abilities_api_active'] = function_exists( 'wp_register_ability' );
		$settings['is_mcp_adapter_active']   = class_exists( '\WP\MCP\Core\McpAdapter' );
		// See EP_Angie::enqueue_scripts() — ANGIE_VERSION is the only signal that
		// the bridge will actually load. Elementor alone is not enough.
		$settings['is_angie_active']         = defined( 'ANGIE_VERSION' );
		$settings['dedicated_server_url']    = rest_url( 'element-pack/mcp' );
		$settings['total_abilities']         = $this->count_abilities();

		// Everything else the connect wizard needs to build a client snippet.
		// It used to be localised onto the standalone AI Tools page; the React
		// dashboard reads it from here instead.
		$user = wp_get_current_user();

		$settings['global_server_url']        = rest_url( 'mcp/mcp-adapter-default-server' );
		$settings['application_password_url'] = admin_url( 'profile.php#application-passwords-section' );
		// Drives the Connect panel's "Create password" button: when false the
		// button is replaced by the manual profile.php route plus the reason it
		// is unavailable.
		$settings['can_create_app_password']  = function_exists( 'wp_is_application_passwords_available_for_user' )
			&& $user instanceof \WP_User
			&& wp_is_application_passwords_available_for_user( $user );
		$settings['current_user']             = $user instanceof \WP_User ? $user->user_login : 'admin';
		$settings['site_url']                 = site_url();
		$settings['site_name']                = get_bloginfo( 'name' );

		return new \WP_REST_Response( $settings, 200 );
	}

	/**
	 * POST /ai-settings
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function update_settings( $request ) {
		$defaults = array(
			'enable_abilities'    => false,
			'allow_modifications' => true,
			'dedicated_server'    => false,
			'angie_enabled'       => false,
			'disabled_abilities'  => array(),
		);

		$current      = EP_Abilities_Bootstrap::get_settings();
		$allowed_keys = array_keys( $defaults );
		$params       = $request->get_json_params();

		if ( ! is_array( $params ) ) {
			return new \WP_Error(
				'ep_ai_invalid_params',
				__( 'Invalid parameters.', 'bdthemes-element-pack' ),
				array( 'status' => 400 )
			);
		}

		foreach ( $allowed_keys as $key ) {
			if ( ! isset( $params[ $key ] ) ) {
				continue;
			}

			if ( 'disabled_abilities' === $key ) {
				$current[ $key ] = is_array( $params[ $key ] )
					? array_values( array_map( 'sanitize_text_field', $params[ $key ] ) )
					: array();
			} else {
				$current[ $key ] = (bool) $params[ $key ];
			}
		}

		// Autoload disabled — this option is only needed when the AI Tools
		// settings/abilities are actually loaded, not on every request.
		update_option( EP_Abilities_Bootstrap::OPTION, $current, false );

		return new \WP_REST_Response(
			array(
				'success'  => true,
				'settings' => $current,
			),
			200
		);
	}

	/**
	 * GET /ai-abilities
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public function get_abilities( $request ) {
		// Ensure handlers are populated — wp_abilities_api_init may not have fired.
		$this->bootstrap->ensure_handlers_loaded();

		$registry = $this->bootstrap->get_registry();

		if ( ! $registry ) {
			return new \WP_REST_Response( array(), 200 );
		}

		$abilities = $registry->get_abilities_info();
		$settings  = EP_Abilities_Bootstrap::get_settings();
		$disabled  = is_array( $settings['disabled_abilities'] ) ? $settings['disabled_abilities'] : array();

		foreach ( $abilities as &$ability ) {
			$ability['is_enabled'] = ! in_array( $ability['name'], $disabled, true )
				&& ! in_array( $ability['full_name'], $disabled, true );
		}
		unset( $ability );

		return new \WP_REST_Response( $abilities, 200 );
	}

	/**
	 * POST /ai-app-password
	 *
	 * Mints an Application Password for the current user so the Connect panel
	 * can drop a ready-to-paste credential straight into the client snippet.
	 * This is the one step users previously had to leave the page for: create
	 * the password on profile.php, copy it, come back, and hand-edit the JSON.
	 *
	 * The plaintext password exists only in this response — WordPress stores
	 * a hash and can never show it again, which is why the UI warns about it.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function create_app_password( $request ) {
		if ( ! class_exists( '\WP_Application_Passwords' ) ) {
			return new \WP_Error(
				'ep_ai_app_passwords_missing',
				__( 'Application Passwords are not available on this site.', 'bdthemes-element-pack' ),
				array( 'status' => 501 )
			);
		}

		$user_id = get_current_user_id();

		if ( ! wp_is_application_passwords_available_for_user( $user_id ) ) {
			return new \WP_Error(
				'ep_ai_app_passwords_disabled',
				__( 'Application Passwords are disabled for your account. They require an HTTPS site (or a local environment), and may be switched off by a plugin or by your host.', 'bdthemes-element-pack' ),
				array( 'status' => 403 )
			);
		}

		$label = sanitize_text_field( (string) $request->get_param( 'label' ) );

		if ( '' === $label ) {
			$label = __( 'AI Client', 'bdthemes-element-pack' );
		}

		$name = $this->unique_app_password_name(
			$user_id,
			/* translators: %s: AI client name, e.g. "Claude Code". */
			sprintf( __( 'Element Pack AI — %s', 'bdthemes-element-pack' ), $label )
		);

		$created = \WP_Application_Passwords::create_new_application_password( $user_id, array( 'name' => $name ) );

		if ( is_wp_error( $created ) ) {
			return $created;
		}

		$user = get_userdata( $user_id );

		return new \WP_REST_Response(
			array(
				'success' => true,
				// Unchunked on purpose: the spaced form WordPress shows in its
				// own UI breaks env vars and shell arguments when pasted.
				'password' => $created[0],
				'name'     => $name,
				'uuid'     => isset( $created[1]['uuid'] ) ? $created[1]['uuid'] : '',
				'username' => $user ? $user->user_login : '',
			),
			200
		);
	}

	/**
	 * Build an Application Password name that does not collide with an
	 * existing one — WordPress rejects duplicates for the same user.
	 *
	 * @param int    $user_id User ID.
	 * @param string $base    Preferred name.
	 * @return string
	 */
	private function unique_app_password_name( $user_id, $base ) {
		$existing = \WP_Application_Passwords::get_user_application_passwords( $user_id );
		$taken    = array();

		foreach ( (array) $existing as $item ) {
			if ( isset( $item['name'] ) ) {
				$taken[] = $item['name'];
			}
		}

		if ( ! in_array( $base, $taken, true ) ) {
			return $base;
		}

		for ( $i = 2; $i < 100; $i++ ) {
			$candidate = $base . ' (' . $i . ')';

			if ( ! in_array( $candidate, $taken, true ) ) {
				return $candidate;
			}
		}

		return $base . ' ' . wp_generate_password( 4, false );
	}

	/**
	 * Count registered element-pack/* abilities.
	 *
	 * @return int
	 */
	private function count_abilities() {
		// When abilities are enabled, count via wp_get_abilities() (it lazily
		// fires wp_abilities_api_init). When disabled, fall back to the handler
		// catalogue so the UI can still show the total.
		if ( function_exists( 'wp_get_abilities' ) ) {
			$settings = EP_Abilities_Bootstrap::get_settings();

			if ( ! empty( $settings['enable_abilities'] ) ) {
				$count  = 0;
				$prefix = EP_Ability_Registry::PREFIX;

				foreach ( wp_get_abilities() as $ability_name => $ability ) {
					if ( 0 === strpos( $ability_name, $prefix ) ) {
						++$count;
					}
				}

				return $count;
			}
		}

		$this->bootstrap->ensure_handlers_loaded();
		$registry = $this->bootstrap->get_registry();

		return $registry ? count( $registry->get_handler_names() ) : 0;
	}
}
