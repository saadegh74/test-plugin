<?php
/**
 * AI Tools legacy page redirect.
 *
 * AI Tools used to be its own wp-admin screen with a vanilla-JS app. It is now
 * a route in the React dashboard, so the old slug only forwards there — old
 * bookmarks, and links printed by earlier releases, keep working.
 *
 * @package ElementPack
 * @since 9.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class EP_AI_Legacy_Page
 *
 * @since 9.9.0
 */
class EP_AI_Legacy_Page {

	/**
	 * Retired admin page slug.
	 *
	 * @var string
	 */
	const PAGE_SLUG = 'element_pack_ai_tools';

	/**
	 * Dashboard route the screen now lives at.
	 *
	 * @var string
	 */
	const ROUTE = '/ai-tools';

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * Get singleton instance.
	 *
	 * @param EP_Abilities_Bootstrap|null $bootstrap Bootstrap instance.
	 * @return self
	 */
	public static function instance( $bootstrap = null ) {
		if ( null === self::$instance ) {
			self::$instance = new self( $bootstrap );
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @param EP_Abilities_Bootstrap $bootstrap Bootstrap instance.
	 */
	private function __construct( $bootstrap ) {
		unset( $bootstrap );

		add_action( 'admin_init', array( $this, 'maybe_redirect' ) );
	}

	/**
	 * The dashboard URL for the AI Tools screen.
	 *
	 * @return string
	 */
	public static function url() {
		return admin_url( 'admin.php?page=element_pack_options' ) . '#' . self::ROUTE;
	}

	/**
	 * Forward the retired slug to the dashboard route.
	 *
	 * @return void
	 */
	public function maybe_redirect() {
		if ( ! isset( $_GET['page'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}

		$page = sanitize_key( wp_unslash( $_GET['page'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( self::PAGE_SLUG !== $page ) {
			return;
		}

		// A fragment survives a Location header, which is what carries the route.
		wp_redirect( self::url() ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- admin_url(), with a hash wp_safe_redirect() would strip.
		exit;
	}
}
