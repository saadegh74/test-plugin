<?php
/**
 * Plugin Info Handlers.
 *
 * info-get: plugin version, module counts, environment info.
 * info-widget: detail for one curated AI-insertable widget.
 * info-categories: module counts per tier.
 *
 * @package ElementPack
 * @since 9.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class EP_Info_Get_Handler
 *
 * @since 9.9.0
 */
class EP_Info_Get_Handler implements EP_Ability_Handler {

	/**
	 * Get the ability name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'info-get';
	}

	/**
	 * Get the wp_register_ability() args array.
	 *
	 * @return array
	 */
	public function get_registration_args() {
		return array(
			'label'               => __( 'Get Plugin Info', 'bdthemes-element-pack' ),
			'description'         => __( 'Returns Element Pack version, module counts per tier, Elementor version, and environment info.', 'bdthemes-element-pack' ),
			'category'            => 'element-pack-info',
			'permission_callback' => function () {
				return current_user_can( 'manage_options' );
			},
			'input_schema'        => array(
				'type'       => 'object',
				'properties' => (object) array(),
			),
			'output_schema'       => array(
				'type'       => 'object',
				'properties' => array(
					'plugin_name'       => array( 'type' => 'string' ),
					'version'           => array( 'type' => 'string' ),
					'elementor_version' => array( 'type' => 'string' ),
					'wordpress_version' => array( 'type' => 'string' ),
					'php_version'       => array( 'type' => 'string' ),
					'modules'           => array( 'type' => 'object' ),
				),
			),
			'meta'                => array(
				'annotations'  => array(
					'readonly'     => true,
					'destructive'  => false,
					'idempotent'   => true,
					'instructions' => 'Use this for version/compatibility questions about Element Pack.',
				),
				'show_in_rest' => true,
				'mcp'          => array( 'public' => true ),
			),
		);
	}

	/**
	 * Execute the ability.
	 *
	 * @param array $input Unused.
	 * @return array
	 */
	public function execute( $input ) {
		$lists  = \ElementPack\Admin\ModuleService::get_runtime_module_lists();
		$counts = array();

		foreach ( EP_Abilities_Bootstrap::get_tier_map() as $tier => $option_key ) {
			$options = \ElementPack\Admin\ModuleService::get_modules_option( $option_key );
			$total   = count( $lists[ $option_key ] );
			$active  = 0;

			foreach ( $lists[ $option_key ] as $entry ) {
				if ( \ElementPack\Admin\ModuleService::is_module_active( $entry['name'], $options ) ) {
					++$active;
				}
			}

			$counts[ $tier ] = array(
				'total'  => $total,
				'active' => $active,
			);
		}

		return array(
			'plugin_name'       => defined( 'BDTEP_TITLE' ) ? BDTEP_TITLE : 'Element Pack Pro',
			'version'           => defined( 'BDTEP_VER' ) ? BDTEP_VER : '',
			'elementor_version' => defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : '',
			'wordpress_version' => get_bloginfo( 'version' ),
			'php_version'       => PHP_VERSION,
			'modules'           => $counts,
		);
	}
}

/**
 * Class EP_Info_Widget_Handler
 *
 * @since 9.9.0
 */
class EP_Info_Widget_Handler implements EP_Ability_Handler {

	/**
	 * Get the ability name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'info-widget';
	}

	/**
	 * Get the wp_register_ability() args array.
	 *
	 * @return array
	 */
	public function get_registration_args() {
		return array(
			'label'               => __( 'Get Widget Details', 'bdthemes-element-pack' ),
			'description'         => __( 'Returns details for one Element Pack widget by module key or Elementor widget name: title, slug, enabled state, and whether the AI may insert it.', 'bdthemes-element-pack' ),
			'category'            => 'element-pack-info',
			'permission_callback' => function () {
				return current_user_can( 'manage_options' );
			},
			'input_schema'        => array(
				'type'       => 'object',
				'required'   => array( 'widget' ),
				'properties' => array(
					'widget' => array(
						'type'        => 'string',
						'description' => __( 'Module key ("accordion") or Elementor widget name ("bdt-accordion").', 'bdthemes-element-pack' ),
					),
				),
			),
			'output_schema'       => array(
				'type'       => 'object',
				'properties' => array(
					'found'        => array( 'type' => 'boolean' ),
					'module'       => array( 'type' => 'string' ),
					'slug'         => array( 'type' => 'string' ),
					'title'        => array( 'type' => 'string' ),
					'is_active'    => array( 'type' => 'boolean' ),
					'ai_insertable' => array( 'type' => 'boolean' ),
				),
			),
			'meta'                => array(
				'annotations'  => array(
					'readonly'     => true,
					'destructive'  => false,
					'idempotent'   => true,
					'instructions' => 'Use this before inserting a widget to confirm it exists and is enabled.',
				),
				'show_in_rest' => true,
				'mcp'          => array( 'public' => true ),
			),
		);
	}

	/**
	 * Execute the ability.
	 *
	 * @param array $input Input parameters.
	 * @return array
	 */
	public function execute( $input ) {
		$query = ! empty( $input['widget'] ) ? sanitize_text_field( $input['widget'] ) : '';

		// The curated AI-insertable set carries slug+module+title — search it first.
		foreach ( EP_Element_Helpers::get_allowed_widget_types() as $widget ) {
			$module = isset( $widget['module'] ) ? $widget['module'] : '';

			if ( $query === $widget['slug'] || ( '' !== $module && $query === $module ) ) {
				$options = \ElementPack\Admin\ModuleService::get_modules_option( 'element_pack_active_modules' );

				return array(
					'found'         => true,
					'module'        => $module,
					'slug'          => $widget['slug'],
					'title'         => $widget['title'],
					'is_active'     => '' === $module
						? true
						: (bool) \ElementPack\Admin\ModuleService::is_module_active( $module, $options ),
					'ai_insertable' => true,
				);
			}
		}

		// Fall back to the full module list (not AI-insertable but may exist).
		$module_key = preg_replace( '/^bdt-/', '', $query );
		$lists      = \ElementPack\Admin\ModuleService::get_runtime_module_lists();

		foreach ( EP_Abilities_Bootstrap::get_tier_map() as $tier => $option_key ) {
			foreach ( $lists[ $option_key ] as $entry ) {
				if ( $entry['name'] === $module_key ) {
					$options = \ElementPack\Admin\ModuleService::get_modules_option( $option_key );

					return array(
						'found'         => true,
						'module'        => $module_key,
						'slug'          => 'bdt-' . $module_key,
						'title'         => ucwords( str_replace( '-', ' ', $module_key ) ),
						'is_active'     => (bool) \ElementPack\Admin\ModuleService::is_module_active( $module_key, $options ),
						'ai_insertable' => false,
					);
				}
			}
		}

		return array(
			'found'         => false,
			'module'        => '',
			'slug'          => '',
			'title'         => '',
			'is_active'     => false,
			'ai_insertable' => false,
		);
	}
}

/**
 * Class EP_Info_Categories_Handler
 *
 * @since 9.9.0
 */
class EP_Info_Categories_Handler implements EP_Ability_Handler {

	/**
	 * Get the ability name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'info-categories';
	}

	/**
	 * Get the wp_register_ability() args array.
	 *
	 * @return array
	 */
	public function get_registration_args() {
		return array(
			'label'               => __( 'List Module Tiers', 'bdthemes-element-pack' ),
			'description'         => __( 'Lists the three Element Pack module tiers (core widgets, extensions, third-party integrations) with total and active counts per tier.', 'bdthemes-element-pack' ),
			'category'            => 'element-pack-info',
			'permission_callback' => function () {
				return current_user_can( 'manage_options' );
			},
			'input_schema'        => array(
				'type'       => 'object',
				'properties' => (object) array(),
			),
			// MCP requires an object at the top level of an output schema; a
			// bare array schema invalidates the entire tool list for strict
			// clients. Hence the named wrapper property.
			'output_schema'       => array(
				'type'       => 'object',
				'properties' => array(
					'tiers' => array(
						'type'  => 'array',
						'items' => array(
							'type'       => 'object',
							'properties' => array(
								'tier'   => array( 'type' => 'string' ),
								'label'  => array( 'type' => 'string' ),
								'total'  => array( 'type' => 'integer' ),
								'active' => array( 'type' => 'integer' ),
							),
						),
					),
				),
				'required'   => array( 'tiers' ),
			),
			'meta'                => array(
				'annotations'  => array(
					'readonly'     => true,
					'destructive'  => false,
					'idempotent'   => true,
					'instructions' => 'Use this for an overview of how many modules exist and are enabled per tier.',
				),
				'show_in_rest' => true,
				'mcp'          => array( 'public' => true ),
			),
		);
	}

	/**
	 * Execute the ability.
	 *
	 * @param array $input Unused.
	 * @return array
	 */
	public function execute( $input ) {
		$labels = array(
			'core'        => __( 'Core Widgets', 'bdthemes-element-pack' ),
			'extension'   => __( 'Extensions', 'bdthemes-element-pack' ),
			'third-party' => __( 'Third Party Integrations', 'bdthemes-element-pack' ),
		);

		$lists  = \ElementPack\Admin\ModuleService::get_runtime_module_lists();
		$result = array();

		foreach ( EP_Abilities_Bootstrap::get_tier_map() as $tier => $option_key ) {
			$options = \ElementPack\Admin\ModuleService::get_modules_option( $option_key );
			$total   = count( $lists[ $option_key ] );
			$active  = 0;

			foreach ( $lists[ $option_key ] as $entry ) {
				if ( \ElementPack\Admin\ModuleService::is_module_active( $entry['name'], $options ) ) {
					++$active;
				}
			}

			$result[] = array(
				'tier'   => $tier,
				'label'  => isset( $labels[ $tier ] ) ? $labels[ $tier ] : $tier,
				'total'  => $total,
				'active' => $active,
			);
		}

		return array( 'tiers' => $result );
	}
}
