<?php
/**
 * Widget Toggle Handlers.
 *
 * Activate / deactivate / bulk-toggle Element Pack modules across the three
 * tiers (core widgets, extensions, third-party). One file, three handlers —
 * they share the tier/option plumbing in the abstract base.
 *
 * @package ElementPack
 * @since 9.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class EP_Widget_Toggle_Base
 *
 * Shared plumbing for module toggling.
 *
 * @since 9.9.0
 */
abstract class EP_Widget_Toggle_Base implements EP_Ability_Handler {

	use EP_Abilities_Helpers;

	/**
	 * Resolve a tier key to its option name.
	 *
	 * @param string $tier Tier key: core|extension|third-party.
	 * @return string|WP_Error Option key or error.
	 */
	protected function resolve_tier_option( $tier ) {
		$map = EP_Abilities_Bootstrap::get_tier_map();

		if ( ! isset( $map[ $tier ] ) ) {
			return new \WP_Error(
				'ep_ai_invalid_tier',
				sprintf(
					/* translators: %s: tier key */
					__( 'Unknown tier "%s". Use core, extension, or third-party.', 'bdthemes-element-pack' ),
					$tier
				),
				array( 'status' => 400 )
			);
		}

		return $map[ $tier ];
	}

	/**
	 * Validate that a module exists in a tier.
	 *
	 * @param string $module     Module key.
	 * @param string $option_key Tier option key.
	 * @return true|WP_Error
	 */
	protected function validate_module( $module, $option_key ) {
		$lists = \ElementPack\Admin\ModuleService::get_runtime_module_lists();
		$names = array_column( $lists[ $option_key ], 'name' );

		if ( ! in_array( $module, $names, true ) ) {
			return new \WP_Error(
				'ep_ai_module_not_found',
				sprintf(
					/* translators: 1: module key, 2: tier option */
					__( 'Module "%1$s" not found in tier "%2$s". Call widgets-list first to discover valid module keys.', 'bdthemes-element-pack' ),
					$module,
					$option_key
				),
				array( 'status' => 404 )
			);
		}

		return true;
	}

	/**
	 * Set one module's state and persist.
	 *
	 * @param string $module     Module key.
	 * @param string $option_key Tier option key.
	 * @param bool   $active     Target state.
	 * @return bool New state.
	 */
	protected function set_module_state( $module, $option_key, $active ) {
		$options = \ElementPack\Admin\ModuleService::get_modules_option( $option_key );

		if ( ! is_array( $options ) ) {
			$options = array();
		}

		$options[ $module ] = $active ? 'on' : 'off';

		// updated_option fires element_pack_flush_modules_option_cache(), so the
		// per-request cache stays correct without an explicit flush here.
		update_option( $option_key, $options );

		return $active;
	}
}

/**
 * Class EP_Widget_Activate_Handler
 *
 * @since 9.9.0
 */
class EP_Widget_Activate_Handler extends EP_Widget_Toggle_Base {

	/**
	 * Get the ability name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'widgets-activate';
	}

	/**
	 * Get the wp_register_ability() args array.
	 *
	 * @return array
	 */
	public function get_registration_args() {
		return array(
			'label'               => __( 'Activate Widget', 'bdthemes-element-pack' ),
			'description'         => __( 'Enables a specific Element Pack module by its key. Pass the tier (core, extension, or third-party) the module belongs to.', 'bdthemes-element-pack' ),
			'category'            => 'element-pack-widgets',
			'permission_callback' => function () {
				return current_user_can( 'manage_options' );
			},
			'input_schema'        => array(
				'type'       => 'object',
				'required'   => array( 'module' ),
				'properties' => array(
					'module' => array(
						'type'        => 'string',
						'description' => __( 'Module key from widgets-list, e.g. "accordion".', 'bdthemes-element-pack' ),
					),
					'tier'   => array(
						'type'        => 'string',
						'enum'        => array( 'core', 'extension', 'third-party' ),
						'description' => __( 'Tier the module belongs to. Default: core.', 'bdthemes-element-pack' ),
					),
				),
			),
			'output_schema'       => array(
				'type'       => 'object',
				'properties' => array(
					'success'   => array( 'type' => 'boolean' ),
					'module'    => array( 'type' => 'string' ),
					'is_active' => array( 'type' => 'boolean' ),
				),
			),
			'meta'                => array(
				'annotations'  => array(
					'readonly'     => false,
					'destructive'  => false,
					'idempotent'   => true,
					'instructions' => 'Use this when the user asks to enable a widget or extension. Confirm the module key via widgets-list first.',
				),
				'show_in_rest' => true,
				'mcp'          => array( 'public' => true ),
			),
		);
	}

	/**
	 * Execute the ability.
	 *
	 * @param array $input Input parameters.
	 * @return array|WP_Error
	 */
	public function execute( $input ) {
		$allowed = $this->check_modifications_allowed();
		if ( is_wp_error( $allowed ) ) {
			return $allowed;
		}

		$module = ! empty( $input['module'] ) ? sanitize_key( $input['module'] ) : '';
		$tier   = ! empty( $input['tier'] ) ? sanitize_text_field( $input['tier'] ) : 'core';

		$option_key = $this->resolve_tier_option( $tier );
		if ( is_wp_error( $option_key ) ) {
			return $option_key;
		}

		$valid = $this->validate_module( $module, $option_key );
		if ( is_wp_error( $valid ) ) {
			return $valid;
		}

		$this->set_module_state( $module, $option_key, true );

		return array(
			'success'   => true,
			'module'    => $module,
			'is_active' => true,
		);
	}
}

/**
 * Class EP_Widget_Deactivate_Handler
 *
 * @since 9.9.0
 */
class EP_Widget_Deactivate_Handler extends EP_Widget_Toggle_Base {

	/**
	 * Get the ability name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'widgets-deactivate';
	}

	/**
	 * Get the wp_register_ability() args array.
	 *
	 * @return array
	 */
	public function get_registration_args() {
		return array(
			'label'               => __( 'Deactivate Widget', 'bdthemes-element-pack' ),
			'description'         => __( 'Disables a specific Element Pack module by its key. Pass the tier (core, extension, or third-party) the module belongs to.', 'bdthemes-element-pack' ),
			'category'            => 'element-pack-widgets',
			'permission_callback' => function () {
				return current_user_can( 'manage_options' );
			},
			'input_schema'        => array(
				'type'       => 'object',
				'required'   => array( 'module' ),
				'properties' => array(
					'module' => array(
						'type'        => 'string',
						'description' => __( 'Module key from widgets-list, e.g. "accordion".', 'bdthemes-element-pack' ),
					),
					'tier'   => array(
						'type'        => 'string',
						'enum'        => array( 'core', 'extension', 'third-party' ),
						'description' => __( 'Tier the module belongs to. Default: core.', 'bdthemes-element-pack' ),
					),
				),
			),
			'output_schema'       => array(
				'type'       => 'object',
				'properties' => array(
					'success'   => array( 'type' => 'boolean' ),
					'module'    => array( 'type' => 'string' ),
					'is_active' => array( 'type' => 'boolean' ),
				),
			),
			'meta'                => array(
				'annotations'  => array(
					'readonly'     => false,
					'destructive'  => false,
					'idempotent'   => true,
					'instructions' => 'Deactivating a module that is used on live pages breaks those pages. Call widgets-get-usage first and warn the user when the module is in use.',
				),
				'show_in_rest' => true,
				'mcp'          => array( 'public' => true ),
			),
		);
	}

	/**
	 * Execute the ability.
	 *
	 * @param array $input Input parameters.
	 * @return array|WP_Error
	 */
	public function execute( $input ) {
		$allowed = $this->check_modifications_allowed();
		if ( is_wp_error( $allowed ) ) {
			return $allowed;
		}

		$module = ! empty( $input['module'] ) ? sanitize_key( $input['module'] ) : '';
		$tier   = ! empty( $input['tier'] ) ? sanitize_text_field( $input['tier'] ) : 'core';

		$option_key = $this->resolve_tier_option( $tier );
		if ( is_wp_error( $option_key ) ) {
			return $option_key;
		}

		$valid = $this->validate_module( $module, $option_key );
		if ( is_wp_error( $valid ) ) {
			return $valid;
		}

		$this->set_module_state( $module, $option_key, false );

		return array(
			'success'   => true,
			'module'    => $module,
			'is_active' => false,
		);
	}
}

/**
 * Class EP_Widget_Bulk_Toggle_Handler
 *
 * @since 9.9.0
 */
class EP_Widget_Bulk_Toggle_Handler extends EP_Widget_Toggle_Base {

	/**
	 * Get the ability name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'widgets-bulk-toggle';
	}

	/**
	 * Get the wp_register_ability() args array.
	 *
	 * @return array
	 */
	public function get_registration_args() {
		return array(
			'label'               => __( 'Bulk Toggle Widgets', 'bdthemes-element-pack' ),
			'description'         => __( 'Activates or deactivates every module in one tier at once. Deactivating all may break the frontend where widgets are in use.', 'bdthemes-element-pack' ),
			'category'            => 'element-pack-widgets',
			'permission_callback' => function () {
				return current_user_can( 'manage_options' );
			},
			'input_schema'        => array(
				'type'       => 'object',
				'required'   => array( 'state' ),
				'properties' => array(
					'state' => array(
						'type'        => 'string',
						'enum'        => array( 'on', 'off' ),
						'description' => __( 'Target state for every module in the tier.', 'bdthemes-element-pack' ),
					),
					'tier'  => array(
						'type'        => 'string',
						'enum'        => array( 'core', 'extension', 'third-party' ),
						'description' => __( 'Tier to toggle. Default: core.', 'bdthemes-element-pack' ),
					),
				),
			),
			'output_schema'       => array(
				'type'       => 'object',
				'properties' => array(
					'success' => array( 'type' => 'boolean' ),
					'tier'    => array( 'type' => 'string' ),
					'state'   => array( 'type' => 'string' ),
					'count'   => array( 'type' => 'integer' ),
				),
			),
			'meta'                => array(
				'annotations'  => array(
					'readonly'     => false,
					'destructive'  => true,
					'idempotent'   => true,
					'instructions' => 'Ask the user for confirmation before bulk-deactivating — widgets in use on published pages will stop rendering.',
				),
				'show_in_rest' => true,
				'mcp'          => array( 'public' => true ),
			),
		);
	}

	/**
	 * Execute the ability.
	 *
	 * @param array $input Input parameters.
	 * @return array|WP_Error
	 */
	public function execute( $input ) {
		$allowed = $this->check_modifications_allowed();
		if ( is_wp_error( $allowed ) ) {
			return $allowed;
		}

		$state = ! empty( $input['state'] ) && 'on' === $input['state'] ? 'on' : 'off';
		$tier  = ! empty( $input['tier'] ) ? sanitize_text_field( $input['tier'] ) : 'core';

		$option_key = $this->resolve_tier_option( $tier );
		if ( is_wp_error( $option_key ) ) {
			return $option_key;
		}

		$lists   = \ElementPack\Admin\ModuleService::get_runtime_module_lists();
		$options = \ElementPack\Admin\ModuleService::get_modules_option( $option_key );

		if ( ! is_array( $options ) ) {
			$options = array();
		}

		$count = 0;
		foreach ( $lists[ $option_key ] as $entry ) {
			$options[ $entry['name'] ] = $state;
			++$count;
		}

		update_option( $option_key, $options );

		return array(
			'success' => true,
			'tier'    => $tier,
			'state'   => $state,
			'count'   => $count,
		);
	}
}
