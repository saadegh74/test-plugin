<?php
/**
 * Widget Usage Handlers.
 *
 * widgets-get-usage: site-wide usage counts for Element Pack widgets across
 * all Elementor content. widgets-deactivate-unused: turns off core-widget
 * modules that appear nowhere in published Elementor data.
 *
 * @package ElementPack
 * @since 9.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class EP_Widget_Usage_Handler
 *
 * @since 9.9.0
 */
class EP_Widget_Usage_Handler implements EP_Ability_Handler {

	/**
	 * Get the ability name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'widgets-get-usage';
	}

	/**
	 * Element Pack widget names that do not start with `bdt-` (legacy names
	 * such as the Lightbox widget's `lightbox`).
	 *
	 * @return string[]
	 */
	private static function unprefixed_widget_names() {
		$names = array();

		foreach ( \ElementPack\Admin\ModuleService::get_runtime_module_lists() as $entries ) {
			foreach ( (array) $entries as $entry ) {
				if ( empty( $entry['name'] ) ) {
					continue;
				}

				foreach ( \ElementPack\Admin\ModuleService::get_module_widget_names( $entry['name'] ) as $widget_name ) {
					if ( 0 !== strpos( $widget_name, 'bdt-' ) ) {
						$names[] = $widget_name;
					}
				}
			}
		}

		return array_values( array_unique( $names ) );
	}

	/**
	 * Scan all Elementor content for Element Pack widget usage.
	 *
	 * @return array<string,int> Map of Elementor widget name => usage count.
	 */
	public static function scan_usage() {
		global $wpdb;

		$extra_names = self::unprefixed_widget_names();

		// Every post that has Elementor data containing an Element Pack widget.
		$like_clauses = array( 'pm.meta_value LIKE %s' );
		$like_values  = array( '%' . $wpdb->esc_like( '"widgetType":"bdt-' ) . '%' );

		foreach ( $extra_names as $widget_name ) {
			$like_clauses[] = 'pm.meta_value LIKE %s';
			$like_values[]  = '%' . $wpdb->esc_like( '"widgetType":"' . $widget_name . '"' ) . '%';
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT pm.meta_value FROM {$wpdb->postmeta} pm
				 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				 WHERE pm.meta_key = %s
				   AND p.post_status IN ('publish','draft','pending','future','private')
				   AND ( " . implode( ' OR ', $like_clauses ) . ' )',
				array_merge( array( '_elementor_data' ), $like_values )
			)
		);

		$usage = array();
		$extra = array_fill_keys( $extra_names, true );

		foreach ( (array) $rows as $json ) {
			if ( ! is_string( $json ) || '' === $json ) {
				continue;
			}

			if ( preg_match_all( '/"widgetType":"([a-z0-9_-]+)"/', $json, $matches ) ) {
				foreach ( $matches[1] as $widget_name ) {
					if ( 0 !== strpos( $widget_name, 'bdt-' ) && ! isset( $extra[ $widget_name ] ) ) {
						continue;
					}

					$usage[ $widget_name ] = isset( $usage[ $widget_name ] ) ? $usage[ $widget_name ] + 1 : 1;
				}
			}
		}

		ksort( $usage );

		return $usage;
	}

	/**
	 * Get the wp_register_ability() args array.
	 *
	 * @return array
	 */
	public function get_registration_args() {
		return array(
			'label'               => __( 'Get Widget Usage Map', 'bdthemes-element-pack' ),
			'description'         => __( 'Returns site-wide usage counts for Element Pack widgets across all Elementor content (pages, posts, and templates). Keys are Elementor widget names (bdt-*).', 'bdthemes-element-pack' ),
			'category'            => 'element-pack-widgets',
			'permission_callback' => function () {
				return current_user_can( 'manage_options' );
			},
			'input_schema'        => array(
				'type'       => 'object',
				'properties' => array(
					'widget_slug' => array(
						'type'        => 'string',
						'description' => __( 'Optional. Filter to a single widget name, e.g. "bdt-accordion".', 'bdthemes-element-pack' ),
					),
				),
			),
			'output_schema'       => array(
				'type'       => 'object',
				'properties' => array(
					'success' => array( 'type' => 'boolean' ),
					'usage'   => array(
						'type'                 => 'object',
						'additionalProperties' => array( 'type' => 'integer' ),
					),
				),
			),
			'meta'                => array(
				'annotations'  => array(
					'readonly'     => true,
					'destructive'  => false,
					'idempotent'   => true,
					'instructions' => 'Use this to check which widgets are actively used on the site before deactivating any widget.',
				),
				'show_in_rest' => true,
				'mcp'          => array( 'public' => true ),
			),
		);
	}

	/**
	 * Execute the ability.
	 *
	 * @param array $input Optional input with widget_slug filter.
	 * @return array Result with usage map.
	 */
	public function execute( $input ) {
		$usage = self::scan_usage();

		if ( ! empty( $input['widget_slug'] ) ) {
			$filter_slug = sanitize_text_field( $input['widget_slug'] );
			$usage       = array( $filter_slug => isset( $usage[ $filter_slug ] ) ? $usage[ $filter_slug ] : 0 );
		}

		return array(
			'success' => true,
			'usage'   => $usage,
		);
	}
}

/**
 * Class EP_Widget_Deactivate_Unused_Handler
 *
 * @since 9.9.0
 */
class EP_Widget_Deactivate_Unused_Handler implements EP_Ability_Handler {

	use EP_Abilities_Helpers;

	/**
	 * Get the ability name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'widgets-deactivate-unused';
	}

	/**
	 * Get the wp_register_ability() args array.
	 *
	 * @return array
	 */
	public function get_registration_args() {
		return array(
			'label'               => __( 'Deactivate Unused Widgets', 'bdthemes-element-pack' ),
			'description'         => __( 'Disables core-widget modules that are not used in any Elementor content (pages, posts, or templates). Extensions and third-party integrations are left untouched.', 'bdthemes-element-pack' ),
			'category'            => 'element-pack-widgets',
			'permission_callback' => function () {
				return current_user_can( 'manage_options' );
			},
			'input_schema'        => array(
				'type'       => 'object',
				'properties' => array(
					'dry_run' => array(
						'type'        => 'boolean',
						'description' => __( 'When true, only report what would be deactivated without changing anything.', 'bdthemes-element-pack' ),
					),
				),
			),
			'output_schema'       => array(
				'type'       => 'object',
				'properties' => array(
					'success'     => array( 'type' => 'boolean' ),
					'dry_run'     => array( 'type' => 'boolean' ),
					'deactivated' => array(
						'type'  => 'array',
						'items' => array( 'type' => 'string' ),
					),
					'kept'        => array(
						'type'  => 'array',
						'items' => array( 'type' => 'string' ),
					),
				),
			),
			'meta'                => array(
				'annotations'  => array(
					'readonly'     => false,
					'destructive'  => true,
					'idempotent'   => true,
					'instructions' => 'Run with dry_run=true first and show the user the list before deactivating for real.',
				),
				'show_in_rest' => true,
				'mcp'          => array( 'public' => true ),
			),
		);
	}

	/**
	 * Execute the ability.
	 *
	 * Widget usage is keyed by Elementor widget name (bdt-*); modules whose
	 * widgets cannot be mapped confidently to a usage entry are kept enabled.
	 *
	 * @param array $input Input parameters.
	 * @return array|WP_Error
	 */
	public function execute( $input ) {
		$allowed = $this->check_modifications_allowed();
		if ( is_wp_error( $allowed ) ) {
			return $allowed;
		}

		$dry_run = ! empty( $input['dry_run'] );
		$usage   = EP_Widget_Usage_Handler::scan_usage();

		// Elementor widget names in use, normalised to module-key candidates.
		$used_modules = array();
		foreach ( array_keys( $usage ) as $widget_name ) {
			// bdt-accordion -> accordion; unprefixed legacy names (lightbox) stay as-is.
			$used_modules[ preg_replace( '/^bdt-/', '', $widget_name ) ] = true;
			$used_modules[ $widget_name ] = true;
		}

		$option_key = 'element_pack_active_modules';
		$lists      = \ElementPack\Admin\ModuleService::get_runtime_module_lists();
		$options    = \ElementPack\Admin\ModuleService::get_modules_option( $option_key );

		if ( ! is_array( $options ) ) {
			$options = array();
		}

		$deactivated = array();
		$kept        = array();

		foreach ( $lists[ $option_key ] as $entry ) {
			$module = $entry['name'];

			$is_active = \ElementPack\Admin\ModuleService::is_module_active( $module, $options );
			if ( ! $is_active ) {
				continue;
			}

			// A module may register several widgets or a widget name that does not
			// equal the module key. Only deactivate when NO used widget name maps
			// to this module key — prefix match keeps multi-widget modules safe.
			$in_use = isset( $used_modules[ $module ] );

			foreach ( \ElementPack\Admin\ModuleService::get_module_widget_names( $module ) as $widget_name ) {
				if ( isset( $usage[ $widget_name ] ) ) {
					$in_use = true;
				}
			}

			if ( ! $in_use ) {
				foreach ( array_keys( $used_modules ) as $used ) {
					if ( 0 === strpos( $used, $module ) || 0 === strpos( $module, $used ) ) {
						$in_use = true;
						break;
					}
				}
			}

			if ( $in_use ) {
				$kept[] = $module;
				continue;
			}

			$deactivated[] = $module;

			if ( ! $dry_run ) {
				$options[ $module ] = 'off';
			}
		}

		if ( ! $dry_run && ! empty( $deactivated ) ) {
			update_option( $option_key, $options );
		}

		return array(
			'success'     => true,
			'dry_run'     => $dry_run,
			'deactivated' => $deactivated,
			'kept'        => $kept,
		);
	}
}
