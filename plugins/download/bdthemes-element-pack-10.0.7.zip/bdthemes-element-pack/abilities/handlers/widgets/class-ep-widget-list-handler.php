<?php
/**
 * Widget List Handler.
 *
 * Returns all Element Pack modules (core widgets, extensions, third-party)
 * with their enabled/disabled status.
 *
 * @package ElementPack
 * @since 9.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class EP_Widget_List_Handler
 *
 * Implements EP_Ability_Handler for the widgets-list ability.
 *
 * @since 9.9.0
 */
class EP_Widget_List_Handler implements EP_Ability_Handler {

	/**
	 * Get the ability name.
	 *
	 * @return string Ability name without plugin prefix.
	 */
	public function get_name() {
		return 'widgets-list';
	}

	/**
	 * Get the wp_register_ability() args array.
	 *
	 * @return array Ability registration args.
	 */
	public function get_registration_args() {
		return array(
			'label'               => __( 'List Widgets', 'bdthemes-element-pack' ),
			'description'         => __( 'Lists Element Pack modules with enabled/disabled status. Three tiers: core (widgets), extension (Elementor extensions), third-party (integration widgets that need another plugin).', 'bdthemes-element-pack' ),
			'category'            => 'element-pack-widgets',
			'permission_callback' => function () {
				return current_user_can( 'manage_options' );
			},
			'input_schema'        => array(
				'type'       => 'object',
				'properties' => array(
					'tier' => array(
						'type'        => 'string',
						'enum'        => array( 'core', 'extension', 'third-party', 'all' ),
						'description' => __( 'Which tier to list. Default: all.', 'bdthemes-element-pack' ),
					),
				),
			),
			// MCP requires the top level of an output schema to be an object,
			// so the list is wrapped in a named property rather than returned
			// bare. A non-object schema here makes strict clients reject the
			// whole tool list, not just this one tool.
			'output_schema'       => array(
				'type'       => 'object',
				'properties' => array(
					'modules' => array(
						'type'  => 'array',
						'items' => array(
							'type'       => 'object',
							'properties' => array(
								'module'    => array( 'type' => 'string' ),
								'tier'      => array( 'type' => 'string' ),
								'is_active' => array( 'type' => 'boolean' ),
							),
						),
					),
				),
				'required'   => array( 'modules' ),
			),
			'meta'                => array(
				'annotations'  => array(
					'readonly'     => true,
					'destructive'  => false,
					'idempotent'   => true,
					'instructions' => 'Use this to show the user all Element Pack modules and their activation status. The module key is what you pass to widgets-activate / widgets-deactivate together with the tier.',
				),
				'show_in_rest' => true,
				'mcp'          => array( 'public' => true ),
			),
		);
	}

	/**
	 * Execute the ability.
	 *
	 * @param array $input Input parameters.
	 * @return array Array of module status objects.
	 */
	public function execute( $input ) {
		$tier   = ! empty( $input['tier'] ) ? sanitize_text_field( $input['tier'] ) : 'all';
		$result = array();

		foreach ( EP_Abilities_Bootstrap::get_tier_map() as $tier_key => $option_key ) {
			if ( 'all' !== $tier && $tier !== $tier_key ) {
				continue;
			}

			$lists   = \ElementPack\Admin\ModuleService::get_runtime_module_lists();
			$options = \ElementPack\Admin\ModuleService::get_modules_option( $option_key );

			foreach ( $lists[ $option_key ] as $entry ) {
				$result[] = array(
					'module'    => $entry['name'],
					'tier'      => $tier_key,
					'is_active' => (bool) \ElementPack\Admin\ModuleService::is_module_active( $entry['name'], $options ),
				);
			}
		}

		return array( 'modules' => $result );
	}
}
