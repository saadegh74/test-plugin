<?php
/**
 * Integrations Handlers.
 *
 * integrations-get: read the element_pack_api_settings option (keys masked).
 * integrations-update: update selected API keys.
 *
 * @package ElementPack
 * @since 9.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class EP_Integrations_Base
 *
 * @since 9.9.0
 */
abstract class EP_Integrations_Base implements EP_Ability_Handler {

	use EP_Abilities_Helpers;

	/**
	 * Whitelisted API-setting keys the AI may read/update.
	 *
	 * Group markers and OAuth blobs from the settings screen are excluded.
	 *
	 * @return string[]
	 */
	protected function allowed_keys() {
		return array(
			'google_map_key',
			'disqus_user_name',
			'open_street_map_access_token',
			'facebook_app_id',
			'facebook_app_secret',
			'google_client_id',
			'instagram_app_id',
			'instagram_app_secret',
			'instagram_access_token',
			'twitter_name',
			'twitter_consumer_key',
			'twitter_consumer_secret',
			'twitter_access_token',
			'twitter_access_token_secret',
			'recaptcha_site_key',
			'recaptcha_secret_key',
			'google_sheets_client_id',
			'google_sheets_client_secret',
			'mailchimp_api_key',
			'mailchimp_list_id',
			'yelp_client_id',
			'yelp_api_key',
			'weatherstack_api_key',
			'open_weather_api_key',
			'contact_form_email',
			'contact_form_spam_email',
			'fb_page_id',
		);
	}

	/**
	 * Keys that hold secrets and are masked on read.
	 *
	 * @return string[]
	 */
	protected function secret_keys() {
		return array(
			'google_map_key',
			'open_street_map_access_token',
			'facebook_app_secret',
			'instagram_app_secret',
			'instagram_access_token',
			// The X/Twitter API Key is a credential, not a public client id —
			// its paired secret was already masked, but leaving this half in the
			// clear defeats the point, since this output is shipped verbatim to
			// whichever third-party AI provider the site owner connected.
			'twitter_consumer_key',
			'twitter_consumer_secret',
			'twitter_access_token',
			'twitter_access_token_secret',
			'recaptcha_secret_key',
			'google_sheets_client_secret',
			'mailchimp_api_key',
			'yelp_api_key',
			'weatherstack_api_key',
			'open_weather_api_key',
		);
	}

	/**
	 * Mask a secret: keep first 4 + last 4 characters.
	 *
	 * @param string $value Raw value.
	 * @return string Masked value.
	 */
	protected function mask( $value ) {
		$len = strlen( $value );

		if ( $len <= 8 ) {
			return str_repeat( '*', $len );
		}

		return substr( $value, 0, 4 ) . str_repeat( '*', max( 4, $len - 8 ) ) . substr( $value, -4 );
	}
}

/**
 * Class EP_Integrations_Get_Handler
 *
 * @since 9.9.0
 */
class EP_Integrations_Get_Handler extends EP_Integrations_Base {

	/**
	 * Get the ability name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'integrations-get';
	}

	/**
	 * Get the wp_register_ability() args array.
	 *
	 * @return array
	 */
	public function get_registration_args() {
		return array(
			'label'               => __( 'Get Integration Settings', 'bdthemes-element-pack' ),
			'description'         => __( 'Retrieves Element Pack integration/API settings (Google Maps, reCAPTCHA, Mailchimp, weather, social keys, and more). Secret values are masked.', 'bdthemes-element-pack' ),
			'category'            => 'element-pack-settings',
			'permission_callback' => function () {
				return current_user_can( 'manage_options' );
			},
			'input_schema'        => array(
				'type'       => 'object',
				'properties' => (object) array(),
			),
			'output_schema'       => array(
				'type'       => 'object',
				'properties' => array(
					'settings' => array(
						'type'                 => 'object',
						'additionalProperties' => array(
							'type'       => 'object',
							'properties' => array(
								'value'     => array( 'type' => 'string' ),
								'is_set'    => array( 'type' => 'boolean' ),
								'is_secret' => array( 'type' => 'boolean' ),
							),
						),
					),
				),
			),
			'meta'                => array(
				'annotations'  => array(
					'readonly'     => true,
					'destructive'  => false,
					'idempotent'   => true,
					'instructions' => 'Secret values are masked and cannot be read back in full. Use is_set to tell the user whether a key is configured.',
				),
				'show_in_rest' => true,
				'mcp'          => array( 'public' => true ),
			),
		);
	}

	/**
	 * Execute the ability.
	 *
	 * @param array $input Unused.
	 * @return array
	 */
	public function execute( $input ) {
		$stored  = get_option( 'element_pack_api_settings', array() );
		$stored  = is_array( $stored ) ? $stored : array();
		$secrets = $this->secret_keys();
		$out     = array();

		foreach ( $this->allowed_keys() as $key ) {
			$raw       = isset( $stored[ $key ] ) && is_string( $stored[ $key ] ) ? $stored[ $key ] : '';
			$is_secret = in_array( $key, $secrets, true );

			$out[ $key ] = array(
				'value'     => ( '' !== $raw && $is_secret ) ? $this->mask( $raw ) : $raw,
				'is_set'    => '' !== $raw,
				'is_secret' => $is_secret,
			);
		}

		return array( 'settings' => $out );
	}
}

/**
 * Class EP_Integrations_Update_Handler
 *
 * @since 9.9.0
 */
class EP_Integrations_Update_Handler extends EP_Integrations_Base {

	/**
	 * Get the ability name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'integrations-update';
	}

	/**
	 * Get the wp_register_ability() args array.
	 *
	 * @return array
	 */
	public function get_registration_args() {
		return array(
			'label'               => __( 'Update Integration Settings', 'bdthemes-element-pack' ),
			'description'         => __( 'Updates Element Pack integration/API settings such as the Google Maps key, reCAPTCHA keys, Mailchimp API key, or weather API keys. Only whitelisted keys are accepted.', 'bdthemes-element-pack' ),
			'category'            => 'element-pack-settings',
			'permission_callback' => function () {
				return current_user_can( 'manage_options' );
			},
			'input_schema'        => array(
				'type'       => 'object',
				'required'   => array( 'settings' ),
				'properties' => array(
					'settings' => array(
						'type'                 => 'object',
						'description'          => __( 'Map of setting key => new value. Pass an empty string to clear a key.', 'bdthemes-element-pack' ),
						'additionalProperties' => array( 'type' => 'string' ),
					),
				),
			),
			'output_schema'       => array(
				'type'       => 'object',
				'properties' => array(
					'success' => array( 'type' => 'boolean' ),
					'updated' => array(
						'type'  => 'array',
						'items' => array( 'type' => 'string' ),
					),
					'skipped' => array(
						'type'  => 'array',
						'items' => array( 'type' => 'string' ),
					),
				),
			),
			'meta'                => array(
				'annotations'  => array(
					'readonly'     => false,
					'destructive'  => false,
					'idempotent'   => true,
					'instructions' => 'Never invent API keys. Only store values the user explicitly provides. Unknown keys are skipped, not saved.',
				),
				'show_in_rest' => true,
				'mcp'          => array( 'public' => true ),
			),
		);
	}

	/**
	 * Execute the ability.
	 *
	 * @param array $input Input parameters.
	 * @return array|WP_Error
	 */
	public function execute( $input ) {
		$allowed = $this->check_modifications_allowed();
		if ( is_wp_error( $allowed ) ) {
			return $allowed;
		}

		if ( empty( $input['settings'] ) || ! is_array( $input['settings'] ) ) {
			return new \WP_Error(
				'ep_ai_invalid_params',
				__( 'The settings parameter must be an object of key/value pairs.', 'bdthemes-element-pack' ),
				array( 'status' => 400 )
			);
		}

		$whitelist = $this->allowed_keys();
		$stored    = get_option( 'element_pack_api_settings', array() );
		$stored    = is_array( $stored ) ? $stored : array();

		$updated = array();
		$skipped = array();

		foreach ( $input['settings'] as $key => $value ) {
			$key = sanitize_key( $key );

			if ( ! in_array( $key, $whitelist, true ) || ! is_string( $value ) ) {
				$skipped[] = $key;
				continue;
			}

			$stored[ $key ] = sanitize_text_field( $value );
			$updated[]      = $key;
		}

		if ( ! empty( $updated ) ) {
			update_option( 'element_pack_api_settings', $stored );
		}

		return array(
			'success' => true,
			'updated' => $updated,
			'skipped' => $skipped,
		);
	}
}
