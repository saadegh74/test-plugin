<?php
/**
 * Widget Types Handler.
 *
 * Lists all widget types available for insertion into Elementor posts.
 * Unified handler replacing template-builder/list-widget-types.
 *
 * @package ElementPack
 * @since 9.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class EP_Widget_Types_Handler
 *
 * Implements EP_Ability_Handler for the builder/list-widget-types ability.
 *
 * @since 9.9.0
 */
class EP_Widget_Types_Handler implements EP_Ability_Handler {

	use EP_Abilities_Helpers;

	/**
	 * Get the ability name.
	 *
	 * @since 9.9.0
	 *
	 * @return string Ability name without plugin prefix.
	 */
	public function get_name() {
		return 'builder-list-widget-types';
	}

	/**
	 * Get the wp_register_ability() args array.
	 *
	 * @since 9.9.0
	 *
	 * @return array Ability registration args.
	 */
	public function get_registration_args() {
		return array(
			'label'               => __( 'List Available Widget Types', 'bdthemes-element-pack' ),
			'description'         => __( 'Lists all widget types that can be inserted. RECOMMENDED — Core: heading, text-editor, image, button, spacer, divider, icon-list. Element Pack: bdt-advanced-icon-box (Icon/Info Box), bdt-price-table, bdt-price-list, bdt-advanced-heading, bdt-post-grid, bdt-review-card, bdt-table.', 'bdthemes-element-pack' ),
			'category'            => 'element-pack-builder',
			'permission_callback' => function () {
				return current_user_can( 'edit_posts' );
			},
			'input_schema'        => array(
				'type'       => 'object',
				'properties' => array(
					'source' => array(
						'type'        => 'string',
						'enum'        => array( 'all', 'header-footer-elementor', 'elementor', 'ultimate-addons-for-elementor' ),
						'default'     => 'all',
						'description' => __( 'Filter by source plugin.', 'bdthemes-element-pack' ),
					),
				),
			),
			// MCP requires an object at the top level of an output schema; a
			// bare array schema invalidates the entire tool list for strict
			// clients. Hence the named wrapper property.
			'output_schema'       => array(
				'type'       => 'object',
				'properties' => array(
					'widgets' => array(
						'type'  => 'array',
						'items' => array(
							'type'       => 'object',
							'properties' => array(
								'slug'   => array( 'type' => 'string' ),
								'title'  => array( 'type' => 'string' ),
								'source' => array( 'type' => 'string' ),
							),
						),
					),
				),
				'required'   => array( 'widgets' ),
			),
			'meta'                => array(
				'annotations'  => array(
					'readonly'     => true,
					'destructive'  => false,
					'idempotent'   => true,
					'instructions' => 'Use this to discover available widget types before building layouts. The slug is what you pass as widget_type. RECOMMENDED WIDGETS: Core -- heading, text-editor, image, button, spacer, divider, icon-list, icon-box. Element Pack -- bdt-advanced-icon-box (Icon/Info Box), bdt-price-table, bdt-price-list, bdt-advanced-heading, bdt-animated-heading, bdt-post-grid, bdt-review-card, bdt-table, bdt-dual-button. Call builder/get-schema with type=widget on any widget to discover its content + style settings before building.',
				),
				'show_in_rest' => true,
				'mcp'          => array( 'public' => true ),
			),
		);
	}

	/**
	 * Execute the ability.
	 *
	 * @since 9.9.0
	 *
	 * @param array $input Validated input parameters.
	 * @return array List of widget types.
	 */
	public function execute( $input ) {
		$widgets = EP_Element_Helpers::get_allowed_widget_types();
		$source  = sanitize_text_field( $input['source'] ?? 'all' );

		if ( 'all' !== $source ) {
			$widgets = array_values(
				array_filter(
					$widgets,
					function ( $w ) use ( $source ) {
						return $w['source'] === $source;
					}
				)
			);
		}

		return array( 'widgets' => $widgets );
	}
}
