<?php
/**
 * Page Update Status Handler.
 *
 * Updates the publish/draft status of an Elementor page or post.
 *
 * @package ElementPack
 * @since 9.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class EP_Page_Update_Status_Handler
 *
 * Implements EP_Ability_Handler for the pages/update-status ability.
 *
 * @since 9.9.0
 */
class EP_Page_Update_Status_Handler implements EP_Ability_Handler {

	use EP_Abilities_Helpers;

	/**
	 * Get the ability name.
	 *
	 * @since 9.9.0
	 *
	 * @return string Ability name without plugin prefix.
	 */
	public function get_name() {
		return 'pages-update-status';
	}

	/**
	 * Get the wp_register_ability() args array.
	 *
	 * @since 9.9.0
	 *
	 * @return array Ability registration args.
	 */
	public function get_registration_args() {
		return array(
			'label'               => __( 'Update Page Status', 'bdthemes-element-pack' ),
			'description'         => __( 'Publishes or unpublishes (drafts) an Elementor page or post.', 'bdthemes-element-pack' ),
			'category'            => 'element-pack-pages',
			'permission_callback' => function () {
				return current_user_can( 'manage_options' );
			},
			'input_schema'        => array(
				'type'       => 'object',
				'required'   => array( 'post_id', 'status' ),
				'properties' => array(
					'post_id' => array(
						'type'        => 'integer',
						'description' => __( 'The page or post ID.', 'bdthemes-element-pack' ),
					),
					'status'  => array(
						'type'        => 'string',
						'enum'        => array( 'publish', 'draft' ),
						'description' => __( 'The new status: publish or draft.', 'bdthemes-element-pack' ),
					),
				),
			),
			'output_schema'       => array(
				'type'       => 'object',
				'properties' => array(
					'success'    => array( 'type' => 'boolean' ),
					'post_id'    => array( 'type' => 'integer' ),
					'old_status' => array( 'type' => 'string' ),
					'new_status' => array( 'type' => 'string' ),
				),
			),
			'meta'                => array(
				'annotations'  => array(
					'readonly'     => false,
					'destructive'  => false,
					'idempotent'   => true,
					'instructions' => 'Changes a page/post between publish and draft status. Cannot be used on trashed posts — restore them first.',
				),
				'show_in_rest' => true,
				'mcp'          => array( 'public' => true ),
			),
		);
	}

	/**
	 * Execute the ability.
	 *
	 * @since 9.9.0
	 *
	 * @param array $input Validated input parameters.
	 * @return array|WP_Error Result data or error.
	 */
	public function execute( $input ) {
		$post_id    = absint( $input['post_id'] );
		$new_status = sanitize_text_field( $input['status'] );
		$validation = $this->validate_elementor_post( $post_id );

		if ( is_wp_error( $validation ) ) {
			return $validation;
		}

		$post       = $validation;
		$old_status = $post->post_status;

		if ( 'trash' === $old_status ) {
			return new \WP_Error(
				'ep_ai_post_trashed',
				__( 'Post is in the trash. Use pages/restore first.', 'bdthemes-element-pack' ),
				array( 'status' => 400 )
			);
		}

		$result = wp_update_post(
			array(
				'ID'          => $post_id,
				'post_status' => $new_status,
			),
			true
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return array(
			'success'    => true,
			'post_id'    => $post_id,
			'old_status' => $old_status,
			'new_status' => $new_status,
		);
	}
}
