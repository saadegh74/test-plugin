<?php
/**
 * Page Delete Handler.
 *
 * Moves an Elementor page or post to the trash.
 *
 * @package ElementPack
 * @since 9.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class EP_Page_Delete_Handler
 *
 * Implements EP_Ability_Handler for the pages/delete ability.
 *
 * @since 9.9.0
 */
class EP_Page_Delete_Handler implements EP_Ability_Handler {

	use EP_Abilities_Helpers;

	/**
	 * Get the ability name.
	 *
	 * @since 9.9.0
	 *
	 * @return string Ability name without plugin prefix.
	 */
	public function get_name() {
		return 'pages-delete';
	}

	/**
	 * Get the wp_register_ability() args array.
	 *
	 * @since 9.9.0
	 *
	 * @return array Ability registration args.
	 */
	public function get_registration_args() {
		return array(
			'label'               => __( 'Delete Page', 'bdthemes-element-pack' ),
			'description'         => __( 'Moves an Elementor page or post to the trash. Does not permanently delete.', 'bdthemes-element-pack' ),
			'category'            => 'element-pack-pages',
			'permission_callback' => function () {
				return current_user_can( 'manage_options' );
			},
			'input_schema'        => array(
				'type'       => 'object',
				'required'   => array( 'post_id' ),
				'properties' => array(
					'post_id' => array(
						'type'        => 'integer',
						'description' => __( 'The page or post ID to trash.', 'bdthemes-element-pack' ),
					),
				),
			),
			'output_schema'       => array(
				'type'       => 'object',
				'properties' => array(
					'success' => array( 'type' => 'boolean' ),
					'post_id' => array( 'type' => 'integer' ),
					'message' => array( 'type' => 'string' ),
				),
			),
			'meta'                => array(
				'annotations'  => array(
					'readonly'     => false,
					'destructive'  => true,
					'idempotent'   => true,
					'instructions' => 'Moves page/post to trash. Ask user to confirm. Does not permanently delete.',
				),
				'show_in_rest' => true,
				'mcp'          => array( 'public' => true ),
			),
		);
	}

	/**
	 * Execute the ability.
	 *
	 * @since 9.9.0
	 *
	 * @param array $input Validated input parameters.
	 * @return array|WP_Error Result data or error.
	 */
	public function execute( $input ) {
		$post_id = absint( $input['post_id'] );
		$post    = get_post( $post_id );

		if ( ! $post ) {
			return new \WP_Error(
				'ep_ai_post_not_found',
				__( 'Post not found.', 'bdthemes-element-pack' ),
				array( 'status' => 404 )
			);
		}

		if ( 'elementor-hf' === $post->post_type ) {
			return new \WP_Error(
				'ep_ai_use_template_api',
				__( 'Only Elementor-enabled posts and pages are supported.', 'bdthemes-element-pack' ),
				array( 'status' => 400 )
			);
		}

		$validation = $this->validate_elementor_post( $post_id );

		if ( is_wp_error( $validation ) ) {
			return $validation;
		}

		// Deleting requires the delete capability for this specific post, not
		// merely edit (which validate_elementor_post checks).
		if ( ! current_user_can( 'delete_post', $post_id ) ) {
			return new \WP_Error(
				'ep_ai_forbidden',
				__( 'You are not allowed to delete this post.', 'bdthemes-element-pack' ),
				array( 'status' => 403 )
			);
		}

		$result = wp_trash_post( $post_id );

		if ( ! $result ) {
			return new \WP_Error(
				'ep_ai_trash_failed',
				__( 'Failed to move post to trash.', 'bdthemes-element-pack' ),
				array( 'status' => 500 )
			);
		}

		return array(
			'success' => true,
			'post_id' => $post_id,
			'message' => sprintf(
				/* translators: %s: post title */
				__( '"%s" moved to trash.', 'bdthemes-element-pack' ),
				get_the_title( $post_id )
			),
		);
	}
}
