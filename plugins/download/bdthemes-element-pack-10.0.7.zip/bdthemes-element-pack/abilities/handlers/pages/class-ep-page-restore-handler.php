<?php
/**
 * Page Restore Handler.
 *
 * Restores a trashed page or post back to its previous status.
 *
 * @package ElementPack
 * @since 9.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class EP_Page_Restore_Handler
 *
 * Implements EP_Ability_Handler for the pages/restore ability.
 *
 * @since 9.9.0
 */
class EP_Page_Restore_Handler implements EP_Ability_Handler {

	use EP_Abilities_Helpers;

	/**
	 * Get the ability name.
	 *
	 * @since 9.9.0
	 *
	 * @return string Ability name without plugin prefix.
	 */
	public function get_name() {
		return 'pages-restore';
	}

	/**
	 * Get the wp_register_ability() args array.
	 *
	 * @since 9.9.0
	 *
	 * @return array Ability registration args.
	 */
	public function get_registration_args() {
		return array(
			'label'               => __( 'Restore Page', 'bdthemes-element-pack' ),
			'description'         => __( 'Restores a trashed page or post back to its previous status.', 'bdthemes-element-pack' ),
			'category'            => 'element-pack-pages',
			'permission_callback' => function () {
				return current_user_can( 'manage_options' );
			},
			'input_schema'        => array(
				'type'       => 'object',
				'required'   => array( 'post_id' ),
				'properties' => array(
					'post_id' => array(
						'type'        => 'integer',
						'description' => __( 'The trashed page or post ID to restore.', 'bdthemes-element-pack' ),
					),
				),
			),
			'output_schema'       => array(
				'type'       => 'object',
				'properties' => array(
					'success'    => array( 'type' => 'boolean' ),
					'post_id'    => array( 'type' => 'integer' ),
					'new_status' => array( 'type' => 'string' ),
					'message'    => array( 'type' => 'string' ),
				),
			),
			'meta'                => array(
				'annotations'  => array(
					'readonly'     => false,
					'destructive'  => false,
					'idempotent'   => true,
					'instructions' => 'Restores a trashed page/post to its previous status. Only works on posts currently in the trash.',
				),
				'show_in_rest' => true,
				'mcp'          => array( 'public' => true ),
			),
		);
	}

	/**
	 * Execute the ability.
	 *
	 * @since 9.9.0
	 *
	 * @param array $input Validated input parameters.
	 * @return array|WP_Error Result data or error.
	 */
	public function execute( $input ) {
		$post_id = absint( $input['post_id'] );
		$post    = get_post( $post_id );

		if ( ! $post ) {
			return new \WP_Error(
				'ep_ai_post_not_found',
				__( 'Post not found.', 'bdthemes-element-pack' ),
				array( 'status' => 404 )
			);
		}

		// Object-level authorization: the current user must be allowed to edit
		// this specific post, not merely hold manage_options. Mirrors the check
		// in the page delete handler.
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return new \WP_Error(
				'ep_ai_forbidden',
				__( 'You are not allowed to restore this post.', 'bdthemes-element-pack' ),
				array( 'status' => 403 )
			);
		}

		if ( 'elementor-hf' === $post->post_type ) {
			return new \WP_Error(
				'ep_ai_use_template_api',
				__( 'Only Elementor-enabled posts and pages are supported.', 'bdthemes-element-pack' ),
				array( 'status' => 400 )
			);
		}

		if ( 'trash' !== $post->post_status ) {
			return new \WP_Error(
				'ep_ai_not_trashed',
				__( 'Post is not in the trash.', 'bdthemes-element-pack' ),
				array( 'status' => 400 )
			);
		}

		$result = wp_untrash_post( $post_id );

		if ( ! $result ) {
			return new \WP_Error(
				'ep_ai_restore_failed',
				__( 'Failed to restore post from trash.', 'bdthemes-element-pack' ),
				array( 'status' => 500 )
			);
		}

		$restored_post = get_post( $post_id );

		return array(
			'success'    => true,
			'post_id'    => $post_id,
			'new_status' => $restored_post->post_status,
			'message'    => sprintf(
				/* translators: %s: post title */
				__( '"%s" restored from trash.', 'bdthemes-element-pack' ),
				get_the_title( $post_id )
			),
		);
	}
}
