<?php
/**
 * Page Update Meta Handler.
 *
 * Updates title, page template, or featured image for an Elementor page or post.
 *
 * @package ElementPack
 * @since 9.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class EP_Page_Update_Meta_Handler
 *
 * Implements EP_Ability_Handler for the pages/update-meta ability.
 *
 * @since 9.9.0
 */
class EP_Page_Update_Meta_Handler implements EP_Ability_Handler {

	use EP_Abilities_Helpers;

	/**
	 * Valid page templates.
	 *
	 * @var array
	 */
	const VALID_TEMPLATES = array( 'elementor_header_footer', 'elementor_canvas', 'default' );

	/**
	 * Get the ability name.
	 *
	 * @since 9.9.0
	 *
	 * @return string Ability name without plugin prefix.
	 */
	public function get_name() {
		return 'pages-update-meta';
	}

	/**
	 * Get the wp_register_ability() args array.
	 *
	 * @since 9.9.0
	 *
	 * @return array Ability registration args.
	 */
	public function get_registration_args() {
		return array(
			'label'               => __( 'Update Page Meta', 'bdthemes-element-pack' ),
			'description'         => __( 'Updates title, page template, or featured image for an Elementor page or post.', 'bdthemes-element-pack' ),
			'category'            => 'element-pack-pages',
			'permission_callback' => function () {
				return current_user_can( 'manage_options' );
			},
			'input_schema'        => array(
				'type'       => 'object',
				'required'   => array( 'post_id' ),
				'properties' => array(
					'post_id'           => array(
						'type'        => 'integer',
						'description' => __( 'The page or post ID to update.', 'bdthemes-element-pack' ),
					),
					'title'             => array(
						'type'        => 'string',
						'description' => __( 'New page/post title.', 'bdthemes-element-pack' ),
					),
					'page_template'     => array(
						'type'        => 'string',
						'enum'        => self::VALID_TEMPLATES,
						'description' => __( 'Elementor page template: elementor_header_footer, elementor_canvas, or default.', 'bdthemes-element-pack' ),
					),
					'featured_image_id' => array(
						'type'        => 'integer',
						'description' => __( 'Attachment ID for featured image. Pass 0 to remove.', 'bdthemes-element-pack' ),
					),
				),
			),
			'output_schema'       => array(
				'type'       => 'object',
				'properties' => array(
					'success'        => array( 'type' => 'boolean' ),
					'post_id'        => array( 'type' => 'integer' ),
					'updated_fields' => array(
						'type'  => 'array',
						'items' => array( 'type' => 'string' ),
					),
				),
			),
			'meta'                => array(
				'annotations'  => array(
					'readonly'     => false,
					'destructive'  => false,
					'idempotent'   => true,
					'instructions' => 'Updates page metadata like title, page template, or featured image. Only provided fields are updated.',
				),
				'show_in_rest' => true,
				'mcp'          => array( 'public' => true ),
			),
		);
	}

	/**
	 * Execute the ability.
	 *
	 * @since 9.9.0
	 *
	 * @param array $input Validated input parameters.
	 * @return array|WP_Error Result data or error.
	 */
	public function execute( $input ) {
		$post_id    = absint( $input['post_id'] );
		$validation = $this->validate_elementor_post( $post_id );

		if ( is_wp_error( $validation ) ) {
			return $validation;
		}

		$updated_fields = array();

		// Update title.
		if ( isset( $input['title'] ) ) {
			$title  = sanitize_text_field( $input['title'] );
			$result = wp_update_post(
				array(
					'ID'         => $post_id,
					'post_title' => $title,
				),
				true
			);

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			$updated_fields[] = 'title';
		}

		// Update page template.
		if ( isset( $input['page_template'] ) ) {
			$template = sanitize_text_field( $input['page_template'] );

			if ( ! in_array( $template, self::VALID_TEMPLATES, true ) ) {
				return new \WP_Error(
					'ep_ai_invalid_template',
					__( 'Invalid page template value.', 'bdthemes-element-pack' ),
					array( 'status' => 400 )
				);
			}

			if ( 'default' === $template ) {
				delete_post_meta( $post_id, '_wp_page_template' );
			} else {
				update_post_meta( $post_id, '_wp_page_template', $template );
			}

			$updated_fields[] = 'page_template';
		}

		// Update featured image.
		if ( isset( $input['featured_image_id'] ) ) {
			$image_id = absint( $input['featured_image_id'] );

			if ( 0 === $image_id ) {
				delete_post_thumbnail( $post_id );
			} else {
				$attachment = get_post( $image_id );

				if ( ! $attachment || 'attachment' !== $attachment->post_type ) {
					return new \WP_Error(
						'ep_ai_invalid_attachment',
						__( 'Invalid attachment ID for featured image.', 'bdthemes-element-pack' ),
						array( 'status' => 400 )
					);
				}

				set_post_thumbnail( $post_id, $image_id );
			}

			$updated_fields[] = 'featured_image';
		}

		if ( empty( $updated_fields ) ) {
			return new \WP_Error(
				'ep_ai_no_fields',
				__( 'No fields provided to update.', 'bdthemes-element-pack' ),
				array( 'status' => 400 )
			);
		}

		return array(
			'success'        => true,
			'post_id'        => $post_id,
			'updated_fields' => $updated_fields,
		);
	}
}
