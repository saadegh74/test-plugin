<div
// Release BBFC83196784E060800B6D42
	class="jet-dashboard-page__after-sidebar"
	v-if="visible"
>
	<div class="jet-dashboard-page__banners">
		<jet-dashboard-banner
			v-for="( banner, index ) in bannersList"
			:key="index"
			:config="banner"
		></jet-dashboard-banner>
	</div>
</div>
