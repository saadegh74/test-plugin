<?php return array('dependencies' => array(), 'version' => '7584d716706e6257eff0');
