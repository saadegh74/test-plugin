/**
 * PowerPack Sitemap Widget with Tree View Support.
 */
(function( $ ) {
	'use strict';

	$( window ).on( 'elementor/frontend/init', () => {

		/**
		 * Tree view functionality as a jQuery plugin.
		 *
		 * Each branch gets a disclosure toggle (div[role=button]) that controls its child list.
		 */
		$.fn.treed = function( options ) {
			const openedClass = options?.openedClass || 'fa-minus-circle';
			const closedClass = options?.closedClass || 'fa-plus-circle';
			const labelFormat = options?.toggleLabel || '%s';
			const uid = options?.uid || '';

			const tree = $( this );

			// The pp-tree class is printed by PHP, so check for toggles to detect a second run.
			if ( tree.find( '.pp-tree-toggle' ).length ) {
				return;
			}

			tree.addClass( 'pp-tree' );

			function setExpanded( $toggle, expanded ) {
				$toggle.attr( 'aria-expanded', expanded ? 'true' : 'false' );
				$toggle.children( '.indicator' )
					.removeClass( `${openedClass} ${closedClass}` )
					.addClass( expanded ? openedClass : closedClass );

				$( document.getElementById( $toggle.attr( 'aria-controls' ) ) ).prop( 'hidden', ! expanded );
			}

			tree.find( 'li' ).has( 'ul' ).each( function( index ) {
				const $branch = $( this );
				const listId = `pp-sitemap-${uid}-branch-${index}`;
				// Leave out the link's screen-reader-only "(opens in a new window)" note.
				const text = $branch.children( 'a' ).first().clone().children( '.elementor-screen-only' ).remove().end().text().trim();
				const $toggle = $( '<div class="pp-tree-toggle" role="button" tabindex="0"><i class="indicator fas" aria-hidden="true"></i></div>' );

				$branch.children( 'ul' ).first().attr( 'id', listId );
				$toggle.attr( {
					'aria-controls': listId,
					'aria-label': labelFormat.replace( '%s', text ),
				} );

				$branch.addClass( 'pp-tree-branch' ).prepend( $toggle );
				setExpanded( $toggle, false );
			} );

			tree.on( 'click', '.pp-tree-toggle', function() {
				const $toggle = $( this );

				setExpanded( $toggle, 'true' !== $toggle.attr( 'aria-expanded' ) );
			} );

			tree.on( 'keydown', '.pp-tree-toggle', function( e ) {
				if ( 'Enter' === e.key || ' ' === e.key ) {
					e.preventDefault();
					$( this ).trigger( 'click' );
				}
			} );
		};

		/**
		 * Elementor Frontend Widget Handler.
		 */
		class SitemapWidget extends elementorModules.frontend.handlers.Base {

			getDefaultSettings() {
				return {
					selectors: {
						list: '.pp-sitemap-list',
					},
				};
			}

			getDefaultElements() {
				const selectors = this.getSettings( 'selectors' );

				return {
					$list: this.$element.find( selectors.list ),
				};
			}

			bindEvents() {
				const elementSettings = this.getElementSettings();
				const list = this.elements.$list;
				const tree = elementSettings.sitemap_tree;
				const style = elementSettings.sitemap_tree_style;

				if ( 'yes' !== tree || ! list.length ) {
					return;
				}

				const styleMap = {
					'plus_circle': { openedClass: 'fa-minus-circle', closedClass: 'fa-plus-circle' },
					'caret': { openedClass: 'fa-caret-down', closedClass: 'fa-caret-right' },
					'plus': { openedClass: 'fa-minus', closedClass: 'fa-plus' },
					'folder': { openedClass: 'fa-folder-open', closedClass: 'fa-folder' },
				};

				list.treed( {
					...( styleMap[ style ] || {} ),
					toggleLabel: list.closest( '.pp-sitemap-wrap' ).attr( 'data-toggle-label' ),
					uid: this.getID(),
				} );
			}
		}

		elementorFrontend.elementsHandler.attachHandler( 'pp-sitemap', SitemapWidget );
	} );
})( jQuery );
