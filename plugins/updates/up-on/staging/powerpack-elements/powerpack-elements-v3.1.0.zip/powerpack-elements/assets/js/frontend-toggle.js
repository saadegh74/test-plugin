(function ($) {
	$( window ).on( 'elementor/frontend/init', () => {
		class ToggleWidget extends elementorModules.frontend.handlers.Base {
			getDefaultSettings() {
				return {
					selectors: {
						container: '.pp-toggle-container',
						switchContainer: '.pp-toggle-switch-container',
						toggleSwitch: '.pp-toggle-switch',
						labelPrimary: '.pp-primary-toggle-label',
						labelSecondary: '.pp-secondary-toggle-label',
						sectionPrimary: '.pp-toggle-section-primary',
						sectionSecondary: '.pp-toggle-section-secondary',
						status: '.pp-toggle-status',
					},
				};
			}

			getDefaultElements() {
				const selectors = this.getSettings( 'selectors' );
				return {
					$container: this.$element.find( selectors.container ),
					$switchContainer: this.$element.find( selectors.switchContainer ),
					$toggleSwitch: this.$element.find( selectors.toggleSwitch ),
					$labelPrimary: this.$element.find( selectors.labelPrimary ),
					$labelSecondary: this.$element.find( selectors.labelSecondary ),
					$sectionPrimary: this.$element.find( selectors.sectionPrimary ),
					$sectionSecondary: this.$element.find( selectors.sectionSecondary ),
					$status: this.$element.find( selectors.status ),
				};
			}

			bindEvents() {
				this.initToggle();
				this.applyUrlState();
			}

			initToggle() {
				const self = this;

				// 'change' covers pointer and keyboard (Space) alike, and keeps the
				// native checked property as the single source of truth.
				this.elements.$toggleSwitch.on( 'change', function() {
					self.switchTo( $( this ).prop( 'checked' ) );
				} );

				this.elements.$labelPrimary.on( 'click', function() {
					self.switchTo( false );
				} );

				this.elements.$labelSecondary.on( 'click', function() {
					self.switchTo( true );
				} );
			}

			setState( isSecondary ) {
				this.elements.$toggleSwitch.prop( 'checked', isSecondary );
				this.elements.$switchContainer.toggleClass( 'pp-toggle-switch-on', isSecondary );
				this.elements.$labelPrimary.toggleClass( 'pp-toggle-active', ! isSecondary );
				this.elements.$labelSecondary.toggleClass( 'pp-toggle-active', isSecondary );
				this.elements.$sectionPrimary.toggle( ! isSecondary );
				this.elements.$sectionSecondary.toggle( isSecondary );
			}

			announceState( isSecondary ) {
				if ( ! this.elements.$status.length ) {
					return;
				}

				const $label = isSecondary ? this.elements.$labelSecondary : this.elements.$labelPrimary;

				this.elements.$status.text( $label.first().text().trim() );
			}

			switchTo( isSecondary ) {
				const $section = isSecondary ? this.elements.$sectionSecondary : this.elements.$sectionPrimary;

				this.setState( isSecondary );
				this.updateUrlState( isSecondary );
				this.announceState( isSecondary );

				$( document ).trigger( 'ppe-toggle-switched', [ $section ] );
			}

			getUrlParamConfig() {
				const $container = this.elements.$container.first();
				const name = $container.attr('data-url-param');
				if ( ! name ) {
					return null;
				}
				return {
					name: name,
					primary: $container.attr('data-url-param-primary') || 'primary',
					secondary: $container.attr('data-url-param-secondary') || 'secondary',
					updateUrl: 'yes' === $container.attr('data-update-url'),
				};
			}

			applyUrlState() {
				const config = this.getUrlParamConfig();
				if ( ! config || 'undefined' === typeof URLSearchParams ) {
					return;
				}

				const value = new URLSearchParams( window.location.search ).get( config.name );
				if ( null === value ) {
					return;
				}

				if ( value === config.secondary ) {
					this.setState( true );
				} else if ( value === config.primary ) {
					this.setState( false );
				}
			}

			updateUrlState( isSecondary ) {
				const config = this.getUrlParamConfig();
				if ( ! config || ! config.updateUrl || ! window.history || ! window.history.replaceState ) {
					return;
				}
				const url = new URL( window.location.href );
				url.searchParams.set( config.name, isSecondary ? config.secondary : config.primary );
				window.history.replaceState( {}, '', url.toString() );
			}
		}

		elementorFrontend.elementsHandler.attachHandler( 'pp-toggle', ToggleWidget );
	} );
})(jQuery);