(function($) {
	$(window).on('elementor/frontend/init', () => {
		class VideoWidget extends elementorModules.frontend.handlers.Base {
			getDefaultSettings() {
				return {
					selectors: {
						outerWrap: '.pp-video',
						videoPlay: '.pp-video-play',
						innerWrap: '.pp-video-container',
						stickyWrap: '.pp-video-sticky-wrap',
					}
				};
			}

			getDefaultElements() {
				const selectors = this.getSettings('selectors');
				return {
					$outerWrap: this.$element.find(selectors.outerWrap),
					$videoPlay: this.$element.find(selectors.videoPlay),
					$innerWrap: this.$element.find(selectors.innerWrap),
					$stickyWrap: this.$element.find(selectors.stickyWrap),
				};
			}

			bindEvents() {
				this.initVideo();
			}

			/**
			 * An event namespace unique to this widget instance, so the window and
			 * document handlers bound in initVideo() can be removed again for this
			 * widget alone.
			 */
			getEventNamespace() {
				return '.ppVideo' + this.getID();
			}

			unbindEvents() {
				if (this.observer) {
					this.observer.disconnect();
					this.observer = null;
				}

				clearTimeout(this.resizeTimer);

				$(window).off(this.getEventNamespace());
				$(document).off(this.getEventNamespace());
			}

			initVideo() {
				// An editor re-render runs bindEvents() again, so drop whatever the
				// previous pass left behind before wiring anything up.
				this.unbindEvents();

				const outerWrap = this.elements.$outerWrap,
					videoSticky = this.getElementSettings('enable_sticky'),
					viewport    = outerWrap.data('vs-viewport'),
					isLightbox  = this.elements.$videoPlay.hasClass('pp-video-play-lightbox'),
					self        = this;

				this.elements.$videoPlay.off('click').on('click', function(e) {
					e.preventDefault();

					const videoPlayer = $(this).find('.pp-video-player');
					if (!isLightbox) {
						self.videoPlay(videoPlayer, outerWrap, true);
					}
				});

				// Native click() so both the handler above and Elementor's delegated
				// lightbox listener fire, exactly as they do for a pointer click.
				this.elements.$videoPlay.off('keydown.ppvideo').on('keydown.ppvideo', function(e) {
					if ('Enter' !== e.key && ' ' !== e.key && 'Spacebar' !== e.key) {
						return;
					}

					e.preventDefault();
					this.click();
				});

				if (!this.isEdit && this.elements.$videoPlay.data('autoplay') === '1' && !isLightbox) {
					const autoplayPlayer = this.$element.find('.pp-video-player');
					self.videoPlay(autoplayPlayer, outerWrap);
				}

				if (videoSticky !== 'yes') {
					return;
				}

				const namespace = this.getEventNamespace();

				this.observer = new IntersectionObserver((entries) => {
					entries.forEach(entry => {
						if (!entry.isIntersecting && entry.boundingClientRect.top < 0) {
							outerWrap.removeClass('pp-sticky-hide').addClass('pp-sticky-apply');

							// Both only have to happen at the moment the video is
							// pinned, which is why there is no scroll handler here.
							this.applyDraggable();
							this.positionStickyPlayer();

							/**
							 * Fires on document after a video has been pinned as a sticky player.
							 *
							 * @since x.x.x
							 *
							 * @param {HTMLElement} target The `.pp-video` element that became sticky.
							 */
							$(document).trigger('pp_after_sticky_applied', [entry.target]);
						} else if (entry.isIntersecting) {
							outerWrap.removeClass('pp-sticky-apply').addClass('pp-sticky-hide');
						}
					});
				}, {
					root: null,
					rootMargin: '0px',
					threshold: viewport / 100,
				});

				this.observer.observe(outerWrap[0]);

				this.$element.find('.pp-video-sticky-close')
					.off('click.closetrigger')
					.on('click.closetrigger', () => this.closeSticky());

				$(document).on(`keydown${namespace}`, (e) => {
					if ('Escape' === e.key && outerWrap.hasClass('pp-sticky-apply')) {
						this.closeSticky();
					}
				});

				this.checkResize();

				$(window).on(`resize${namespace}`, () => {
					clearTimeout(this.resizeTimer);
					this.resizeTimer = setTimeout(() => this.checkResize(), 150);
				});
			}

			videoPlay(selector, outerWrap, moveFocus = false) {
				const iframe = $('<iframe>', {
					frameborder: '0',
					allowfullscreen: '1',
					allow: 'autoplay; encrypted-media;',
				});

				const videoSrc = selector.data('src');

				if (selector.find('iframe').length === 0) {
					if (
						outerWrap.hasClass('pp-video-type-youtube') ||
						outerWrap.hasClass('pp-video-type-vimeo') ||
						outerWrap.hasClass('pp-video-type-dailymotion')
					) {
						iframe.attr('src', videoSrc);
					}

					// An iframe needs its own accessible name, and once the player is
					// live the wrapper must stop being a button - interactive content
					// inside one is flattened into its accessible name.
					const $playControl = selector.closest('.pp-video-play');

					iframe.attr('title', $playControl.attr('aria-label') || '');

					selector.html(iframe);

					$playControl.removeAttr('role tabindex aria-label');

					if (outerWrap.hasClass('pp-video-type-hosted')) {
						const hostedParams = outerWrap.data('hosted-params') || {};

						iframe.on('load', () => {
							const iframeBody = iframe.contents().find('body');

							// The iframe body carries the UA margin that used to show
							// as a black border around self hosted video in Safari.
							iframeBody.css('margin', 0);

							const videoEl = $('<video>')
								.addClass('pp-hosted-video')
								.attr(hostedParams)
								.attr({
									src: videoSrc,
									autoplay: 'autoplay',
								})
								.css({
									width: '100%',
									height: '100%',
								});

							iframeBody.append(videoEl);
						});
					}

					if (moveFocus && iframe[0]) {
						iframe[0].focus({ preventScroll: true });
					}
				}
			}

			/**
			 * jQuery UI draggable only has to be initialised once, at the moment the
			 * player is pinned.
			 */
			applyDraggable() {
				const $stickyWrap = this.elements.$stickyWrap;

				if (this.isEdit || !$stickyWrap.length || $stickyWrap.hasClass('ui-draggable')) {
					return;
				}

				$stickyWrap.draggable({
					start: function () {
						const $this = $(this);
						$this.css({
							transform: 'none',
							top: `${$this.offset().top}px`,
							left: `${$this.offset().left}px`,
						});
					},
					containment: 'window',
				});
			}

			/**
			 * Offset the pinned player by the height of its own info bar.
			 */
			positionStickyPlayer() {
				const infobar = this.$element.find('.pp-video-sticky-infobar');

				if (!infobar.length) {
					return;
				}

				const innerWrap = this.elements.$innerWrap,
					stickyMarginBottom = this.elements.$outerWrap.data('sticky-bottom');

				let infobarHeight = infobar.outerHeight();

				if (this.$element.hasClass('pp-video-sticky-center_left') || this.$element.hasClass('pp-video-sticky-center_right')) {
					infobarHeight = Math.ceil(infobarHeight / 2);
					innerWrap.css('top', `calc(50% - ${infobarHeight}px)`);
				}

				if (
					(this.$element.hasClass('pp-video-sticky-bottom_left') || this.$element.hasClass('pp-video-sticky-bottom_right')) &&
					Number.isFinite(stickyMarginBottom)
				) {
					innerWrap.css('bottom', Math.ceil(infobarHeight) + stickyMarginBottom);
				}
			}

			closeSticky() {
				if (this.observer) {
					this.observer.unobserve(this.elements.$outerWrap[0]);
				}

				this.elements.$outerWrap.removeClass('pp-sticky-apply pp-sticky-hide');

				// The close button is now hidden, so move focus somewhere real.
				if (this.elements.$videoPlay.length) {
					this.elements.$videoPlay[0].focus({ preventScroll: true });
				}
			}

			checkResize() {
				if (!this.observer) {
					return;
				}

				const stickyDevice = this.getElementSettings('sticky_hide_on'),
					currentDeviceMode = elementorFrontend.getCurrentDeviceMode();

				if (Array.isArray(stickyDevice) && stickyDevice.includes(currentDeviceMode)) {
					this.disableSticky();
				} else {
					this.observer.observe(this.elements.$outerWrap[0]);
				}
			}

			disableSticky() {
				this.observer.unobserve(this.elements.$outerWrap[0]);
				this.elements.$outerWrap.removeClass('pp-sticky-apply pp-sticky-hide');
			}
		}

		elementorFrontend.elementsHandler.attachHandler('pp-video', VideoWidget);
	});
})(jQuery);
