(function ($) {
	$( window ).on( 'elementor/frontend/init', () => {
		class TestimonialsWidget extends elementorModules.frontend.handlers.Base {
			getDefaultSettings() {
				return {
					selectors: {
						testimonials: '.pp-testimonials',
						testimonialsWrap: '.pp-testimonials-wrap',
						swiperSlide: '.pp-testimonial-slide',
						status: '.pp-testimonials-status',
					},
					slidesPerView: {
						widescreen: 3,
						desktop: 3,
						laptop: 3,
						tablet_extra: 3,
						tablet: 2,
						mobile_extra: 2,
						mobile: 1
					}
				};
			}

			getDefaultElements() {
				const selectors = this.getSettings( 'selectors' );
				return {
					$testimonials: this.$element.find( selectors.testimonials ),
					$testimonialsWrap: this.$element.find( selectors.testimonialsWrap ),
					$swiperSlide: this.$element.find( selectors.swiperSlide ),
					$status: this.$element.find( selectors.status ),
				};
			}

			getI18n() {
				return ( 'undefined' !== typeof ppTestimonialsScript && ppTestimonialsScript.i18n )
					? ppTestimonialsScript.i18n
					: {};
			}

			prefersReducedMotion() {
				return !! ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches );
			}

			/**
			 * Autoplay and slide animation are decorative, so an explicit system-level
			 * request for reduced motion is always honoured — there is no author opt-out.
			 */
			isMotionReduced() {
				return this.prefersReducedMotion();
			}

			getSlidesCount() {
				return this.elements.$swiperSlide.length;
			}

			getDeviceSlidesPerView(device) {
				const slidesPerViewKey = 'slides_per_view' + ('desktop' === device ? '' : '_' + device);
				return Math.min(this.getSlidesCount(), +this.getSliderSettings(slidesPerViewKey) || this.getSettings('slidesPerView')[device]);
			}

			getDeviceSlidesToScroll(device) {
				const slidesToScrollKey = 'slides_to_scroll' + ('desktop' === device ? '' : '_' + device);
				return Math.min(this.getSlidesCount(), +this.getSliderSettings(slidesToScrollKey) || 1);
			}

			getCenterPadding(device) {
				// The slider settings carry center_padding as a CSS string ("0px", "30px").
				// Swiper needs a number here: a string makes it concatenate instead of add,
				// which turns snapGrid/translate into NaN and leaves every slide at opacity 1.
				const padding = elementorFrontend.utils.controls.getResponsiveControlValue(this.getSliderSettings(), 'center_padding', 'size', device);
				return parseFloat( padding ) || 0;
			}

			getSpaceBetween(device) {
				const key = 'space_between' + ('desktop' === device ? '' : '_' + device);
				const val = this.getSliderSettings(key);
				return ( undefined === val || '' === val ) ? 0 : parseInt( val, 10 ) || 0;
			}

			getSliderSettings(prop) {
				const sliderSettings = ( undefined !== this.elements.$testimonialsWrap.data('slider-settings') ) ? this.elements.$testimonialsWrap.data('slider-settings') : '';

				if ( 'undefined' !== typeof prop && 'undefined' !== sliderSettings[prop] ) {
					return sliderSettings[prop];
				}

				return sliderSettings;
			}

			getSwiperOptions() {
				const sliderSettings = this.getSliderSettings();
				const useFade        = !!sliderSettings.fade;

				const swiperOptions = {
					slidesPerView:              useFade ? 1 : this.getDeviceSlidesPerView('desktop'),
					slidesPerGroup:             useFade ? 1 : this.getDeviceSlidesToScroll('desktop'),
					spaceBetween:               this.getSpaceBetween('desktop'),
					speed:                      sliderSettings.speed,
					loop:                       !!sliderSettings.loop,
					effect:                     useFade ? 'fade' : 'slide',
					direction:                  sliderSettings.vertical ? 'vertical' : 'horizontal',
					grabCursor:                 true,
					watchSlidesProgress:        true,
					handleElementorBreakpoints: true,
				};

				if ( useFade ) {
					swiperOptions.fadeEffect = { crossFade: true };
				}

				if ( sliderSettings.center_mode ) {
					swiperOptions.centeredSlides = true;
					const padding = this.getCenterPadding('desktop');
					if ( padding ) {
						swiperOptions.slidesOffsetBefore = padding;
						swiperOptions.slidesOffsetAfter  = padding;
					}
				}

				if ( sliderSettings.arrows ) {
					swiperOptions.navigation = {
						prevEl: '.pp-arrow-prev-' + this.getID(),
						nextEl: '.pp-arrow-next-' + this.getID(),
					};
				}

				if ( sliderSettings.dots ) {
					swiperOptions.pagination = {
						el: '.pp-testimonials-pagination-' + this.getID(),
						type: 'bullets',
						clickable: true,
					};
				}

				/*
				 * Swiper 8 runs its a11y module by default, so the arrows and bullets are
				 * already named and operable, but from Swiper's English defaults, which
				 * read "1 / 3" for a slide. Passing the localised strings is what this
				 * opt-in is for.
				 *
				 * The keyboard module rides along: it listens on the document, so
				 * enabling it everywhere would let an arrow key pressed anywhere on the
				 * page move every slider currently on screen.
				 */
				if ( 'yes' === sliderSettings.a11y ) {
					const i18n = this.getI18n();

					swiperOptions.a11y = {
						enabled:                    true,
						prevSlideMessage:           i18n.prevSlide  || 'Previous slide',
						nextSlideMessage:           i18n.nextSlide  || 'Next slide',
						firstSlideMessage:          i18n.firstSlide || 'This is the first slide',
						lastSlideMessage:           i18n.lastSlide  || 'This is the last slide',
						paginationBulletMessage:    i18n.paginationBullet || 'Go to slide {{index}}',
						slideLabelMessage:          i18n.slideLabel || 'Slide {{index}} of {{slidesLength}}',
						slideRole:                  'group',
						itemRoleDescriptionMessage: i18n.slideRoleDescription || 'slide',
					};

					swiperOptions.keyboard = {
						enabled:        true,
						onlyInViewport: true,
					};
				}

				if ( ! useFade ) {
					const breakpointsSettings = {},
						breakpoints = elementorFrontend.config.responsive.activeBreakpoints;

					Object.keys(breakpoints).forEach((breakpointName) => {
						const bpValue = breakpoints[breakpointName].value;
						breakpointsSettings[bpValue] = {
							slidesPerView: this.getDeviceSlidesPerView(breakpointName),
							slidesPerGroup: this.getDeviceSlidesToScroll(breakpointName),
							spaceBetween: this.getSpaceBetween(breakpointName),
						};

						if ( sliderSettings.center_mode ) {
							const bpPadding = this.getCenterPadding(breakpointName);
							if ( bpPadding ) {
								breakpointsSettings[bpValue].slidesOffsetBefore = bpPadding;
								breakpointsSettings[bpValue].slidesOffsetAfter  = bpPadding;
							}
						}
					});

					swiperOptions.breakpoints = breakpointsSettings;
				}

				if ( ! this.isEdit && sliderSettings.autoplay && ! this.isMotionReduced() ) {
					swiperOptions.autoplay = {
						delay: sliderSettings.autoplay_speed || 3000,
						disableOnInteraction: false,
					};
				}

				return swiperOptions;
			}

			bindEvents() {
				const layout          = this.elements.$testimonials.data( 'layout' ),
					elementSettings   = this.getElementSettings();

				if ( 'carousel' === layout || 'slideshow' === layout ) {
					this.initSlider().then( () => {
						if ( 'slideshow' === layout && 'yes' === elementSettings.thumbnail_nav ) {
							this.thumbsNav();
						}

						this.bindA11y();

						this.applyVerticalHeight();

						this.ppWidgetUpdate();

						this.widgetResize();
					} );
				}

				if ( 'masonry' === layout ) {
					this.initMasonryLayout();
				}
			}

			initMasonryLayout() {
				const self = this;

				this.masonry = new PPMasonry( {
					container: this.elements.$testimonials[0],
					itemSelector: '.pp-grid-item-wrap',
				} );

				this.masonry.observeResize();

				// Measure once images are loaded, then keep it in sync as (lazy) images resolve.
				this.elements.$testimonials.imagesLoaded( function () {
					self.masonry.setReady();
					self.masonry.layout();
				} );

				this.elements.$testimonials.find('img').on('load', function () {
					self.masonry.layoutIfReady();
				} );
			}

			onElementChange() {
				if ( this.masonry && 'masonry' === this.elements.$testimonials.data('layout') ) {
					setTimeout( () => this.masonry.layout() );
				}
			}

			onDestroy() {
				if ( this.masonry ) {
					this.masonry.destroy();
				}

				if ( super.onDestroy ) {
					super.onDestroy();
				}
			}

			async initSlider() {
				const Swiper = elementorFrontend.utils.swiper;
				this.swiper = await new Swiper( this.elements.$testimonials, this.getSwiperOptions() );
			}

			/**
			 * Everything the slider needs once Swiper is up: tab order, announcements
			 * and the ways the visitor can stop the autoplay.
			 */
			bindA11y() {
				const sliderSettings = this.getSliderSettings();

				this.syncSlideVisibility();

				// Autoplay must not speak. A position announcement answers the user
				// having navigated; on a timer it just interrupts whatever they are
				// reading, every few seconds, for as long as the page is open.
				this.userNavigated = false;

				/*
				 * Swiper emits navigationNext/navigationPrev only after slideNext() has
				 * run, by which time slideChange has already come and gone, so a flag set
				 * from those events is always one move behind, so the first press of an
				 * arrow announces nothing at all. Marking the intent on the way down, in
				 * the capture phase, gets there before Swiper's own handler.
				 */
				const controls = '.pp-slider-arrow, .swiper-pagination-bullet, .pp-testimonials-thumb-item-wrap';

				const markNavigated = ( e ) => {
					const onControl = e.target.closest && e.target.closest( controls );

					if ( 'keydown' === e.type ) {
						// Swiper's keyboard module moves the slider from the arrow keys
						// wherever focus sits inside the widget, not only on a control.
						const isNavKey = [ 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown' ].indexOf( e.key ) > -1;

						if ( ! isNavKey && ! ( onControl && ( 'Enter' === e.key || ' ' === e.key || 'Spacebar' === e.key ) ) ) {
							return;
						}
					} else if ( ! onControl ) {
						return;
					}

					this.userNavigated = true;
				};

				const wrap = this.elements.$testimonialsWrap[0];

				if ( wrap ) {
					wrap.addEventListener( 'pointerdown', markNavigated, true );
					wrap.addEventListener( 'keydown', markNavigated, true );
				}

				// A swipe is deliberate too, and touchEnd lands before the transition.
				this.swiper.on( 'touchEnd', () => {
					this.userNavigated = true;
				} );

				this.swiper.on( 'slideChange', () => {
					this.announceSlidePosition();
				} );

				// Swiper settles which slides are on screen only once the movement is over.
				this.swiper.on( 'slideChangeTransitionEnd resize breakpoint', () => {
					this.syncSlideVisibility();
				} );

				/*
				 * Swiper points the arrows' aria-controls at the slides wrapper, which is
				 * correct and stays as it is; the status region is what describes the
				 * result of pressing them.
				 */
				const statusId = this.elements.$status.attr( 'id' );

				if ( statusId ) {
					this.$element.find( '.pp-slider-arrow' ).attr( 'aria-describedby', statusId );
				}

				/*
				 * params.autoplay.enabled, not the widget setting: it is true only where
				 * the autoplay actually started: never in the editor, and never once
				 * reduced motion has held it back. Swiper's autoplay.start() carries no
				 * such guard of its own, so a resume bound on a slider that is not
				 * autoplaying would set one running.
				 */
				if ( ! this.swiper.autoplay || ! this.swiper.params.autoplay || ! this.swiper.params.autoplay.enabled ) {
					return;
				}

				if ( 'yes' === sliderSettings.pause_on_hover ) {
					this.togglePauseOnHover( true );
				}

				// focusin/focusout is the keyboard equivalent of the hover pause, so it is
				// bound whenever the autoplay runs and not only where the author asked to
				// pause on hover.
				this.togglePauseOnFocus( true );
			}

			/**
			 * Slides that are off screen, and Swiper's loop clones that repeat every
			 * testimonial twice more, have to leave the accessibility tree and the tab
			 * order together. inert is what actually takes the links inside out of the
			 * tab order; aria-hidden on its own leaves focus landing on content nobody
			 * can see.
			 */
			syncSlideVisibility() {
				const $slides = this.elements.$testimonials.find( '.swiper-slide' );

				// The fade effect never sets the visibility class. Hiding every slide
				// because none is marked visible would be far worse than hiding none.
				const hasVisibilityClass = $slides.filter( '.swiper-slide-visible' ).length > 0;

				$slides.each( function () {
					// A slide is never itself a control, so it should hold no tabindex at all.
					this.removeAttribute( 'tabindex' );

					if ( ! hasVisibilityClass || this.classList.contains( 'swiper-slide-visible' ) ) {
						this.removeAttribute( 'aria-hidden' );
						this.removeAttribute( 'inert' );
					} else {
						this.setAttribute( 'aria-hidden', 'true' );
						this.setAttribute( 'inert', '' );
					}
				} );
			}

			/**
			 * Announces the slide position, but only where the user asked for the move.
			 */
			announceSlidePosition() {
				if ( ! this.userNavigated || ! this.elements.$status.length ) {
					return;
				}

				this.userNavigated = false;

				const statusFormat = this.getI18n().slideStatus || 'Showing Slide %1$s of %2$s';

				this.elements.$status.text(
					statusFormat
						.replace( '%1$s', this.swiper.realIndex + 1 )
						.replace( '%2$s', this.getSlidesCount() )
				);
			}

			startAutoplay() {
				if ( this.swiper && this.swiper.autoplay && ! this.swiper.autoplay.running ) {
					this.swiper.autoplay.start();
				}
			}

			stopAutoplay() {
				if ( this.swiper && this.swiper.autoplay && this.swiper.autoplay.running ) {
					this.swiper.autoplay.stop();
				}
			}

			togglePauseOnHover( toggleOn ) {
				if ( toggleOn ) {
					this.$element.on( {
						mouseenter: () => this.stopAutoplay(),
						mouseleave: () => this.startAutoplay(),
					} );
				} else {
					this.$element.off( 'mouseenter mouseleave' );
				}
			}

			togglePauseOnFocus( toggleOn ) {
				if ( toggleOn ) {
					this.$element.on( {
						focusin: () => this.stopAutoplay(),
						focusout: () => this.startAutoplay(),
					} );
				} else {
					this.$element.off( 'focusin focusout' );
				}
			}

			applyVerticalHeight() {
				if ( ! this.swiper || 'vertical' !== this.swiper.params.direction ) {
					return;
				}

				const $container = this.elements.$testimonials;
				const $slides    = this.elements.$swiperSlide;
				const swiper     = this.swiper;

				const recalc = () => {
					$container.css( 'height', '' );
					$slides.css( 'height', '' );

					let maxHeight = 0;
					$slides.each( function () {
						const h = $( this ).outerHeight();
						if ( h > maxHeight ) {
							maxHeight = h;
						}
					} );

					if ( ! maxHeight ) {
						return;
					}

					const spv = parseFloat( swiper.params.slidesPerView ) || 1;
					const spb = parseFloat( swiper.params.spaceBetween ) || 0;
					const totalHeight = ( maxHeight * spv ) + ( spb * Math.max( 0, spv - 1 ) );

					$container.css( 'height', totalHeight + 'px' );
					swiper.update();
				};

				$container.imagesLoaded( recalc );

				swiper.on( 'resize', recalc );
				swiper.on( 'breakpoint', recalc );
			}

			thumbsNav() {
				const thumbsNav = this.$element.find( '.pp-testimonials-thumb-item-wrap' );
				const swiper    = this.swiper;
				const self      = this;

				/*
				 * data-slide-index, not the position in the list: a testimonial with no
				 * image renders no thumbnail, which shifts every thumbnail after it and
				 * used to send both the click and the active marker to the wrong slide.
				 */
				const setActive = ( realIndex ) => {
					thumbsNav.removeClass( 'pp-active-slide' ).attr( 'aria-current', 'false' );

					thumbsNav.filter( '[data-slide-index="' + realIndex + '"]' )
						.addClass( 'pp-active-slide' )
						.attr( 'aria-current', 'true' );
				};

				setActive( swiper.realIndex );

				swiper.on( 'slideChange', function () {
					setActive( swiper.realIndex );
				});

				thumbsNav.on( 'click', function ( e ) {
					e.preventDefault();

					const index = parseInt( $( this ).attr( 'data-slide-index' ), 10 ) || 0;

					self.userNavigated = true;

					swiper.slideToLoop ? swiper.slideToLoop( index ) : swiper.slideTo( index );
				});

				/*
				 * The thumbnails carry role=button, so Enter and Space have to be wired
				 * up by hand; Left/Right move between them as expected of a button group.
				 */
				thumbsNav.on( 'keydown', function ( e ) {
					if ( 'Enter' === e.key || ' ' === e.key || 'Spacebar' === e.key ) {
						// Space would scroll the page.
						e.preventDefault();
						$( this ).trigger( 'click' );
						return;
					}

					if ( 'ArrowRight' !== e.key && 'ArrowLeft' !== e.key ) {
						return;
					}

					e.preventDefault();

					const index = thumbsNav.index( this ),
						next    = ( 'ArrowRight' === e.key ) ? index + 1 : index - 1;

					thumbsNav.eq( ( next + thumbsNav.length ) % thumbsNav.length ).trigger( 'focus' ).trigger( 'click' );
				});
			}

			widgetResize() {
				const testimonialsWrap = this.elements.$testimonialsWrap;
				const swiper           = this.swiper;

				if ( elementorFrontend.isEditMode ) {
					if ( 'undefined' !== typeof ResizeObserver && testimonialsWrap[0] ) {
						const ro = new ResizeObserver( function() {
							swiper.update();
						});
						ro.observe( testimonialsWrap[0] );
					}
				}
			}

			ppWidgetUpdate() {
				const swiper = this.swiper;
				const $triggers = [
					'ppe-tabs-switched',
					'ppe-toggle-switched',
					'ppe-accordion-switched',
					'ppe-popup-opened',
				];

				$triggers.forEach(function(trigger) {
					if ( 'undefined' !== typeof trigger ) {
						$(document).on(trigger, function(e, wrap) {
							if ( 'ppe-popup-opened' == trigger ) {
								wrap = $('.pp-modal-popup-' + wrap);
							}

							if ( wrap.find( '.pp-testimonials' ).length > 0 ) {
								setTimeout(function() {
									swiper.update();
								}, 100);
							}
						});
					}
				});
			}
		}

		elementorFrontend.elementsHandler.attachHandler( 'pp-testimonials', TestimonialsWidget );
	} );
})(jQuery);
