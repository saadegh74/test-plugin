(function ($) {
	$( window ).on( 'elementor/frontend/init', () => {
		class TabbedGalleryWidget extends elementorModules.frontend.handlers.Base {
			getDefaultSettings() {
				return {
					selectors: {
						swiperContainer: '.pp-swiper-slider',
						swiperSlide: '.swiper-slide',
					},
					slidesPerView: {
						widescreen: 3,
						desktop: 3,
						laptop: 3,
						tablet_extra: 3,
						tablet: 2,
						mobile_extra: 2,
						mobile: 1
					},
					effect: 'slide'
				};
			}

			getDefaultElements() {
				const selectors = this.getSettings( 'selectors' );
				return {
					$swiperContainer: this.$element.find( selectors.swiperContainer ),
					$swiperSlide: this.$element.find( selectors.swiperSlide ),
				};
			}

			getSliderSettings(prop) {
				const sliderSettings = ( undefined !== this.elements.$swiperContainer.data('slider-settings') ) ? this.elements.$swiperContainer.data('slider-settings') : '';

				if ( 'undefined' !== typeof prop && 'undefined' !== sliderSettings[prop] ) {
					return sliderSettings[prop];
				}

				return sliderSettings;
			}

			getSlidesCount() {
				return this.elements.$swiperSlide.length;
			}

			getEffect() {
				return ( this.getSliderSettings('effect') || this.getSettings('effect') );
			}

			getDeviceSlidesPerView(device) {
				const slidesPerViewKey = 'slides_per_view' + ('desktop' === device ? '' : '_' + device);
				return Math.min(this.getSlidesCount(), +this.getSliderSettings(slidesPerViewKey) || this.getSettings('slidesPerView')[device]);
			}

			getSlidesPerView(device) {
				if ('slide' === this.getEffect()) {
					return this.getDeviceSlidesPerView(device);
				}
				return 1;
			}

			getDeviceSlidesToScroll(device) {
				const slidesToScrollKey = 'slides_to_scroll' + ('desktop' === device ? '' : '_' + device);
				return Math.min(this.getSlidesCount(), +this.getElementSettings(slidesToScrollKey) || 1);
			}

			getSlidesToScroll(device) {
				if ('slide' === this.getEffect()) {
					return this.getDeviceSlidesToScroll(device);
				}
				return 1;
			}

			getSpaceBetween(device) {
				let propertyName = 'space_between';
				if (device && 'desktop' !== device) {
					propertyName += '_' + device;
				}
				return elementorFrontend.utils.controls.getResponsiveControlValue(this.getSliderSettings(), 'space_between', 'size', device) || 0;
			}

			getI18n() {
				return ( 'undefined' !== typeof ppTabbedGalleryScript && ppTabbedGalleryScript.i18n )
					? ppTabbedGalleryScript.i18n
					: {};
			}

			prefersReducedMotion() {
				return !! ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches );
			}

			/**
			 * Autoplay and slide animation are decorative, so an explicit system-level
			 * request for reduced motion is always honoured — there is no author opt-out.
			 */
			isMotionReduced() {
				return this.prefersReducedMotion();
			}

			getSwiperOptions() {
				const sliderSettings = this.getSliderSettings();
				const i18n = this.getI18n();
				// const swiperOptions = ( undefined !== this.elements.$swiperContainer.data('slider-settings') ) ? this.elements.$swiperContainer.data('slider-settings') : '';

				const swiperOptions = {
					grabCursor:                'yes' === sliderSettings.grab_cursor,
					// initialSlide:               this.getInitialSlide(),
					slidesPerView:              this.getSlidesPerView('desktop'),
					slidesPerGroup:             this.getSlidesToScroll('desktop'),
					spaceBetween:               this.getSpaceBetween(),
					loop:                       'yes' === sliderSettings.loop,
					centeredSlides:             'yes' === sliderSettings.centered_slides,
					speed:                      this.isMotionReduced() ? 0 : sliderSettings.speed,
					autoHeight:                 sliderSettings.auto_height,
					effect:                     this.getEffect(),
					watchSlidesVisibility:      true,
					watchSlidesProgress:        true,
					preventClicksPropagation:   false,
					slideToClickedSlide:        true,
					observer:                   true,
					observeParents:             true,
					handleElementorBreakpoints: true,
					/*
					 * Swiper's a11y module is what makes the arrows and pagination
					 * bullets focusable and operable with Enter/Space — they are
					 * div[role=button], which fires no click from the keyboard.
					 */
					a11y: {
						enabled:                 true,
						prevSlideMessage:        i18n.prevSlide || 'Previous slide',
						nextSlideMessage:        i18n.nextSlide || 'Next slide',
						firstSlideMessage:       i18n.firstSlide || 'This is the first slide',
						lastSlideMessage:        i18n.lastSlide || 'This is the last slide',
						paginationBulletMessage: i18n.paginationBullet || 'Go to slide {{index}}',
						slideLabelMessage:       i18n.slideLabel || 'Slide {{index}} of {{slidesLength}}',
						itemRoleDescriptionMessage: i18n.slideRoleDescription || 'slide'
					},
					keyboard: {
						enabled: true,
						onlyInViewport: true
					}
				};

				if ( 'fade' === this.getEffect() ) {
					swiperOptions.fadeEffect = {
						crossFade: true,
					};
				}

				if ( sliderSettings.show_arrows ) {
					var prevEle = ( this.isEdit ) ? '.elementor-swiper-button-prev' : '.swiper-button-prev-' + this.getID();
					var nextEle = ( this.isEdit ) ? '.elementor-swiper-button-next' : '.swiper-button-next-' + this.getID();

					swiperOptions.navigation = {
						prevEl: prevEle,
						nextEl: nextEle,
					};
				}

				if ( sliderSettings.pagination ) {
					var paginationEle = ( this.isEdit ) ? '.swiper-pagination' : '.swiper-pagination-' + this.getID();

					swiperOptions.pagination = {
						el: paginationEle,
						type: sliderSettings.pagination,
						clickable: true
					};
				}

				if ('cube' !== this.getEffect()) {
					const breakpointsSettings = {},
					breakpoints = elementorFrontend.config.responsive.activeBreakpoints;

					Object.keys(breakpoints).forEach(breakpointName => {
						breakpointsSettings[breakpoints[breakpointName].value] = {
							slidesPerView: this.getSlidesPerView(breakpointName),
							slidesPerGroup: this.getSlidesToScroll(breakpointName),
						};

						if ( this.getSpaceBetween(breakpointName) ) {
							breakpointsSettings[breakpoints[breakpointName].value].spaceBetween = this.getSpaceBetween(breakpointName);
						}
					});

					swiperOptions.breakpoints = breakpointsSettings;
				}

				// Reduced motion means no self-starting movement at all.
				if ( !this.isEdit && sliderSettings.autoplay && !this.isMotionReduced() ) {
					swiperOptions.autoplay = {
						delay: sliderSettings.autoplay_speed,
						disableOnInteraction: 'yes' === sliderSettings.pause_on_interaction
					};
				}

				return swiperOptions;
			}

			bindEvents() {
				this.initSlider();
			}

			async initSlider() {
				const elementSettings = this.getElementSettings();

				const Swiper = elementorFrontend.utils.swiper;
    			this.swiper = await new Swiper(this.elements.$swiperContainer, this.getSwiperOptions());

				if ('yes' === elementSettings.pause_on_hover) {
					this.togglePauseOnHover(true);
				}

				this.initTabs();

				this.updateSlideA11y();

				this.initFancybox();
			}

			initTabs() {
				let tabsNav = this.$element.find( '.pp-gallery-filters .pp-gallery-filter' ),
					self = this;
				const sliderOptions = this.getSwiperOptions();
				const sliderSettings = this.getSliderSettings();

				this.setActiveTab( tabsNav, tabsNav.eq(0) );

				if ( 'undefined' !== typeof this.swiper ) {
					this.swiper.on( 'slideChange', function () {
						var currentSlide = self.$element.find( '.swiper-slide.swiper-slide-active' ).data( 'swiper-slide-index' );
						var nextSlide    = self.$element.find( '.swiper-slide.swiper-slide-next' ).data( 'swiper-slide-index' );

						var tabGroupCurrent = tabsNav.eq( currentSlide ).data('group'),
							tabGroupNext    = tabsNav.eq( nextSlide ).data('group');

						if ( tabGroupCurrent !== tabGroupNext ) {
							var $group = tabsNav.eq( nextSlide ).data('group');
							self.setActiveTab( tabsNav, tabsNav.filter('[data-group="' + $group + '"]') );
						}
					});

					this.swiper.on( 'slideChangeTransitionEnd', function () {
						self.updateSlideA11y();
					});

					this.swiper.on( 'resize breakpoint', function () {
						self.updateSlideA11y();
					});

					// Spacers carry the same class for index parity, but only the real
					// buttons are interactive.
					tabsNav.filter( '[role="button"]' ).on( 'click', function ( e ) {
						e.preventDefault();

						var currentSlide;

						if ( ( $( window ).width() <= 480 ) && sliderSettings.slides_per_view_mobile <= 2 ) {
							currentSlide = $(this).data('index') + parseInt( sliderSettings.slides_per_view_mobile );
						} else if ( ( $( window ).width() <= 768 ) && sliderSettings.slides_per_view_tablet <= 2 ) {
							currentSlide = $(this).data('index') + parseInt( sliderSettings.slides_per_view_tablet );
						} else {
							currentSlide = $(this).data('index') + parseInt( sliderOptions.slidesPerView );
						}

						self.setActiveTab( tabsNav, $(this) );

						self.swiper.slideTo( currentSlide );
					});

					// The filters carry role="button", so Enter and Space have to be
					// wired up by hand; Left/Right move between them as expected of a
					// button group.
					tabsNav.filter( '[role="button"]' ).on( 'keydown', function ( e ) {
						if ( 'Enter' === e.key || ' ' === e.key || 'Spacebar' === e.key ) {
							// Space would scroll the page.
							e.preventDefault();
							$( this ).trigger( 'click' );
							return;
						}

						if ( 'ArrowRight' !== e.key && 'ArrowLeft' !== e.key ) {
							return;
						}

						e.preventDefault();

						const buttons = tabsNav.filter( '[role="button"]' ),
							index     = buttons.index( this ),
							next      = ( 'ArrowRight' === e.key ) ? index + 1 : index - 1;

						buttons.eq( ( next + buttons.length ) % buttons.length ).trigger( 'focus' ).trigger( 'click' );
					});
				}
			}

			setActiveTab( tabsNav, $active ) {
				tabsNav.removeClass( 'pp-active-slide' );
				tabsNav.filter( '[role="button"]' ).attr( 'aria-current', 'false' );

				$active.addClass( 'pp-active-slide' );
				$active.filter( '[role="button"]' ).attr( 'aria-current', 'true' );

				this.announceGroup( $active.filter( '[role="button"]' ).first() );
			}

			/**
			 * Keep slides that are scrolled out of view, and Swiper's loop clones,
			 * out of the tab order — otherwise focus lands on content nobody can see.
			 */
			updateSlideA11y() {
				this.elements.$swiperContainer.find( '.swiper-slide' ).each( function () {
					const $slide    = $( this ),
						isDuplicate = this.classList.contains( 'swiper-slide-duplicate' ),
						isVisible   = this.classList.contains( 'swiper-slide-visible' ) && ! isDuplicate;

					this.setAttribute( 'aria-hidden', isVisible ? 'false' : 'true' );

					const $focusable = $slide.find( 'a, button, [tabindex]' );

					if ( isVisible ) {
						$focusable.removeAttr( 'tabindex' );
					} else {
						$focusable.attr( 'tabindex', '-1' );
					}
				});
			}

			/**
			 * Announce the group change. Tab activation and swiping both bypass
			 * Swiper's own navigation notifications, so nothing else reports it.
			 */
			announceGroup( $button ) {
				const $status = this.$element.find( '.pp-tabbed-gallery-status' );

				if ( ! $status.length || ! $button.length ) {
					return;
				}

				const i18n = this.getI18n(),
					format = i18n.status || 'Showing %s',
					label  = $.trim( $button.find( '.pp-gallery-filter-label' ).text() );

				if ( '' === label ) {
					return;
				}

				$status.text( format.replace( '%s', label ) );
			}

			togglePauseOnHover(toggleOn) {
				if (toggleOn) {
					// focusin/focusout is the keyboard equivalent of the hover pause.
					this.elements.$swiperContainer.on({
						mouseenter: () => {
							this.swiper.autoplay.stop();
						},
						mouseleave: () => {
							this.swiper.autoplay.start();
						},
						focusin: () => {
							this.swiper.autoplay.stop();
						},
						focusout: () => {
							this.swiper.autoplay.start();
						}
					});
				} else {
					this.elements.$swiperContainer.off('mouseenter mouseleave focusin focusout');
				}
			}

			initFancybox() {
				// The class and the data-fancybox value both have to match what
				// render_gallery_items() actually prints.
				const sliderId       = 'pp-tabbed-gallery-' + this.getID(),
					lightboxSelector = '.swiper-slide:not(.swiper-slide-duplicate) .pp-tabbed-gallery-item-link[data-fancybox="' + sliderId + '"]';

				if ( $(lightboxSelector).length > 0 ) {
					$(lightboxSelector).fancybox({
						loop: true
					} );
				}
			}
		}

		elementorFrontend.elementsHandler.attachHandler( 'pp-tabbed-gallery', TabbedGalleryWidget );
	} );
})(jQuery);