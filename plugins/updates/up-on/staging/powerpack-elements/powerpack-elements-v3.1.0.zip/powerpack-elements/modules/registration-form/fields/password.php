<div class="pp-rf-field-inner">
	<input
		type="password" 
		class="pp-rf-control elementor-field elementor-size-sm elementor-size-<?php echo esc_attr( $settings['input_size'] ); ?> form-field-password elementor-field-textual" 
		name="<?php echo esc_attr( $field_name ); ?>" 
		id="<?php echo esc_attr( $field_id ); ?>" 
		value="" 
		placeholder="<?php echo esc_attr( $field['placeholder'] ); ?>" 
		autocomplete="new-password" 
		autocorrect="off" 
		autocapitalize="off" 
		spellcheck="false" 
		required="required" 
		aria-required="true" 
		aria-invalid="false" 
		aria-describedby="<?php echo esc_attr( $field_id ); ?>-error <?php echo esc_attr( $field_id ); ?>-error-inline <?php echo esc_attr( $field_id ); ?>-pws" 
	/>
	<?php if ( ! empty( $field['password_toggle'] ) && 'yes' === $field['password_toggle'] ) { ?>
	<button type="button" class="pp-rf-toggle-pw hide-if-no-js" aria-pressed="false" aria-controls="<?php echo esc_attr( $field_id ); ?>" aria-label="<?php esc_attr_e( 'Show password', 'powerpack' ); ?>">
		<span class="fa far fa-eye" aria-hidden="true"></span>
	</button>
	<?php } ?>
</div>
<div class="pp-rf-pws-status" id="<?php echo esc_attr( $field_id ); ?>-pws" role="status" aria-live="polite" aria-atomic="true"></div>
