<?php
namespace PowerpackElements\Modules\Logos\Widgets;

use PowerpackElements\Base\Powerpack_Widget;
use PowerpackElements\Classes\PP_Helper;
use PowerpackElements\Classes\PP_Config;

// Elementor Classes
use Elementor\Controls_Manager;
use Elementor\Control_Media;
use Elementor\Utils;
use Elementor\Repeater;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Image_Size;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Logo Grid Widget
 */
class Logo_Grid extends Powerpack_Widget {

	/**
	 * Retrieve logo grid widget name.
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return parent::get_widget_name( 'Logo_Grid' );
	}

	/**
	 * Retrieve logo grid widget title.
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return parent::get_widget_title( 'Logo_Grid' );
	}

	/**
	 * Retrieve logo grid widget icon.
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return parent::get_widget_icon( 'Logo_Grid' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 1.4.13.1
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return parent::get_widget_keywords( 'Logo_Grid' );
	}

	/**
	 * Whether the widget renders dynamic content.
	 *
	 * @since 2.10.19
	 * @access protected
	 *
	 * @return bool False — content depends only on widget settings.
	 */
	protected function is_dynamic_content(): bool {
		return false;
	}

	/**
	 * Get style dependencies.
	 *
	 * Retrieve the list of style dependencies the widget requires.
	 *
	 * @since 2.11.0
	 * @access public
	 *
	 * @return array Widget style dependencies.
	 */
	public function get_style_depends(): array {
		return [ 'widget-pp-logo-grid' ];
	}

	/**
	 * Whether the widget should be wrapped in an inner wrapper element.
	 *
	 * Disabled when Elementor's "Optimized Markup" experiment is active so the
	 * widget output participates in the leaner DOM.
	 *
	 * @since 2.11.8
	 * @access public
	 *
	 * @return bool
	 */
	public function has_widget_inner_wrapper(): bool {
		return ! PP_Helper::is_feature_active( 'e_optimized_markup' );
	}

	/**
	 * Register logo grid widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 2.0.3
	 * @access protected
	 */
	protected function register_controls() {
		/* Content Tab */
		$this->register_content_logo_grid_controls();

		/* Style Tab */
		$this->register_style_logos_controls();
		$this->register_style_title_controls();
	}

	/**
	 * Register the Logo Grid content section controls.
	 *
	 * @access protected
	 */
	protected function register_content_logo_grid_controls() {
		$this->start_controls_section(
			'section_logo_grid',
			[
				'label' => esc_html__( 'Logo Grid', 'powerpack' ),
			]
		);

		$repeater = new Repeater();

		$repeater->start_controls_tabs( 'items_repeater' );

		$repeater->start_controls_tab( 'tab_content', [ 'label' => esc_html__( 'Content', 'powerpack' ) ] );

			$repeater->add_control(
				'logo_image',
				[
					'label'             => esc_html__( 'Image', 'powerpack' ),
					'type'              => Controls_Manager::MEDIA,
					'dynamic'           => [
						'active'   => true,
					],
					'default'           => [
						'url' => Utils::get_placeholder_image_src(),
					],
				]
			);

			$repeater->add_control(
				'title',
				[
					'label'             => esc_html__( 'Title', 'powerpack' ),
					'type'              => Controls_Manager::TEXT,
					'dynamic'           => [
						'active'   => true,
					],
				]
			);

			$repeater->add_control(
				'link',
				[
					'label'             => esc_html__( 'Link', 'powerpack' ),
					'type'              => Controls_Manager::URL,
					'dynamic'           => [
						'active'   => true,
					],
					'placeholder'       => 'https://www.your-link.com',
					'default'           => [
						'url' => '',
					],
				]
			);

		$repeater->end_controls_tab();

		$repeater->start_controls_tab( 'tab_style', [ 'label' => esc_html__( 'Style', 'powerpack' ) ] );

			$repeater->add_control(
				'custom_style',
				[
					'label'             => esc_html__( 'Custom Style', 'powerpack' ),
					'type'              => Controls_Manager::SWITCHER,
					'description'       => esc_html__( 'Add custom styles which will affect only this item', 'powerpack' ),
					'default'           => '',
					'label_on'          => esc_html__( 'On', 'powerpack' ),
					'label_off'         => esc_html__( 'Off', 'powerpack' ),
					'return_value'      => 'yes',
				]
			);

			$repeater->add_control(
				'custom_style_target',
				[
					'label'                => esc_html__( 'Apply Styles To', 'powerpack' ),
					'type'                 => Controls_Manager::SELECT,
					'default'              => 'container',
					'options'              => [
						'logo'      => esc_html__( 'Logo Image', 'powerpack' ),
						'container' => esc_html__( 'Logo Container', 'powerpack' ),
					],
					'condition'          => [
						'custom_style' => 'yes',
					],
				]
			);

			$repeater->add_control(
				'custom_logo_wrapper_bg',
				[
					'label'              => esc_html__( 'Background Color', 'powerpack' ),
					'type'               => Controls_Manager::COLOR,
					'default'            => '',
					'selectors'          => [
						'{{WRAPPER}} {{CURRENT_ITEM}}.pp-logo-grid-item-custom, {{WRAPPER}} {{CURRENT_ITEM}} .pp-logo-grid-item-custom' => 'background-color: {{VALUE}}',
					],
					'condition'          => [
						'custom_style'   => 'yes',
					],
				]
			);

			$repeater->add_control(
				'custom_logo_wrapper_border_type',
				[
					'label'                => esc_html__( 'Border Type', 'powerpack' ),
					'type'                 => Controls_Manager::SELECT,
					'default'              => '',
					'options'              => [
						''       => esc_html__( 'None', 'powerpack' ),
						'solid'  => esc_html__( 'Solid', 'powerpack' ),
						'double' => esc_html__( 'Double', 'powerpack' ),
						'dotted' => esc_html__( 'Dotted', 'powerpack' ),
						'dashed' => esc_html__( 'Dashed', 'powerpack' ),
						'groove' => esc_html__( 'Groove', 'powerpack' ),
					],
					'selectors'             => [
						'{{WRAPPER}} {{CURRENT_ITEM}}.pp-logo-grid-item-custom, {{WRAPPER}} {{CURRENT_ITEM}} .pp-logo-grid-item-custom' => 'border-style: {{VALUE}};',
					],
					'condition'          => [
						'custom_style'   => 'yes',
					],
				]
			);

			$repeater->add_control(
				'custom_logo_border_width',
				[
					'label'                 => esc_html__( 'Border Width', 'powerpack' ),
					'type'                  => Controls_Manager::SLIDER,
					'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
					'range'                 => [
						'px' => [
							'min' => 0,
							'max' => 20,
						],
					],
					'selectors'             => [
						'{{WRAPPER}} {{CURRENT_ITEM}}.pp-logo-grid-item-custom, {{WRAPPER}} {{CURRENT_ITEM}} .pp-logo-grid-item-custom' => 'border-width: {{SIZE}}{{UNIT}};',
					],
					'condition'          => [
						'custom_style'   => 'yes',
						'custom_logo_wrapper_border_type!' => '',
					],
				]
			);

			$repeater->add_control(
				'custom_logo_wrapper_border_color',
				[
					'label'              => esc_html__( 'Border Color', 'powerpack' ),
					'type'               => Controls_Manager::COLOR,
					'default'            => '',
					'selectors'          => [
						'{{WRAPPER}} {{CURRENT_ITEM}}.pp-logo-grid-item-custom, {{WRAPPER}} {{CURRENT_ITEM}} .pp-logo-grid-item-custom' => 'border-color: {{VALUE}}',
					],
					'condition'          => [
						'custom_style' => 'yes',
						'custom_logo_wrapper_border_type!' => '',
					],
				]
			);

		$repeater->end_controls_tab();

		$repeater->end_controls_tabs();

		$this->add_control(
			'pp_logos',
			[
				'label'     => esc_html__( 'Add Logos', 'powerpack' ),
				'type'      => Controls_Manager::REPEATER,
				'default'   => [
					[
						'logo_image' => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
					[
						'logo_image' => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
					[
						'logo_image' => [
							'url' => Utils::get_placeholder_image_src(),
						],
					],
				],
				'fields'        => $repeater->get_controls(),
				'title_field'   => '{{title}}',
			]
		);

		$this->add_control(
			'show_title',
			[
				'label'                 => esc_html__( 'Show Title', 'powerpack' ),
				'type'                  => Controls_Manager::SWITCHER,
				'default'               => 'yes',
				'label_on'              => esc_html__( 'Yes', 'powerpack' ),
				'label_off'             => esc_html__( 'No', 'powerpack' ),
				'return_value'          => 'yes',
				'separator'             => 'before',
			]
		);

		$this->add_control(
			'title_html_tag',
			[
				'label'                => esc_html__( 'Title HTML Tag', 'powerpack' ),
				'type'                 => Controls_Manager::SELECT,
				'default'              => 'h4',
				'options'              => [
					'h1'     => esc_html__( 'H1', 'powerpack' ),
					'h2'     => esc_html__( 'H2', 'powerpack' ),
					'h3'     => esc_html__( 'H3', 'powerpack' ),
					'h4'     => esc_html__( 'H4', 'powerpack' ),
					'h5'     => esc_html__( 'H5', 'powerpack' ),
					'h6'     => esc_html__( 'H6', 'powerpack' ),
					'div'    => esc_html__( 'div', 'powerpack' ),
					'span'   => esc_html__( 'span', 'powerpack' ),
					'p'      => esc_html__( 'p', 'powerpack' ),
				],
				'condition'             => [
					'show_title'   => 'yes',
				],
			]
		);

		$this->add_control(
			'randomize',
			[
				'label'                 => esc_html__( 'Randomize Logos', 'powerpack' ),
				'type'                  => Controls_Manager::SWITCHER,
				'default'               => '',
				'label_on'              => esc_html__( 'Yes', 'powerpack' ),
				'label_off'             => esc_html__( 'No', 'powerpack' ),
				'return_value'          => 'yes',
				'description'           => esc_html__( 'Shuffles the order on every page load. If page caching is active, the cached version will keep a fixed order until the cache is refreshed.', 'powerpack' ),
			]
		);

		$logo_columns = range( 1, 12 );
		$logo_columns = array_combine( $logo_columns, $logo_columns );

		$this->add_responsive_control(
			'columns',
			[
				'label'                 => esc_html__( 'Columns', 'powerpack' ),
				'type'                  => Controls_Manager::SELECT,
				'default'               => '3',
				'tablet_default'        => '2',
				'mobile_default'        => '1',
				'options'               => $logo_columns,
				'prefix_class'          => 'elementor-grid%s-',
			]
		);

		$this->add_responsive_control(
			'logos_spacing',
			[
				'label'                 => esc_html__( 'Logos Gap', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'default'               => [ 'size' => 10 ],
				'range'                 => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'             => [
					'{{WRAPPER}}' => '--grid-column-gap: {{SIZE}}{{UNIT}}; --grid-row-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'logos_vertical_align',
			[
				'label'                 => esc_html__( 'Vertical Align', 'powerpack' ),
				'type'                  => Controls_Manager::CHOOSE,
				'label_block'           => false,
				'default'               => 'top',
				'options'               => [
					'top'          => [
						'title'    => esc_html__( 'Top', 'powerpack' ),
						'icon'     => 'eicon-v-align-top',
					],
					'middle'       => [
						'title'    => esc_html__( 'Center', 'powerpack' ),
						'icon'     => 'eicon-v-align-middle',
					],
					'bottom'       => [
						'title'    => esc_html__( 'Bottom', 'powerpack' ),
						'icon'     => 'eicon-v-align-bottom',
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-logo-grid .elementor-grid-item' => 'align-items: {{VALUE}};',
				],
				'selectors_dictionary'  => [
					'top'          => 'flex-start',
					'middle'       => 'center',
					'bottom'       => 'flex-end',
				],
			]
		);

		$this->add_control(
			'logos_horizontal_align',
			[
				'label'                 => esc_html__( 'Horizontal Align', 'powerpack' ),
				'type'                  => Controls_Manager::CHOOSE,
				'label_block'           => false,
				'options'               => [
					'left'      => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-h-align-left',
					],
					'center'           => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-h-align-center',
					],
					'right'            => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'default'               => 'center',
				'selectors_dictionary'  => [
					'left'     => 'flex-start',
					'center'   => 'center',
					'right'    => 'flex-end',
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-logo-grid .elementor-grid-item, {{WRAPPER}} .pp-logo-grid .pp-logo-wrap' => 'justify-content: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'                  => 'image',
				'label'                 => esc_html__( 'Image Size', 'powerpack' ),
				'default'               => 'full',
			]
		);

		$this->add_responsive_control(
			'logos_width',
			[
				'label'             => esc_html__( 'Image Width', 'powerpack' ),
				'type'              => Controls_Manager::SLIDER,
				'size_units'        => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range'             => [
					'px' => [
						'min'   => 10,
						'max'   => 800,
						'step'  => 1,
					],
				],
				'selectors'         => [
					'{{WRAPPER}} .pp-logo-wrap img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/*-----------------------------------------------------------------------------------*/
	/*	STYLE TAB
	/*-----------------------------------------------------------------------------------*/

	/**
	 * Register the Logos style section controls.
	 *
	 * @access protected
	 */
	protected function register_style_logos_controls() {
		$this->start_controls_section(
			'section_logos_style',
			[
				'label'                 => esc_html__( 'Logos', 'powerpack' ),
				'tab'                   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs( 'tabs_logos_style' );

		$this->start_controls_tab(
			'tab_logos_normal',
			[
				'label'             => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'                  => 'logo_bg',
				'label'                 => esc_html__( 'Background', 'powerpack' ),
				'types'                 => [ 'classic', 'gradient' ],
				'exclude'               => [ 'image' ],
				'selector'              => '{{WRAPPER}} .pp-logo-wrap',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'                  => 'logo_border',
				'label'                 => esc_html__( 'Border', 'powerpack' ),
				'placeholder'           => '1px',
				'default'               => '1px',
				'selector'              => '{{WRAPPER}} .pp-logo-wrap',
			]
		);

		$this->add_control(
			'logo_border_radius',
			[
				'label'                 => esc_html__( 'Border Radius', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'             => [
					'{{WRAPPER}} .pp-logo-wrap, {{WRAPPER}} .pp-logo-wrap img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'logo_padding',
			[
				'label'                 => esc_html__( 'Padding', 'powerpack' ),
				'type'                  => Controls_Manager::DIMENSIONS,
				'size_units'            => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'             => [
					'{{WRAPPER}} .pp-logo-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'grayscale_normal',
			[
				'label'             => esc_html__( 'Grayscale', 'powerpack' ),
				'type'              => Controls_Manager::SWITCHER,
				'default'           => 'no',
				'label_on'          => esc_html__( 'Yes', 'powerpack' ),
				'label_off'         => esc_html__( 'No', 'powerpack' ),
				'return_value'      => 'yes',
			]
		);

		$this->add_control(
			'opacity_normal',
			[
				'label'             => esc_html__( 'Opacity', 'powerpack' ),
				'type'              => Controls_Manager::SLIDER,
				'range'             => [
					'px' => [
						'min'   => 0,
						'max'   => 1,
						'step'  => 0.1,
					],
				],
				'selectors'         => [
					'{{WRAPPER}} .pp-logo-wrap img' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'                  => 'pp_logo_box_shadow_normal',
				'selector'              => '{{WRAPPER}} .pp-logo-wrap',
				'separator'             => 'before',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_logos_hover',
			[
				'label'                 => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'                  => 'logos_bg_hover',
				'label'                 => esc_html__( 'Background', 'powerpack' ),
				'types'                 => [ 'classic', 'gradient' ],
				'exclude'               => [ 'image' ],
				'selector'              => '{{WRAPPER}} .pp-logo-wrap:hover, {{WRAPPER}} .elementor-grid-item:focus-within .pp-logo-wrap',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'                  => 'logo_border_hover',
				'label'                 => esc_html__( 'Border', 'powerpack' ),
				'placeholder'           => '1px',
				'default'               => '1px',
				'selector'              => '{{WRAPPER}} .pp-logo-wrap:hover, {{WRAPPER}} .elementor-grid-item:focus-within .pp-logo-wrap',
			]
		);

		$this->add_responsive_control(
			'translate',
			[
				'label'                 => esc_html__( 'Slide', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'range'                 => [
					'px' => [
						'min'   => -40,
						'max'   => 40,
						'step'  => 1,
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .elementor-grid-item:hover, {{WRAPPER}} .elementor-grid-item:focus-within' => 'transform:translateY({{SIZE}}{{UNIT}})',
				],
			]
		);

		$this->add_control(
			'grayscale_hover',
			[
				'label'             => esc_html__( 'Grayscale', 'powerpack' ),
				'type'              => Controls_Manager::SWITCHER,
				'default'           => 'no',
				'label_on'          => esc_html__( 'Yes', 'powerpack' ),
				'label_off'         => esc_html__( 'No', 'powerpack' ),
				'return_value'      => 'yes',
			]
		);

		$this->add_control(
			'opacity_hover',
			[
				'label'             => esc_html__( 'Opacity', 'powerpack' ),
				'type'              => Controls_Manager::SLIDER,
				'range'             => [
					'px' => [
						'min'   => 0,
						'max'   => 1,
						'step'  => 0.1,
					],
				],
				'selectors'         => [
					'{{WRAPPER}} .pp-logo-wrap:hover img, {{WRAPPER}} .elementor-grid-item:focus-within img' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'                  => 'pp_logo_box_shadow_hover',
				'selector'              => '{{WRAPPER}} .pp-logo-wrap:hover, {{WRAPPER}} .elementor-grid-item:focus-within .pp-logo-wrap',
				'separator'             => 'before',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Register the Title style section controls.
	 *
	 * @access protected
	 */
	protected function register_style_title_controls() {
		$this->start_controls_section(
			'section_logo_title_style',
			[
				'label'                 => esc_html__( 'Title', 'powerpack' ),
				'tab'                   => Controls_Manager::TAB_STYLE,
				'condition'             => [
					'show_title'   => 'yes',
				],
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'              => esc_html__( 'Color', 'powerpack' ),
				'type'               => Controls_Manager::COLOR,
				'default'            => '',
				'selectors'          => [
					'{{WRAPPER}} .pp-logo-title' => 'color: {{VALUE}}',
				],
				'condition'          => [
					'show_title'   => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'                  => 'title_typography',
				'label'                 => esc_html__( 'Typography', 'powerpack' ),
				'global'                => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector'              => '{{WRAPPER}} .pp-logo-title',
				'condition'             => [
					'show_title'   => 'yes',
				],
			]
		);

		$this->add_control(
			'title_spacing',
			[
				'label'                 => esc_html__( 'Spacing', 'powerpack' ),
				'type'                  => Controls_Manager::SLIDER,
				'size_units'            => [ 'px', 'em', 'rem', 'custom' ],
				'range'                 => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'             => [
					'{{WRAPPER}} .pp-logo-title' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
				'condition'             => [
					'show_title'   => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render logo grid widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( 'logo-grid', [
			'class' => 'pp-logo-grid elementor-grid',
			'role'  => 'list',
		] );

		if ( 'yes' === $settings['grayscale_normal'] ) {
			$this->add_render_attribute( 'logo-grid', 'class', 'grayscale-normal' );
		}

		if ( 'yes' === $settings['grayscale_hover'] ) {
			$this->add_render_attribute( 'logo-grid', 'class', 'grayscale-hover' );
		}
		?>
		<div <?php $this->print_render_attribute_string( 'logo-grid' ); ?>>
			<?php
			$logos = $settings['pp_logos'];

			if ( 'yes' === $settings['randomize'] ) {
				shuffle( $logos );
			}

			foreach ( $logos as $index => $item ) :
				if ( ! empty( $item['logo_image']['url'] ) ) {
					$item_wrap_setting_key  = $this->get_repeater_setting_key( 'item_wrap', 'logos', $index );
					$item_setting_key       = $this->get_repeater_setting_key( 'item', 'logos', $index );
					$link_setting_key       = $this->get_repeater_setting_key( 'link', 'logos', $index );
					$image_link_setting_key = $link_setting_key . '-image';

					$this->add_render_attribute( $item_wrap_setting_key, [
						'class' => [
							'elementor-grid-item',
							'elementor-repeater-item-' . esc_attr( $item['_id'] ),
						],
						'role'  => 'listitem',
					] );

					$this->add_render_attribute( $item_setting_key, 'class', 'pp-logo-wrap' );

					if ( 'yes' === $item['custom_style'] ) {
						if ( 'logo' === $item['custom_style_target'] ) {
							$this->add_render_attribute( $item_setting_key, 'class', 'pp-logo-grid-item-custom' );
						} else {
							$this->add_render_attribute( $item_wrap_setting_key, 'class', 'pp-logo-grid-item-custom' );
						}
					}

					$has_link    = ! empty( $item['link']['url'] );
					$title_shown = 'yes' === $settings['show_title'] && '' !== trim( $item['title'] );
					$image_html  = $this->render_image( $item, $settings, $this->get_logo_alt( $item, $title_shown, $has_link ) );
					$title_html  = esc_html( $item['title'] );

					if ( $has_link ) {
						$this->add_link_attributes( $link_setting_key, $item['link'] );
						$this->add_link_attributes( $image_link_setting_key, $item['link'] );

						if ( $title_shown ) {
							/*
							 * The title link below goes to the same place and carries the name,
							 * so keeping both would give every logo two tab stops to one
							 * destination. The image link stays clickable for a pointer and
							 * leaves the tab order and the accessibility tree.
							 */
							$this->add_render_attribute( $image_link_setting_key, [
								'tabindex'    => '-1',
								'aria-hidden' => 'true',
							] );

							$title_html .= $this->get_new_tab_notice( $item['link'] );
						} else {
							$image_html .= $this->get_new_tab_notice( $item['link'] );
						}
					}
					?>
					<div <?php $this->print_render_attribute_string( $item_wrap_setting_key ); ?>>
						<div <?php $this->print_render_attribute_string( $item_setting_key ); ?>>
							<?php echo $this->maybe_wrap_in_link( $image_html, $image_link_setting_key, $has_link ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in render_image(), get_new_tab_notice() and Elementor's attribute string. ?>
						</div>
						<?php
						if ( $title_shown ) {
							printf(
								'<%1$s class="pp-logo-title">%2$s</%1$s>',
								esc_html( PP_Helper::validate_html_tag( $settings['title_html_tag'] ) ),
								$this->maybe_wrap_in_link( $title_html, $link_setting_key, $has_link ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped with esc_html(), get_new_tab_notice() and Elementor's attribute string.
							);
						}
						?>
					</div>
					<?php
				}
			endforeach;
			?>
		</div>
		<?php
	}

	/**
	 * Wrap already-escaped HTML in the item's anchor when a link is set.
	 *
	 * Caller is responsible for escaping `$content`; the anchor attributes are
	 * built from a render-attribute key, which Elementor escapes on output.
	 *
	 * @since 3.0.0
	 * @access protected
	 *
	 * @param string $content          Already-escaped HTML to wrap.
	 * @param string $link_setting_key Render-attribute key holding anchor attributes.
	 * @param bool   $has_link         Whether `$content` should be wrapped.
	 *
	 * @return string
	 */
	protected function maybe_wrap_in_link( $content, $link_setting_key, $has_link ) {
		if ( ! $has_link ) {
			return $content;
		}

		return sprintf(
			'<a %1$s>%2$s</a>',
			$this->get_render_attribute_string( $link_setting_key ),
			$content
		);
	}

	/**
	 * Alt text for a logo image.
	 *
	 * A logo stands for the company it belongs to, so an image without alt text falls
	 * back to the item's title, and a linked one with neither falls back to a generic
	 * name rather than leaving the link to be announced as its URL. Where the title is
	 * shown beside the logo it already carries the name, so the image keeps whatever
	 * alt it has.
	 *
	 * @since 3.1.0
	 * @access protected
	 *
	 * @param array $item        Repeater item data.
	 * @param bool  $title_shown Whether the item's title is printed beside the logo.
	 * @param bool  $has_link    Whether the logo is linked.
	 *
	 * @return string
	 */
	protected function get_logo_alt( $item, $title_shown, $has_link ) {
		$image_alt = Control_Media::get_image_alt( $item['logo_image'] );

		if ( '' !== $image_alt || $title_shown ) {
			return $image_alt;
		}

		$image_alt = trim( $item['title'] );

		if ( '' === $image_alt && $has_link ) {
			$image_alt = __( 'Logo', 'powerpack' );
		}

		return $image_alt;
	}

	/**
	 * Visually hidden warning for a link that opens in a new tab.
	 *
	 * Nothing else tells a screen reader user that the tab is about to change, and
	 * the link text itself is the author's, so the notice rides inside the link.
	 *
	 * @since 3.1.0
	 * @access protected
	 *
	 * @param array $link The repeater item's link setting.
	 *
	 * @return string The notice markup, or an empty string where the link stays in place.
	 */
	protected function get_new_tab_notice( $link ) {
		if ( empty( $link['is_external'] ) ) {
			return '';
		}

		return '<span class="elementor-screen-only">' . esc_html__( '(opens in a new tab)', 'powerpack' ) . '</span>';
	}

	/**
	 * Render image HTML for a single logo grid item.
	 *
	 * @access protected
	 *
	 * @param array       $item      Repeater item data.
	 * @param array       $instance  Widget settings.
	 * @param string|null $image_alt Alt text; resolved from the attachment when null.
	 *
	 * @return string Image HTML.
	 */
	protected function render_image( $item, $instance, $image_alt = null ) {

		$image_id  = apply_filters( 'wpml_object_id', $item['logo_image']['id'], 'attachment', true );
		$image_url = Group_Control_Image_Size::get_attachment_image_src( $image_id, 'image', $instance );

		if ( null === $image_alt ) {
			$image_alt = Control_Media::get_image_alt( $item['logo_image'] );
		}

		if ( ! $image_url ) {
			$image_url = $item['logo_image']['url'];
		}

		return sprintf( '<img src="%s" alt="%s" />', esc_url( $image_url ), esc_attr( $image_alt ) );
	}

	/**
	 * Render logo grid widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @access protected
	 */
	protected function content_template() {
		?>
		<#
			var generic_logo   = '<?php echo esc_js( __( 'Logo', 'powerpack' ) ); ?>',
				new_tab_notice = '<span class="elementor-screen-only"><?php echo esc_js( __( '(opens in a new tab)', 'powerpack' ) ); ?></span>';

			view.addRenderAttribute( 'logo-grid', {
				'class': 'pp-logo-grid elementor-grid',
				'role': 'list',
			});

			if ( settings.grayscale_normal == 'yes' ) {
				view.addRenderAttribute( 'logo-grid', {
					'class': 'grayscale-normal',
				});
			}

			if ( settings.grayscale_hover == 'yes' ) {
				view.addRenderAttribute( 'logo-grid', {
					'class': 'grayscale-hover',
				});
			}
		#>
		<div {{{ view.getRenderAttributeString( 'logo-grid' ) }}}>
			<# _.each( settings.pp_logos, function( item ) {
				if ( ! item.logo_image || ! item.logo_image.url ) {
					return;
				}

				// Resolved before any markup is printed, so a size that isn't ready yet
				// skips the item instead of leaving its wrappers open.
				var image_url = item.logo_image.url;

				if ( item.logo_image.id ) {
					image_url = elementor.imagesManager.getImageUrl( {
						id: item.logo_image.id,
						url: item.logo_image.url,
						size: settings.image_size,
						dimension: settings.image_custom_dimension,
						model: view.getEditModel()
					} );

					if ( ! image_url ) {
						return;
					}
				}

				var item_wrap_custom_style_class = '',
					item_custom_style_class      = '',
					linkAttrs                    = '',
					notice                       = '',
					title                        = ( item.title || '' ).trim(),
					has_link                     = !! ( item.link && item.link.url ),
					title_shown                  = 'yes' === settings.show_title && '' !== title,
					image_alt                    = item.logo_image.alt || ( title_shown ? '' : ( title || ( has_link ? generic_logo : '' ) ) );
			#>
					<#
						if ( 'yes' === item.custom_style ) {
							if ( 'logo' === item.custom_style_target ) {
								item_custom_style_class = 'pp-logo-grid-item-custom';
							} else {
								item_wrap_custom_style_class = 'pp-logo-grid-item-custom';
							}
						}

						if ( has_link ) {
							var rel = '';
							linkAttrs = ' href="' + _.escape( item.link.url ) + '"';
							if ( item.link.is_external ) {
								linkAttrs += ' target="_blank"';
								rel = 'noopener';
								notice = new_tab_notice;
							}
							if ( item.link.nofollow ) {
								rel = ( rel ? rel + ' ' : '' ) + 'nofollow';
							}
							if ( rel ) {
								linkAttrs += ' rel="' + rel + '"';
							}
						}
					#>
					<div class="elementor-grid-item elementor-repeater-item-{{ item._id }} {{ item_wrap_custom_style_class }}" role="listitem">
						<div class="pp-logo-wrap {{ item_custom_style_class }}">
							<# if ( has_link ) {
								// The title beside the logo already names it, so the image link
								// there would be a second tab stop to the same place.
							#>
								<a{{{ linkAttrs }}}{{{ title_shown ? ' tabindex="-1" aria-hidden="true"' : '' }}}>
							<# } #>
							<img src="{{ image_url }}" alt="{{ image_alt }}" />
							<# if ( has_link ) { #>
								{{{ title_shown ? '' : notice }}}</a>
							<# } #>
						</div>
						<# if ( title_shown ) {
							var titleHTMLTag = elementor.helpers.validateHTMLTag( settings.title_html_tag );
						#>
							<{{{ titleHTMLTag }}} class="pp-logo-title"><# if ( has_link ) { #><a{{{ linkAttrs }}}><# } #>{{ item.title }}<# if ( has_link ) { #>{{{ notice }}}</a><# } #></{{{ titleHTMLTag }}}>
						<# } #>
					</div>
			<# } ); #>
		</div>
		<?php
	}
}
