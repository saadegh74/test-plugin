<?php
/**
 * PowerPack WooCommerce Cart widget.
 *
 * @package PowerPack
 */

namespace PowerpackElements\Modules\Woocommerce\Widgets;

use PowerpackElements\Classes\PP_Helper;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;

if ( ! defined( 'ABSPATH' ) ) {
	exit;   // Exit if accessed directly.
}

/**
 * Woo - Cart Widget
 */
class Woo_Cart extends Woo_Base_Widget {

	/**
	 * Whether WooCommerce coupons are enabled for the store.
	 *
	 * Resolved once at the start of render(), before this widget installs its
	 * own `woocommerce_coupons_enabled` override, so callbacks that fire while
	 * that override is active can still see the real store setting.
	 *
	 * @since 3.0.0
	 * @var bool
	 */
	private $coupons_active = false;

	/**
	 * Count of wrapper divs this widget has opened and not yet closed.
	 *
	 * The wrappers are opened and closed across five separate WooCommerce
	 * template hooks, so the count is tracked rather than assumed. See
	 * close_cart_wrappers().
	 *
	 * @since 3.0.0
	 * @var int
	 */
	private $open_wrappers = 0;

	/**
	 * Retrieve Woo - Cart widget categories.
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return parent::get_woo_categories();
	}

	/**
	 * Retrieve Woo - Cart widget name.
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return parent::get_widget_name( 'Woo_Cart' );
	}

	/**
	 * Retrieve Woo - Cart widget title.
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return parent::get_widget_title( 'Woo_Cart' );
	}

	/**
	 * Retrieve Woo - Cart widget icon.
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return parent::get_widget_icon( 'Woo_Cart' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the Woo - Cart widget belongs to.
	 *
	 * @since 1.4.13.1
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return parent::get_widget_keywords( 'Woo_Cart' );
	}

	/**
	 * Retrieve the list of scripts the Woo - Cart widget depended on.
	 *
	 * @access public
	 *
	 * @return array scripts.
	 */
	public function get_script_depends() {
		return [ 'pp-woo-cart' ];
	}

	/**
	 * Retrieve the list of styles the Woo - Cart depended on.
	 *
	 * Used to set style dependencies required to run the widget.
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_style_depends() {
		return [
			'pp-woocommerce',
		];
	}

	/**
	 * Whether the widget renders Elementor's inner wrapper element.
	 *
	 * Returns false when the Optimized Markup experiment is active, so the
	 * extra '.elementor-widget-container' div is dropped.
	 *
	 * @since 2.11.8
	 * @access public
	 *
	 * @return bool Whether to render the inner wrapper.
	 */
	public function has_widget_inner_wrapper(): bool {
		return ! PP_Helper::is_feature_active( 'e_optimized_markup' );
	}

	/**
	 * Register Woo - Cart widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 2.0.3
	 * @access protected
	 */
	protected function register_controls() {
		/* General Controls */
		$this->register_content_general_controls();

		/* Order Summary */
		$this->register_content_order_summary_controls();

		/* Coupon */
		if ( $this->is_wc_feature_active( 'coupons' ) ) {
			$this->register_content_coupon_controls();
		}

		/* Totals */
		$this->register_content_totals_controls();

		/* Additional Options */
		$this->register_content_additional_options_controls();

		/* Style Tab: Headings */
		$this->register_style_heading_controls();

		/* Style Tab: Sections */
		$this->register_style_cart_sections_controls();

		/* Style Tab: Cart Table */
		$this->register_style_cart_table_controls();

		/* Style Tab: Update Cart Button */
		$this->register_style_update_cart_button_controls();

		/* Style Tab: Coupon */
		$this->register_style_form_coupon_controls();

		/* Style Tab: Cart Total */
		$this->register_style_cart_totals_controls();

		/* Style Tab: Checkout Button */
		$this->register_style_checkout_button_controls();

		/* Style Tab: Return to Shop Button */
		$this->register_style_return_to_shop_button_controls();

		/* Style Tab: Cross Sells */
		$this->register_style_cross_sells_controls();
	}

	/**
	 * Register cart widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.4.3
	 * @access protected
	 */
	protected function register_content_general_controls() {

		$this->start_controls_section(
			'section_settings',
			[
				'label' => esc_html__( 'General', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'show_cross_sells',
			[
				'label'        => esc_html__( 'Show Cross Sells', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'cross_sell_thumbnail',
				'label'     => esc_html__( 'Image Size', 'powerpack' ),
				'default'   => 'woocommerce_thumbnail',
				'exclude'   => [ 'custom' ],
				'condition' => [
					'show_cross_sells' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Content Tab: Order Summary
	 *
	 * @since 2.9.5
	 * @access protected
	 */
	protected function register_content_order_summary_controls() {
		$this->start_controls_section(
			'section_order_summary',
			[
				'label'     => esc_html__( 'Order Summary', 'powerpack' ),
				'condition' => [
					'update_cart_automatically' => '',
				],
			]
		);

			$this->add_control(
				'update_cart_button_heading',
				[
					'type'  => Controls_Manager::HEADING,
					'label' => esc_html__( 'Update Cart Button', 'powerpack' ),
				]
			);

			$this->add_control(
				'update_cart_button_text',
				[
					'label'       => esc_html__( 'Text', 'powerpack' ),
					'type'        => Controls_Manager::TEXT,
					'dynamic'     => [
						'active' => true,
					],
					'placeholder' => esc_html__( 'Update Cart', 'powerpack' ),
					'default'     => esc_html__( 'Update Cart', 'powerpack' ),
				]
			);

		$this->end_controls_section();
	}

	/**
	 * Content Tab: Coupon
	 *
	 * @since 2.9.5
	 * @access protected
	 */
	protected function register_content_coupon_controls() {
		$this->start_controls_section(
			'section_coupon',
			[
				'label' => esc_html__( 'Coupon', 'powerpack' ),
			]
		);

		$this->add_control(
			'show_coupon',
			[
				'label'        => esc_html__( 'Show Coupon Field', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'apply_coupon_heading',
			[
				'type'      => Controls_Manager::HEADING,
				'label'     => esc_html__( 'Apply Coupon Button', 'powerpack' ),
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_control(
			'apply_coupon_button_text',
			[
				'label'       => esc_html__( 'Text', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Apply coupon', 'powerpack' ),
				'default'     => esc_html__( 'Apply coupon', 'powerpack' ),
				'condition'   => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Content Tab: Totals
	 *
	 * @since 2.9.5
	 * @access protected
	 */
	protected function register_content_totals_controls() {
		$this->start_controls_section(
			'section_totals',
			[
				'label' => esc_html__( 'Totals', 'powerpack' ),
			]
		);

			$this->add_control(
				'totals_section_title',
				[
					'label'       => esc_html__( 'Section Title', 'powerpack' ),
					'type'        => Controls_Manager::TEXT,
					'dynamic'     => [
						'active' => true,
					],
					'placeholder' => esc_html__( 'Cart Totals', 'powerpack' ),
					'default'     => esc_html__( 'Cart Totals', 'powerpack' ),
				]
			);

			$this->add_responsive_control(
				'totals_section_title_alignment',
				[
					'label'     => esc_html__( 'Alignment', 'powerpack' ),
					'type'      => Controls_Manager::CHOOSE,
					'options'   => [
						'start'  => [
							'title' => esc_html__( 'Start', 'powerpack' ),
							'icon'  => 'eicon-text-align-left',
						],
						'center' => [
							'title' => esc_html__( 'Center', 'powerpack' ),
							'icon'  => 'eicon-text-align-center',
						],
						'end'    => [
							'title' => esc_html__( 'End', 'powerpack' ),
							'icon'  => 'eicon-text-align-right',
						],
					],
					'selectors' => [
						'{{WRAPPER}} .pp-woo-cart .cart_totals > h2' => 'text-align: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'update_shipping_button_heading',
				[
					'type'      => Controls_Manager::HEADING,
					'label'     => esc_html__( 'Update Shipping Button', 'powerpack' ),
					'separator' => 'before',
				]
			);

			$this->add_control(
				'update_shipping_button_text',
				[
					'label'       => esc_html__( 'Text', 'powerpack' ),
					'type'        => Controls_Manager::TEXT,
					'dynamic'     => [
						'active' => true,
					],
					'placeholder' => esc_html__( 'Update', 'powerpack' ),
					'default'     => esc_html__( 'Update', 'powerpack' ),
				]
			);

			$this->add_control(
				'checkout_button_heading',
				[
					'type'  => Controls_Manager::HEADING,
					'label' => esc_html__( 'Checkout Button', 'powerpack' ),
				]
			);

			$this->add_control(
				'checkout_button_text',
				[
					'label'       => esc_html__( 'Text', 'powerpack' ),
					'type'        => Controls_Manager::TEXT,
					'dynamic'     => [
						'active' => true,
					],
					'placeholder' => esc_html__( 'Proceed to Checkout', 'powerpack' ),
					'default'     => esc_html__( 'Proceed to Checkout', 'powerpack' ),
				]
			);

			$this->add_responsive_control(
				'checkout_button_alignment',
				[
					'label'                => esc_html__( 'Alignment', 'powerpack' ),
					'type'                 => Controls_Manager::CHOOSE,
					'options'              => [
						'start'   => [
							'title' => esc_html__( 'Start', 'powerpack' ),
							'icon'  => 'eicon-text-align-left',
						],
						'center'  => [
							'title' => esc_html__( 'Center', 'powerpack' ),
							'icon'  => 'eicon-text-align-center',
						],
						'end'     => [
							'title' => esc_html__( 'End', 'powerpack' ),
							'icon'  => 'eicon-text-align-right',
						],
						'justify' => [
							'title' => esc_html__( 'Justify', 'powerpack' ),
							'icon'  => 'eicon-text-align-justify',
						],
					],
					'selectors'            => [
						'{{WRAPPER}} .wc-proceed-to-checkout' => '{{VALUE}};',
					],
					// Button width is owned by the checkout_button_width control
					// and its pp-woo-cart-checkout-button-* class. Alignment
					// only sets how the button sits in the column.
					'selectors_dictionary' => [
						'start'   => '--place-order-title-alignment: flex-start;',
						'center'  => '--place-order-title-alignment: center;',
						'end'     => '--place-order-title-alignment: flex-end;',
						'justify' => '--place-order-title-alignment: stretch;',
					],
				]
			);

		$this->end_controls_section();
	}

	/**
	 * Content Tab: Additional Options
	 *
	 * @since 2.9.5
	 * @access protected
	 */
	protected function register_content_additional_options_controls() {
		$this->start_controls_section(
			'section_additional_options',
			[
				'label' => esc_html__( 'Additional Options', 'powerpack' ),
			]
		);

			$this->add_control(
				'update_cart_automatically',
				[
					'label'     => esc_html__( 'Update Cart Automatically', 'powerpack' ),
					'type'      => Controls_Manager::SWITCHER,
					'label_on'  => esc_html__( 'Yes', 'powerpack' ),
					'label_off' => esc_html__( 'No', 'powerpack' ),
					// Hides the now redundant Update Cart button, which the
					// frontend script clicks on the shopper's behalf. Uses a
					// prefix class rather than a selector so the button's
					// display is only touched when the option is on.
					'prefix_class' => 'pp-woo-cart-auto-update-',
					// No markup depends on this, so 'ui' re-applies the prefix
					// class without re-rendering, and the script rebinds itself
					// from onElementChange(). 'template' would run the whole
					// [woocommerce_cart] shortcode again, cart totals and cross
					// sell loop included, just to toggle a switch. 'none' would
					// be wrong here: it skips applying the class as well.
					'frontend_available' => true,
					'render_type'        => 'ui',
				]
			);

			$this->add_control(
				'update_cart_automatically_description',
				[
					'raw'             => esc_html__( 'Changes to the cart will update automatically.', 'powerpack' ),
					'type'            => Controls_Manager::RAW_HTML,
					'content_classes' => 'elementor-descriptor',
				]
			);

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Headings
	 *
	 * Registers the style controls shared by the Cart Totals and Cross Sells
	 * section headings.
	 *
	 * @since 1.4.3
	 * @access protected
	 */
	protected function register_style_heading_controls() {

		$this->start_controls_section(
			'section_headings_style',
			[
				'label' => esc_html__( 'Headings', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'sections_headings_text_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart_totals > h2, {{WRAPPER}} .pp-woo-cart .cross-sells > h2' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'sections_headings_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-woo-cart .cart_totals > h2, {{WRAPPER}} .pp-woo-cart .cross-sells > h2',
			]
		);

		$this->add_responsive_control(
			'sections_headings_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => 5,
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart .cart_totals > h2, {{WRAPPER}} .pp-woo-cart .cross-sells > h2' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Sections
	 *
	 * Registers the style controls applied to every cart section through the
	 * '--sections-*' custom properties.
	 *
	 * @since 2.9.5
	 * @access protected
	 */
	protected function register_style_cart_sections_controls() {
		$this->start_controls_section(
			'section_cart_sections_style',
			[
				'label' => esc_html__( 'Sections', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'cart_sections_background',
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .pp-cart-section, {{WRAPPER}} .cross-sells, {{WRAPPER}} .cart_totals',
			]
		);

		$this->add_control(
			'cart_sections_border_border',
			[
				'label'     => esc_html__( 'Border Type', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '',
				'options'   => [
					'none'   => esc_html__( 'None', 'powerpack' ),
					'solid'  => esc_html__( 'Solid', 'powerpack' ),
					'double' => esc_html__( 'Double', 'powerpack' ),
					'dotted' => esc_html__( 'Dotted', 'powerpack' ),
					'dashed' => esc_html__( 'Dashed', 'powerpack' ),
					'groove' => esc_html__( 'Groove', 'powerpack' ),
				],
				'selectors' => [
					'{{WRAPPER}}' => '--sections-border-type: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'cart_sections_border_width',
			[
				'label'      => esc_html__( 'Border Width', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'top'      => 1,
					'right'    => 1,
					'bottom'   => 1,
					'left'     => 1,
					'isLinked' => true,
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--sections-border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'cart_sections_border_border!' => '',
				],
			]
		);

		$this->add_control(
			'cart_sections_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#d4d4d4',
				'selectors' => [
					'{{WRAPPER}}' => '--sections-border-color: {{VALUE}};',
				],
				'condition' => [
					'cart_sections_border_border!' => '',
				],
			]
		);

		$this->add_control(
			'cart_sections_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}}' => '--sections-border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'cart_sections_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}}' => '--sections-padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Cart Table
	 *
	 * Registers the style controls for the cart table wrapper, the table
	 * itself, its head, its rows and the per-row controls.
	 *
	 * @since 1.4.3
	 * @access protected
	 */
	protected function register_style_cart_table_controls() {
		$this->start_controls_section(
			'section_cart_table_style',
			[
				'label' => esc_html__( 'Cart Table', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'cart_table_section_heading',
			[
				'label' => esc_html__( 'Section', 'powerpack' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'cart_table_section_background',
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .pp-woo-cart .pp-shop-table',
			]
		);

		$this->add_control(
			'cart_table_section_border_border',
			[
				'label'     => esc_html__( 'Border Type', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '',
				'options'   => [
					'none'   => esc_html__( 'None', 'powerpack' ),
					'solid'  => esc_html__( 'Solid', 'powerpack' ),
					'double' => esc_html__( 'Double', 'powerpack' ),
					'dotted' => esc_html__( 'Dotted', 'powerpack' ),
					'dashed' => esc_html__( 'Dashed', 'powerpack' ),
					'groove' => esc_html__( 'Groove', 'powerpack' ),
				],
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .pp-shop-table' => 'border-style: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'cart_table_section_border_width',
			[
				'label'      => esc_html__( 'Border Width', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'top'      => 1,
					'right'    => 1,
					'bottom'   => 1,
					'left'     => 1,
					'isLinked' => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart .pp-shop-table' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'cart_table_section_border_border!' => '',
				],
			]
		);

		$this->add_control(
			'cart_table_section_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#d4d4d4',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .pp-shop-table' => 'border-color: {{VALUE}};',
				],
				'condition' => [
					'cart_table_section_border_border!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'cart_table_section_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart .pp-shop-table' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'section_cart_table_box_heading',
			[
				'label'     => esc_html__( 'Table', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'section_cart_table_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-woo-cart table.cart',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'section_cart_table_background',
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .pp-woo-cart .cart',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'section_cart_table_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-cart .cart, {{WRAPPER}} .pp-woo-cart .cart th, {{WRAPPER}} .pp-woo-cart .cart td',
			]
		);

		$this->add_control(
			'section_cart_table_border_collapse',
			[
				'label'     => esc_html__( 'Border Collapse', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'collapse',
				'options'   => [
					'inherit'  => esc_html__( 'Theme Default', 'powerpack' ),
					'collapse' => esc_html__( 'Collapse', 'powerpack' ),
					'separate' => esc_html__( 'Separate', 'powerpack' ),
				],
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart' => 'border-collapse: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'section_cart_table_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart .cart' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'section_cart_table_box_shadow',
				'separator' => 'before',
				'selector'  => '{{WRAPPER}} .pp-woo-cart .cart',
			]
		);

		$this->add_control(
			'section_cart_table_cell_heading',
			[
				'label'     => esc_html__( 'Table Cell', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'section_cart_table_cell_padding',
			[
				'label'       => esc_html__( 'Padding', 'powerpack' ),
				'type'        => Controls_Manager::DIMENSIONS,
				'size_units'  => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'   => [
					'{{WRAPPER}} .pp-woo-cart table.cart th, {{WRAPPER}} .pp-woo-cart table.cart td' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'section_review_order_table_head_heading',
			[
				'label'     => esc_html__( 'Table Head', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'section_cart_table_head_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-woo-cart table.cart thead th',
			]
		);

		$this->add_control(
			'section_review_order_table_head_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart table.cart thead th' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'section_review_order_table_head_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart table.cart thead th' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'section_cart_table_cart_items_heading',
			[
				'label'     => esc_html__( 'Cart Items', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'cart_items_row_separator_type',
			[
				'label'     => esc_html__( 'Separator Type', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'solid',
				'options'   => [
					'none'   => esc_html__( 'None', 'powerpack' ),
					'solid'  => esc_html__( 'Solid', 'powerpack' ),
					'dotted' => esc_html__( 'Dotted', 'powerpack' ),
					'dashed' => esc_html__( 'Dashed', 'powerpack' ),
					'double' => esc_html__( 'Double', 'powerpack' ),
				],
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .woocommerce-cart-form table.cart td' => 'border-top-style: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cart_items_row_separator_color',
			[
				'label'     => esc_html__( 'Separator Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#D4D4D4',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .woocommerce-cart-form table.cart td' => 'border-top-color: {{VALUE}};',
				],
				'condition' => [
					'cart_items_row_separator_type!' => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'cart_items_row_separator_size',
			[
				'label'      => esc_html__( 'Separator Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => 1,
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 20,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart .woocommerce-cart-form table.cart td' => 'border-top-width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'cart_items_row_separator_type!' => 'none',
				],
			]
		);

		$this->start_controls_tabs( 'cart_items_rows_tabs_style' );

		$this->start_controls_tab(
			'cart_items_even_row',
			[
				'label' => esc_html__( 'Even Row', 'powerpack' ),
			]
		);

		$this->add_control(
			'cart_items_even_row_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart .cart_item:nth-child(2n) td' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cart_items_even_row_links_color',
			[
				'label'     => esc_html__( 'Links Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart .cart_item:nth-child(2n) a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cart_items_even_row_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart .cart_item:nth-child(2n) td' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'cart_items_odd_row',
			[
				'label' => esc_html__( 'Odd Row', 'powerpack' ),
			]
		);

		$this->add_control(
			'cart_items_odd_row_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart .cart_item:nth-child(2n+1) td' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cart_items_odd_row_links_color',
			[
				'label'     => esc_html__( 'Links Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart .cart_item:nth-child(2n+1) a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cart_items_odd_row_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart .cart_item:nth-child(2n+1) td' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'cart_items_image_heading',
			[
				'label'     => esc_html__( 'Image', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'cart_items_image_width',
			[
				'label'      => esc_html__( 'Width', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => 80,
					'unit' => 'px',
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart table.cart .product-thumbnail img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'cart_items_quantity_input_heading',
			[
				'label'     => esc_html__( 'Quantity Input', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'cart_items_quantity_input_width',
			[
				'label'      => esc_html__( 'Width', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 20,
						'max' => 500,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart .cart .quantity .input-text' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'cart_items_quantity_input_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart .cart .quantity .input-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_quantity_input_style' );

		$this->start_controls_tab(
			'tab_quantity_input_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_control(
			'cart_items_quantity_input_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart .quantity .input-text' => 'color: {{VALUE}} !important;',
				],
			]
		);

		$this->add_control(
			'cart_items_quantity_input_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart .quantity .input-text' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'cart_items_quantity_input_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-cart .cart .quantity .input-text',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_quantity_input_hover',
			[
				'label'     => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_control(
			'cart_items_quantity_input_color_hover',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart .quantity .input-text:hover' => 'color: {{VALUE}} !important;',
				],
			]
		);

		$this->add_control(
			'cart_items_quantity_input_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart .quantity .input-text:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cart_items_quantity_input_border_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart .quantity .input-text:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_quantity_input_focus',
			[
				'label'     => esc_html__( 'Focus', 'powerpack' ),
			]
		);

		$this->add_control(
			'cart_items_quantity_input_color_focus',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart .quantity .input-text:focus' => 'color: {{VALUE}} !important;',
				],
			]
		);

		$this->add_control(
			'cart_items_quantity_input_bg_color_focus',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart .quantity .input-text:focus' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cart_items_quantity_input_border_focus',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart .quantity .input-text:focus' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'cart_items_remove_icon_heading',
			[
				'label'     => esc_html__( 'Product Remove Icon', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'cart_items_remove_icon_size',
			[
				'label'      => esc_html__( 'Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 10,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart table.cart .remove' => 'font-size: {{SIZE}}{{UNIT}}; width: calc({{SIZE}}{{UNIT}} + 6px); height: calc({{SIZE}}{{UNIT}} + 6px); line-height: calc({{SIZE}}{{UNIT}} + 3px);',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_cart_items_remove_icon_style' );

		$this->start_controls_tab(
			'tab_cart_items_remove_icon_normal',
			[
				'label' => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_control(
			'cart_items_remove_icon_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart table.cart .remove' => 'color: {{VALUE}} !important;',
				],
			]
		);

		$this->add_control(
			'cart_items_remove_icon_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart table.cart .remove' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cart_items_remove_icon_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart table.cart .remove' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_cart_items_remove_icon_hover',
			[
				'label' => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_control(
			'cart_items_remove_icon_color_hover',
			[
				'label'     => esc_html__( 'Hover Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart table.cart .remove:hover' => 'color: {{VALUE}} !important;',
				],
			]
		);

		$this->add_control(
			'cart_items_remove_icon_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart table.cart .remove:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cart_items_remove_icon_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart table.cart .remove:hover' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Cart Totals
	 *
	 * Registers the style controls for the cart totals section and its table.
	 *
	 * @since 1.4.3
	 * @access protected
	 */
	protected function register_style_cart_totals_controls() {
		$this->start_controls_section(
			'section_cart_totals_style',
			[
				'label' => esc_html__( 'Cart Totals', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'cart_totals_section_heading',
			[
				'label' => esc_html__( 'Section', 'powerpack' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'cart_totals_section_background',
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .pp-woo-cart .cart_totals',
			]
		);

		$this->add_control(
			'cart_totals_section_border_border',
			[
				'label'     => esc_html__( 'Border Type', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '',
				'options'   => [
					'none'   => esc_html__( 'None', 'powerpack' ),
					'solid'  => esc_html__( 'Solid', 'powerpack' ),
					'double' => esc_html__( 'Double', 'powerpack' ),
					'dotted' => esc_html__( 'Dotted', 'powerpack' ),
					'dashed' => esc_html__( 'Dashed', 'powerpack' ),
					'groove' => esc_html__( 'Groove', 'powerpack' ),
				],
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart_totals' => 'border-style: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'cart_totals_section_border_width',
			[
				'label'      => esc_html__( 'Border Width', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'top'      => 1,
					'right'    => 1,
					'bottom'   => 1,
					'left'     => 1,
					'isLinked' => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart .cart_totals' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'cart_totals_section_border_border!' => '',
				],
			]
		);

		$this->add_control(
			'cart_totals_section_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#d4d4d4',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart_totals' => 'border-color: {{VALUE}};',
				],
				'condition' => [
					'cart_totals_section_border_border!' => '',
				],
			]
		);

		$this->add_control(
			'cart_totals_section_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart .cart_totals' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'cart_totals_box_heading',
			[
				'label' => esc_html__( 'Table', 'powerpack' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'cart_totals_background',
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .pp-woo-cart .cart_totals .shop_table th, {{WRAPPER}} .pp-woo-cart .cart_totals .shop_table td',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'cart_totals_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-cart .cart_totals .shop_table th, {{WRAPPER}} .pp-woo-cart .cart_totals .shop_table td',
			]
		);

		$this->add_control(
			'cart_totals_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart .cart_totals .shop_table' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'cart_totals_box_shadow',
				'separator' => 'before',
				'selector'  => '{{WRAPPER}} .pp-woo-cart .cart_totals .shop_table',
			]
		);

		$this->add_responsive_control(
			'cart_totals_cell_padding',
			[
				'label'      => esc_html__( 'Cell Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart .cart_totals .shop_table th, {{WRAPPER}} .pp-woo-cart .cart_totals .shop_table td' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'cart_totals_text_heading',
			[
				'label'     => esc_html__( 'Table Text', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'cart_totals_text_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-woo-cart .cart_totals .shop_table',
			]
		);

		$this->add_control(
			'cart_totals_text_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart_totals .shop_table' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cart_totals_headings_heading',
			[
				'label'     => esc_html__( 'Table Headings', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'cart_totals_headings_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-woo-cart .cart_totals .shop_table th',
			]
		);

		$this->add_control(
			'cart_totals_headings_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart_totals .shop_table th' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Update Cart Button
	 *
	 * Registers the style controls for the cart table's Update Cart button.
	 *
	 * @since 1.4.3
	 * @access protected
	 */
	protected function register_style_update_cart_button_controls() {

		$this->start_controls_section(
			'section_update_cart_button_style',
			[
				'label'     => esc_html__( 'Update Cart Button', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				// The button is hidden when the cart updates automatically.
				'condition' => [
					'update_cart_automatically' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'update_cart_button_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-woo-cart .cart .button[name="update_cart"]',
			]
		);

		$this->add_responsive_control(
			'update_cart_button_width',
			[
				'label'      => esc_html__( 'Width', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 50,
						'max' => 500,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart .cart .button[name="update_cart"]' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'update_cart_button_margin',
			[
				'label'              => esc_html__( 'Margin', 'powerpack' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'allowed_dimensions' => 'vertical',
				'placeholder'        => [
					'top'    => '',
					'right'  => 'auto',
					'bottom' => '',
					'left'   => 'auto',
				],
				'selectors'          => [
					'{{WRAPPER}} .pp-woo-cart .cart .button[name="update_cart"]' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_update_cart_button_style' );

		$this->start_controls_tab(
			'tab_update_cart_button_normal',
			[
				'label' => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_control(
			'update_cart_button_bg_color_normal',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart .button[name="update_cart"]' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'update_cart_button_text_color_normal',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart .button[name="update_cart"]' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'update_cart_button_border_normal',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-cart .cart .button[name="update_cart"]',
			]
		);

		$this->add_control(
			'update_cart_button_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart .cart .button[name="update_cart"]' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'update_cart_button_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart .cart .button[name="update_cart"]' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'update_cart_button_box_shadow',
				'selector' => '{{WRAPPER}} .pp-woo-cart .cart .button[name="update_cart"]',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_update_cart_button_hover',
			[
				'label' => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_control(
			'update_cart_button_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart .button[name="update_cart"]:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'update_cart_button_text_color_hover',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart .button[name="update_cart"]:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'update_cart_button_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart .button[name="update_cart"]:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'update_cart_button_box_shadow_hover',
				'selector' => '{{WRAPPER}} .pp-woo-cart .cart .button[name="update_cart"]:hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Coupon
	 *
	 * Registers the style controls for the coupon section, its input field and
	 * its apply button.
	 *
	 * @since 1.4.3
	 * @access protected
	 */
	protected function register_style_form_coupon_controls() {

		$this->start_controls_section(
			'form_coupon_style',
			[
				'label'     => esc_html__( 'Coupon', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_control(
			'form_coupon_section_heading',
			[
				'label'     => esc_html__( 'Section', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'form_coupon_section_background',
				'types'     => [ 'classic', 'gradient' ],
				'selector'  => '{{WRAPPER}} .pp-woo-cart .coupon',
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_control(
			'form_coupon_section_border_border',
			[
				'label'     => esc_html__( 'Border Type', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => '',
				'options'   => [
					'none'   => esc_html__( 'None', 'powerpack' ),
					'solid'  => esc_html__( 'Solid', 'powerpack' ),
					'double' => esc_html__( 'Double', 'powerpack' ),
					'dotted' => esc_html__( 'Dotted', 'powerpack' ),
					'dashed' => esc_html__( 'Dashed', 'powerpack' ),
					'groove' => esc_html__( 'Groove', 'powerpack' ),
				],
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .coupon' => 'border-style: {{VALUE}};',
				],
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'form_coupon_section_border_width',
			[
				'label'      => esc_html__( 'Border Width', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'top'      => 1,
					'right'    => 1,
					'bottom'   => 1,
					'left'     => 1,
					'isLinked' => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart .coupon' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'show_coupon'                        => 'yes',
					'form_coupon_section_border_border!' => '',
				],
			]
		);

		$this->add_control(
			'form_coupon_section_border_color',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#d4d4d4',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .coupon' => 'border-color: {{VALUE}};',
				],
				'condition' => [
					'show_coupon'                        => 'yes',
					'form_coupon_section_border_border!' => '',
				],
			]
		);

		$this->add_control(
			'form_coupon_section_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart .coupon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_control(
			'form_coupon_input_heading',
			[
				'label'     => esc_html__( 'Input', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'form_coupon_input_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'selector'  => '{{WRAPPER}} #pp-woo-cart-{{ID}} .coupon .input-text',
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'form_coupon_input_width',
			[
				'label'      => esc_html__( 'Input Width', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 400,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} #pp-woo-cart-{{ID}} .coupon .input-text' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'form_coupon_input_height',
			[
				'label'      => esc_html__( 'Input Height', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} #pp-woo-cart-{{ID}} .coupon .input-text' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_control(
			'form_coupon_input_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} #pp-woo-cart-{{ID}} .coupon .input-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_form_coupon_input_style' );

		$this->start_controls_tab(
			'tab_form_coupon_input_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_control(
			'form_coupon_input_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} #pp-woo-cart-{{ID}} .coupon .input-text' => 'color: {{VALUE}};',
				],
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_control(
			'form_coupon_input_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} #pp-woo-cart-{{ID}} .coupon .input-text' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'form_coupon_input_border',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} #pp-woo-cart-{{ID}} .coupon .input-text',
				'condition'   => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_control(
			'form_coupon_input_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} #pp-woo-cart-{{ID}} .coupon .input-text' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'form_coupon_input_box_shadow',
				'separator' => 'before',
				'selector'  => '{{WRAPPER}} #pp-woo-cart-{{ID}} .coupon .input-text',
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_form_coupon_input_hover',
			[
				'label'     => esc_html__( 'Hover', 'powerpack' ),
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_control(
			'form_coupon_input_text_color_hover',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} #pp-woo-cart-{{ID}} .coupon .input-text:hover' => 'color: {{VALUE}};',
				],
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_control(
			'form_coupon_input_background_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} #pp-woo-cart-{{ID}} .coupon .input-text:hover' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_control(
			'form_coupon_input_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} #pp-woo-cart-{{ID}} .coupon .input-text:hover' => 'border-color: {{VALUE}};',
				],
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_form_coupon_input_focus',
			[
				'label'     => esc_html__( 'Focus', 'powerpack' ),
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_control(
			'form_coupon_input_text_color_focus',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} #pp-woo-cart-{{ID}} .coupon .input-text:focus' => 'color: {{VALUE}};',
				],
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_control(
			'form_coupon_input_background_color_focus',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} #pp-woo-cart-{{ID}} .coupon .input-text:focus' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_control(
			'form_coupon_input_border_color_focus',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} #pp-woo-cart-{{ID}} .coupon .input-text:focus' => 'border-color: {{VALUE}};',
				],
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'form_coupon_button_label_heading',
			[
				'label'     => esc_html__( 'Coupon Button', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'form_coupon_button_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'selector'  => '{{WRAPPER}} .pp-woo-cart .coupon .button',
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'form_coupon_button_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 60,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart .coupon .button' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'form_coupon_button_width',
			[
				'label'      => esc_html__( 'Width', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 50,
						'max' => 500,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart .coupon .button' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_form_coupon_button_style' );

		$this->start_controls_tab(
			'tab_form_coupon_button_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_control(
			'form_coupon_button_text_color_normal',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .coupon .button' => 'color: {{VALUE}}',
				],
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_control(
			'form_coupon_button_bg_color_normal',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .coupon .button' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'form_coupon_button_border_normal',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-cart .coupon .button',
				'condition'   => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_control(
			'form_coupon_button_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart .coupon .button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'form_coupon_button_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart .coupon .button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'form_coupon_button_box_shadow',
				'selector'  => '{{WRAPPER}} .pp-woo-cart .coupon .button',
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_form_coupon_button_hover',
			[
				'label'     => esc_html__( 'Hover', 'powerpack' ),
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_control(
			'form_coupon_button_text_color_hover',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .coupon .button:hover' => 'color: {{VALUE}}',
				],
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_control(
			'form_coupon_button_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .coupon .button:hover' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_control(
			'form_coupon_button_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .coupon .button:hover' => 'border-color: {{VALUE}}',
				],
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'form_coupon_button_box_shadow_hover',
				'selector'  => '{{WRAPPER}} .pp-woo-cart .coupon .button:hover',
				'condition' => [
					'show_coupon' => 'yes',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Checkout Button
	 *
	 * Registers the style controls for the Proceed to Checkout button.
	 *
	 * @since 1.4.3
	 * @access protected
	 */
	protected function register_style_checkout_button_controls() {

		$this->start_controls_section(
			'section_checkout_button_style',
			[
				'label' => esc_html__( 'Checkout Button', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'checkout_button_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-woo-cart .cart_totals .checkout-button',
			]
		);

		$this->add_control(
			'checkout_button_width',
			[
				'label'        => esc_html__( 'Width', 'powerpack' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'auto',
				'options'      => [
					'auto'   => esc_html__( 'Auto', 'powerpack' ),
					'full'   => esc_html__( 'Full Width', 'powerpack' ),
					'custom' => esc_html__( 'Custom', 'powerpack' ),
				],
				'prefix_class' => 'pp-woo-cart-checkout-button-',
			]
		);

		$this->add_responsive_control(
			'checkout_button_custom_width',
			[
				'label'      => esc_html__( 'Custom Width', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 50,
						'max' => 500,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart .cart_totals .checkout-button' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'checkout_button_width' => 'custom',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_checkout_button_style' );

		$this->start_controls_tab(
			'tab_checkout_button_normal',
			[
				'label' => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_control(
			'checkout_button_text_color_normal',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart_totals .checkout-button' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'checkout_button_bg_color_normal',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'global'    => [
					'default' => Global_Colors::COLOR_ACCENT,
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart_totals .checkout-button' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'checkout_button_border_normal',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-cart .cart_totals .checkout-button',
			]
		);

		$this->add_control(
			'checkout_button_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart .cart_totals .checkout-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'checkout_button_margin',
			[
				'label'              => esc_html__( 'Margin', 'powerpack' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'allowed_dimensions' => 'vertical',
				'placeholder'        => [
					'top'    => '',
					'right'  => 'auto',
					'bottom' => '',
					'left'   => 'auto',
				],
				'selectors'          => [
					'{{WRAPPER}} .pp-woo-cart .cart_totals .checkout-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'checkout_button_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart .cart_totals .checkout-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'checkout_button_box_shadow',
				'selector' => '{{WRAPPER}} .pp-woo-cart .cart_totals .checkout-button',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_checkout_button_hover',
			[
				'label' => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_control(
			'checkout_button_text_color_hover',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart_totals .checkout-button:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'checkout_button_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart_totals .checkout-button:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'checkout_button_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cart_totals .checkout-button:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'checkout_button_box_shadow_hover',
				'selector' => '{{WRAPPER}} .pp-woo-cart .cart_totals .checkout-button:hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Return to Shop Button
	 *
	 * Registers the style controls for the Return to Shop button shown when the
	 * cart is empty.
	 *
	 * @since 2.3.6
	 * @access protected
	 */
	protected function register_style_return_to_shop_button_controls() {

		$this->start_controls_section(
			'section_return_to_shop_button_style',
			[
				'label' => esc_html__( 'Return to Shop Button', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'return_to_shop_button_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-woo-cart .return-to-shop .wc-backward',
			]
		);

		$this->add_control(
			'return_to_shop_button_width',
			[
				'label'        => esc_html__( 'Width', 'powerpack' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'auto',
				'options'      => [
					'auto'   => esc_html__( 'Auto', 'powerpack' ),
					'full'   => esc_html__( 'Full Width', 'powerpack' ),
					'custom' => esc_html__( 'Custom', 'powerpack' ),
				],
				'prefix_class' => 'pp-woo-cart-return-to-shop-button-',
			]
		);

		$this->add_responsive_control(
			'return_to_shop_button_custom_width',
			[
				'label'      => esc_html__( 'Custom Width', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => '',
				],
				'range'      => [
					'px' => [
						'min' => 50,
						'max' => 500,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart .return-to-shop .wc-backward' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'return_to_shop_button_width' => 'custom',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_return_to_shop_button_style' );

		$this->start_controls_tab(
			'tab_return_to_shop_button_normal',
			[
				'label' => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_control(
			'return_to_shop_button_bg_color_normal',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .return-to-shop .wc-backward' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'return_to_shop_button_text_color_normal',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .return-to-shop .wc-backward' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'return_to_shop_button_border_normal',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-woo-cart .return-to-shop .wc-backward',
			]
		);

		$this->add_control(
			'return_to_shop_button_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart .return-to-shop .wc-backward' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'return_to_shop_button_margin',
			[
				'label'              => esc_html__( 'Margin', 'powerpack' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'allowed_dimensions' => 'vertical',
				'placeholder'        => [
					'top'    => '',
					'right'  => 'auto',
					'bottom' => '',
					'left'   => 'auto',
				],
				'selectors'          => [
					'{{WRAPPER}} .pp-woo-cart .return-to-shop .wc-backward' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'return_to_shop_button_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-woo-cart .return-to-shop .wc-backward' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'return_to_shop_button_box_shadow',
				'selector' => '{{WRAPPER}} .pp-woo-cart .return-to-shop .wc-backward',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_return_to_shop_button_hover',
			[
				'label' => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_control(
			'return_to_shop_button_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .return-to-shop .wc-backward:hover' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'return_to_shop_button_text_color_hover',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .return-to-shop .wc-backward:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'return_to_shop_button_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .return-to-shop .wc-backward:hover' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'return_to_shop_button_box_shadow_hover',
				'selector' => '{{WRAPPER}} .pp-woo-cart .return-to-shop .wc-backward:hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Style Tab: Cross Sells
	 *
	 * Registers the style controls for the cross sells product loop.
	 *
	 * @since 1.4.3
	 * @access protected
	 */
	protected function register_style_cross_sells_controls() {

		$this->start_controls_section(
			'section_cross_sells_style',
			[
				'label'     => esc_html__( 'Cross Sells', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_cross_sells' => 'yes',
				],
			]
		);

		$this->add_control(
			'cross_sells_title_heading',
			[
				'label'     => esc_html__( 'Title', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'condition' => [
					'show_cross_sells' => 'yes',
				],
			]
		);

		$this->add_control(
			'cross_sells_title_color_normal',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cross-sells .woocommerce-loop-product__title' => 'color: {{VALUE}}',
				],
				'condition' => [
					'show_cross_sells' => 'yes',
				],
			]
		);

		$this->add_control(
			'cross_sells_title_color_hover',
			[
				'label'     => esc_html__( 'Hover Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cross-sells .woocommerce-loop-product__title:hover' => 'color: {{VALUE}}',
				],
				'condition' => [
					'show_cross_sells' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'cross_sells_title_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'selector'  => '{{WRAPPER}} .pp-woo-cart .cross-sells .woocommerce-loop-product__title',
				'condition' => [
					'show_cross_sells' => 'yes',
				],
			]
		);

		$this->add_control(
			'cross_sells_price_heading',
			[
				'label'     => esc_html__( 'Price', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'show_cross_sells' => 'yes',
				],
			]
		);

		$this->add_control(
			'cross_sells_price_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cross-sells .price' => 'color: {{VALUE}}',
				],
				'condition' => [
					'show_cross_sells' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'cross_sells_price_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'selector'  => '{{WRAPPER}} .pp-woo-cart .cross-sells .price',
				'condition' => [
					'show_cross_sells' => 'yes',
				],
			]
		);

		$this->add_control(
			'cross_sells_button_heading',
			[
				'label'     => esc_html__( 'Button', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'show_cross_sells' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'cross_sells_button_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'selector'  => '{{WRAPPER}} .pp-woo-cart .cross-sells .button',
				'condition' => [
					'show_cross_sells' => 'yes',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_cross_sells_button' );

		$this->start_controls_tab(
			'tab_cross_sells_button_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => [
					'show_cross_sells' => 'yes',
				],
			]
		);

		$this->add_control(
			'cross_sells_button_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cross-sells .button' => 'color: {{VALUE}}',
				],
				'condition' => [
					'show_cross_sells' => 'yes',
				],
			]
		);

		$this->add_control(
			'cross_sells_button_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cross-sells .button' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'show_cross_sells' => 'yes',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_cross_sells_hover',
			[
				'label'     => esc_html__( 'Hover', 'powerpack' ),
				'condition' => [
					'show_cross_sells' => 'yes',
				],
			]
		);

		$this->add_control(
			'cross_sells_button_color_hover',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cross-sells .button:hover' => 'color: {{VALUE}}',
				],
				'condition' => [
					'show_cross_sells' => 'yes',
				],
			]
		);

		$this->add_control(
			'cross_sells_button_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cross-sells .button:hover' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'show_cross_sells' => 'yes',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_control(
			'cross_sells_sale_badge_heading',
			[
				'label'     => esc_html__( 'Sale Badge', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'show_cross_sells' => 'yes',
				],
			]
		);

		$this->add_control(
			'cross_sells_sale_badge_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cross-sells .onsale' => 'color: {{VALUE}}',
				],
				'condition' => [
					'show_cross_sells' => 'yes',
				],
			]
		);

		$this->add_control(
			'cross_sells_sale_badge_bg_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-woo-cart .cross-sells .onsale' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'show_cross_sells' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'cross_sells_sale_badge_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'selector'  => '{{WRAPPER}} .pp-woo-cart .cross-sells .onsale',
				'condition' => [
					'show_cross_sells' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Init Gettext Modifications
	 *
	 * Sets the '$gettext_modifications' property used with the 'filter_gettext()' in the extended Base_Widget.
	 *
	 * @since 2.9.5
	 */
	protected function init_gettext_modifications() {
		$instance = $this->get_settings_for_display();

		/*
		 * Empty entries are dropped rather than passed through. Each of these
		 * controls shows the WooCommerce wording as its placeholder, so
		 * clearing the field should fall back to the real translation instead
		 * of replacing the label with nothing.
		 */
		$this->gettext_modifications = array_filter(
			[
				'Update cart'         => $instance['update_cart_button_text'],
				'Cart totals'         => $instance['totals_section_title'],
				'Proceed to checkout' => $instance['checkout_button_text'],
				'Update'              => $instance['update_shipping_button_text'],
				// Registered only when the store has coupons enabled, so unlike
				// the others this key is not always present.
				'Apply coupon'        => ! empty( $instance['apply_coupon_button_text'] ) ? $instance['apply_coupon_button_text'] : '',
			],
			static function ( $replacement ) {
				return '' !== trim( (string) $replacement );
			}
		);
	}

	/**
	 * Disable Cart Coupon
	 *
	 * Suppresses WooCommerce's built-in coupon interface for the duration of
	 * this widget's render.
	 *
	 * The following disabling of cart coupon needs to be done this way so that
	 * we only disable the display of coupon interface in our cart widget and
	 * 'wc_coupons_enabled()' can still be reliably used elsewhere.
	 *
	 * @since 2.9.5
	 * @access public
	 */
	public function disable_cart_coupon() {
		add_filter( 'woocommerce_coupons_enabled', [ $this, 'cart_coupon_return_false' ], 90 );
	}

	/**
	 * Enable Cart Coupon
	 *
	 * Restores the filter removed by 'disable_cart_coupon()'.
	 *
	 * @since 2.9.5
	 * @access public
	 */
	public function enable_cart_coupon() {
		remove_filter( 'woocommerce_coupons_enabled', [ $this, 'cart_coupon_return_false' ], 90 );
	}

	/**
	 * Cart Coupon Return False
	 *
	 * Callback for the 'woocommerce_coupons_enabled' filter.
	 *
	 * @since 2.9.5
	 * @access public
	 *
	 * @return bool Always false.
	 */
	public function cart_coupon_return_false() {
		return false;
	}

	/**
	 * Render Woocommerce Cart Coupon Form
	 *
	 * A custom function to render a coupon form on the Cart widget. The default WC coupon form
	 * was removed in this file's render() method.
	 *
	 * We are doing this in order to match the placement of the coupon form to the provided design.
	 *
	 * @since 3.5.0
	 * @access private
	 */
	private function render_woocommerce_cart_coupon_form() {
		$button_classes = [ 'button', 'pp-apply-coupon' ];

		// Derived from the widget id: WooCommerce hardcodes coupon_code, which
		// collides as soon as two cart widgets, or a cart and a checkout
		// widget, share a page.
		$coupon_id = 'coupon_code-' . $this->get_id();

		$this->add_render_attribute(
			'button_coupon', [
				'class' => $button_classes,
				'name'  => 'apply_coupon',
				'type'  => 'submit',
			]
		);
		?>
		<div class="coupon pp-cart-section">
			<div class="form-row coupon-col">
				<div class="coupon-col-start">
					<label for="<?php echo esc_attr( $coupon_id ); ?>" class="elementor-screen-only"><?php esc_html_e( 'Coupon:', 'powerpack' ); ?></label>
					<input type="text" name="coupon_code" class="input-text" id="<?php echo esc_attr( $coupon_id ); ?>" value="" placeholder="<?php esc_attr_e( 'Coupon code', 'powerpack' ); ?>" />
				</div>
				<div class="coupon-col-end">
					<button <?php $this->print_render_attribute_string( 'button_coupon' ); ?> value="<?php esc_attr_e( 'Apply coupon', 'powerpack' ); ?>"><?php esc_html_e( 'Apply coupon', 'powerpack' ); ?></button>
				</div>
				<?php do_action( 'woocommerce_cart_coupon' ); ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Woocommerce Before Cart
	 *
	 * Output containing elements. Callback function for the woocommerce_before_cart hook
	 *
	 * This eliminates the need for template overrides.
	 *
	 * @since 2.9.5
	 */
	public function woocommerce_before_cart() {
		$this->open_wrappers += 2;
		?>
		<div class="pp-cart-container">
			<div class="pp-cart-column pp-cart-column-start">
		<?php
	}

	/**
	 * Close Cart Wrappers
	 *
	 * Closes up to $count of this widget's wrapper divs, never more than are
	 * actually open.
	 *
	 * The wrappers are opened and closed across five WooCommerce template
	 * hooks. A theme shipping its own cart/cart.php that drops one of those
	 * hooks would otherwise leave divs unclosed, which breaks the rest of the
	 * page rather than just this widget. Counting what was opened keeps the
	 * markup balanced whichever hooks actually fire.
	 *
	 * @since 3.0.0
	 * @access private
	 *
	 * @param int $count Number of wrappers to close.
	 */
	private function close_cart_wrappers( $count ) {
		$count = min( (int) $count, $this->open_wrappers );

		if ( $count < 1 ) {
			return;
		}

		$this->open_wrappers -= $count;

		echo str_repeat( '</div>', $count ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static markup.
	}

	/**
	 * Woocommerce Before Cart Table
	 *
	 * Output containing elements. Callback function for the woocommerce_before_cart_table hook
	 *
	 * This eliminates the need for template overrides.
	 *
	 * @since 2.9.5
	 */
	public function woocommerce_before_cart_table() {
		++$this->open_wrappers;
		?>
		<div class="pp-shop-table pp-cart-section">
		<?php
	}

	/**
	 * Woocommerce After Cart Table
	 *
	 * Output containing elements. Callback function for the woocommerce_after_cart_table hook
	 *
	 * This eliminates the need for template overrides.
	 *
	 * @since 2.9.5
	 */
	public function woocommerce_after_cart_table() {
		$this->close_cart_wrappers( 1 );

		$settings = $this->get_settings_for_display();

		/*
		 * Gated on the widget setting rather than wc_coupons_enabled(). This
		 * runs while our own woocommerce_coupons_enabled override may still be
		 * installed, so the global would answer for the widget instead of the
		 * store.
		 */
		if ( $this->coupons_active && 'yes' === $settings['show_coupon'] ) {
			$this->render_woocommerce_cart_coupon_form();
		}
	}

	/**
	 * Woocommerce Before Cart Collaterals
	 *
	 * Output containing elements. * Callback function for the woocommerce_before_cart_collaterals hook
	 *
	 * This eliminates the need for template overrides.
	 *
	 * Closes the start column and opens the end one. pp-cart-column-inner and
	 * pp-cart-totals used to be nested divs of their own, each a single child
	 * of the last with no styling anywhere in the plugin. They are kept as
	 * class names on the surviving element so custom CSS that targets them
	 * still matches.
	 *
	 * @since 2.9.5
	 */
	public function woocommerce_before_cart_collaterals() {
		$this->close_cart_wrappers( 1 );
		++$this->open_wrappers;
		?>
			<div class="pp-cart-column pp-cart-column-end pp-cart-column-inner pp-cart-totals">
		<?php
	}

	/**
	 * Woocommerce After Cart
	 *
	 * Output containing elements. Callback function for the woocommerce_after_cart hook.
	 *
	 * This eliminates the need for template overrides.
	 *
	 * @since 2.9.5
	 */
	public function woocommerce_after_cart() {
		$this->close_cart_wrappers( $this->open_wrappers );
	}

	/**
	 * Render output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		// Resolved before any of our own filters are installed, so this is the
		// store setting rather than our temporary override.
		$this->coupons_active = $this->is_wc_feature_active( 'coupons' );
		$this->open_wrappers  = 0;

		$this->add_render_attribute(
			'container', [
				'class' => [
					'pp-woocommerce',
					'pp-woo-cart',
				],
				'id'    => [
					'pp-woo-cart-' . $this->get_id(),
				],
			]
		);

		/**
		 * Fires before the Woo - Cart widget's outer wrapper is printed.
		 *
		 * @since 1.4.3
		 */
		do_action( 'pp_woo_before_cart_wrap' );
		?>

		<div <?php $this->print_render_attribute_string( 'container' ); ?>>
			<?php
			/**
			 * Add actions & filters before displaying our Widget.
			 */
			add_filter( 'gettext', [ $this, 'filter_gettext' ], 20, 3 );

			/*
			 * WooCommerce prints its own coupon box inside the cart table's
			 * actions row. Suppress it for the length of the table either way:
			 * when the coupon field is switched on we print our own after the
			 * table, and when it is off there should be no coupon UI at all.
			 *
			 * Both hooks are added unconditionally so the filter installed by
			 * disable_cart_coupon() is always taken back off again. Leaving it
			 * in place would make wc_coupons_enabled() report false for
			 * everything rendered after this widget.
			 */
			if ( $this->coupons_active ) {
				add_action( 'woocommerce_cart_contents', [ $this, 'disable_cart_coupon' ] );
				add_action( 'woocommerce_after_cart_contents', [ $this, 'enable_cart_coupon' ] );
			}

			if ( 'yes' === $settings['show_cross_sells'] ) {
				add_filter( 'single_product_archive_thumbnail_size', [ $this, 'cross_sell_thumbnail' ], 8 );
			}

			/**
			 * Fires inside the Woo - Cart widget wrapper, before the cart
			 * shortcode is rendered.
			 *
			 * @since 1.4.3
			 */
			do_action( 'pp_woo_before_cart_content' );

			// Remembered so the original registration can be restored exactly.
			// Another plugin may have moved or already removed it.
			$cross_sells_priority = has_action( 'woocommerce_cart_collaterals', 'woocommerce_cross_sell_display' );
			$hide_cross_sells     = '' === $settings['show_cross_sells'] && false !== $cross_sells_priority;

			if ( $hide_cross_sells ) {
				remove_action( 'woocommerce_cart_collaterals', 'woocommerce_cross_sell_display', $cross_sells_priority );
			}

			add_action( 'woocommerce_before_cart', [ $this, 'woocommerce_before_cart' ] );
			add_action( 'woocommerce_after_cart_table', [ $this, 'woocommerce_after_cart_table' ] );
			add_action( 'woocommerce_before_cart_table', [ $this, 'woocommerce_before_cart_table' ] );
			add_action( 'woocommerce_before_cart_collaterals', [ $this, 'woocommerce_before_cart_collaterals' ] );
			add_action( 'woocommerce_after_cart', [ $this, 'woocommerce_after_cart' ] );

			echo do_shortcode( '[woocommerce_cart]' );

			// Close anything the cart template left open. A theme that ships its
			// own cart/cart.php and drops one of the hooks above would otherwise
			// leak unclosed divs into the rest of the page.
			$this->close_cart_wrappers( $this->open_wrappers );

			if ( 'yes' === $settings['show_cross_sells'] ) {
				remove_filter( 'single_product_archive_thumbnail_size', [ $this, 'cross_sell_thumbnail' ], 8 );
			}

			if ( $hide_cross_sells ) {
				add_action( 'woocommerce_cart_collaterals', 'woocommerce_cross_sell_display', $cross_sells_priority );
			}

			/**
			 * Fires inside the Woo - Cart widget wrapper, after the cart
			 * shortcode has been rendered.
			 *
			 * @since 1.4.3
			 */
			do_action( 'pp_woo_after_cart_content' );

			/**
			 * Remove actions & filters after displaying our Widget.
			 */
			remove_filter( 'gettext', [ $this, 'filter_gettext' ], 20 );

			if ( $this->coupons_active ) {
				remove_action( 'woocommerce_cart_contents', [ $this, 'disable_cart_coupon' ] );
				remove_action( 'woocommerce_after_cart_contents', [ $this, 'enable_cart_coupon' ] );

				// Those hooks only fire for a cart with contents - an empty cart
				// renders cart-empty.php instead - so make sure the filter is
				// gone whether or not they ran.
				$this->enable_cart_coupon();
			}

			remove_action( 'woocommerce_before_cart', [ $this, 'woocommerce_before_cart' ] );
			remove_action( 'woocommerce_after_cart_table', [ $this, 'woocommerce_after_cart_table' ] );
			remove_action( 'woocommerce_before_cart_table', [ $this, 'woocommerce_before_cart_table' ] );
			remove_action( 'woocommerce_before_cart_collaterals', [ $this, 'woocommerce_before_cart_collaterals' ] );
			remove_action( 'woocommerce_after_cart', [ $this, 'woocommerce_after_cart' ] );
			?>
		</div>

		<?php
		/**
		 * Fires after the Woo - Cart widget's outer wrapper is closed.
		 *
		 * @since 1.4.3
		 */
		do_action( 'pp_woo_after_cart_wrap' );
	}

	/**
	 * Set the product thumbnail size on cross sell.
	 *
	 * @since 2.3.0
	 * @access public
	 *
	 * @param string $size Registered image size (default: 'woocommerce_thumbnail').
	 * @return string Image size selected on the widget, or $size when unset.
	 */
	public function cross_sell_thumbnail( $size ) {
		$settings = $this->get_settings_for_display();

		return $settings['cross_sell_thumbnail_size'] ? $settings['cross_sell_thumbnail_size'] : $size;
	}
}
