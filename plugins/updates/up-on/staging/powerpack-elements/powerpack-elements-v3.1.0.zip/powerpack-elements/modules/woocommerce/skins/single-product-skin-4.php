<?php
/**
 * PowerPack WooCommerce Skin Grid - Default.
 *
 * @package PowerPack
 */

namespace PowerpackElements\Modules\Woocommerce\Skins;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Class Single_Product_Skin_4
 *
 * @property Products $parent
 */
class Single_Product_Skin_4 extends Single_Product_Base {

	/**
	 * Get ID.
	 *
	 * @since 2.7.0
	 * @access public
	 */
	public function get_id() {
		return 'skin-4';
	}

	/**
	 * Get title.
	 *
	 * @since 2.7.0
	 * @access public
	 */
	public function get_title() {
		return esc_html__( 'Skin 4', 'powerpack' );
	}

}
