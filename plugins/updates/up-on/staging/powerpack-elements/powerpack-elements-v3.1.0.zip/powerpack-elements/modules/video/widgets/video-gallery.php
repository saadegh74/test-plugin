<?php
namespace PowerpackElements\Modules\Video\Widgets;

use PowerpackElements\Base\Powerpack_Widget;
use PowerpackElements\Classes\PP_Helper;
use PowerpackElements\Classes\PP_Admin_Settings;

// Elementor Classes.
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Icons_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Embed;
use Elementor\Modules\DynamicTags\Module as TagsModule;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Video Gallery Widget
 */
class Video_Gallery extends Powerpack_Widget {

	/**
	 * Retrieve video gallery widget name.
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return parent::get_widget_name( 'Video_Gallery' );
	}

	/**
	 * Retrieve video gallery widget title.
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return parent::get_widget_title( 'Video_Gallery' );
	}

	/**
	 * Retrieve video gallery widget icon.
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return parent::get_widget_icon( 'Video_Gallery' );
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return parent::get_widget_keywords( 'Video_Gallery' );
	}

	/**
	 * Whether the widget output depends on dynamic content.
	 *
	 * Opts the widget out of Elementor's element cache invalidation.
	 *
	 * @access protected
	 *
	 * @return bool Whether the widget renders dynamic content.
	 */
	protected function is_dynamic_content(): bool {
		return false;
	}

	/**
	 * Retrieve the list of scripts the video gallery widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		if ( PP_Helper::is_edit_mode() || PP_Helper::is_preview_mode() ) {
			return [
				'jquery-fancybox',
				'swiper',
				'jquery-resize',
				'pp-video-gallery',
			];
		}

		$settings = $this->get_settings_for_display();
		$scripts = [];

		if ( 'lightbox' === $settings['click_action'] ) {
			array_push( $scripts, 'jquery-fancybox', 'pp-video-gallery' );
		}

		if ( 'grid' === $settings['layout'] || 'yes' === $settings['filter_enable'] || 'yes' === $settings['pagination'] ) {
			array_push( $scripts, 'pp-video-gallery' );
		}

		if ( 'carousel' === $settings['layout'] ) {
			array_push( $scripts, 'swiper', 'pp-video-gallery' );
		}

		return array_values( array_unique( $scripts ) );
	}

	/**
	 * Retrieve the list of styles the video gallery widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_style_depends() {
		if ( PP_Helper::is_edit_mode() || PP_Helper::is_preview_mode() ) {
			return [
				'fancybox',
				'e-swiper',
				'pp-swiper',
				'pp-filter-animations',
				'widget-pp-video-gallery',
			];
		}

		$settings = $this->get_settings_for_display();
		$styles = [ 'widget-pp-video-gallery' ];

		if ( 'grid' === $settings['layout'] && 'yes' === $settings['filter_enable'] ) {
			if ( 'none' !== $settings['pointer'] ) {
				array_push( $styles, 'pp-filter-animations' );
			}
		}

		if ( 'carousel' === $settings['layout'] ) {
			array_push( $styles, 'e-swiper', 'pp-swiper' );
		}

		if ( 'lightbox' === $settings['click_action'] ) {
			array_push( $styles, 'fancybox' );
		}

		return $styles;
	}

	/**
	 * Whether the widget renders Elementor's inner wrapper element.
	 *
	 * @access public
	 *
	 * @return bool Whether the inner wrapper should be printed.
	 */
	public function has_widget_inner_wrapper(): bool {
		return ! PP_Helper::is_feature_active( 'e_optimized_markup' );
	}

	/**
	 * Register video gallery widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 2.0.3
	 * @access protected
	 */
	protected function register_controls() {
		/* Content Tab */
		$this->register_content_gallery_controls();
		$this->register_content_filter_controls();
		$this->register_content_play_icon_controls();
		$this->register_content_settings_controls();
		$this->register_content_load_more_controls();
		$this->register_content_carousel_controls();

		/* Style Tab */
		$this->register_style_layout_controls();
		$this->register_style_overlay_controls();
		$this->register_style_play_icon_controls();
		$this->register_style_content_controls();
		$this->register_style_filter_controls();
		$this->register_style_arrows_controls();
		$this->register_style_pagination_dots_controls();
		$this->register_style_pagination_fraction_controls();
		$this->register_style_load_more_controls();
		$this->register_style_lightbox_controls();
	}

	/**
	 * Register the content tab Gallery controls.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_content_gallery_controls() {
		/**
		 * Content Tab: Gallery
		 */
		$this->start_controls_section(
			'section_gallery',
			[
				'label' => esc_html__( 'Gallery', 'powerpack' ),
			]
		);

		$this->add_control(
			'source',
			[
				'label'   => esc_html__( 'Source', 'powerpack' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'custom',
				'options' => [
					'custom'      => esc_html__( 'Custom', 'powerpack' ),
					'yt-playlist' => esc_html__( 'YouTube Playlist', 'powerpack' ),
					'yt-channel'  => esc_html__( 'YouTube Channel', 'powerpack' ),
				],
			]
		);

		$admin_link = PP_Admin_Settings::get_form_action( '&tab=integration' );
		if ( ! $this->get_youtube_api() ) {
			$this->add_control(
				'youtube_api_error_msg',
				[
					'type'            => Controls_Manager::RAW_HTML,
					'raw'             => sprintf(
						/* translators: 1: Link opening tag, 2: Link closing tag. */
						esc_html__( 'To display videos from YouTube Playlist or Channel, you must have a YouTube API key. %1$sClick here%2$s to setup your YouTube API key.', 'powerpack' ),
						sprintf( '<a href="%s" target="_blank">', $admin_link ),
						'</a>'
					),
					'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
					'condition'       => [
						'source' => [ 'yt-playlist', 'yt-channel' ],
					],
				]
			);
		}

		$this->add_control(
			'yt_playlist_id',
			[
				'label'       => esc_html__( 'YouTube Playlist ID', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active'     => true,
				],
				'placeholder' => esc_html__( 'Enter YouTube Playlist ID', 'powerpack' ),
				'default'     => '',
				'label_block' => true,
				'ai'          => [
					'active' => false,
				],
				'condition'   => [
					'source' => [ 'yt-playlist' ],
				],
			]
		);

		$this->add_control(
			'yt_channel_id',
			[
				'label'       => esc_html__( 'YouTube channel ID', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active'     => true,
				],
				'placeholder' => esc_html__( 'Enter YouTube channel ID', 'powerpack' ),
				'default'     => '',
				'label_block' => true,
				'ai'          => [
					'active' => false,
				],
				'condition'   => [
					'source' => [ 'yt-channel' ],
				],
			]
		);

		$this->add_control(
			'yt_vides_count',
			[
				'label'       => esc_html__( 'Number of Videos', 'powerpack' ),
				'description' => esc_html__( 'PowerPack allows fetching 200 videos from an API due to performance issues.', 'powerpack' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 9,
				'min'         => 1,
				'max'         => 200,
				'step'        => 1,
				'condition'   => [
					'source' => [ 'yt-playlist', 'yt-channel' ],
				],
			]
		);

		$this->add_control(
			'yt_video_title_show',
			[
				'label'        => esc_html__( 'Show Video Title', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'default'      => 'no',
				'condition'    => [
					'source' => [ 'yt-playlist', 'yt-channel' ],
				],
			]
		);

		$this->add_control(
			'yt_video_title',
			[
				'label'                 => esc_html__( 'Video Title', 'powerpack' ),
				'type'                  => Controls_Manager::TEXT,
				'label_block'           => true,
				'default'               => '',
				'placeholder'           => '',
				'dynamic'               => [
					'active' => true,
				],
				'condition'   => [
					'source'              => [ 'yt-playlist', 'yt-channel' ],
					'yt_video_title_show' => 'yes',
				],
			]
		);

		$this->add_control(
			'yt_title_length',
			[
				'label'       => esc_html__( 'Title Length', 'powerpack' ),
				'title'       => esc_html__( 'Words', 'powerpack' ),
				'description' => esc_html__( 'Number of words to be displayed from the video title', 'powerpack' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 10,
				'min'         => 0,
				'step'        => 1,
				'condition'   => [
					'source'              => [ 'yt-playlist', 'yt-channel' ],
					'yt_video_title_show' => 'yes',
				],
			]
		);

		$this->add_control(
			'yt_video_description_show',
			[
				'label'        => esc_html__( 'Show Video Description', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
				'default'      => 'no',
				'condition'    => [
					'source' => [ 'yt-playlist', 'yt-channel' ],
				],
			]
		);

		$this->add_control(
			'yt_video_description',
			[
				'label'                 => esc_html__( 'Description', 'powerpack' ),
				'type'                  => Controls_Manager::TEXTAREA,
				'label_block'           => true,
				'rows'                  => 3,
				'default'               => '',
				'placeholder'           => '',
				'dynamic'               => [
					'active' => true,
				],
				'condition'   => [
					'source'                    => [ 'yt-playlist', 'yt-channel' ],
					'yt_video_description_show' => 'yes',
				],
			]
		);

		$this->add_control(
			'yt_content_length',
			[
				'label'       => esc_html__( 'Description Length', 'powerpack' ),
				'title'       => esc_html__( 'Words', 'powerpack' ),
				'description' => esc_html__( 'Number of words to be displayed from the video description', 'powerpack' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 30,
				'min'         => 0,
				'step'        => 1,
				'condition'   => [
					'source'                    => [ 'yt-playlist', 'yt-channel' ],
					'yt_video_description_show' => 'yes',
				],
			]
		);

		$this->add_control(
			'yt_thumbnail_size',
			[
				'label'                 => esc_html__( 'Thumbnail Size', 'powerpack' ),
				'type'                  => Controls_Manager::SELECT,
				'default'               => 'maxresdefault',
				'options'               => [
					'maxresdefault' => esc_html__( 'Maximum Resolution', 'powerpack' ),
					'hqdefault'     => esc_html__( 'High Quality', 'powerpack' ),
					'mqdefault'     => esc_html__( 'Medium Quality', 'powerpack' ),
					'sddefault'     => esc_html__( 'Standard Quality', 'powerpack' ),
				],
				'condition'   => [
					'source' => [ 'yt-playlist', 'yt-channel' ],
				],
			]
		);

		$this->add_control(
			'videos_refresh_time',
			[
				'label'   => esc_html__( 'Refresh Videos after', 'powerpack' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'day',
				'options' => [
					'hour'  => esc_html__( 'Hour', 'powerpack' ),
					'day'   => esc_html__( 'Day', 'powerpack' ),
					'week'  => esc_html__( 'Week', 'powerpack' ),
					'month' => esc_html__( 'Month', 'powerpack' ),
					'year'  => esc_html__( 'Year', 'powerpack' ),
				],
				'condition'   => [
					'source' => [ 'yt-playlist', 'yt-channel' ],
				],
			]
		);

		$repeater = new Repeater();

		$repeater->start_controls_tabs( 'tabs_video_gallery' );

		$repeater->start_controls_tab(
			'tab_content',
			[
				'label' => esc_html__( 'Content', 'powerpack' ),
			]
		);

		$repeater->add_control(
			'video_source',
			[
				'label'   => esc_html__( 'Source', 'powerpack' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'youtube',
				'options' => [
					'youtube'     => esc_html__( 'YouTube', 'powerpack' ),
					'vimeo'       => esc_html__( 'Vimeo', 'powerpack' ),
					'dailymotion' => esc_html__( 'Dailymotion', 'powerpack' ),
					'hosted'      => esc_html__( 'Self Hosted', 'powerpack' ),
				],
			]
		);

		$repeater->add_control(
			'insert_url',
			[
				'label'     => esc_html__( 'External URL', 'powerpack' ),
				'type'      => Controls_Manager::SWITCHER,
				'ai'        => [
					'active' => false,
				],
				'condition' => [
					'video_source' => 'hosted',
				],
			]
		);

		$repeater->add_control(
			'hosted_url',
			[
				'label'      => esc_html__( 'Choose File', 'powerpack' ),
				'type'       => Controls_Manager::MEDIA,
				'dynamic'    => [
					'active' => true,
					'categories' => [
						TagsModule::MEDIA_CATEGORY,
					],
				],
				'media_type' => 'video',
				'ai'         => [
					'active' => false,
				],
				'condition'  => [
					'video_source' => 'hosted',
					'insert_url'   => '',
				],
			]
		);

		$repeater->add_control(
			'external_url',
			[
				'label'        => esc_html__( 'URL', 'powerpack' ),
				'type'         => Controls_Manager::URL,
				'autocomplete' => false,
				'options'      => false,
				'label_block'  => true,
				'show_label'   => false,
				'dynamic'      => [
					'active' => true,
					'categories' => [
						TagsModule::POST_META_CATEGORY,
						TagsModule::URL_CATEGORY,
					],
				],
				'media_type'   => 'video',
				'placeholder'  => esc_html__( 'Enter your URL', 'powerpack' ),
				'ai'           => [
					'active' => false,
				],
				'condition'    => [
					'video_source' => 'hosted',
					'insert_url'   => 'yes',
				],
			]
		);

		$repeater->add_control(
			'start',
			[
				'label'       => esc_html__( 'Start Time', 'powerpack' ),
				'type'        => Controls_Manager::NUMBER,
				'description' => esc_html__( 'Specify a start time (in seconds)', 'powerpack' ),
				'dynamic'     => [
					'active' => true,
				],
				'condition'   => [
					'video_source' => 'hosted',
				],
			]
		);

		$repeater->add_control(
			'end',
			[
				'label'       => esc_html__( 'End Time', 'powerpack' ),
				'type'        => Controls_Manager::NUMBER,
				'description' => esc_html__( 'Specify an end time (in seconds)', 'powerpack' ),
				'dynamic'     => [
					'active' => true,
				],
				'condition'   => [
					'video_source' => 'hosted',
				],
			]
		);

		$repeater->add_control(
			'youtube_url',
			[
				'label'       => esc_html__( 'URL', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active'     => true,
					'categories' => [
						TagsModule::POST_META_CATEGORY,
						TagsModule::URL_CATEGORY,
					],
				],
				'placeholder' => esc_html__( 'Enter your YouTube URL', 'powerpack' ),
				'default'     => 'https://www.youtube.com/watch?v=XHOmBV4js_E',
				'label_block' => true,
				'ai'          => [
					'active' => false,
				],
				'condition'   => [
					'video_source' => 'youtube',
				],
			]
		);

		$repeater->add_control(
			'vimeo_url',
			[
				'label'       => esc_html__( 'URL', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active'     => true,
					'categories' => [
						TagsModule::POST_META_CATEGORY,
						TagsModule::URL_CATEGORY,
					],
				],
				'placeholder' => esc_html__( 'Enter your Vimeo URL', 'powerpack' ),
				'default'     => 'https://vimeo.com/235215203',
				'label_block' => true,
				'ai'          => [
					'active' => false,
				],
				'condition'   => [
					'video_source' => 'vimeo',
				],
			]
		);

		$repeater->add_control(
			'dailymotion_url',
			[
				'label'       => esc_html__( 'URL', 'powerpack' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active'     => true,
					'categories' => [
						TagsModule::POST_META_CATEGORY,
						TagsModule::URL_CATEGORY,
					],
				],
				'placeholder' => esc_html__( 'Enter your Dailymotion URL', 'powerpack' ),
				'default'     => 'https://www.dailymotion.com/video/x6tqhqb',
				'label_block' => true,
				'ai'          => [
					'active' => false,
				],
				'condition'   => [
					'video_source' => 'dailymotion',
				],
			]
		);

		$repeater->add_control(
			'cc_load_policy',
			[
				'label'     => esc_html__( 'Captions', 'powerpack' ),
				'type'      => Controls_Manager::SWITCHER,
				'condition' => [
					'video_source' => 'youtube',
				],
			]
		);

		$repeater->add_control(
			'filter_label',
			[
				'label'                 => esc_html__( 'Filter Label', 'powerpack' ),
				'type'                  => Controls_Manager::TEXT,
				'default'               => '',
				'placeholder'           => '',
				'dynamic'               => [
					'active' => true,
				],
			]
		);

		$repeater->add_control(
			'video_title',
			[
				'label'                 => esc_html__( 'Video Title', 'powerpack' ),
				'type'                  => Controls_Manager::TEXT,
				'label_block'           => true,
				'default'               => '',
				'placeholder'           => '',
				'dynamic'               => [
					'active' => true,
				],
			]
		);

		$repeater->add_control(
			'video_description',
			[
				'label'                 => esc_html__( 'Description', 'powerpack' ),
				'type'                  => Controls_Manager::TEXTAREA,
				'label_block'           => true,
				'rows'                  => 3,
				'default'               => '',
				'placeholder'           => '',
				'dynamic'               => [
					'active' => true,
				],
			]
		);

		$repeater->add_control(
			'thumbnail_size',
			[
				'label'                 => esc_html__( 'Thumbnail Size', 'powerpack' ),
				'type'                  => Controls_Manager::SELECT,
				'default'               => 'maxresdefault',
				'options'               => [
					'maxresdefault' => esc_html__( 'Maximum Resolution', 'powerpack' ),
					'hqdefault'     => esc_html__( 'High Quality', 'powerpack' ),
					'mqdefault'     => esc_html__( 'Medium Quality', 'powerpack' ),
					'sddefault'     => esc_html__( 'Standard Quality', 'powerpack' ),
				],
				'condition'             => [
					'video_source' => 'youtube',
				],
			]
		);

		$repeater->add_control(
			'custom_thumbnail',
			[
				'label'                 => esc_html__( 'Custom Thumbnail', 'powerpack' ),
				'type'                  => Controls_Manager::SWITCHER,
				'default'               => '',
			]
		);

		$repeater->add_control(
			'custom_image',
			[
				'label'                 => esc_html__( 'Image', 'powerpack' ),
				'type'                  => Controls_Manager::MEDIA,
				'default'               => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'dynamic'               => [
					'active' => true,
				],
				'conditions'            => [
					'terms' => [
						[
							'name'      => 'custom_thumbnail',
							'operator'  => '==',
							'value'     => 'yes',
						],
					],
				],
			]
		);

		$repeater->end_controls_tab();

		$repeater->start_controls_tab(
			'tab_schema',
			[
				'label' => esc_html__( 'Schema', 'powerpack' ),
			]
		);

		$repeater->add_control(
			'video_schema_title',
			[
				'label'                 => esc_html__( 'Video Title', 'powerpack' ),
				'type'                  => Controls_Manager::TEXT,
				'label_block'           => true,
				'default'               => '',
				'placeholder'           => '',
				'dynamic'               => [
					'active' => true,
				],
			]
		);

		$repeater->add_control(
			'video_schema_description',
			[
				'label'                 => esc_html__( 'Description', 'powerpack' ),
				'type'                  => Controls_Manager::TEXTAREA,
				'label_block'           => true,
				'rows'                  => 3,
				'default'               => '',
				'placeholder'           => '',
				'dynamic'               => [
					'active' => true,
				],
			]
		);

		$repeater->add_control(
			'video_schema_image',
			[
				'label'                 => esc_html__( 'Image', 'powerpack' ),
				'type'                  => Controls_Manager::MEDIA,
				'default'               => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'dynamic'               => [
					'active' => true,
				],
			]
		);

		$repeater->add_control(
			'video_schema_upload_date',
			[
				'label'                 => esc_html__( 'Upload Date & Time', 'powerpack' ),
				'type'                  => Controls_Manager::DATE_TIME,
				'default'               => gmdate( 'Y-m-d H:i' ),
			]
		);

		$repeater->end_controls_tab();

		$repeater->end_controls_tabs();

		$this->add_control(
			'gallery_videos',
			[
				'label'       => '',
				'type'        => Controls_Manager::REPEATER,
				'default'     => [
					[
						'video_source' => 'youtube',
						'youtube_url'  => 'https://www.youtube.com/watch?v=XHOmBV4js_E',
						'filter_label' => 'YouTube',
					],
					[
						'video_source' => 'vimeo',
						'vimeo_url'    => 'https://vimeo.com/235215203',
						'filter_label' => 'Vimeo',
					],
					[
						'video_source'    => 'dailymotion',
						'dailymotion_url' => 'https://www.dailymotion.com/video/x6tqhqb',
						'filter_label'    => 'Dailymotion',
					],
					[
						'video_source' => 'vimeo',
						'vimeo_url'    => 'https://vimeo.com/235215203',
						'filter_label' => 'Vimeo',
					],
					[
						'video_source'    => 'dailymotion',
						'dailymotion_url' => 'https://www.dailymotion.com/video/x6tqhqb',
						'filter_label'    => 'Dailymotion',
					],
					[
						'video_source' => 'youtube',
						'youtube_url'  => 'https://www.youtube.com/watch?v=XHOmBV4js_E',
						'filter_label' => 'YouTube',
					],
				],
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ video_title }}}',
				'condition'   => [
					'source' => [ 'custom' ],
				],
			]
		);

		$this->add_control(
			'enable_schema',
			[
				'label'        => esc_html__( 'Enable Schema', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'return_value' => 'yes',
				'separator'    => 'before',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the content tab Filter controls.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_content_filter_controls() {
		/**
		 * Content Tab: Filter
		 */
		$this->start_controls_section(
			'section_filter',
			[
				'label'     => esc_html__( 'Filter', 'powerpack' ),
				'condition' => [
					'layout' => 'grid',
					'source!' => [ 'yt-playlist', 'yt-channel' ],
				],
			]
		);

		$this->add_control(
			'filter_enable',
			[
				'label'     => esc_html__( 'Enable Filter', 'powerpack' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => '',
				'condition' => [
					'layout' => 'grid',
					'source!' => [ 'yt-playlist', 'yt-channel' ],
				],
			]
		);

		$this->add_control(
			'filter_all_label',
			[
				'label'     => esc_html__( '"All" Filter Label', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'All', 'powerpack' ),
				'condition' => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
					'source!' => [ 'yt-playlist', 'yt-channel' ],
				],
			]
		);

		$this->add_responsive_control(
			'filter_alignment',
			[
				'label'       => esc_html__( 'Alignment', 'powerpack' ),
				'label_block' => false,
				'type'        => Controls_Manager::CHOOSE,
				'default'     => 'center',
				'options'     => [
					'left'   => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-h-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-h-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'selectors'   => [
					'{{WRAPPER}} .pp-gallery-filters' => 'text-align: {{VALUE}};',
				],
				'condition'   => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
					'source!' => [ 'yt-playlist', 'yt-channel' ],
				],
			]
		);

		$this->add_control(
			'pointer',
			[
				'label'          => esc_html__( 'Pointer', 'powerpack' ),
				'type'           => Controls_Manager::SELECT,
				'default'        => 'underline',
				'options'        => [
					'none'        => esc_html__( 'None', 'powerpack' ),
					'underline'   => esc_html__( 'Underline', 'powerpack' ),
					'overline'    => esc_html__( 'Overline', 'powerpack' ),
					'double-line' => esc_html__( 'Double Line', 'powerpack' ),
					'framed'      => esc_html__( 'Framed', 'powerpack' ),
					'background'  => esc_html__( 'Background', 'powerpack' ),
					'text'        => esc_html__( 'Text', 'powerpack' ),
				],
				'style_transfer' => true,
				'condition'      => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
					'source!' => [ 'yt-playlist', 'yt-channel' ],
				],
			]
		);

		$this->add_control(
			'animation_line',
			[
				'label'     => esc_html__( 'Animation', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'fade',
				'options'   => [
					'fade'     => esc_html__( 'Fade', 'powerpack' ),
					'slide'    => esc_html__( 'Slide', 'powerpack' ),
					'grow'     => esc_html__( 'Grow', 'powerpack' ),
					'drop-in'  => esc_html__( 'Drop In', 'powerpack' ),
					'drop-out' => esc_html__( 'Drop Out', 'powerpack' ),
					'none'     => esc_html__( 'None', 'powerpack' ),
				],
				'condition' => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
					'pointer'       => [ 'underline', 'overline', 'double-line' ],
					'source!' => [ 'yt-playlist', 'yt-channel' ],
				],
			]
		);

		$this->add_control(
			'animation_framed',
			[
				'label'     => esc_html__( 'Animation', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'fade',
				'options'   => [
					'fade'    => esc_html__( 'Fade', 'powerpack' ),
					'grow'    => esc_html__( 'Grow', 'powerpack' ),
					'shrink'  => esc_html__( 'Shrink', 'powerpack' ),
					'draw'    => esc_html__( 'Draw', 'powerpack' ),
					'corners' => esc_html__( 'Corners', 'powerpack' ),
					'none'    => esc_html__( 'None', 'powerpack' ),
				],
				'condition' => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
					'pointer'       => 'framed',
					'source!' => [ 'yt-playlist', 'yt-channel' ],
				],
			]
		);

		$this->add_control(
			'animation_background',
			[
				'label'     => esc_html__( 'Animation', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'fade',
				'options'   => [
					'fade'                   => esc_html__( 'Fade', 'powerpack' ),
					'grow'                   => esc_html__( 'Grow', 'powerpack' ),
					'shrink'                 => esc_html__( 'Shrink', 'powerpack' ),
					'sweep-left'             => esc_html__( 'Sweep Left', 'powerpack' ),
					'sweep-right'            => esc_html__( 'Sweep Right', 'powerpack' ),
					'sweep-up'               => esc_html__( 'Sweep Up', 'powerpack' ),
					'sweep-down'             => esc_html__( 'Sweep Down', 'powerpack' ),
					'shutter-in-vertical'    => esc_html__( 'Shutter In Vertical', 'powerpack' ),
					'shutter-out-vertical'   => esc_html__( 'Shutter Out Vertical', 'powerpack' ),
					'shutter-in-horizontal'  => esc_html__( 'Shutter In Horizontal', 'powerpack' ),
					'shutter-out-horizontal' => esc_html__( 'Shutter Out Horizontal', 'powerpack' ),
					'none'                   => esc_html__( 'None', 'powerpack' ),
				],
				'condition' => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
					'pointer'       => 'background',
					'source!' => [ 'yt-playlist', 'yt-channel' ],
				],
			]
		);

		$this->add_control(
			'animation_text',
			[
				'label'     => esc_html__( 'Animation', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'grow',
				'options'   => [
					'grow'   => esc_html__( 'Grow', 'powerpack' ),
					'shrink' => esc_html__( 'Shrink', 'powerpack' ),
					'sink'   => esc_html__( 'Sink', 'powerpack' ),
					'float'  => esc_html__( 'Float', 'powerpack' ),
					'skew'   => esc_html__( 'Skew', 'powerpack' ),
					'rotate' => esc_html__( 'Rotate', 'powerpack' ),
					'none'   => esc_html__( 'None', 'powerpack' ),
				],
				'condition' => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
					'pointer'       => 'text',
					'source!' => [ 'yt-playlist', 'yt-channel' ],
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the content tab Play Icon controls.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_content_play_icon_controls() {
		/**
		 * Content Tab: Play Icon
		 */
		$this->start_controls_section(
			'section_play_icon_settings',
			[
				'label' => esc_html__( 'Play Icon', 'powerpack' ),
			]
		);

		$this->add_control(
			'play_icon_type',
			[
				'label'       => esc_html__( 'Icon Type', 'powerpack' ),
				'label_block' => false,
				'toggle'      => false,
				'type'        => Controls_Manager::CHOOSE,
				'options'     => [
					'none'  => [
						'title' => esc_html__( 'None', 'powerpack' ),
						'icon'  => 'eicon-ban',
					],
					'icon'  => [
						'title' => esc_html__( 'Icon', 'powerpack' ),
						'icon'  => 'eicon-star',
					],
					'image' => [
						'title' => esc_html__( 'Image', 'powerpack' ),
						'icon'  => 'eicon-image-bold',
					],
				],
				'default'     => 'icon',
			]
		);

		$this->add_control(
			'select_play_icon',
			[
				'label'            => esc_html__( 'Select Icon', 'powerpack' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'play_icon',
				'default'          => [
					'value'   => 'fas fa-play-circle',
					'library' => 'fa-solid',
				],
				'recommended'      => [
					'fa-regular' => [
						'play-circle',
					],
					'fa-solid'   => [
						'play',
						'play-circle',
					],
				],
				'condition'        => [
					'play_icon_type' => 'icon',
				],
			]
		);

		$this->add_control(
			'play_icon_image',
			[
				'label'     => esc_html__( 'Select Image', 'powerpack' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'dynamic'   => [
					'active' => true,
				],
				'condition' => [
					'play_icon_type' => 'image',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the content tab Gallery Settings controls.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_content_settings_controls() {
		/**
		 * Content Tab: Gallery Settings
		 */
		$this->start_controls_section(
			'section_settings',
			[
				'label' => esc_html__( 'Gallery Settings', 'powerpack' ),
			]
		);

		$this->add_control(
			'layout',
			[
				'label'              => esc_html__( 'Layout', 'powerpack' ),
				'type'               => Controls_Manager::SELECT,
				'default'            => 'grid',
				'options'            => [
					'grid'     => esc_html__( 'Grid', 'powerpack' ),
					'carousel' => esc_html__( 'Carousel', 'powerpack' ),
				],
				'frontend_available' => true,
			]
		);

		$this->add_responsive_control(
			'columns',
			[
				'label'          => esc_html__( 'Columns', 'powerpack' ),
				'type'           => Controls_Manager::SELECT,
				'default'        => '3',
				'tablet_default' => '2',
				'mobile_default' => '1',
				'options'        => [
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
					'5' => '5',
					'6' => '6',
					'7' => '7',
					'8' => '8',
				],
				'prefix_class'   => 'elementor-grid%s-',
				// Also feeds slides_per_view in slider_settings(), which is printed into
				// data-slider-settings, so the markup has to be rebuilt when it changes.
				'render_type'    => 'template',
			]
		);

		$this->add_control(
			'aspect_ratio',
			[
				'label'                => esc_html__( 'Aspect Ratio', 'powerpack' ),
				'type'                 => Controls_Manager::SELECT,
				'options'              => [
					'169' => '16:9',
					'219' => '21:9',
					'916' => '9:16',
					'43'  => '4:3',
					'32'  => '3:2',
					'11'  => '1:1',
				],
				'selectors_dictionary'  => [
					'169' => '1.77777', // 16 / 9
					'219' => '2.33333', // 21 / 9
					'43'  => '1.33333', // 4 / 3
					'32'  => '1.5', // 3 / 2
					'11'  => '1', // 1 / 1
					'916' => '0.5625', // 9 / 16
				],
				'default'              => '169',
				'selectors'            => [
					'{{WRAPPER}} .pp-video-container' => 'aspect-ratio: {{VALUE}}',
					// The lightbox is appended to the body, so it is addressed by its own class
					// rather than through the widget wrapper.
					'.pp-video-gallery-lightbox-{{ID}} .fancybox-content' => '--pp-lightbox-aspect-ratio: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'preload',
			[
				'label'       => esc_html__( 'Preload', 'powerpack' ),
				'description' => esc_html__( 'Use in case of self hosted video', 'powerpack' ),
				'type'        => Controls_Manager::SELECT,
				'options'     => [
					'auto'     => esc_html__( 'Auto', 'powerpack' ),
					'metadata' => esc_html__( 'Meta data', 'powerpack' ),
					'none'     => esc_html__( 'None', 'powerpack' ),
				],
				'default'     => 'auto',
			]
		);

		$this->add_control(
			'mute',
			[
				'label'        => esc_html__( 'Mute', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => '',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'click_action',
			[
				'label'   => esc_html__( 'Click Action', 'powerpack' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'inline',
				'options' => [
					'inline'   => esc_html__( 'Play Inline', 'powerpack' ),
					'lightbox' => esc_html__( 'Play in Lightbox', 'powerpack' ),
				],
			]
		);

		$this->add_control(
			'ordering',
			[
				'label'   => esc_html__( 'Ordering', 'powerpack' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					''       => esc_html__( 'Default', 'powerpack' ),
					'random' => esc_html__( 'Random', 'powerpack' ),
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the content tab Load More Button controls.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_content_load_more_controls() {
		/**
		 * Content Tab: Load More Button
		 */
		$this->start_controls_section(
			'section_pagination',
			[
				'label'     => esc_html__( 'Load More Button', 'powerpack' ),
				'condition' => [
					'layout!'        => 'carousel',
					'filter_enable!' => 'yes',
					'source'         => 'custom',
				],
			]
		);

		$this->add_control(
			'pagination',
			[
				'label'     => esc_html__( 'Load More Button', 'powerpack' ),
				'type'      => Controls_Manager::SWITCHER,
				'default'   => '',
				'condition' => [
					'layout!' => 'carousel',
					'filter_enable!' => 'yes',
				],
			]
		);

		$this->add_control(
			'images_per_page',
			[
				'label'     => esc_html__( 'Images Per Page', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => 6,
				'ai'        => [
					'active' => false,
				],
				'condition' => [
					'layout!' => 'carousel',
					'filter_enable!' => 'yes',
					'pagination' => 'yes',
				],
			]
		);

		$this->add_control(
			'load_more_text',
			[
				'label'     => esc_html__( 'Button Text', 'powerpack' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => esc_html__( 'Load More', 'powerpack' ),
				'condition' => [
					'layout!' => 'carousel',
					'filter_enable!' => 'yes',
					'pagination' => 'yes',
				],
			]
		);

		$this->add_control(
			'select_load_more_icon',
			[
				'label'            => esc_html__( 'Button Icon', 'powerpack' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'load_more_icon',
				'condition'        => [
					'layout!' => 'carousel',
					'filter_enable!' => 'yes',
					'pagination' => 'yes',
				],
			]
		);

		$this->add_control(
			'button_icon_position',
			[
				'label'     => esc_html__( 'Icon Position', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'after',
				'options'   => [
					'after'  => esc_html__( 'After', 'powerpack' ),
					'before' => esc_html__( 'Before', 'powerpack' ),
				],
				'condition' => [
					'layout!' => 'carousel',
					'filter_enable!' => 'yes',
					'pagination' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'load_more_align',
			[
				'label'     => esc_html__( 'Alignment', 'powerpack' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-h-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-h-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'default'   => 'center',
				'selectors' => [
					'{{WRAPPER}} .pp-video-gallery-pagination' => 'text-align: {{VALUE}};',
				],
				'condition' => [
					'layout!' => 'carousel',
					'filter_enable!' => 'yes',
					'pagination' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the content tab Carousel Settings controls.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_content_carousel_controls() {
		/**
		 * Content Tab: Carousel Settings
		 */
		$this->start_controls_section(
			'section_additional_options',
			[
				'label'     => esc_html__( 'Carousel Settings', 'powerpack' ),
				'condition' => [
					'layout' => 'carousel',
				],
			]
		);

		$this->add_control(
			'animation_speed',
			[
				'label'   => esc_html__( 'Animation Speed', 'powerpack' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 500,
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'        => esc_html__( 'Autoplay', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'autoplay_speed',
			[
				'label'     => esc_html__( 'Autoplay Speed', 'powerpack' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 3000,
				'condition' => [
					'autoplay' => 'yes',
				],
			]
		);

		$this->add_control(
			'pause_on_hover',
			[
				'label'              => esc_html__( 'Pause on Hover', 'powerpack' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => 'yes',
				'label_on'           => esc_html__( 'Yes', 'powerpack' ),
				'label_off'          => esc_html__( 'No', 'powerpack' ),
				'return_value'       => 'yes',
				'frontend_available' => true,
				'condition'          => [
					'autoplay' => 'yes',
				],
			]
		);

		$this->add_control(
			'infinite_loop',
			[
				'label'        => esc_html__( 'Infinite Loop', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'adaptive_height',
			[
				'label'        => esc_html__( 'Adaptive Height', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'direction',
			[
				'label'       => esc_html__( 'Direction', 'powerpack' ),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => false,
				'toggle'      => false,
				'options'     => [
					'left'  => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-h-align-left',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'default'     => 'left',
			]
		);

		$this->add_control(
			'navigation_heading',
			[
				'label'     => esc_html__( 'Navigation', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'arrows',
			[
				'label'        => esc_html__( 'Arrows', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'dots',
			[
				'label'        => esc_html__( 'Pagination', 'powerpack' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'no',
				'label_on'     => esc_html__( 'Yes', 'powerpack' ),
				'label_off'    => esc_html__( 'No', 'powerpack' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'pagination_type',
			[
				'label'     => esc_html__( 'Pagination Type', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'bullets',
				'options'   => [
					'bullets'  => esc_html__( 'Dots', 'powerpack' ),
					'fraction' => esc_html__( 'Fraction', 'powerpack' ),
				],
				'condition' => [
					'dots' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the style tab Layout controls.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_style_layout_controls() {
		/**
		 * Style Tab: Layout
		 */
		$this->start_controls_section(
			'section_layout_style',
			[
				'label' => esc_html__( 'Layout', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'columns_gap',
			[
				'label'          => esc_html__( 'Columns Gap', 'powerpack' ),
				'type'           => Controls_Manager::SLIDER,
				'size_units'     => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'        => [
					'size' => 20,
					'unit' => 'px',
				],
				'range'          => [
					'px' => [
						'max' => 100,
					],
				],
				'tablet_default' => [
					'unit' => 'px',
				],
				'mobile_default' => [
					'unit' => 'px',
				],
				'render_type'    => 'template',
				'selectors'      => [
					'{{WRAPPER}}' => '--grid-column-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'rows_gap',
			[
				'label'          => esc_html__( 'Rows Gap', 'powerpack' ),
				'type'           => Controls_Manager::SLIDER,
				'size_units'     => [ 'px', '%', 'em', 'rem', 'custom' ],
				'default'        => [
					'size' => 20,
					'unit' => 'px',
				],
				'range'          => [
					'px' => [
						'max' => 100,
					],
				],
				'tablet_default' => [
					'unit' => 'px',
				],
				'mobile_default' => [
					'unit' => 'px',
				],
				'selectors'      => [
					'{{WRAPPER}}' => '--grid-row-gap: {{SIZE}}{{UNIT}};',
				],
				'condition'      => [
					'layout' => 'grid',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the style tab Overlay controls.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_style_overlay_controls() {
		/**
		 * Style Tab: Overlay
		 */
		$this->start_controls_section(
			'section_overlay_style',
			[
				'label' => esc_html__( 'Overlay', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'overlay_blend_mode',
			[
				'label'     => esc_html__( 'Blend Mode', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'normal',
				'options'   => [
					'normal'      => esc_html__( 'Normal', 'powerpack' ),
					'multiply'    => esc_html__( 'Multiply', 'powerpack' ),
					'screen'      => esc_html__( 'Screen', 'powerpack' ),
					'overlay'     => esc_html__( 'Overlay', 'powerpack' ),
					'darken'      => esc_html__( 'Darken', 'powerpack' ),
					'lighten'     => esc_html__( 'Lighten', 'powerpack' ),
					'color-dodge' => esc_html__( 'Color Dodge', 'powerpack' ),
					'color'       => esc_html__( 'Color', 'powerpack' ),
					'hue'         => esc_html__( 'Hue', 'powerpack' ),
					'hard-light'  => esc_html__( 'Hard Light', 'powerpack' ),
					'soft-light'  => esc_html__( 'Soft Light', 'powerpack' ),
					'difference'  => esc_html__( 'Difference', 'powerpack' ),
					'exclusion'   => esc_html__( 'Exclusion', 'powerpack' ),
					'saturation'  => esc_html__( 'Saturation', 'powerpack' ),
					'luminosity'  => esc_html__( 'Luminosity', 'powerpack' ),
				],
				'selectors' => [
					'{{WRAPPER}} .pp-video-overlay' => 'mix-blend-mode: {{VALUE}};',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_overlay_style' );

		$this->start_controls_tab(
			'tab_overlay_normal',
			[
				'label' => esc_html__( 'Normal', 'powerpack' ),
			]
		);

		$this->add_control(
			'overlay_background_color_normal',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-video-overlay' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'overlay_margin_normal',
			[
				'label'      => esc_html__( 'Margin', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-video-overlay' => 'top: {{SIZE}}{{UNIT}}; bottom: {{SIZE}}{{UNIT}}; left: {{SIZE}}{{UNIT}}; right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'overlay_opacity_normal',
			[
				'label'     => esc_html__( 'Opacity', 'powerpack' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => 0,
						'max'  => 1,
						'step' => 0.1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .pp-video-overlay' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_overlay_hover',
			[
				'label' => esc_html__( 'Hover', 'powerpack' ),
			]
		);

		$this->add_control(
			'overlay_background_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-grid-item-wrap:hover .pp-video-overlay' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'overlay_margin_hover',
			[
				'label'      => esc_html__( 'Margin', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-grid-item-wrap:hover .pp-video-overlay' => 'top: {{SIZE}}{{UNIT}}; bottom: {{SIZE}}{{UNIT}}; left: {{SIZE}}{{UNIT}}; right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'overlay_opacity_hover',
			[
				'label'     => esc_html__( 'Opacity', 'powerpack' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min'  => 0,
						'max'  => 1,
						'step' => 0.1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .pp-grid-item-wrap:hover .pp-video-overlay' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Register the style tab Play Icon controls.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_style_play_icon_controls() {
		/**
		 * Style Tab: Play Icon
		 */
		$this->start_controls_section(
			'section_play_icon_style',
			[
				'label'     => esc_html__( 'Play Icon', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'play_icon_type!' => 'none',
				],
			]
		);

		$this->add_responsive_control(
			'play_icon_size',
			[
				'label'      => esc_html__( 'Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min' => 10,
						'max' => 400,
					],
				],
				'default'    => [
					'size' => 50,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--pp-play-icon-size: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'play_icon_type!' => 'none',
				],
			]
		);

		$this->add_control(
			'play_icon_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-video-play-icon img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'play_icon_type' => 'image',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_play_icon_style' );

		$this->start_controls_tab(
			'tab_play_icon_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => [
					'play_icon_type'           => 'icon',
					'select_play_icon[value]!' => '',
				],
			]
		);

		$this->add_control(
			'play_icon_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-video-play-icon'     => 'color: {{VALUE}}',
					'{{WRAPPER}} .pp-video-play-icon svg' => 'fill: {{VALUE}}',
				],
				'condition' => [
					'play_icon_type'           => 'icon',
					'select_play_icon[value]!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name'      => 'play_icon_text_shadow',
				'label'     => esc_html__( 'Shadow', 'powerpack' ),
				'selector'  => '{{WRAPPER}} .pp-video-play-icon',
				'condition' => [
					'play_icon_type'           => 'icon',
					'select_play_icon[value]!' => '',
				],
			]
		);

		$this->add_control(
			'play_icon_opacity',
			[
				'label'     => esc_html__( 'Opacity', 'powerpack' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max'  => 1,
						'min'  => 0,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .pp-video-play-icon' => 'opacity: {{SIZE}}',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_play_icon_hover',
			[
				'label'     => esc_html__( 'Hover', 'powerpack' ),
				'condition' => [
					'play_icon_type'           => 'icon',
					'select_play_icon[value]!' => '',
				],
			]
		);

		$this->add_control(
			'play_icon_hover_color',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pp-video-container:hover .pp-video-play-icon' => 'color: {{VALUE}}',
					'{{WRAPPER}} .pp-video-container:hover .pp-video-play-icon svg' => 'fill: {{VALUE}}',
				],
				'condition' => [
					'play_icon_type'           => 'icon',
					'select_play_icon[value]!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name'      => 'play_icon_hover_text_shadow',
				'selector'  => '{{WRAPPER}} .pp-video-container:hover .pp-video-play-icon',
				'condition' => [
					'play_icon_type'           => 'icon',
					'select_play_icon[value]!' => '',
				],
			]
		);

		$this->add_control(
			'play_icon_hover_opacity',
			[
				'label'     => esc_html__( 'Opacity', 'powerpack' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max'  => 1,
						'min'  => 0,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .pp-video-container:hover .pp-video-play-icon' => 'opacity: {{SIZE}}',
				],
				'condition' => [
					'play_icon_type!' => 'none',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Register the style tab Content controls.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_style_content_controls() {
		/**
		 * Style Tab: Content
		 */
		$this->start_controls_section(
			'section_video_content_style',
			[
				'label' => esc_html__( 'Content', 'powerpack' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'video_title_position',
			[
				'label'     => esc_html__( 'Content Position', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'below-video',
				'options'   => [
					'over-image'  => esc_html__( 'Over Thumbnail', 'powerpack' ),
					'hover'       => esc_html__( 'Over Thumbnail on Hover', 'powerpack' ),
					'above-video' => esc_html__( 'Above Video', 'powerpack' ),
					'below-video' => esc_html__( 'Below Video', 'powerpack' ),
				],
				'prefix_class' => 'pp-video-gallery-content-',
				'render_type'  => 'template',
			]
		);

		$this->add_control(
			'video_title_vertical_align',
			[
				'label'                => esc_html__( 'Vertical Align', 'powerpack' ),
				'type'                 => Controls_Manager::CHOOSE,
				'label_block'          => false,
				'toggle'               => false,
				'default'              => 'bottom',
				'options'              => [
					'top'    => [
						'title' => esc_html__( 'Top', 'powerpack' ),
						'icon'  => 'eicon-v-align-top',
					],
					'middle' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-v-align-middle',
					],
					'bottom' => [
						'title' => esc_html__( 'Bottom', 'powerpack' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'selectors_dictionary' => [
					'top'    => 'flex-start',
					'middle' => 'center',
					'bottom' => 'flex-end',
				],
				'selectors'            => [
					'{{WRAPPER}} .pp-media-content' => 'justify-content: {{VALUE}};',
				],
				'condition'            => [
					'video_title_position' => [ 'over-image', 'hover' ],
				],
			]
		);

		$this->add_control(
			'video_title_horizontal_align',
			[
				'label'                => esc_html__( 'Horizontal Align', 'powerpack' ),
				'type'                 => Controls_Manager::CHOOSE,
				'label_block'          => false,
				'toggle'               => false,
				'options'              => [
					'left'    => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-h-align-left',
					],
					'center'  => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-h-align-center',
					],
					'right'   => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-h-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justify', 'powerpack' ),
						'icon'  => 'eicon-h-align-stretch',
					],
				],
				'default'              => 'center',
				'selectors_dictionary' => [
					'left'    => 'flex-start',
					'center'  => 'center',
					'right'   => 'flex-end',
					'justify' => 'stretch',
				],
				'selectors'            => [
					'{{WRAPPER}} .pp-media-content' => 'align-items: {{VALUE}};',
				],
				'condition'            => [
					'video_title_position' => [ 'over-image', 'hover' ],
				],
			]
		);

		$this->add_responsive_control(
			'video_title_text_align',
			[
				'label'     => esc_html__( 'Text Align', 'powerpack' ),
				'type'      => Controls_Manager::CHOOSE,
				'default'   => '',
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'powerpack' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'powerpack' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'powerpack' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .pp-video-content' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'video_title_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-video-content' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'video_title_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-video-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'video_title_heading',
			[
				'label'     => esc_html__( 'Video Title', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'video_title_html_tag',
			[
				'label'       => esc_html__( 'Title HTML Tag', 'powerpack' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'h3',
				'options'     => [
					'h1'   => esc_html__( 'H1', 'powerpack' ),
					'h2'   => esc_html__( 'H2', 'powerpack' ),
					'h3'   => esc_html__( 'H3', 'powerpack' ),
					'h4'   => esc_html__( 'H4', 'powerpack' ),
					'h5'   => esc_html__( 'H5', 'powerpack' ),
					'h6'   => esc_html__( 'H6', 'powerpack' ),
					'div'  => esc_html__( 'div', 'powerpack' ),
					'span' => esc_html__( 'span', 'powerpack' ),
					'p'    => esc_html__( 'p', 'powerpack' ),
				],
				'render_type' => 'template',
			]
		);

		$this->add_control(
			'video_title_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-video-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'video_title_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-video-title',
			]
		);

		$this->add_responsive_control(
			'video_title_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 80,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-video-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'video_description_heading',
			[
				'label'     => esc_html__( 'Video Description', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'video_description_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-video-description' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'video_description_typography',
				'label'    => esc_html__( 'Typography', 'powerpack' ),
				'selector' => '{{WRAPPER}} .pp-video-description',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the style tab Filters controls.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_style_filter_controls() {
		/**
		 * Style Tab: Filters
		 */
		$this->start_controls_section(
			'section_filter_style',
			[
				'label'     => esc_html__( 'Filters', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'filter_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'selector'  => '{{WRAPPER}} .pp-gallery-filters .pp-gallery-filter-text',
				'condition' => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'filters_gap_horizontal',
			[
				'label'      => esc_html__( 'Horizontal Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [
					'size' => 5,
				],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-gallery-filters .pp-gallery-filter' => 'margin-left: {{SIZE}}{{UNIT}}; margin-right: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'filters_gap_vertical',
			[
				'label'       => esc_html__( 'Vertical Spacing', 'powerpack' ),
				'description' => esc_html__( 'You can use vertical spacing to distance filters from one another, if they are stacked.', 'powerpack' ),
				'type'        => Controls_Manager::SLIDER,
				'size_units'  => [ 'px', 'em', 'rem', 'custom' ],
				'default'     => [
					'size' => 5,
				],
				'range'       => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'   => [
					'{{WRAPPER}} .pp-gallery-filters .pp-gallery-filter' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition'   => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'filters_margin_bottom',
			[
				'label'      => esc_html__( 'Filters Bottom Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 80,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-gallery-filters' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_filter_style' );

		$this->start_controls_tab(
			'tab_filter_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
				],
			]
		);

		$this->add_control(
			'filter_color_normal',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-gallery-filters .pp-gallery-filter' => 'color: {{VALUE}};',
				],
				'condition' => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
				],
			]
		);

		$this->add_control(
			'filter_background_color_normal',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-gallery-filters .pp-gallery-filter' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'filter_border_normal',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-gallery-filters .pp-gallery-filter',
				'condition'   => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
				],
			]
		);

		$this->add_control(
			'filter_border_radius_normal',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-gallery-filters .pp-gallery-filter' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'filter_padding',
			[
				'label'       => esc_html__( 'Padding', 'powerpack' ),
				'type'        => Controls_Manager::DIMENSIONS,
				'size_units'  => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'placeholder' => [
					'top'    => '',
					'right'  => '',
					'bottom' => '',
					'left'   => '',
				],
				'selectors'   => [
					'{{WRAPPER}} .pp-gallery-filters .pp-gallery-filter' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'   => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'filter_box_shadow',
				'selector'  => '{{WRAPPER}} .pp-gallery-filters .pp-gallery-filter',
				'condition' => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_filter_hover',
			[
				'label'     => esc_html__( 'Hover', 'powerpack' ),
				'condition' => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
				],
			]
		);

		$this->add_control(
			'filter_color_hover',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-gallery-filters .pp-gallery-filter:hover' => 'color: {{VALUE}};',
				],
				'condition' => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
				],
			]
		);

		$this->add_control(
			'filter_background_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-gallery-filters .pp-gallery-filter:hover' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
				],
			]
		);

		$this->add_control(
			'filter_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-gallery-filters .pp-gallery-filter:hover' => 'border-color: {{VALUE}};',
				],
				'condition' => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'filter_box_shadow_hover',
				'selector'  => '{{WRAPPER}} .pp-gallery-filters .pp-gallery-filter:hover',
				'condition' => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
				],
			]
		);

		$this->add_control(
			'galleries_pointer_color_hover',
			[
				'label'     => esc_html__( 'Pointer Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'global'    => [
					'default' => Global_Colors::COLOR_ACCENT,
				],
				'selectors' => [
					'{{WRAPPER}}' => '--filters-pointer-bg-color-hover: {{VALUE}}',
				],
				'condition' => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
					'pointer!'      => [ 'none', 'text' ],
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_filter_active',
			[
				'label'     => esc_html__( 'Active', 'powerpack' ),
				'condition' => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
				],
			]
		);

		$this->add_control(
			'filter_color_active',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-gallery-filters .pp-gallery-filter.pp-active' => 'color: {{VALUE}};',
				],
				'condition' => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
				],
			]
		);

		$this->add_control(
			'filter_background_color_active',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-gallery-filters .pp-gallery-filter.pp-active' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
				],
			]
		);

		$this->add_control(
			'filter_border_color_active',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-gallery-filters .pp-gallery-filter.pp-active' => 'border-color: {{VALUE}};',
				],
				'condition' => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'filter_box_shadow_active',
				'selector'  => '{{WRAPPER}} .pp-gallery-filters .pp-gallery-filter.pp-active',
				'condition' => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
				],
			]
		);

		$this->add_control(
			'galleries_pointer_color_active',
			[
				'label'     => esc_html__( 'Pointer Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'global'    => [
					'default' => Global_Colors::COLOR_ACCENT,
				],
				'selectors' => [
					'{{WRAPPER}}' => '--filters-pointer-bg-color-active: {{VALUE}}',
				],
				'condition' => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
					'pointer!'      => [ 'none', 'text' ],
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'pointer_width',
			[
				'label'      => esc_html__( 'Pointer Width', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'max' => 30,
					],
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--filters-pointer-border-width: {{SIZE}}{{UNIT}}',
				],
				'separator'  => 'before',
				'condition'  => [
					'layout'        => 'grid',
					'filter_enable' => 'yes',
					'pointer'       => [ 'underline', 'overline', 'double-line', 'framed' ],
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the style tab Arrows controls.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_style_arrows_controls() {
		/**
		 * Style Tab: Arrows
		 */
		$this->start_controls_section(
			'section_arrows_style',
			[
				'label'     => esc_html__( 'Arrows', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'layout' => 'carousel',
					'arrows' => 'yes',
				],
			]
		);

		$this->add_control(
			'select_arrow',
			[
				'label'                  => esc_html__( 'Choose Arrow', 'powerpack' ),
				'type'                   => Controls_Manager::ICONS,
				'fa4compatibility'       => 'arrow',
				'label_block'            => false,
				'default'                => [
					'value'   => 'fas fa-angle-right',
					'library' => 'fa-solid',
				],
				'skin'                   => 'inline',
				'exclude_inline_options' => 'svg',
				'recommended'            => [
					'fa-regular' => [
						'arrow-alt-circle-right',
						'caret-square-right',
						'hand-point-right',
					],
					'fa-solid'   => [
						'angle-right',
						'angle-double-right',
						'chevron-right',
						'chevron-circle-right',
						'arrow-right',
						'long-arrow-alt-right',
						'caret-right',
						'caret-square-right',
						'arrow-circle-right',
						'arrow-alt-circle-right',
						'toggle-right',
						'hand-point-right',
					],
				],
				'condition' => [
					'layout' => 'carousel',
					'arrows' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'arrows_size',
			[
				'label'      => esc_html__( 'Arrows Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'default'    => [ 'size' => '22' ],
				'range'      => [
					'px' => [
						'min'  => 15,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-slider-arrow' => 'font-size: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'layout' => 'carousel',
					'arrows' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'arrows_position',
			[
				'label'      => esc_html__( 'Align Arrows', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => -100,
						'max'  => 50,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .elementor-swiper-button-next' => 'inset-inline-end: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .elementor-swiper-button-prev' => 'inset-inline-start: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'layout' => 'carousel',
					'arrows' => 'yes',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_arrows_style' );

		$this->start_controls_tab(
			'tab_arrows_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => [
					'layout' => 'carousel',
					'arrows' => 'yes',
				],
			]
		);

		$this->add_control(
			'arrows_bg_color_normal',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-slider-arrow' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'layout' => 'carousel',
					'arrows' => 'yes',
				],
			]
		);

		$this->add_control(
			'arrows_color_normal',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-slider-arrow' => 'color: {{VALUE}};',
				],
				'condition' => [
					'layout' => 'carousel',
					'arrows' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'arrows_border_normal',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-slider-arrow',
				'condition'   => [
					'layout' => 'carousel',
					'arrows' => 'yes',
				],
			]
		);

		$this->add_control(
			'arrows_border_radius_normal',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-slider-arrow' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'layout' => 'carousel',
					'arrows' => 'yes',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_arrows_hover',
			[
				'label'     => esc_html__( 'Hover', 'powerpack' ),
				'condition' => [
					'layout' => 'carousel',
					'arrows' => 'yes',
				],
			]
		);

		$this->add_control(
			'arrows_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-slider-arrow:hover' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'layout' => 'carousel',
					'arrows' => 'yes',
				],
			]
		);

		$this->add_control(
			'arrows_color_hover',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-slider-arrow:hover' => 'color: {{VALUE}};',
				],
				'condition' => [
					'layout' => 'carousel',
					'arrows' => 'yes',
				],
			]
		);

		$this->add_control(
			'arrows_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-slider-arrow:hover' => 'border-color: {{VALUE}};',
				],
				'condition' => [
					'layout' => 'carousel',
					'arrows' => 'yes',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			'arrows_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-slider-arrow' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator'  => 'before',
				'condition'  => [
					'layout' => 'carousel',
					'arrows' => 'yes',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the style tab Pagination: Dots controls.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_style_pagination_dots_controls() {
		/**
		 * Style Tab: Dots
		 */
		$this->start_controls_section(
			'section_dots_style',
			[
				'label'     => esc_html__( 'Pagination: Dots', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'layout'          => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'bullets',
				],
			]
		);

		$this->add_control(
			'dots_position',
			[
				'label'        => esc_html__( 'Position', 'powerpack' ),
				'type'         => Controls_Manager::SELECT,
				'options'      => [
					'inside'  => esc_html__( 'Inside', 'powerpack' ),
					'outside' => esc_html__( 'Outside', 'powerpack' ),
				],
				'default'      => 'outside',
				'prefix_class' => 'pp-swiper-slider-pagination-',
				'condition'    => [
					'layout'          => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'bullets',
				],
			]
		);

		$this->add_responsive_control(
			'dots_size',
			[
				'label'      => esc_html__( 'Size', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 2,
						'max'  => 40,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .swiper-pagination-bullet' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'layout'          => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'bullets',
				],
			]
		);

		$this->add_responsive_control(
			'dots_spacing',
			[
				'label'      => esc_html__( 'Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 1,
						'max'  => 30,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .swiper-pagination-bullet' => 'margin-left: {{SIZE}}{{UNIT}}; margin-right: {{SIZE}}{{UNIT}}',
				],
				'condition'  => [
					'layout'          => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'bullets',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_dots_style' );

		$this->start_controls_tab(
			'tab_dots_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => [
					'layout'          => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'bullets',
				],
			]
		);

		$this->add_control(
			'dots_color_normal',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-pagination-bullet' => 'background: {{VALUE}};',
				],
				'condition' => [
					'layout'          => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'bullets',
				],
			]
		);

		$this->add_control(
			'active_dot_color_normal',
			[
				'label'     => esc_html__( 'Active Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'background: {{VALUE}};',
				],
				'condition' => [
					'layout'          => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'bullets',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'dots_border_normal',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .swiper-pagination-bullet',
				'condition'   => [
					'layout'          => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'bullets',
				],
			]
		);

		$this->add_control(
			'dots_border_radius_normal',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .swiper-pagination-bullet' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'layout'          => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'bullets',
				],
			]
		);

		$this->add_responsive_control(
			'dots_margin',
			[
				'label'              => esc_html__( 'Margin', 'powerpack' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px', '%', 'em', 'rem', 'custom' ],
				'allowed_dimensions' => 'vertical',
				'placeholder'        => [
					'top'    => '',
					'right'  => 'auto',
					'bottom' => '',
					'left'   => 'auto',
				],
				'selectors'          => [
					'{{WRAPPER}} .swiper-pagination' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'          => [
					'layout'          => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'bullets',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_dots_hover',
			[
				'label'     => esc_html__( 'Hover', 'powerpack' ),
				'condition' => [
					'layout'          => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'bullets',
				],
			]
		);

		$this->add_control(
			'dots_color_hover',
			[
				'label'     => esc_html__( 'Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-pagination-bullet:hover' => 'background: {{VALUE}};',
				],
				'condition' => [
					'layout'          => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'bullets',
				],
			]
		);

		$this->add_control(
			'dots_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-pagination-bullet:hover' => 'border-color: {{VALUE}};',
				],
				'condition' => [
					'layout'          => 'carousel',
					'dots'            => 'yes',
					'pagination_type' => 'bullets',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Register the style tab Pagination: Fraction controls.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_style_pagination_fraction_controls() {
		/**
		 * Style Tab: Pagination: Fraction
		 * -------------------------------------------------
		 */
		$this->start_controls_section(
			'section_fraction_style',
			[
				'label'     => esc_html__( 'Pagination: Fraction', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'dots'            => 'yes',
					'pagination_type' => 'fraction',
				],
			]
		);

		$this->add_control(
			'fraction_text_color',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .swiper-pagination-fraction' => 'color: {{VALUE}};',
				],
				'condition' => [
					'dots'            => 'yes',
					'pagination_type' => 'fraction',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'fraction_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'global'    => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector'  => '{{WRAPPER}} .swiper-pagination-fraction',
				'condition' => [
					'dots'            => 'yes',
					'pagination_type' => 'fraction',
				],
			]
		);

		$this->add_control(
			'fraction_position',
			[
				'label'        => esc_html__( 'Position', 'powerpack' ),
				'type'         => Controls_Manager::SELECT,
				'options'      => [
					'inside'  => esc_html__( 'Inside', 'powerpack' ),
					'outside' => esc_html__( 'Outside', 'powerpack' ),
				],
				'default'      => 'outside',
				'prefix_class' => 'pp-swiper-slider-pagination-',
				'condition'    => [
					'dots'            => 'yes',
					'pagination_type' => 'fraction',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register the style tab Load More Button controls.
	 *
	 * @access protected
	 *
	 * @return void
	 */
	protected function register_style_load_more_controls() {
		/**
		 * Style Tab: Load More Button
		 * -------------------------------------------------
		 */
		$this->start_controls_section(
			'section_load_more_button_style',
			[
				'label'     => esc_html__( 'Load More Button', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'layout!'         => 'carousel',
					'filter_enable!'  => 'yes',
					'pagination'      => 'yes',
					'load_more_text!' => '',
					'source'          => 'custom',
				],
			]
		);

		$this->add_control(
			'button_size',
			[
				'label'     => esc_html__( 'Size', 'powerpack' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'sm',
				'options'   => [
					'xs' => esc_html__( 'Extra Small', 'powerpack' ),
					'sm' => esc_html__( 'Small', 'powerpack' ),
					'md' => esc_html__( 'Medium', 'powerpack' ),
					'lg' => esc_html__( 'Large', 'powerpack' ),
					'xl' => esc_html__( 'Extra Large', 'powerpack' ),
				],
				'condition' => [
					'layout!'         => 'carousel',
					'filter_enable!'  => 'yes',
					'pagination'      => 'yes',
					'load_more_text!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'button_margin_top',
			[
				'label'      => esc_html__( 'Top Spacing', 'powerpack' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 80,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .pp-video-gallery-pagination' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'layout!'         => 'carousel',
					'filter_enable!'  => 'yes',
					'pagination'      => 'yes',
					'load_more_text!' => '',
				],
			]
		);

		$this->start_controls_tabs( 'tabs_load_more_button_style' );

		$this->start_controls_tab(
			'tab_load_more_button_normal',
			[
				'label'     => esc_html__( 'Normal', 'powerpack' ),
				'condition' => [
					'layout!'         => 'carousel',
					'filter_enable!'  => 'yes',
					'pagination'      => 'yes',
					'load_more_text!' => '',
				],
			]
		);

		$this->add_control(
			'load_more_button_text_color_normal',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-gallery-load-more' => 'color: {{VALUE}}',
					'{{WRAPPER}} .pp-gallery-load-more .pp-icon svg' => 'fill: {{VALUE}}',
				],
				'condition' => [
					'layout!'         => 'carousel',
					'filter_enable!'  => 'yes',
					'pagination'      => 'yes',
					'load_more_text!' => '',
				],
			]
		);

		$this->add_control(
			'load_more_button_bg_color_normal',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'global'    => [
					'default' => Global_Colors::COLOR_ACCENT,
				],
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-gallery-load-more' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'layout!'         => 'carousel',
					'filter_enable!'  => 'yes',
					'pagination'      => 'yes',
					'load_more_text!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'        => 'load_more_button_border_normal',
				'label'       => esc_html__( 'Border', 'powerpack' ),
				'placeholder' => '1px',
				'default'     => '1px',
				'selector'    => '{{WRAPPER}} .pp-gallery-load-more',
				'condition'   => [
					'layout!'         => 'carousel',
					'filter_enable!'  => 'yes',
					'pagination'      => 'yes',
					'load_more_text!' => '',
				],
			]
		);

		$this->add_control(
			'load_more_button_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-gallery-load-more' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'layout!'         => 'carousel',
					'filter_enable!'  => 'yes',
					'pagination'      => 'yes',
					'load_more_text!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'load_more_button_typography',
				'label'     => esc_html__( 'Typography', 'powerpack' ),
				'global'    => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector'  => '{{WRAPPER}} .pp-gallery-load-more',
				'condition' => [
					'layout!'         => 'carousel',
					'filter_enable!'  => 'yes',
					'pagination'      => 'yes',
					'load_more_text!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'load_more_button_padding',
			[
				'label'      => esc_html__( 'Padding', 'powerpack' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
				'selectors'  => [
					'{{WRAPPER}} .pp-gallery-load-more' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'layout!'         => 'carousel',
					'filter_enable!'  => 'yes',
					'pagination'      => 'yes',
					'load_more_text!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'load_more_button_box_shadow',
				'selector'  => '{{WRAPPER}} .pp-gallery-load-more',
				'condition' => [
					'layout!'         => 'carousel',
					'filter_enable!'  => 'yes',
					'pagination'      => 'yes',
					'load_more_text!' => '',
				],
			]
		);

		$this->add_control(
			'load_more_button_icon_heading',
			[
				'label'     => esc_html__( 'Button Icon', 'powerpack' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'layout!'                       => 'carousel',
					'filter_enable!'                => 'yes',
					'pagination'                    => 'yes',
					'select_load_more_icon[value]!' => '',
				],
			]
		);

		$this->add_responsive_control(
			'load_more_button_icon_margin',
			[
				'label'       => esc_html__( 'Margin', 'powerpack' ),
				'type'        => Controls_Manager::DIMENSIONS,
				'size_units'  => [ 'px', '%', 'em', 'rem', 'custom' ],
				'placeholder' => [
					'top'    => '',
					'right'  => '',
					'bottom' => '',
					'left'   => '',
				],
				'selectors'   => [
					'{{WRAPPER}} .pp-video-gallery-pagination .pp-gallery-load-more-icon' => 'margin-top: {{TOP}}{{UNIT}}; margin-left: {{LEFT}}{{UNIT}}; margin-right: {{RIGHT}}{{UNIT}}; margin-bottom: {{BOTTOM}}{{UNIT}};',
				],
				'condition'   => [
					'layout!'                       => 'carousel',
					'filter_enable!'                => 'yes',
					'pagination'                    => 'yes',
					'select_load_more_icon[value]!' => '',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_button_hover',
			[
				'label'     => esc_html__( 'Hover', 'powerpack' ),
				'condition' => [
					'layout!'         => 'carousel',
					'filter_enable!'  => 'yes',
					'pagination'      => 'yes',
					'load_more_text!' => '',
				],
			]
		);

		$this->add_control(
			'button_text_color_hover',
			[
				'label'     => esc_html__( 'Text Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-gallery-load-more:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .pp-gallery-load-more:hover .pp-icon svg' => 'fill: {{VALUE}}',
				],
				'condition' => [
					'layout!'         => 'carousel',
					'filter_enable!'  => 'yes',
					'pagination'      => 'yes',
					'load_more_text!' => '',
				],
			]
		);

		$this->add_control(
			'button_bg_color_hover',
			[
				'label'     => esc_html__( 'Background Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-gallery-load-more:hover' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'layout!'         => 'carousel',
					'filter_enable!'  => 'yes',
					'pagination'      => 'yes',
					'load_more_text!' => '',
				],
			]
		);

		$this->add_control(
			'button_border_color_hover',
			[
				'label'     => esc_html__( 'Border Color', 'powerpack' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .pp-gallery-load-more:hover' => 'border-color: {{VALUE}}',
				],
				'condition' => [
					'layout!'         => 'carousel',
					'filter_enable!'  => 'yes',
					'pagination'      => 'yes',
					'load_more_text!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'button_box_shadow_hover',
				'selector'  => '{{WRAPPER}} .pp-gallery-load-more:hover',
				'condition' => [
					'layout!'         => 'carousel',
					'filter_enable!'  => 'yes',
					'pagination'      => 'yes',
					'load_more_text!' => '',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	/**
	 * Register lightbox style controls.
	 *
	 * @since 3.1.0
	 * @access protected
	 */
	protected function register_style_lightbox_controls() {
		/**
		 * Style Tab: Lightbox
		 * -------------------------------------------------
		 */
		$this->start_controls_section(
			'section_lightbox_style',
			array(
				'label'     => esc_html__( 'Lightbox', 'powerpack' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					'click_action' => 'lightbox',
				),
			)
		);

		$this->add_responsive_control(
			'lightbox_video_width',
			array(
				'label'       => esc_html__( 'Video Width', 'powerpack' ),
				'description' => esc_html__( 'The video keeps the aspect ratio set in Gallery Settings and shrinks to fit smaller screens, so this is the widest it will be shown.', 'powerpack' ),
				'type'        => Controls_Manager::SLIDER,
				'size_units'  => array( 'px', '%', 'vw', 'em', 'rem', 'custom' ),
				'default'     => array(
					'unit' => '%',
				),
				'range'       => array(
					'px' => array(
						'min' => 240,
						'max' => 2560,
					),
					'%'  => array(
						'min' => 20,
					),
					'vw' => array(
						'min' => 20,
					),
				),
				'selectors'   => array(
					// The lightbox is appended to the body, so it is addressed by its own class
					// rather than through the widget wrapper.
					'.pp-video-gallery-lightbox-{{ID}} .fancybox-content' => '--pp-lightbox-width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render Video Gallery output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$gallery        = [];
		$is_editor      = PP_Helper::is_edit_mode();

		if ( 'yt-playlist' === $settings['source'] || 'yt-channel' === $settings['source'] ) {
			$gallery = $this->get_youtube_videos();

			if ( is_wp_error( $gallery ) ) {
				$error_message = $gallery->get_error_message();

				if ( $is_editor ) {
					$this->render_editor_placeholder(
						[
							'title' => esc_html__( 'YouTube Videos', 'powerpack' ),
							'body' => $error_message,
						]
					);
				}
				return;
			}
		} else {
			$gallery_videos = $settings['gallery_videos'];

			if ( 'random' === $settings['ordering'] ) {
				$keys = array_keys( $gallery_videos );
				shuffle( $keys );
	
				foreach ( $keys as $key ) {
					$gallery[ $key ] = $gallery_videos[ $key ];
				}
			} else {
				$gallery = $gallery_videos;
			}
		}

		$classes = [
			'pp-video-gallery',
		];

		$this->add_render_attribute(
			[
				'gallery-container' => [
					'class' => [
						'pp-video-gallery-container',
						'pp-video-gallery-' . $settings['layout'],
					],
				],
				'gallery-wrap'      => [
					'class' => 'pp-video-gallery-wrap',
				],
			]
		);

		if ( 'carousel' === $settings['layout'] ) {
			$classes[] = 'pp-swiper-slider';
		}

		if ( 'grid' === $settings['layout'] ) {
			// Native CSS grid (Elementor core) for every grid variant. Filtering/pagination are
			// handled by the widget's JS (FLIP animation / append) instead of Isotope.
			$classes[] = 'elementor-grid';

			if ( 'yes' === $settings['filter_enable'] ) {
				$classes[] = 'pp-video-gallery-filter-enabled';
			}
		}

		$this->add_render_attribute(
			'gallery',
			[
				'class'       => $classes,
				'data-action' => $settings['click_action'],
			]
		);

		if ( 'carousel' === $settings['layout'] ) {
			$slider_options = $this->slider_settings();
			$this->add_render_attribute( 'gallery', 'data-slider-settings', wp_json_encode( $slider_options ) );

			$direction = ( 'right' === $settings['direction'] ) ? 'rtl' : 'ltr';

			$this->add_render_attribute(
				[
					'gallery-wrap' => [
						'class' => 'swiper-container-wrap'
					],
					'gallery'      => [
						'class' => 'swiper',
						'dir'   => $direction,
					],
				]
			);
		}
		?>
		<div <?php $this->print_render_attribute_string( 'gallery-container' ); ?>>
			<div <?php $this->print_render_attribute_string( 'gallery-wrap' ); ?>>
				<?php $this->render_filters(); ?>
				<div <?php $this->print_render_attribute_string( 'gallery' ); ?>>
					<?php if ( 'carousel' === $settings['layout'] ) { ?>
					<div class="swiper-wrapper">
					<?php } ?>
						<?php $this->render_videos( $gallery ); ?>
					<?php if ( 'carousel' === $settings['layout'] ) { ?>
					</div>
					<?php } ?>
				</div>
				<?php
					// Load more pagination.
					$this->render_pagination();

					// Carousel navigation.
					if ( 'carousel' === $settings['layout'] ) {
						$this->render_dots();
						$this->render_arrows();
					}
				?>
			</div>
		</div>
		<?php

	}

	/**
	 * Carousel Settings.
	 *
	 * @access public
	 */
	public function slider_settings() {
		$settings = $this->get_settings();

		$slides_to_show        = ( '' !== $settings['columns'] ) ? absint( $settings['columns'] ) : 3;
		$slides_to_show_tablet = ! empty( $settings['columns_tablet'] ) ? absint( $settings['columns_tablet'] ) : 2;
		$slides_to_show_mobile = ! empty( $settings['columns_mobile'] ) ? absint( $settings['columns_mobile'] ) : 2;
		$spacing               = ! empty( $settings['columns_gap']['size'] ) ? $settings['columns_gap']['size'] : 10;
		$spacing_tablet        = ! empty( $settings['columns_gap_tablet']['size'] ) ? $settings['columns_gap_tablet']['size'] : 10;
		$spacing_mobile        = ! empty( $settings['columns_gap_mobile']['size'] ) ? $settings['columns_gap_mobile']['size'] : 10;

		$slider_options = [
			'speed'            => ( '' !== $settings['animation_speed'] ) ? $settings['animation_speed'] : 500,
			'slides_per_view'  => $slides_to_show,
			'slides_to_scroll' => 1,
			'space_between'    => $spacing,
			'auto_height'      => ( 'yes' === $settings['adaptive_height'] ) ? 'yes' : '',
			'loop'             => ( 'yes' === $settings['infinite_loop'] ) ? 'yes' : '',
		];

		if ( 'yes' === $settings['autoplay'] ) {
			$autoplay_speed = 3000;
			$slider_options['autoplay'] = 'yes';

			if ( ! empty( $settings['autoplay_speed']['size'] ) ) {
				$autoplay_speed = $settings['autoplay_speed']['size'];
			}

			$slider_options['autoplay_speed'] = $autoplay_speed;
		}

		if ( 'yes' === $settings['dots'] && $settings['pagination_type'] ) {
			$slider_options['pagination'] = $settings['pagination_type'];
		}

		if ( 'yes' === $settings['arrows'] ) {
			$slider_options['show_arrows'] = true;
		}

		$breakpoints = PP_Helper::elementor()->breakpoints->get_active_breakpoints();

		foreach ( $breakpoints as $device => $breakpoint ) {
			if ( in_array( $device, [ 'mobile', 'tablet', 'desktop' ] ) ) {
				switch ( $device ) {
					case 'desktop':
						$slider_options['slides_per_view'] = absint( $slides_to_show );
						$slider_options['space_between'] = absint( $spacing );
						break;
					case 'tablet':
						$slider_options['slides_per_view_tablet'] = absint( $slides_to_show_tablet );
						$slider_options['space_between_tablet'] = absint( $spacing_tablet );
						break;
					case 'mobile':
						$slider_options['slides_per_view_mobile'] = absint( $slides_to_show_mobile );
						$slider_options['space_between_mobile'] = absint( $spacing_mobile );
						break;
				}
			} else {
				if ( ! empty( $settings[ 'columns_' . $device ]['size'] ) ) {
					$slider_options['slides_per_view_' . $device] = absint( $settings['columns_' . $device]['size'] );
				}

				if ( ! empty( $settings[ 'columns_gap_' . $device ]['size'] ) ) {
					$slider_options['space_between_' . $device] = absint( $settings['columns_gap_' . $device]['size'] );
				}
			}
		}

		return $slider_options;
	}

	/**
	 * Render coupons carousel dots output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render_dots() {
		$settings = $this->get_settings_for_display();

		if ( 'yes' === $settings['dots'] ) {
			?>
			<!-- Add Pagination -->
			<div class="swiper-pagination swiper-pagination-<?php echo esc_attr( $this->get_id() ); ?>"></div>
			<?php
		}
	}

	/**
	 * Render coupons carousel arrows output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render_arrows() {
		PP_Helper::render_arrows( $this );
	}

	/**
	 * Render Video Gallery Filters
	 *
	 * @return void
	 */
	protected function render_filters() {
		$settings = $this->get_settings_for_display();

		if ( 'grid' === $settings['layout'] && 'yes' === $settings['filter_enable'] ) {
			$all_text = ( $settings['filter_all_label'] ) ? $settings['filter_all_label'] : esc_html__( 'All', 'powerpack' );

			// The former .pp-filters-wrapper element carried no styling of its own, so its
			// class moves onto the filter list itself rather than keeping an empty wrapper.
			$this->add_render_attribute(
				'filters-container',
				[
					'class'      => [ 'pp-filters-wrapper', 'pp-gallery-filters' ],
					'role'       => 'group',
					// Elementor escapes render attribute values on output, so these are raw.
					'aria-label' => __( 'Filter videos by category', 'powerpack' ),
				]
			);

			if ( $settings['pointer'] ) {
				if ( 'underline' === $settings['pointer'] || 'overline' === $settings['pointer'] || 'double-line' === $settings['pointer'] ) {
					$this->add_render_attribute( 'filters-container', 'class', 'pp-pointer-line' );
				}

				$this->add_render_attribute( 'filters-container', 'class', 'pp-pointer-' . $settings['pointer'] );

				foreach ( $settings as $key => $value ) {
					if ( 0 === strpos( $key, 'animation' ) && $value ) {
						$this->add_render_attribute( 'filters-container', 'class', 'pp-animation-' . $value );
						break;
					}
				}
			}

			$gallery = $this->get_filter_values();
			?>
			<div <?php $this->print_render_attribute_string( 'filters-container' ); ?>>
				<button type="button" class="pp-gallery-filter pp-active" data-filter="*" aria-pressed="true">
					<span class="pp-gallery-filter-text"><?php echo esc_html( $all_text ); ?></span>
				</button>
				<?php foreach ( $gallery as $index => $filter_label ) { ?>
					<?php if ( $filter_label ) { ?>
						<button type="button" class="pp-gallery-filter" data-filter=".<?php echo esc_attr( $index ); ?>" aria-pressed="false">
							<span class="pp-gallery-filter-text"><?php echo esc_html( $filter_label ); ?></span>
						</button>
					<?php } ?>
				<?php } ?>
			</div>
			<p class="pp-gallery-filter-status" role="status" aria-live="polite" data-template="<?php echo esc_attr__( 'Filtered by: %s', 'powerpack' ); ?>"></p>
			<?php
		}
	}

	/**
	 * Build the playback URL for a self hosted video.
	 *
	 * Appends the media fragment when a start and/or end time is set on the item.
	 *
	 * @since 2.2.7
	 * @access protected
	 *
	 * @param array $item Repeater item for the video.
	 *
	 * @return string Video URL, or an empty string when no source is set.
	 */
	protected function get_hosted_video_url( $item ) {
		if ( ! empty( $item['insert_url'] ) ) {
			$video_url = $item['external_url']['url'];
		} else {
			$video_url = $item['hosted_url']['url'];
		}

		if ( empty( $video_url ) ) {
			return '';
		}

		if ( $item['start'] || $item['end'] ) {
			$video_url .= '#t=';
		}

		if ( $item['start'] ) {
			$video_url .= (int) $item['start'];
		}

		if ( $item['end'] ) {
			$video_url .= ',' . (int) $item['end'];
		}

		return $video_url;
	}

	/**
	 * Render Video Content
	 *
	 * @access protected
	 */
	protected function render_video_content( $item, $index ) {
		$settings              = $this->get_settings_for_display();
		$content_container_key = $this->get_repeater_setting_key( 'content-container', 'video', $index );

		$this->add_render_attribute( $content_container_key, 'class', 'pp-video-content-container' );

		$over_thumbnail = ( 'hover' === $settings['video_title_position'] || 'over-image' === $settings['video_title_position'] );

		if ( $over_thumbnail ) {
			$this->add_render_attribute( $content_container_key, 'class', 'pp-media-content' );
		}

		// Over the thumbnail this content renders inside the play link. An anchor nested in
		// an anchor is invalid HTML that browsers recover from by splitting the tile apart,
		// and a link there could never be clicked anyway because the play link takes the
		// click, so anchors are dropped for those two positions only.
		$allowed_html = wp_kses_allowed_html( 'post' );

		if ( $over_thumbnail ) {
			unset( $allowed_html['a'] );
		}

		if ( $item['video_title'] || $item['video_description'] ) { ?>
			<div <?php $this->print_render_attribute_string( $content_container_key ); ?>>
				<div class="pp-video-content">
					<?php if ( $item['video_title'] ) { ?>
						<<?php PP_Helper::print_validated_html_tag( $settings['video_title_html_tag'] ); ?> class="pp-video-title">
							<?php echo wp_kses( $item['video_title'], $allowed_html ); ?>
						</<?php PP_Helper::print_validated_html_tag( $settings['video_title_html_tag'] ); ?>>
					<?php } ?>

					<?php if ( $item['video_description'] ) { ?>
						<div class="pp-video-description">
							<?php echo wp_kses( $this->parse_text_editor( $item['video_description'] ), $allowed_html ); ?>
						</div>
					<?php } ?>
				</div>
			</div>
			<?php
		}
	}

	/**
	 * Build the DOM id for a gallery item that is described by the schema.
	 *
	 * Scoped to the widget id so that two Video Gallery widgets on one page do not
	 * emit colliding ids. Module::print_video_gallery_schema() builds the matching
	 * anchor, so the two must be changed together.
	 *
	 * @since 3.1.0
	 * @access protected
	 *
	 * @param int $position One based position of the video within the gallery.
	 *
	 * @return string Element id.
	 */
	protected function get_schema_item_id( $position ) {
		return 'pp-video-gallery-item-' . $this->get_id() . '-' . $position;
	}

	/**
	 * Alternative text for a video thumbnail.
	 *
	 * Prefers the attachment's own alt text for custom thumbnails, then the video
	 * title. Returns an empty string rather than falling back to the filter label,
	 * which names the category and not the video.
	 *
	 * @since 3.1.0
	 * @access protected
	 *
	 * @param array $item Repeater item for the video.
	 *
	 * @return string Alt text, possibly empty.
	 */
	protected function get_video_thumbnail_alt( $item ) {
		if ( ! empty( $item['custom_thumbnail'] ) && 'yes' === $item['custom_thumbnail'] && ! empty( $item['custom_image']['id'] ) ) {
			$alt = get_post_meta( $item['custom_image']['id'], '_wp_attachment_image_alt', true );

			if ( $alt ) {
				return $alt;
			}
		}

		if ( ! empty( $item['video_title'] ) ) {
			return wp_strip_all_tags( $item['video_title'] );
		}

		return '';
	}

	/**
	 * Render Videos
	 *
	 * @access protected
	 */
	protected function render_video( $item, $index ) {
		$settings = $this->get_settings_for_display();

		$video_container_key = $this->get_repeater_setting_key( 'container', 'video', $index );
		$item_wrap_key = $this->get_repeater_setting_key( 'item_wrap', 'video', $index );
		$this->add_render_attribute( $video_container_key, 'class', 'pp-video-container' );
		$this->add_render_attribute( $item_wrap_key, 'class', [ 'pp-video' ] );

		if ( 'carousel' === $settings['layout'] ) {
			$this->add_render_attribute( $item_wrap_key, 'class', [ 'swiper-slide' ] );
		} else {
			$tags = $this->get_filter_keys( $item );

			$this->add_render_attribute( $item_wrap_key, 'class', [ 'pp-grid-item-wrap', 'elementor-grid-item' ] );

			$this->add_render_attribute( $item_wrap_key, 'class', array_keys( $tags ) );
		}

		if ( 'yes' === $settings['enable_schema'] ) {
			// Scoped to the widget id so two galleries on one page cannot collide, and so
			// the anchors built in Module::print_video_gallery_schema() resolve.
			$this->add_render_attribute( $item_wrap_key, 'id', $this->get_schema_item_id( $index + 1 ) );
		}
		?>
		<div <?php $this->print_render_attribute_string( $item_wrap_key ); ?>>
				<?php
				if ( 'above-video' === $settings['video_title_position'] ) {
					$this->render_video_content( $item, $index );
				}

				$video_url_src = '';
				$thumb_size    = '';

				if ( 'youtube' === $item['video_source'] ) {
					$video_url_src = $item['youtube_url'];
					if ( 'yt-playlist' === $settings['source'] || 'yt-channel' === $settings['source'] ) {
						$thumb_size = $settings['yt_thumbnail_size'];
					} else {
						// Repeater key: absent on items built from the YouTube API.
						$thumb_size = ! empty( $item['thumbnail_size'] ) ? $item['thumbnail_size'] : 'maxresdefault';
					}
				} elseif ( 'vimeo' === $item['video_source'] ) {
					$video_url_src = $item['vimeo_url'];
				} elseif ( 'dailymotion' === $item['video_source'] ) {
					$video_url_src = $item['dailymotion_url'];
				}

				$video_play_key = $this->get_repeater_setting_key( 'play', 'video', $index );
				$this->add_render_attribute( $video_play_key, 'class', 'pp-video-play' );

				if ( 'hosted' === $item['video_source'] ) {
					$video_url = $this->get_hosted_video_url( $item );
				} else {
					$embed_params = $this->get_embed_params( $item );

					if ( preg_match( '/youtube\.com\/shorts\/(\w+\s*\/?)*([0-9]+)*(.*)$/i', $video_url_src, $matches ) ) {
						$video_id  = $matches[1];
						$video_url = $this->get_yt_short_embed_url( $video_id, $embed_params );
					} else {
						$video_url = Embed::get_embed_url( $video_url_src, $embed_params, [] );
					}
				}

				// URLs here are fed straight into an iframe src and reachable from a dynamic tag,
				// so the scheme is validated. esc_url_raw() rather than esc_url(): the value is not
				// being written into HTML at this point - Elementor escapes render attributes on
				// output - so it should not carry display-time entity encoding.
				if ( 'inline' === $settings['click_action'] ) {
					$this->add_render_attribute( $video_play_key, 'data-src', esc_url_raw( $video_url ) );

					// Without JS the anchor should still reach the video's own page, so the
					// href keeps the watch URL while data-src carries the embed URL.
					$this->add_render_attribute( $video_play_key, 'href', esc_url_raw( $video_url_src ? $video_url_src : $video_url ) );
				} else {
					$this->add_render_attribute( $video_play_key, 'data-fancybox', 'video-gallery-' . $this->get_id() );

					if ( 'hosted' === $item['video_source'] || empty( $video_url ) ) {
						// An unrecognised provider URL has no embed URL to build; let fancyBox work it out.
						$this->add_render_attribute( $video_play_key, 'href', esc_url_raw( empty( $video_url ) ? $video_url_src : $video_url ) );
					} else {
						/**
						 * Hand fancyBox the finished embed URL instead of the provider page URL.
						 *
						 * Left to itself, fancyBox matches the provider URL and rebuilds the embed
						 * from its own defaults - youtube-nocookie.com with `enablejsapi=1` - which
						 * drops every embed parameter this widget computed (autoplay, mute, captions,
						 * Vimeo colour) and leaves the player waiting for a click instead of starting
						 * on its own. `data-type` keeps fancyBox from matching the URL at all, and
						 * `iframe.preload` off stops it mounting the iframe off-screen behind
						 * `visibility: hidden`, which suppresses autoplay on its own.
						 */
						$this->add_render_attribute(
							$video_play_key,
							[
								'href'         => esc_url_raw( $video_url_src ),
								'data-src'     => esc_url_raw( $video_url ),
								'data-type'    => 'iframe',
								'data-options' => wp_json_encode(
									[
										'iframe'     => [ 'preload' => false ],
										// An iframe slide is sized by CSS alone, so these classes
										// are what the stylesheet and the widget's own Lightbox
										// controls hook on to.
										'slideClass' => 'pp-video-gallery-lightbox-slide pp-video-gallery-lightbox-' . $this->get_id(),
									]
								),
							]
						);
					}
				}

				$video_label = $item['video_title'] ? wp_strip_all_tags( $item['video_title'] ) : '';

				if ( $video_label ) {
					$this->add_render_attribute(
						$video_play_key,
						'aria-label',
						/* translators: %s: Video title. */
						sprintf( __( 'Play video: %s', 'powerpack' ), $video_label )
					);
				} else {
					$this->add_render_attribute( $video_play_key, 'aria-label', __( 'Play video', 'powerpack' ) );
				}
				?>
				<div <?php $this->print_render_attribute_string( $video_container_key ); ?>>
					<a <?php $this->print_render_attribute_string( $video_play_key ); ?>>
						<?php
							// Video Overlay.
							echo wp_kses_post( $this->render_video_overlay( $index ) );
						?>
						<div class="pp-video-player">
							<?php
							// Resolved once: for Vimeo and Dailymotion this can be an HTTP request.
							$video_thumb = $this->get_video_thumbnail( $item, $thumb_size );
							?>
							<div class="pp-video-thumb-wrap">
								<?php
								if ( $video_thumb ) {
									$this->render_video_thumbnail( $item, $video_thumb );
								} elseif ( 'hosted' === $item['video_source'] ) {
									?>
									<video class="pp-hosted-video" src="<?php echo esc_url( $this->get_hosted_video_url( $item ) ); ?>" preload="<?php echo esc_attr( $settings['preload'] ); ?>"></video>
									<?php
								}

								$this->render_play_icon( $index );

								if ( 'over-image' === $settings['video_title_position'] || 'hover' === $settings['video_title_position'] ) {
									$this->render_video_content( $item, $index );
								}
								?>
							</div>
						</div>
					</a>
				</div>
				<?php
				if ( 'below-video' === $settings['video_title_position'] ) {
					$this->render_video_content( $item, $index );
				}
				?>
		</div>
		<?php
	}

	/**
	 * Render Videos
	 *
	 * @access protected
	 */
	protected function render_videos( $gallery ) {
		$settings       = $this->get_settings_for_display();
		$per_page       = $settings['images_per_page'];
		$has_pagination = $this->has_load_more();

		foreach ( $gallery as $index => $item ) {
			if ( $has_pagination && $index >= $per_page ) {
				break;
			}

			$this->render_video( $item, $index );
		}
	}

	/**
	 * Whether the Load More button is active for the current settings.
	 *
	 * Load More pages through the custom `gallery_videos` repeater, so it never applies
	 * to the YouTube sources - their videos come from the API instead, and paging the
	 * repeater there would append the shipped demo videos.
	 *
	 * @since 3.1.0
	 * @access protected
	 *
	 * @return bool Whether Load More should render.
	 */
	protected function has_load_more() {
		$settings = $this->get_settings_for_display();

		return 'custom' === $settings['source']
			&& 'carousel' !== $settings['layout']
			&& 'yes' === $settings['pagination']
			&& 'yes' !== $settings['filter_enable']
			&& ! empty( $settings['images_per_page'] );
	}

	/**
	 * Render a video's thumbnail image.
	 *
	 * Custom thumbnails are printed through wp_get_attachment_image() so they keep their
	 * srcset, sizes and intrinsic dimensions. Remote posters have no attachment behind
	 * them, so they fall back to a plain tag with the same loading hints.
	 *
	 * @since 3.1.0
	 * @access protected
	 *
	 * @param array  $item      Repeater item for the video.
	 * @param string $thumb_url Already resolved thumbnail URL.
	 *
	 * @return void
	 */
	protected function render_video_thumbnail( $item, $thumb_url ) {
		$alt = $this->get_video_thumbnail_alt( $item );

		if ( ! empty( $item['custom_thumbnail'] ) && 'yes' === $item['custom_thumbnail'] && ! empty( $item['custom_image']['id'] ) ) {
			$image_html = wp_get_attachment_image(
				$item['custom_image']['id'],
				'full',
				false,
				[
					'class'    => 'pp-video-thumb',
					'alt'      => $alt,
					'loading'  => 'lazy',
					'decoding' => 'async',
				]
			);

			// Empty when the attachment has since been deleted; fall through to the URL.
			if ( $image_html ) {
				echo $image_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped by wp_get_attachment_image().
				return;
			}
		}
		?>
		<img class="pp-video-thumb" src="<?php echo esc_url( $thumb_url ); ?>" alt="<?php echo esc_attr( $alt ); ?>" loading="lazy" decoding="async">
		<?php
	}

	/**
	 * Returns Video Thumbnail.
	 *
	 * @param  array $item       Video.
	 * @param  mixed $thumb_size Thumbnail size.
	 *
	 * @access protected
	 */
	protected function get_video_thumbnail( $item, $thumb_size = '' ) {
		// A custom thumbnail wins for every source, and an empty one still suppresses the
		// remote lookup, as it always has.
		if ( ! empty( $item['custom_thumbnail'] ) && 'yes' === $item['custom_thumbnail'] ) {
			return ! empty( $item['custom_image']['url'] ) ? $item['custom_image']['url'] : '';
		}

		$video_id = $this->get_video_id( $item );

		if ( ! $video_id ) {
			return '';
		}

		if ( 'youtube' === $item['video_source'] ) {
			// YouTube thumbnails are addressable, so no request is needed.
			return 'https://i.ytimg.com/vi/' . $video_id . '/' . $thumb_size . '.jpg';
		}

		if ( 'vimeo' === $item['video_source'] || 'dailymotion' === $item['video_source'] ) {
			return $this->get_remote_video_thumbnail( $item['video_source'], $video_id );
		}

		return '';
	}

	/**
	 * Look up a Vimeo or Dailymotion thumbnail URL, through a transient.
	 *
	 * Vimeo and Dailymotion have no addressable thumbnail URL, so the poster has to be
	 * fetched. Uncached that is a blocking HTTP request per video on every page view, so
	 * both hits and misses are cached - misses briefly, so a failing endpoint is not
	 * retried on every request but still recovers quickly.
	 *
	 * @since 3.1.0
	 * @access protected
	 *
	 * @param string $source   Video source, 'vimeo' or 'dailymotion'.
	 * @param string $video_id Video id at that source.
	 *
	 * @return string Thumbnail URL, or an empty string when it could not be resolved.
	 */
	protected function get_remote_video_thumbnail( $source, $video_id ) {
		$cache_key = 'pp_vg_thumb_' . $source . '_' . md5( $video_id );
		$cached    = get_transient( $cache_key );

		// A cached miss is stored as an empty string, so distinguish it from "not cached".
		if ( false !== $cached ) {
			return $cached;
		}

		/**
		 * Filters how long a resolved Vimeo or Dailymotion thumbnail URL is cached.
		 *
		 * @since 3.1.0
		 *
		 * @param int    $ttl      Cache lifetime in seconds. Default one day.
		 * @param string $source   Video source, 'vimeo' or 'dailymotion'.
		 * @param string $video_id Video id at that source.
		 */
		$ttl = apply_filters( 'pp_video_gallery_thumbnail_cache_time', DAY_IN_SECONDS, $source, $video_id );

		if ( 'vimeo' === $source ) {
			// The .json variant of this endpoint returns the same payload as the .php one,
			// without requiring the response body to be unserialised.
			$endpoint = 'https://vimeo.com/api/v2/video/' . rawurlencode( $video_id ) . '.json';
		} else {
			$endpoint = 'https://api.dailymotion.com/video/' . rawurlencode( $video_id ) . '?fields=thumbnail_url';
		}

		$response = wp_remote_get( $endpoint, [ 'timeout' => 5 ] );

		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			set_transient( $cache_key, '', min( $ttl, HOUR_IN_SECONDS ) );

			return '';
		}

		$body      = wp_remote_retrieve_body( $response );
		$thumb_url = '';

		if ( 'vimeo' === $source ) {
			$vimeo = json_decode( $body, true );

			if ( ! empty( $vimeo[0]['thumbnail_large'] ) ) {
				$thumb_url = str_replace( '_640', '_840', $vimeo[0]['thumbnail_large'] );
			}
		} else {
			$dailymotion = json_decode( $body, true );

			if ( ! empty( $dailymotion['thumbnail_url'] ) ) {
				$thumb_url = $dailymotion['thumbnail_url'];
			}
		}

		set_transient( $cache_key, $thumb_url, $thumb_url ? $ttl : min( $ttl, HOUR_IN_SECONDS ) );

		return $thumb_url;
	}

	/**
	 * Returns Video ID.
	 *
	 * @access protected
	 */
	protected function get_video_id( $item ) {

		$video_id = '';

		if ( 'youtube' === $item['video_source'] ) {
			$url = $item['youtube_url'];

			if ( preg_match( '#(?<=v=|v\/|vi=|vi\/|youtu.be\/)[a-zA-Z0-9_-]{11}#', $url, $matches ) ) {
				$video_id = $matches[0];
			} else {
				if ( preg_match( '/youtube\.com\/shorts\/(\w+\s*\/?)*([0-9]+)*(.*)$/i', $url, $matches ) ) {
					$video_id = $matches[1];
				}
			}
		} elseif ( 'vimeo' === $item['video_source'] ) {
			$url = $item['vimeo_url'];

			$video_id = preg_replace( '/[^\/]+[^0-9]|(\/)/', '', rtrim( $url, '/' ) );

		} elseif ( 'dailymotion' === $item['video_source'] ) {
			$url = $item['dailymotion_url'];

			if ( preg_match( '/^.+dailymotion.com\/(?:video|swf\/video|embed\/video|hub|swf)\/([^&?]+)/', $url, $matches ) ) {
				$video_id = $matches[1];
			}
		}

		return $video_id;

	}

	/**
	 * Render youtube short embed URL.
	 *
	 * @since 2.9.0
	 * @access protected
	 */
	private function get_yt_short_embed_url( $video_id, $embed_params ) {
		$yt_url = 'https://www.youtube.com/embed/' . $video_id;
		return add_query_arg( $embed_params, $yt_url );
	}

	/**
	 * Get embed params.
	 *
	 * Retrieve video widget embed parameters.
	 *
	 * @access public
	 *
	 * @return array Video embed parameters.
	 */
	public function get_embed_params( $item ) {
		$settings = $this->get_settings_for_display();

		$params = [];

		$params_dictionary = [];

		if ( 'youtube' === $item['video_source'] ) {

			$params_dictionary = [
				'mute',
			];

			// Videos pulled from a YouTube playlist or channel are built without the repeater keys.
			if ( ! empty( $item['cc_load_policy'] ) && 'yes' === $item['cc_load_policy'] ) {
				$params['cc_load_policy'] = 1;
			}

			$params['autoplay'] = 1;

			$params['wmode'] = 'opaque';
		} elseif ( 'vimeo' === $item['video_source'] ) {

			$params_dictionary = [
				'mute' => 'muted',
			];

			$params['autopause'] = '0';
			$params['autoplay']  = '1';
		} elseif ( 'dailymotion' === $item['video_source'] ) {

			$params_dictionary = [
				'mute',
			];

			$params['endscreen-enable'] = '0';
			$params['autoplay']         = 1;

		}

		foreach ( $params_dictionary as $key => $param_name ) {
			$setting_name = $param_name;

			if ( is_string( $key ) ) {
				$setting_name = $key;
			}

			$setting_value = $settings[ $setting_name ] ? '1' : '0';

			$params[ $param_name ] = $setting_value;
		}

		return $params;
	}

	/**
	 * Build the overlay element markup for a gallery item.
	 *
	 * @access protected
	 *
	 * @param int $index Index of the video within the gallery.
	 *
	 * @return string Overlay element markup.
	 */
	protected function render_video_overlay( $index ) {
		$overlay_setting_key = $this->get_repeater_setting_key( 'overlay', 'gallery_videos', $index );

		$this->add_render_attribute(
			$overlay_setting_key,
			'class',
			[
				'pp-media-overlay',
				'pp-video-overlay',
			]
		);

		return '<div ' . $this->get_render_attribute_string( $overlay_setting_key ) . '></div>';
	}

	/**
	 * Render play icon output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @access protected
	 */
	protected function render_play_icon( $index ) {
		$settings = $this->get_settings_for_display();

		if ( 'none' === $settings['play_icon_type'] ) {
			return;
		}

		$play_icon_key = $this->get_repeater_setting_key( 'container', 'play-icon', $index );
		$this->add_render_attribute( $play_icon_key, 'class', 'pp-video-play-icon' );

		if ( 'icon' === $settings['play_icon_type'] ) {
			if ( ! isset( $settings['play_icon'] ) && ! Icons_Manager::is_migration_allowed() ) {
				// add old default
				$settings['play_icon'] = 'fa fa-play-circle';
			}

			$has_icon = ! empty( $settings['play_icon'] );

			if ( $has_icon ) {
				$this->add_render_attribute( 'play-icon-i', 'class', $settings['play_icon'] );
				$this->add_render_attribute( 'play-icon-i', 'aria-hidden', 'true' );
			}

			if ( ! $has_icon && ! empty( $settings['select_play_icon']['value'] ) ) {
				$has_icon = true;
			}
			$migrated = isset( $settings['__fa4_migrated']['select_play_icon'] );
			$is_new   = ! isset( $settings['play_icon'] ) && Icons_Manager::is_migration_allowed();
			?>
			<span <?php $this->print_render_attribute_string( $play_icon_key ); ?>>
				<?php
				if ( $is_new || $migrated ) {
					Icons_Manager::render_icon( $settings['select_play_icon'], [ 'aria-hidden' => 'true' ] );
				} elseif ( ! empty( $settings['play_icon'] ) ) {
					?>
					<i <?php $this->print_render_attribute_string( 'play-icon-i' ); ?>></i>
					<?php
				}
				?>
			</span>
			<?php

		} elseif ( 'image' === $settings['play_icon_type'] ) {

			if ( $settings['play_icon_image']['url'] ) {
				?>
				<span <?php $this->print_render_attribute_string( $play_icon_key ); ?>>
					<img src="<?php echo esc_url( $settings['play_icon_image']['url'] ); ?>" alt="">
				</span>
				<?php
			}
		}
	}

	/**
	 * Build the CSS class fragment for a filter label.
	 *
	 * Note on the algorithm: json_encode() is used to transliterate non-Latin labels into
	 * their \uXXXX escapes so something survives the character strip below. It is kept
	 * exactly as it was because its output becomes both the item class and the matching
	 * data-filter value on rendered pages, so any change would break custom CSS written
	 * against those classes. Labels that differ only in stripped characters do collide
	 * (`Rock & Roll` and `RockRoll` both yield `rockroll`), which is a known limitation.
	 *
	 * @since 3.1.0
	 * @access public
	 *
	 * @param string $string Filter label to convert.
	 *
	 * @return string Lowercased string containing only letters, digits and hyphens.
	 */
	public function get_filter_class( $string ) {

		// Replaces all spaces with hyphens.
		$string = str_replace( ' ', '-', $string );

		// Encode non-English letters.
		$string = json_encode( $string );

		// Removes special chars.
		$string = preg_replace( '/[^A-Za-z0-9\-]/', '', $string );

		// Turn into lower case characters.
		return strtolower( $string );
	}

	/**
	 * Render filter keys array.
	 *
	 * @access public
	 */
	public function get_filter_keys( $item ) {

		$filters = explode( ',', $item['filter_label'] );
		$filters = array_map( 'trim', $filters );

		$filters_array = [];

		foreach ( $filters as $key => $value ) {
			$filters_array[ 'filter-' . $this->get_filter_class( $value ) ] = $value;
		}

		return $filters_array;
	}

	/**
	 * Get Filter values array.
	 *
	 * Returns the Filter array of objects.
	 *
	 * @access public
	 */
	public function get_filter_values() {

		$settings = $this->get_settings_for_display();

		$filters = [];

		if ( ! empty( $settings['gallery_videos'] ) ) {

			foreach ( $settings['gallery_videos'] as $key => $value ) {

				$filter_keys = $this->get_filter_keys( $value );

				if ( ! empty( $filter_keys ) ) {

					$filters = array_unique( array_merge( $filters, $filter_keys ) );
				}
			}
		}

		return $filters;
	}

	/**
	 * Render pagination
	 */
	protected function render_pagination() {
		if ( ! $this->has_load_more() ) {
			return;
		}

		$settings     = $this->get_settings_for_display();
		$videos       = $settings['gallery_videos'];
		$videos_count = count( $videos );
		$per_page     = $settings['images_per_page'];

		if ( $videos_count > $per_page ) {

			if ( ! isset( $settings['load_more_icon'] ) && ! Icons_Manager::is_migration_allowed() ) {
				// add old default.
				$settings['load_more_icon'] = '';
			}

			$has_icon = ! empty( $settings['load_more_icon'] );

			if ( $has_icon ) {
				$this->add_render_attribute( 'i', 'class', $settings['load_more_icon'] );
				$this->add_render_attribute( 'i', 'aria-hidden', 'true' );
			}

			if ( ! $has_icon && ! empty( $settings['select_load_more_icon']['value'] ) ) {
				$has_icon = true;
			}
			$migrated = isset( $settings['__fa4_migrated']['select_load_more_icon'] );
			$is_new   = ! isset( $settings['load_more_icon'] ) && Icons_Manager::is_migration_allowed();

			$this->add_render_attribute(
				'load-more-button',
				'class',
				[
					'pp-gallery-load-more',
					'elementor-button',
					'elementor-size-' . $settings['button_size'],
				]
			);
			?>
			<div class="pp-video-gallery-pagination" data-per-page="<?php echo esc_attr( $settings['images_per_page'] ); ?>">
				<button type="button" <?php $this->print_render_attribute_string( 'load-more-button' ); ?>>

					<?php if ( $has_icon && 'before' === $settings['button_icon_position'] ) { ?>
						<span class="pp-gallery-load-more-icon pp-icon pp-no-trans">
							<?php
							if ( $is_new || $migrated ) {
								Icons_Manager::render_icon( $settings['select_load_more_icon'], [ 'aria-hidden' => 'true' ] );
							} elseif ( ! empty( $settings['load_more_icon'] ) ) {
								?>
								<i <?php $this->print_render_attribute_string( 'i' ); ?>></i>
								<?php
							}
							?>
						</span>
					<?php } ?>
					<span class="pp-gallery-load-more-text">
						<?php echo wp_kses_post( $settings['load_more_text'] ); ?>
					</span>
					<?php if ( $has_icon && 'after' === $settings['button_icon_position'] ) { ?>
						<span class="pp-gallery-load-more-icon pp-icon pp-no-trans">
							<?php
							if ( $is_new || $migrated ) {
								Icons_Manager::render_icon( $settings['select_load_more_icon'], [ 'aria-hidden' => 'true' ] );
							} elseif ( ! empty( $settings['load_more_icon'] ) ) {
								?>
								<i <?php $this->print_render_attribute_string( 'i' ); ?>></i>
								<?php
							}
							?>
						</span>
					<?php } ?>
				</button>
				<?php
				// Preserve the keys so the deferred items keep their real gallery index.
				// Without this array_slice() reindexes from zero, the render attribute keys
				// collide with the already rendered items, and Elementor merges the two sets
				// of values - producing a two URL data-src and a duplicated id.
				$offset_videos = array_slice( $videos, (int) $settings['images_per_page'], null, true );
				$offset_items = '';
				ob_start();

				foreach ( $offset_videos as $index => $video ) {
					if ( ! is_array( $video ) ) {
						continue;
					}

					$this->render_video( $video, $index );
				}

				$offset_items = ob_get_clean();

				// $offset_items is markup this widget just rendered, so every value inside it
				// has already been escaped at the point it was written - that is why it is
				// echoed raw below. The one thing raw markup must not contain here is a
				// literal "</script", which would close the template early; wp_kses_post()
				// strips script tags and esc_attr() encodes "<", so it cannot occur, and this
				// neutralises it regardless.
				$offset_items = str_ireplace( '</script', '<\/script', $offset_items );
				?>
				<script type="text/html" class="pp-video-gallery-pagination-items">
					<?php echo preg_replace( '/\>\s+\</m', '><', $offset_items ); ?>
				</script>
			</div>
			<?php
		}
	}

	/**
	 * Gets expire time of transient.
	 *
	 * @since 2.10.18
	 * @param array $settings The settings array.
	 * @return the reviews transient expire time.
	 * @access public
	 */
	public function get_transient_expire( $settings ) {

		$expire_value = $settings['videos_refresh_time'];
		$expire_time  = 24 * HOUR_IN_SECONDS;

		if ( 'hour' === $expire_value ) {
			$expire_time = 60 * MINUTE_IN_SECONDS;
		} elseif ( 'week' === $expire_value ) {
			$expire_time = 7 * DAY_IN_SECONDS;
		} elseif ( 'month' === $expire_value ) {
			$expire_time = 30 * DAY_IN_SECONDS;
		} elseif ( 'year' === $expire_value ) {
			$expire_time = 365 * DAY_IN_SECONDS;
		}

		return $expire_time;
	}

	/**
	 * Get YouTube API from PowerPack Addons options.
	 *
	 * @since 2.10.18
	 * @return string
	 */
	public function get_youtube_api() {
		return PP_Admin_Settings::get_option( 'pp_youtube_api_key' );
	}

	/**
	 * Fetch videos from the YouTube Data API.
	 *
	 * Walks the API's paginated results recursively, up to five pages.
	 *
	 * @since 2.10.18
	 * @access public
	 *
	 * @param array  $yt_data Videos collected by the previous page.
	 * @param string $token   Page token for the request. Empty for the first page.
	 * @param int    $page    Zero based index of the page being requested.
	 *
	 * @return array|\WP_Error Response with 'data' and 'error' keys, or a WP_Error
	 *                        when the API key, channel ID or playlist ID is missing.
	 */
	public function get_youtube_api_data( $yt_data, $token = '', $page = 0 ) {
		$settings = $this->get_settings_for_display();

		$api_key = $this->get_youtube_api();
		$source  = ( 'yt-channel' === $settings['source'] ) ? 'channel' : 'playlist';

		if ( empty( $api_key ) ) {
			$message = ( 'channel' === $source )
				? esc_html__( 'To display videos from YouTube channel, you need to setup API key.', 'powerpack' )
				: esc_html__( 'To display videos from YouTube playlist, you need to setup API key.', 'powerpack' );

			return new \WP_Error( 'missing_api_key', $message );
		}

		if ( 'channel' === $source ) {
			$channel_id = ! empty( $settings['yt_channel_id'] ) ? esc_html( $settings['yt_channel_id'] ) : '';

			if ( empty( $channel_id ) ) {
				return new \WP_Error( 'missing_channel_id', esc_html__( 'To display videos from YouTube channel, you need to provide valid Channel ID.', 'powerpack' ) );
			}
		} else {
			$playlist_id = ! empty( $settings['yt_playlist_id'] ) ? esc_html( $settings['yt_playlist_id'] ) : '';

			if ( empty( $playlist_id ) ) {
				return new \WP_Error( 'missing_plylist_id', esc_html__( 'To display videos from YouTube playlist, you need to provide valid Playlist ID.', 'powerpack' ) );
			}
		}

		$api_args = [
			'method'  => 'GET',
			// The API key travels in the query string, so certificate verification has to
			// stay on - WordPress verifies by default, which is why sslverify is absent.
			'timeout' => 15,
		];

		if ( 'yt-channel' === $settings['source'] ) {
			$yt_args = [
				'part'       => 'snippet,id',
				// Search also returns the channel and its playlists, which have no video ID.
				'type'       => 'video',
				'order'      => 'date',
				'maxResults' => 50,
				'key'        => $api_key,
				'channelId'  => $channel_id,
			];
			if ( ! empty( $token ) ) {
				$yt_args['pageToken'] = $token;
			}
			$url = add_query_arg(
				$yt_args,
				'https://www.googleapis.com/youtube/v3/search'
			);
		} else {
			$yt_args = [
				'part'       => 'snippet',
				'maxResults' => 50,
				'key'        => $api_key,
				'playlistId' => $playlist_id,
			];
			if ( ! empty( $token ) ) {
				$yt_args['pageToken'] = $token;
			}
			$url = add_query_arg(
				$yt_args,
				'https://www.googleapis.com/youtube/v3/playlistItems'
			);
		}

		$api_data = wp_remote_post(
			esc_url_raw( $url ),
			$api_args
		);

		$response = [
			'data'	=> [],
			'error' => false,
		];

		if ( is_wp_error( $api_data ) ) {
			$response['error'] = $api_data;
		} else {
			if ( 200 === wp_remote_retrieve_response_code( $api_data ) ) {
				$data = json_decode( wp_remote_retrieve_body( $api_data ), false );

				$yt_videos = $yt_data;
				if ( $data->pageInfo->totalResults ) {

					foreach ( $data->items as $item ) {
						$yt_videos[] = $item;
					}

					if ( 4 >= $page ) {
					$nextPageToken = ! empty( $data->nextPageToken ) ? $data->nextPageToken : '';
					if ( ! empty( $nextPageToken ) ) {
							$page++;
							$next_page_data = $this->get_youtube_api_data( $data->items, $nextPageToken, $page );
							foreach ( $next_page_data['data']['video'] as $new_item ) {
								if ( ! in_array( $new_item, $yt_videos ) ) {
									$yt_videos[] = $new_item;
								}
							}
						}
					}

					$response['data'] = [
						'video' => $yt_videos,
					];

					$response['error'] = false;
				} else {
					$response['error'] = esc_html__( 'This playlist doesn\'t have any videos.', 'powerpack' );
				}
			}
		}

		return $response;
	}

	/**
	 * Get the YouTube videos for the widget, from the transient when it is warm.
	 *
	 * @since 2.10.18
	 * @access public
	 *
	 * @return array Response with 'data' and 'error' keys.
	 */
	public function get_youtube_playlist_videos_data() {
		$settings = $this->get_settings_for_display();

		$response = [
			'data'	=> [],
			'error' => false,
		];

		$source_id = ( 'yt-channel' === $settings['source'] ) ? $settings['yt_channel_id'] : $settings['yt_playlist_id'];

		// Hashed because YouTube ids are case sensitive and can push the option name past
		// the length a transient key allows.
		$transient_name = $source_id ? 'pp_yt_videos_' . md5( $source_id ) : '';

		$response['data'] = $transient_name ? get_transient( $transient_name ) : false;

		if ( empty( $response['data'] ) ) {
			$yt_data = [];

			$api_datas = $this->get_youtube_api_data( $yt_data, '', 0 );

			if ( is_wp_error( $api_datas ) ) {
				$response['error'] = $api_datas;

				return $response;
			}

			$final_yt_data = [];

			if ( isset( $api_datas['data'] ) && ! empty( $api_datas['data'] ) ) {

				foreach ( $api_datas['data'] as $api_datas ) {
					foreach ( $api_datas as $api_data ) {
						$final_yt_data[] = $api_data;
					}
				}

				$response['data'] = [
					'video' => $final_yt_data,
				];

				if ( $transient_name ) {
					set_transient( $transient_name, $response['data'], $this->get_transient_expire( $settings ) );
				}

				$response['error'] = false;
			}
		}

		return $response;
	}

	/**
	 * Get YouTube videos normalised into the gallery item shape.
	 *
	 * @since 2.10.18
	 * @access public
	 *
	 * @return array|\WP_Error Gallery items, or a WP_Error when the API request failed.
	 */
	public function get_youtube_videos() {
		$settings = $this->get_settings_for_display();

		$videos = $this->get_youtube_playlist_videos_data();

		if ( is_wp_error( $videos['error'] ) ) {
			return $videos['error'];
		}

		if ( empty( $videos['data'] ) ) {
			return;
		}

		$parsed_videos = [];

		$data = $videos['data']['video'];

		$videos_count = $settings['yt_vides_count'];
		$data = array_slice( $data, 0, $videos_count );

		foreach ( $data as $video ) {
			if ( ! empty( $video->snippet->title ) && 'Private video' !== $video->snippet->title ) {
				$_video = [];

				$video_id = '';

				if ( 'yt-channel' === $settings['source'] ) {
					$video_id = isset( $video->id->videoId ) ? $video->id->videoId : '';
				} elseif ( 'yt-playlist' === $settings['source'] ) {
					$video_id = isset( $video->snippet->resourceId->videoId ) ? $video->snippet->resourceId->videoId : '';
				}

				// Skip entries that are not videos rather than emitting an empty item.
				if ( ! $video_id ) {
					continue;
				}

				$_video['video_source'] = 'youtube';
				$_video['filter_label'] = 'youtube';
				$_video['_id']          = $video_id;

				if ( 'yes' === $settings['yt_video_title_show'] ) {
					$post_title = ( ! empty( $settings['yt_video_title'] ) ) ? esc_html( $settings['yt_video_title'] ) : $video->snippet->title;
					$title_length = $settings['yt_title_length'];

					/**
					 * Filters the string appended to a truncated YouTube video title.
					 *
					 * @since 3.1.0
					 *
					 * @param string $more Text appended when the title is trimmed. Default '...'.
					 */
					$more = apply_filters( 'pp_yt_video_title_limit_more', '...' );

					$post_title            = wp_trim_words( $post_title, $title_length, $more );
					$_video['video_title'] = $post_title;
				} else {
					$_video['video_title'] = '';
				}

				if ( 'yes' === $settings['yt_video_description_show'] ) {
					$post_content = ( ! empty( $settings['yt_video_description'] ) ) ? esc_html( $settings['yt_video_description'] ) : $video->snippet->description;
					$content_length = $settings['yt_content_length'];

					/**
					 * Filters the string appended to a truncated YouTube video description.
					 *
					 * @since 3.1.0
					 *
					 * @param string $more Text appended when the description is trimmed. Default '...'.
					 */
					$more = apply_filters( 'pp_yt_video_content_limit_more', '...' );

					$post_content                = wp_trim_words( $post_content, $content_length, $more );
					$_video['video_description'] = $post_content;
				} else {
					$_video['video_description'] = '';
				}

				$youtube_url           = 'https://www.youtube.com/watch?v=' . $video_id;
				$_video['youtube_url'] = $youtube_url;

				$parsed_videos[] = $_video;
			}
		}

		return $parsed_videos;
	}
}
