<?php
/**
 * Authorization boundary for request-selected Gutenberg preview data.
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Scope preview authority to an actual REST callback, including nested dispatches.
 */
class Jet_Engine_Blocks_Preview_Context {

	/** @var WP_REST_Request|null Active JetEngine block-renderer request. */
	private static $request = null;

	/** @var int Active block render depth within this REST callback only. */
	private static $render_depth = 0;

	/** @var object[] Custom objects resolved from the editable owner's stored source. */
	private static $custom_objects = array();

	/**
	 * Invoke the endpoint within an exception-safe preview scope after core permissions.
	 *
	 * Unrelated nested REST callbacks temporarily suspend the outer preview policy.
	 * Existing dispatch overrides are left untouched.
	 *
	 * @param mixed $result Existing dispatch override, normally null.
	 * @param WP_REST_Request $request Actual REST request.
	 * @param string $route Matched route pattern.
	 * @param array $handler Registered endpoint handler.
	 * @return mixed Endpoint response or existing dispatch override.
	 */
	public static function dispatch( $result, $request, $route, $handler ) {
		$is_preview = 1 === preg_match( '#^/wp/v2/block-renderer/jet-engine/[^/]+$#D', $request->get_route() );
		if ( null !== $result || ( ! $is_preview && ! self::$request ) ) {
			return $result;
		}
		$previous = self::$request;
		$previous_depth = self::$render_depth;
		$restore = $is_preview ? self::preserve_context() : null;
		if ( $is_preview ) { self::$custom_objects = array(); }
		self::$request = $is_preview ? $request : null;
		self::$render_depth = 0;
		try {
			return call_user_func( $handler['callback'], $request );
		} finally {
			try {
				if ( $restore ) { $restore(); }
			} finally {
				self::$request = $previous;
				self::$render_depth = $previous_depth;
			}
		}
	}

	/**
	 * Preserve listing state, scoped custom-object grants and postdata globals.
	 *
	 * Endpoint and nested block renders each own a scope; restoring an inner block
	 * must not leave its object active in the parent renderer. Query objects themselves
	 * are not changed by setup_postdata() and remain owned by their query consumer.
	 *
	 * @return Closure Callback restoring listing and global state, in LIFO order.
	 */
	public static function preserve_context() {
		$restore = jet_engine()->listings->data->preserve_context();
		$custom_objects = self::$custom_objects;
		$globals = array();
		foreach ( array( 'post', 'id', 'authordata', 'currentday', 'currentmonth', 'page', 'pages', 'multipage', 'more', 'numpages' ) as $key ) {
			$globals[ $key ] = array( array_key_exists( $key, $GLOBALS ), isset( $GLOBALS[ $key ] ) ? $GLOBALS[ $key ] : null );
		}
		/** @return void Restore engine-owned slots and postdata globals. */
		return function () use ( $restore, $globals, $custom_objects ) {
			try {
				$restore();
			} finally {
				self::$custom_objects = $custom_objects;
				foreach ( $globals as $key => $state ) {
					if ( $state[0] ) {
						$GLOBALS[ $key ] = $state[1];
					} else {
						unset( $GLOBALS[ $key ] );
					}
				}
			}
		};
	}

	/**
	 * Return the actual preview request rather than inferring authority from globals.
	 *
	 * @return WP_REST_Request|null Active request, or null outside preview dispatch.
	 */
	public static function get_request() {
		return self::$request;
	}

	/**
	 * Enter a block render without confusing nested blocks with nested REST requests.
	 *
	 * @return Closure Restore the enclosing render depth and listing context.
	 */
	public static function preserve_render_context() {
		$restore = self::preserve_context();
		$depth = self::$render_depth++;
		return function () use ( $restore, $depth ) {
			try { $restore(); } finally { self::$render_depth = $depth; }
		};
	}

	/** @return bool Whether a parent block already established this preview's context. */
	public static function is_nested_render() {
		return self::$render_depth > 1;
	}

	/**
	 * Validate an external identifier without coercing malformed input to another ID.
	 *
	 * @param mixed $value Submitted identifier.
	 * @return int Positive identifier, or zero for invalid input.
	 */
	public static function get_id( $value ) {
		if ( ! is_int( $value ) && ! is_string( $value ) ) {
			return 0;
		}
		$id = filter_var( $value, FILTER_VALIDATE_INT, array( 'options' => array( 'min_range' => 1 ) ) );
		return false === $id ? 0 : $id;
	}

	/**
	 * Authorize the effective object without changing frontend listing visibility.
	 *
	 * @param object|false|null $object Object selected by the source or context.
	 * @return bool Whether the active preview may read this object.
	 */
	public static function can_read( $object ) {
		if ( ! self::$request ) {
			return true;
		}
		if ( ! is_object( $object ) || is_wp_error( $object ) ) {
			return false;
		}
		if ( $object instanceof WP_Post ) {
			return current_user_can( 'read_post', $object->ID )
				&& ( ! post_password_required( $object ) || current_user_can( 'edit_post', $object->ID ) );
		}
		if ( $object instanceof WP_User ) {
			return $object->ID > 0 && ( get_current_user_id() === (int) $object->ID || current_user_can( 'edit_user', $object->ID ) );
		}
		if ( $object instanceof WP_Term ) {
			$taxonomy = get_taxonomy( $object->taxonomy );
			return $object->term_id > 0 && $taxonomy
				&& ( is_taxonomy_viewable( $taxonomy ) || current_user_can( 'edit_term', $object->term_id ) );
		}
		if ( $object instanceof WP_Comment ) {
			return current_user_can( 'edit_comment', $object->comment_ID );
		}
		/**
		 * Authorize a custom preview object; never overrides native-object checks.
		 *
		 * @param bool $allowed Whether this object came from an editable stored source or the viewer can manage options.
		 * @param object $object Resolved custom object.
		 * @param WP_REST_Request $request Active preview request.
		 */
		$allowed = in_array( $object, self::$custom_objects, true ) || current_user_can( 'manage_options' );
		return (bool) apply_filters( 'jet-engine/blocks-views/preview/custom-object-access', $allowed, $object, self::$request );
	}

	/**
	 * Resolve a preview selection using stored settings or a readable posts-only override.
	 *
	 * Custom source callbacks may use an empty ID to select their own sample. Their
	 * returned custom object is authorized only within this render's preserved scope;
	 * native posts/users/terms/comments always retain independent authorization.
	 *
	 * @param Jet_Engine_Render_Base $render Renderer passed to native custom-source filters.
	 * @return array|false Listing ID/settings/object tuple, or false for a denied selection.
	 */
	public static function resolve( $render ) {
		$request = self::$request;
		if ( ! $request ) {
			return false;
		}
		$owner_id = self::get_id( $request->get_param( 'post_id' ) );
		$owner = $owner_id ? get_post( $owner_id ) : null;
		if ( null !== $request->get_param( 'post_id' ) && ( ! $owner || ! current_user_can( 'edit_post', $owner_id ) ) ) {
			return false;
		}
		$settings = array( 'listing_source' => 'posts' );
		$is_listing = $owner && jet_engine()->post_type->slug() === $owner->post_type;
		if ( $is_listing ) {
			$stored = get_post_meta( $owner_id, '_elementor_page_settings', true );
			$settings = is_array( $stored ) ? array_merge( $settings, $stored ) : $settings;
		}
		// Query Loop controls intentionally select a post even inside a non-post listing.
		$requested_listing = $request->get_param( 'listing' );
		if ( is_array( $requested_listing ) && isset( $requested_listing['listing_source'] ) && 'posts' === $requested_listing['listing_source'] ) {
			$settings = array( 'listing_source' => 'posts' );
		}
		$source = $settings['listing_source'];
		$native = in_array( $source, array( 'posts', 'repeater', 'users', 'terms' ), true );
		$requested_object = $request->get_param( 'object' );
		$object_id = null !== $requested_object ? self::get_id( $requested_object ) : $owner_id;
		// WordPress query strings encode false as "false"; custom adapters may ignore it.
		$empty_sample = in_array( $requested_object, array( null, false, '', 'false', 0, '0' ), true );
		if ( ! $object_id && ( $native || ! $is_listing || ! $empty_sample ) ) {
			return false;
		}
		switch ( $source ) {
			case 'posts':
			case 'repeater':
				$object = get_post( $object_id );
				break;
			case 'users':
				$object = get_user_by( 'ID', $object_id );
				break;
			case 'terms':
				$object = get_term( $object_id, isset( $settings['listing_tax'] ) ? $settings['listing_tax'] : '' );
				break;
			default:
				if ( ! $is_listing ) { return false; }
				// Adapters that resolve their sample through the current document need this owner.
				jet_engine()->listings->data->set_listing( jet_engine()->listings->get_new_doc( $settings, $owner_id ) );
				// Query Builder's adapter expects a document ID, not a selectable result ID.
				if ( 'query' === $source ) { $object_id = $owner_id; }
				$object = apply_filters( 'jet-engine/listing/render/object/' . $source, false, $object_id, $settings, $render );
				if ( is_object( $object ) && ! is_wp_error( $object )
					&& ! $object instanceof WP_Post && ! $object instanceof WP_User
					&& ! $object instanceof WP_Term && ! $object instanceof WP_Comment ) {
					self::$custom_objects[] = $object;
				}
		}
		if ( $object instanceof WP_Post && 'posts' === $source ) {
			$settings['listing_post_type'] = $object->post_type;
		}
		return self::can_read( $object ) ? array( $owner_id, $settings, $object ) : false;
	}
}
