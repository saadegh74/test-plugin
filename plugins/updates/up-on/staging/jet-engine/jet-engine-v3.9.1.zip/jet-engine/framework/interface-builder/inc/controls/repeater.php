<?php
/**
 * Class for the building ui-repeater elements.
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! class_exists( 'CX_Control_Repeater' ) ) {

	/**
	 * Class for the building ui-repeater elements.
	 */
	class CX_Control_Repeater extends CX_Controls_Base {

		/**
		 * Default settings
		 *
		 * @var array
		 */
		public $defaults_settings = array(
			'type'        => 'repeater',
			'id'          => 'cx-ui-repeater-id',
			'name'        => 'cx-ui-repeater-name',
			'value'       => array(),
			'fields'      => array(),
			'label'       => '',
			'add_label'   => 'Add Item',
			'class'       => '',
			'layout'      => 'block',
			'ui_kit'      => true,
			'required'    => false,
			'title_field' => '',
			'collapsed'   => false,
			'items_count' => null,
		);

		/**
		 * Stored data to process it while renderinr row
		 *
		 * @var array
		 */
		public $data = array();

		/**
		 * Repeater instances counter
		 *
		 * @var integer
		 */
		public static $instance_id = 0;

		/**
		 * Current onstance TMPL name
		 *
		 * @var string
		 */
		public $tmpl_name = '';

		/**
		 * Holder for templates to print it in bottom of customizer page
		 *
		 * @var string
		 */
		public static $customizer_tmpl_to_print = null;

		/**
		 * Is tmpl scripts already printed in customizer
		 *
		 * @var boolean
		 */
		public static $customizer_tmpl_printed = false;

		/**
		 * Child repeater instances
		 *
		 * @var array
		 */
		private $_childs = array();

		/**
		 * Check if we render template for JS
		 *
		 * @var boolean
		 */
		private $_is_js_row = false;

		/**
		 * Init.
		 *
		 * @since 1.0.0
		 */
		public function init() {

			$this->set_tmpl_data();
			add_action( 'admin_footer', array( $this, 'print_js_template' ), 0 );
			add_action( 'customize_controls_print_footer_scripts', array( $this, 'fix_customizer_tmpl' ), 9999 );

		}

		/**
		 * Retrun scripts dependencies list for current control.
		 *
		 * @return array
		 */
		public function get_script_depends() {
			return array( 'jquery-ui-sortable', 'wp-util' );
		}

		/**
		 * Render html UI_Repeater.
		 *
		 * @since 1.0.1
		 */
		public function render() {

			$html        = '';
			$class       = $this->settings['class'];
			$ui_kit      = ! empty( $this->settings['ui_kit'] ) ? 'cx-ui-kit' : '';
			$value       = ( ! empty( $this->settings['value'] ) && is_array( $this->settings['value'] ) ) ? count( $this->settings['value'] ) : 0;
			$title_field = ! empty( $this->settings['title_field'] ) ? 'data-title-field="' . $this->settings['title_field'] . '"' : '';
			$count       = '';

			if ( null !== $this->settings['items_count'] ) {
				$count = sprintf(
					' <span class="cx-ui-repeater-child-count">%d</span>',
					absint( $this->settings['items_count'] )
				);
			}



			add_filter( 'cx_control/is_repeater', '__return_true' );

			$html .= '<div class="cx-ui-container">';

			if ( '' !== $this->settings['label'] ) {
				$html .= '<label class="cx-label cx-ui-repeater-label" for="' . esc_attr( $this->settings['id'] ) . '">'
				         . wp_kses_post( $this->settings['label'] )
				         . $count
				         . '</label> ';
			}

			$html .= sprintf( '<div class="cx-ui-repeater-container %1$s %2$s">',
					$ui_kit,
					esc_attr( $class )
				);

			if ( $this->is_table_layout() ) {
				$html .= $this->render_table( $value, $title_field );
			} else {
				$html .= sprintf(
					'<div class="cx-ui-repeater-list" data-name="%1$s" data-index="%2$s" data-widget-id="__i__" data-repeater-path="%4$s" %3$s id="%5$s">',
					$this->get_tmpl_name(),
					$value,
					$title_field,
					esc_attr( $this->settings['name'] ),
					esc_attr( $this->settings['id'] )
				);

					if ( is_array( $this->settings['value'] ) ) {
						$index = 0;
						foreach ( $this->settings['value'] as $data ) {
							$this->_is_js_row = false;
							$html .= $this->render_row( $index, false, $data );
							$index++;
						}
					}
					$html .= '</div>';
					$html .= sprintf(
						'<a href="#" class="cx-ui-repeater-add" role="button" aria-label="%2$s">%1$s</a>',
						esc_html( $this->settings['add_label'] ),
						esc_attr( $this->settings['add_label'] )
					);
			}
			$html .= '</div>';
			$html .= '</div>';

			/**
			 * Maybe add js repeater template to response
			 *
			 * @var bool
			 */
			$add_js_to_response = apply_filters( 'cx_control/add_data_to_element', false );

			if ( $add_js_to_response ) {
				$html .= $this->get_js_template();
			}

			$html .= $this->get_additional_data();

			remove_all_filters( 'cx_control/is_repeater' );

			return $html;
		}

		/**
		 * Check if table layout should be used.
		 *
		 * @return bool
		 */
		public function is_table_layout() {
			return ! empty( $this->settings['layout'] ) && 'table' === $this->settings['layout'];
		}

		/**
		 * Render table layout for repeater.
		 *
		 * @param int    $value       Items count.
		 * @param string $title_field Title field attribute.
		 *
		 * @return string
		 */
		public function render_table( $value, $title_field ) {

			$fields = $this->get_table_fields();
			$html = '<div class="cx-ui-repeater-table-wrapper">';
			$html .= '<table class="cx-ui-repeater-table">';

			$html .= $this->render_table_head( $fields );
			$html .= sprintf(
				'<tbody class="cx-ui-repeater-list cx-ui-repeater-table-body" data-name="%1$s" data-index="%2$s" data-widget-id="__i__" data-repeater-path="%4$s" data-table-fields="%6$s" %3$s id="%5$s">',
				$this->get_tmpl_name(),
				$value,
				$title_field,
				esc_attr( $this->settings['name'] ),
				esc_attr( $this->settings['id'] ),
				esc_attr( wp_json_encode( $fields ) )
			);

			if ( is_array( $this->settings['value'] ) ) {
				$index = 0;
				foreach ( $this->settings['value'] as $data ) {
					$this->_is_js_row = false;
					$html .= $this->render_row( $index, false, $data );
					$index++;
				}
			}

			$html .= '</tbody>';
			$html .= $this->render_table_foot( $fields );
			$html .= '</table>';
			$html .= '</div>';
			$html .= sprintf(
				'<a href="#" class="cx-ui-repeater-add" role="button" aria-label="%2$s">%1$s</a>',
				esc_html( $this->settings['add_label'] ),
				esc_attr( $this->settings['add_label'] )
			);

			return $html;

		}

		/**
		 * Check if a child field should create a visible table column.
		 *
		 * @param array $field Field settings.
		 *
		 * @return bool
		 */
		public function is_table_field_visible( $field ) {
			return empty( $field['type'] ) || 'hidden' !== $field['type'];
		}

		/**
		 * Get table field metadata for child fields.
		 *
		 * @return array
		 */
		public function get_table_fields() {

			$fields = array();

			foreach ( $this->settings['fields'] as $field ) {

				if ( ! $this->is_table_field_visible( $field ) ) {
					continue;
				}

				$name = ! empty( $field['table_name'] ) ? $field['table_name'] : $field['name'];

				$fields[] = array(
					'label'       => ! empty( $field['table_label'] ) ? wp_strip_all_tags( $field['table_label'] ) : $name,
					'name'        => $name,
					'description' => ! empty( $field['table_description'] ) ? wp_strip_all_tags( $field['table_description'] ) : '',
				);
			}

			return $fields;

		}

		/**
		 * Render table layout header.
		 *
		 * @param array $fields Table field metadata.
		 *
		 * @return string
		 */
		public function render_table_head( $fields ) {

			$html = '<thead class="cx-ui-repeater-table-head">';
			$html .= '<tr class="cx-ui-repeater-table-head-row">';
			$html .= '<th class="cx-ui-repeater-table-index-heading" scope="col">#</th>';

			foreach ( $fields as $field ) {
				$html .= '<th class="cx-ui-repeater-table-field-heading" scope="col">' . esc_html( $field['label'] ) . '</th>';
			}

			$html .= '<th class="cx-ui-repeater-table-actions-heading" scope="col"></th>';
			$html .= '</tr>';
			$html .= '</thead>';

			return $html;

		}

		/**
		 * Render table layout footer.
		 *
		 * @param array $fields Table field metadata.
		 *
		 * @return string
		 */
		public function render_table_foot( $fields ) {

			$html = '<tfoot class="cx-ui-repeater-table-foot">';
			$html .= '<tr class="cx-ui-repeater-table-foot-row">';
			$html .= '<td class="cx-ui-repeater-table-index-footer"></td>';

			foreach ( $fields as $field ) {
				$html .= '<td class="cx-ui-repeater-table-field-footer">';
				$html .= '<div class="cx-ui-repeater-table-field-name">' . esc_html( 'Name: ' ) . '<span class="je-field-name">' . esc_html( $field['name'] ) . '</span></div>';

				if ( ! empty( $field['description'] ) ) {
					$html .= '<div class="cx-ui-repeater-table-field-description">' . esc_html( $field['description'] ) . '</div>';
				}

				$html .= '</td>';
			}

			$html .= '<td class="cx-ui-repeater-table-actions-footer"></td>';
			$html .= '</tr>';
			$html .= '</tfoot>';

			return $html;

		}

		/**
		 * Get additional data to return
		 * @return [type] [description]
		 */
		public function get_additional_data() {

			$data = apply_filters( 'cx_control/add_repeater_data', array() );

			if ( ! empty( $data ) ) {
				return implode( ' ', $data );
			}

		}

		/**
		 * Render single row for repeater
		 *
		 * @param string $index        Current row index.
		 * @param number $widget_index It contains widget index.
		 * @param array  $data         Values to paste.
		 * @since 1.0.1
		 */
		public function render_row( $index, $widget_index, $data ) {

			if ( $this->is_table_layout() ) {
				return $this->render_table_row( $index, $widget_index, $data );
			}

			$this->data = $data;

			$item_classes = array( 'cx-ui-repeater-item cx-ui-repeater-block-item' );

			if ( $this->settings['collapsed'] && ! $this->_is_js_row ) {
				$item_classes[] = 'cx-ui-repeater-min';
			}

			$html = '<div class="' . implode( ' ', $item_classes ) . '" data-item-index="' . $index .'">';
			$html .= '<div class="cx-ui-repeater-actions-box cx-ui-repeater-block-actions-box">';

			$html .= '<a href="#" class="cx-ui-repeater-toggle" role="button" aria-label="' . esc_attr__( 'Toggle row', 'jet-engine' ) . '" aria-expanded="' . ( in_array( 'cx-ui-repeater-min', $item_classes, true ) ? 'false' : 'true' ) . '"></a>';
			// Repeater titles are display-only labels. Values can come from stored meta.
			$html .= '<span class="cx-ui-repeater-title">' . esc_html( $this->get_row_title() ) . '</span>';
			$html .= '<a href="#" class="cx-ui-repeater-copy" role="button" aria-label="' . esc_attr__( 'Duplicate row', 'jet-engine' ) . '"><svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><rect width="16" height="16" transform="matrix(1 0 0 -1 0 16)" fill="white"></rect><path d="M13.401 14.5362V4.35745H5.47721V14.5362H13.401ZM13.401 2.92766C13.7848 2.92766 14.1234 3.07518 14.4169 3.37021C14.7104 3.64255 14.8571 3.97163 14.8571 4.35745V14.5362C14.8571 14.922 14.7104 15.2624 14.4169 15.5574C14.1234 15.8525 13.7848 16 13.401 16H5.47721C5.09344 16 4.75482 15.8525 4.46134 15.5574C4.16787 15.2624 4.02113 14.922 4.02113 14.5362V4.35745C4.02113 3.97163 4.16787 3.64255 4.46134 3.37021C4.75482 3.07518 5.09344 2.92766 5.47721 2.92766H13.401ZM11.2338 0V1.46383H2.56504V11.6426H1.14282V1.46383C1.14282 1.07801 1.27827 0.737589 1.54917 0.442553C1.84265 0.147518 2.18127 0 2.56504 0H11.2338Z"></path></svg></a>';
			$html .= '<a href="#" class="cx-ui-repeater-remove" role="button" aria-label="' . esc_attr__( 'Delete row', 'jet-engine' ) . '">';
				$html .= '<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><rect width="16" height="16" transform="matrix(1 0 0 -1 0 16)" fill="white"></rect><path d="M2.28564 14.192V3.42847H13.7142V14.192C13.7142 14.6685 13.5208 15.0889 13.1339 15.4533C12.747 15.8177 12.3005 15.9999 11.7946 15.9999H4.20529C3.69934 15.9999 3.25291 15.8177 2.866 15.4533C2.4791 15.0889 2.28564 14.6685 2.28564 14.192Z"></path><path d="M14.8571 1.14286V2.28571H1.14282V1.14286H4.57139L5.56085 0H10.4391L11.4285 1.14286H14.8571Z"></path></svg>';
				$html .= '<div class="cx-tooltip">Are you sure?<br><span class="cx-ui-repeater-remove__confirm">Yes</span> / <span class="cx-ui-repeater-remove__cancel">No</span></div>';
			$html .='</a>';

			$html .= '</div>';
			$html .= '<div class="cheryr-ui-repeater-content-box">';
			foreach ( $this->settings['fields'] as $field ) {

				$field_classes = array(
					'cx-ui-repeater-item-control',
					'cx-repeater-item-control-' . esc_attr( $field['type'] ),
					$field['id'] . '-wrap',
				);

				if ( ! empty( $field['class'] ) ) {
					$field_classes[] = $field['class'];
				}

				$field_classes = implode( ' ', $field_classes );

				$html .= '<div class="' . $field_classes . '" data-repeater-control-name="' . $field['id'] . '">';
				$html .= $this->render_field( $index, $widget_index, $field );
				$html .= '</div>';
			}
			$html .= '</div>';
			$html .= '</div>';

			$this->data = array();

			return $html;
		}

		/**
		 * Render single table row for repeater.
		 *
		 * @param string $index        Current row index.
		 * @param number $widget_index It contains widget index.
		 * @param array  $data         Values to paste.
		 *
		 * @return string
		 */
		public function render_table_row( $index, $widget_index, $data ) {

			$this->data = $data;

			$html = '<tr class="cx-ui-repeater-item cx-ui-repeater-table-row" data-item-index="' . $index . '">';
			$html .= '<td class="cx-ui-repeater-actions-box cx-ui-repeater-table-index-cell">';
			$html .= '<span class="cx-ui-repeater-table-index">' . esc_html( is_numeric( $index ) ? absint( $index ) + 1 : $index ) . '</span>';
			$html .= '</td>';

			foreach ( $this->settings['fields'] as $field ) {

				$field_classes = array(
					'cx-ui-repeater-item-control',
					'cx-repeater-item-control-' . esc_attr( $field['type'] ),
					$field['id'] . '-wrap',
				);

				if ( ! empty( $field['class'] ) ) {
					$field_classes[] = $field['class'];
				}

				$field_classes = implode( ' ', $field_classes );

				$cell_attributes = $this->is_table_field_visible( $field ) ? '' : ' hidden';

				$html .= '<td class="cx-ui-repeater-table-field-cell"' . $cell_attributes . '>';
				$html .= '<div class="' . $field_classes . '" data-repeater-control-name="' . $field['id'] . '">';
				$html .= $this->render_field( $index, $widget_index, $this->prepare_table_cell_field( $field ) );
				$html .= '</div>';
				$html .= '</td>';
			}

			$html .= '<td class="cx-ui-repeater-table-actions-cell">';
			$html .= '<a href="#" class="cx-ui-repeater-copy" role="button" aria-label="' . esc_attr__( 'Duplicate row', 'jet-engine' ) . '"><svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.401 14.5362V4.35745H5.47721V14.5362H13.401ZM13.401 2.92766C13.7848 2.92766 14.1234 3.07518 14.4169 3.37021C14.7104 3.64255 14.8571 3.97163 14.8571 4.35745V14.5362C14.8571 14.922 14.7104 15.2624 14.4169 15.5574C14.1234 15.8525 13.7848 16 13.401 16H5.47721C5.09344 16 4.75482 15.8525 4.46134 15.5574C4.16787 15.2624 4.02113 14.922 4.02113 14.5362V4.35745C4.02113 3.97163 4.16787 3.64255 4.46134 3.37021C4.75482 3.07518 5.09344 2.92766 5.47721 2.92766H13.401ZM11.2338 0V1.46383H2.56504V11.6426H1.14282V1.46383C1.14282 1.07801 1.27827 0.737589 1.54917 0.442553C1.84265 0.147518 2.18127 0 2.56504 0H11.2338Z"></path></svg></a>';
			$html .= '<a href="#" class="cx-ui-repeater-remove" role="button" aria-label="' . esc_attr__( 'Delete row', 'jet-engine' ) . '">';
				$html .= '<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M2.28564 14.192V3.42847H13.7142V14.192C13.7142 14.6685 13.5208 15.0889 13.1339 15.4533C12.747 15.8177 12.3005 15.9999 11.7946 15.9999H4.20529C3.69934 15.9999 3.25291 15.8177 2.866 15.4533C2.4791 15.0889 2.28564 14.6685 2.28564 14.192Z"></path><path d="M14.8571 1.14286V2.28571H1.14282V1.14286H4.57139L5.56085 0H10.4391L11.4285 1.14286H14.8571Z"></path></svg>';
				$html .= '<div class="cx-tooltip cx-tooltip-left">Are you sure?<br><span class="cx-ui-repeater-remove__confirm">Yes</span> / <span class="cx-ui-repeater-remove__cancel">No</span></div>';
			$html .='</a>';
			$html .= '</td>';
			$html .= '</tr>';

			$this->data = array();

			return $html;

		}

		/**
		 * Prepare child field settings for table cell rendering.
		 *
		 * @param array $field Field settings.
		 *
		 * @return array
		 */
		public function prepare_table_cell_field( $field ) {

			$field['label']       = '';
			$field['title']       = '';
			$field['description'] = '';

			return $field;

		}

		/**
		 * Get repeater item title
		 *
		 * @return string
		 * @since 1.0.1
		 */
		public function get_row_title() {

			if ( empty( $this->settings['title_field'] ) ) {
				return '';
			}

			if ( ! empty( $this->data[ $this->settings['title_field'] ] ) ) {
				$title_field    = $this->settings['title_field'];
				$field_settings = $this->settings['fields'][ $title_field ];
				$row_title      = $this->data[ $title_field ];

				if ( empty( $row_title ) ) {
					return '';
				}

				switch( $field_settings['type'] ) {

					case 'posts':

						if ( is_array( $row_title ) ) {
							$row_title = array_map( 'get_the_title', $row_title );
						} else {
							$row_title = get_the_title( $row_title );
						}
						break;

					case 'select':

						if ( ! is_array( $row_title ) ) {
							$row_title = array( $row_title );
						}

						$row_title = array_map( function ( $item ) use ( $field_settings ) {

							if ( isset( $field_settings['options'][ $item ] ) ) {
								return $field_settings['options'][ $item ];
							}

							return $item;

						}, $row_title );

						break;
				}

				if ( is_array( $row_title ) ) {
					$row_title = join( ', ', $row_title );
				}

				return $row_title;
			}

			return '';
		}

		/**
		 * Return default IB view content
		 *
		 * @param  [type] $view [description]
		 * @param  array  $args [description]
		 * @return [type]       [description]
		 */
		public function get_view( $view, $args = array() ) {

			if ( ! $this->base_path ) {
				return null;
			}

			$file = $this->base_path . 'views/' . $view . '.php';

			if ( ! file_exists( $file ) ) {
				return null;
			}

			ob_start();
			include $file;
			return ob_get_clean();

		}

		public function prepare_field_value( $field, $value ) {

			$field_type = isset( $field['type'] ) ? $field['type'] : false;

			switch ( $field_type ) {
				case 'checkbox':

					if ( ! empty( $field['options_callback'] ) ) {
						$options = call_user_func( $field['options_callback'] );
					}

					if ( ! empty( $field['is_array'] ) && ! empty( $options ) && ! empty( $value ) ) {

						$adjusted = array();

						if ( ! is_array( $value ) ) {
							$value = array( $value );
						}

						foreach ( $value as $val ) {
							$adjusted[ $val ] = 'true';
						}

						foreach ( $options as $opt_val => $opt_label ) {
							if ( ! in_array( $opt_val, $value ) ) {
								$adjusted[ $opt_val ] = 'false';
							}
						}

						$value = $adjusted;
					}

					break;
				case 'text':

					if ( ! empty( $value ) && $this->to_timestamp( $field ) && is_numeric( $value ) ) {

						switch ( $field['input_type'] ) {
							case 'date':
								$value = $this->get_date( 'Y-m-d', $value );
								break;

							case 'datetime-local':
								$value = $this->get_date( 'Y-m-d\TH:i', $value );
								break;
						}
					}

					break;

			}

			return $value;
		}

		public function get_date( $format, $time ) {
			return apply_filters( 'jet-engine/repeater/date', date( $format, $time ), $time, $format );
		}

		public function to_timestamp( $field ) {

			if ( empty( $field['input_type'] ) ) {
				return false;
			}

			if ( empty( $field['is_timestamp'] ) ) {
				return false;
			}


			if ( ! in_array( $field['input_type'], array( 'date', 'datetime-local' ) ) ) {
				return false;
			}

			return ( true === $field['is_timestamp'] );

		}

		/**
		 * Render single repeater field
		 *
		 * @param  string $index        Current row index.
		 * @param  number $widget_index It contains widget index.
		 * @param  array  $field        Values to paste.
		 * @return string
		 */
		public function render_field( $index, $widget_index, $field ) {

			if ( empty( $field['type'] ) || empty( $field['name'] ) ) {
				return '"type" and "name" are required fields for UI_Repeater items';
			}

			$field = wp_parse_args( $field, array(
				'value' => '',
			) );

			$parent_name    = str_replace( '__i__', $widget_index, $this->settings['name'] );
			$parent_name    = str_replace( '{{{data.index}}}', '{{{data.parentIndex}}}', $parent_name );
			$field['id']    = sprintf( '%s-%s', $field['id'], $index );
			$field['value'] = isset( $this->data[ $field['name'] ] ) ? $this->data[ $field['name'] ] : $field['value'];
			$field['name']  = sprintf( '%1$s[item-%2$s][%3$s]', $parent_name, $index, $field['name'] );

			switch ( $field['type'] ) {

				case 'html':
					return sprintf( '<div class="cx-ui-container">%s</div>', $field['html'] );

				default:

					$ui_class_name  = 'CX_Control_' . ucwords( $field['type'] );

					if ( ! class_exists( $ui_class_name ) ) {
						return '<p>Class <b>' . $ui_class_name . '</b> not exist!</p>';
					}

					$field['value'] = $this->prepare_field_value( $field, $field['value'] );

					if ( 'repeater' === $field['type'] ) {
						$field['items_count'] = is_array( $field['value'] )
							? count( $field['value'] )
							: 0;
					}

					$ui_item = new $ui_class_name( $field );

					if ( 'repeater' === $ui_item->settings['type'] && true === $this->_is_js_row ) {
						$this->_childs[] = $ui_item;
					}

					return $ui_item->render();

			}

		}

		/**
		 * Get TMPL name for current repeater instance.
		 *
		 * @return string
		 */
		public function get_tmpl_name() {
			return $this->tmpl_name;
		}

		/**
		 * Set current repeater instance ID
		 *
		 * @return void
		 */
		public function set_tmpl_data() {
			self::$instance_id++;
			$this->tmpl_name = sprintf( 'repeater-template-%s', self::$instance_id );

			global $wp_customize;
			if ( isset( $wp_customize ) ) {
				self::$customizer_tmpl_to_print .= $this->get_js_template();
			}

		}

		/**
		 * Print JS template for current repeater instance
		 *
		 * @return void
		 */
		public function print_js_template() {

			echo $this->get_js_template();

			if ( ! empty( $this->_childs ) ) {
				foreach ( $this->_childs as $child ) {
					echo $child->get_js_template();
				}
			}

		}

		/**
		 * Get JS template to print
		 *
		 * @return string
		 */
		public function get_js_template() {

			$this->_is_js_row = true;

			return sprintf(
				'<script type="text/html" id="tmpl-%1$s">%2$s</script>',
				$this->get_tmpl_name(),
				$this->render_row( '{{{data.index}}}', '{{{data.widgetId}}}', array() )
			);

		}

		/**
		 * Outputs JS templates on customizer page
		 *
		 * @return void
		 */
		public function fix_customizer_tmpl() {
			if ( true === self::$customizer_tmpl_printed ) {
				return;
			}
			self::$customizer_tmpl_printed = true;
			echo self::$customizer_tmpl_to_print;
		}
	}
}
