<?php
/**
 * @author    ThemePunch <info@themepunch.com>
 * @link      https://www.themepunch.com/
 * @copyright 2026 ThemePunch
 */

if(!defined('ABSPATH')) exit();
?>
<!-- Menu: the list this layer repeats over, kept in the module (settings.menus) so a phone menu can read the same one.
     The rows are built by SR7.editor.elements.menu.read -->
<sr-separator keepborder>
	<sr-separator-head>
		<sr-separator-title><?php _e('Menu','revslider'); ?></sr-separator-title><sr-tooltip key="menulist"></sr-tooltip>
		<sr-separator-toggle><svg class="sr--icon" width="20" height="12"><use xlink:href="#General_Expand_Large"></use></svg></sr-separator-toggle>
	</sr-separator-head>
	<sr-separator-body>
		<sr-drop id="sr_menu_src" class="sr--mb--10" wide data-v="own" data-defval="own" data-onchange="editor.elements.menu.source">
			<sr-drop-view>
				<span class="sr--drop--value"></span>
				<span class="sr--form--otitle"><?php _e('Items','revslider'); ?></span>
				<span class="sr--drop--icon"><svg width="10" height="6" transform="translate(0, -1)"><use xlink:href="#Drop_Down"></use></svg></span>
			</sr-drop-view>
			<sr-drops data-v="own"><?php _e('Own List','revslider'); ?></sr-drops>
			<sr-drops data-v="wp"><?php _e('WordPress Menu','revslider'); ?></sr-drops>
		</sr-drop>
		<sr-drop id="sr_menu_wp" class="sr--mb--10" wide data-onchange="editor.elements.menu.source">
			<sr-drop-view>
				<span class="sr--drop--value"></span>
				<span class="sr--form--otitle"><?php _e('Menu','revslider'); ?></span>
				<span class="sr--drop--icon"><svg width="10" height="6" transform="translate(0, -1)"><use xlink:href="#Drop_Down"></use></svg></span>
			</sr-drop-view>
		</sr-drop>
		<sr-wrap id="sr_elements_menu_list"></sr-wrap>
		<sr-button id="sr_menu_add" full clean class="sr--cta sr--mb--15" data-action="editor.elements.menu.add"><svg class="sr--icon" width="10" height="10"><use xlink:href="#General_Add"></use></svg> <?php _e('Add Menu Item','revslider'); ?></sr-button>
		<sr-input wide><input name="Delay per Item" r="menu.st" type="text" number="true" dragnumber min="0" max="400" step="10" validate autocomplete="off"><span noicon class="sr--form--otitle"><?php _e('Delay per Item (ms)','revslider'); ?></span></sr-input>
		<sr-sp h="5"></sr-sp>
	</sr-separator-body>
</sr-separator>
